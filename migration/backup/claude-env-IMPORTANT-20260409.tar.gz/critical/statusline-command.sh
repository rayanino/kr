#!/usr/bin/env bash
# Claude Code status line — grid layout with background pills and aligned separators
# Requires: jq, bash 3.2+, 256-color terminal, UTF-8

input=$(cat)

# ---------------------------------------------------------------------------
# Colors
# ---------------------------------------------------------------------------
R="\033[0m"
BOLD="\033[1m"
C_GREEN="\033[38;5;78m"
C_YELLOW="\033[38;5;220m"
C_ORANGE="\033[38;5;208m"
C_RED="\033[38;5;196m"
C_BLUE="\033[38;5;75m"
C_CYAN="\033[38;5;87m"
C_PURPLE="\033[38;5;141m"
C_GRAY="\033[38;5;245m"
C_WHITE="\033[38;5;255m"
C_PINK="\033[38;5;213m"

# Pill background
BG="\033[48;5;236m"
# Separator: dimmed │ with no background
SEP_CH="\033[38;5;240m│\033[0m"

# ---------------------------------------------------------------------------
# Parse JSON
# ---------------------------------------------------------------------------
model=$(echo "$input"     | jq -r '.model.display_name // "Unknown"')
used=$(echo "$input"      | jq -r '.context_window.used_percentage // empty')
remaining=$(echo "$input" | jq -r '.context_window.remaining_percentage // empty')
cwd=$(echo "$input"       | jq -r '.workspace.current_dir // .cwd // ""')
session=$(echo "$input"   | jq -r '.session_name // empty')
vim_mode=$(echo "$input"  | jq -r '.vim.mode // empty')
version=$(echo "$input"   | jq -r '.version // empty')
output_style=$(echo "$input" | jq -r '.output_style.name // empty')
think_budget=$(echo "$input" | jq -r '.thinking.budget_tokens // empty')
five_pct=$(echo "$input"  | jq -r '.rate_limits.five_hour.used_percentage // empty')
five_rst=$(echo "$input"  | jq -r '.rate_limits.five_hour.resets_at       // empty')
week_pct=$(echo "$input"  | jq -r '.rate_limits.seven_day.used_percentage // empty')
week_rst=$(echo "$input"  | jq -r '.rate_limits.seven_day.resets_at       // empty')
ctx_total=$(echo "$input" | jq -r '.context_window.context_window_size    // empty')

git_branch=""
if git -C "${cwd:-$PWD}" --no-optional-locks rev-parse --abbrev-ref HEAD 2>/dev/null | read -r _b; then
  git_branch="$_b"
fi
[ -z "$git_branch" ] && git_branch=$(git --no-optional-locks rev-parse --abbrev-ref HEAD 2>/dev/null || true)

COLS=$(tput cols 2>/dev/null || echo 80)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
render_bar() {
  local pct="$1" width="$2" fc="$3" ec="$4"
  [ -z "$pct" ] && pct=0
  local filled=$(( pct * width / 100 ))
  [ "$filled" -gt "$width" ] && filled=$width
  local empty=$(( width - filled ))
  local bar=""
  local i=0
  if [ "$filled" -gt 0 ]; then
    bar="${fc}"
    while [ "$i" -lt "$filled" ]; do bar="${bar}█"; i=$(( i + 1 )); done
    bar="${bar}${R}${BG}"
  fi
  if [ "$empty" -gt 0 ]; then
    bar="${bar}${ec}"
    i=0
    while [ "$i" -lt "$empty" ]; do bar="${bar}░"; i=$(( i + 1 )); done
    bar="${bar}${R}${BG}"
  fi
  printf '%s' "$bar"
}

pct_color() {
  local v="$1"
  [ -z "$v" ] && { printf '%s' "$C_GRAY"; return; }
  if   [ "$v" -ge 60 ]; then printf '%s' "$C_GREEN"
  elif [ "$v" -ge 30 ]; then printf '%s' "$C_YELLOW"
  elif [ "$v" -ge 10 ]; then printf '%s' "$C_ORANGE"
  else                        printf '%s' "$C_RED"
  fi
}

reset_label() {
  local epoch="$1"
  [ -z "$epoch" ] && return
  local now diff h m
  now=$(date +%s); diff=$(( epoch - now ))
  [ "$diff" -le 0 ] && { printf 'resetting'; return; }
  h=$(( diff / 3600 )); m=$(( (diff % 3600) / 60 ))
  if [ "$h" -gt 0 ]; then printf 'in %dh%02dm' "$h" "$m"
  else printf 'in %dm' "$m"; fi
}

pad_spaces() {
  local n="$1"
  if [ "$n" -gt 0 ]; then printf '%*s' "$n" ''; fi
}

# ---------------------------------------------------------------------------
# Integer conversions
# ---------------------------------------------------------------------------
used_int=0;        [ -n "$used"      ] && used_int=${used%.*}
remaining_int=100; [ -n "$remaining" ] && remaining_int=${remaining%.*}
five_int=0;        [ -n "$five_pct"  ] && five_int=${five_pct%.*}
week_int=0;        [ -n "$week_pct"  ] && week_int=${week_pct%.*}

BAR_CTX=12
BAR_RL=8

# ---------------------------------------------------------------------------
# Build segments: arrays of (display_string, visible_width) pairs
# display_string does NOT include BG — that's added during rendering
# ---------------------------------------------------------------------------
all_display=()
all_widths=()

add_seg() {
  all_display+=("$1")
  all_widths+=("$2")
}

# Vim mode
if [ -n "$vim_mode" ]; then
  if   [ "$vim_mode" = "NORMAL" ]; then add_seg "${C_ORANGE}${BOLD} N ${R}" 3
  elif [ "$vim_mode" = "INSERT" ]; then add_seg "${C_GREEN}${BOLD} I ${R}" 3
  else add_seg "${C_BLUE}${BOLD} ${vim_mode} ${R}" $(( ${#vim_mode} + 2 ))
  fi
fi

# Model + version
s="${C_CYAN}${model}${R}"; w=${#model}
if [ -n "$version" ]; then
  s="${s} ${C_GRAY}v${version}${R}"; w=$(( w + 2 + ${#version} ))
fi
add_seg "$s" "$w"

# Thinking effort
if [ -n "$think_budget" ]; then
  if   [ "$think_budget" -ge 16000 ]; then tl="${C_PURPLE}${BOLD}MAX${R}"; tw=3
  elif [ "$think_budget" -ge 10000 ]; then tl="${C_PURPLE}HIGH${R}"; tw=4
  elif [ "$think_budget" -ge 5000  ]; then tl="${C_BLUE}MED${R}"; tw=3
  elif [ "$think_budget" -ge 1000  ]; then tl="${C_GRAY}LOW${R}"; tw=3
  else tl="${C_GRAY}MIN${R}"; tw=3; fi
  add_seg "think:${tl}" $(( 6 + tw ))
fi

# Output style
if [ -n "$output_style" ] && [ "$output_style" != "default" ]; then
  add_seg "${C_GRAY}style:${output_style}${R}" $(( 6 + ${#output_style} ))
fi

# Context bar
if [ -n "$used" ]; then
  ctx_c=$(pct_color "$remaining_int")
  ctx_bar=$(render_bar "$used_int" "$BAR_CTX" "$ctx_c" "$C_GRAY")
  s="ctx ${ctx_bar} ${ctx_c}${used_int}%${R}"
  w=$(( 4 + BAR_CTX + 1 + ${#used_int} + 1 ))
  if [ -n "$ctx_total" ]; then
    ctx_used_k=$(( used_int * ctx_total / 100 / 1000 ))
    ctx_total_k=$(( ctx_total / 1000 ))
    tk="${ctx_used_k}k/${ctx_total_k}k"
    s="${s} ${C_GRAY}${tk}${R}"; w=$(( w + 1 + ${#tk} ))
  fi
  add_seg "$s" "$w"
fi

# 5h rate limit
if [ -n "$five_pct" ]; then
  fl_c=$(pct_color "$(( 100 - five_int ))")
  fl_bar=$(render_bar "$five_int" "$BAR_RL" "$fl_c" "$C_GRAY")
  fl_rst=$(reset_label "$five_rst")
  s="5h ${fl_bar} ${fl_c}${five_int}%${R}"
  w=$(( 3 + BAR_RL + 1 + ${#five_int} + 1 ))
  if [ -n "$fl_rst" ]; then
    s="${s} ${C_GRAY}${fl_rst}${R}"; w=$(( w + 1 + ${#fl_rst} ))
  fi
  add_seg "$s" "$w"
fi

# 7d rate limit
if [ -n "$week_pct" ]; then
  wl_c=$(pct_color "$(( 100 - week_int ))")
  wl_bar=$(render_bar "$week_int" "$BAR_RL" "$wl_c" "$C_GRAY")
  wl_rst=$(reset_label "$week_rst")
  s="7d ${wl_bar} ${wl_c}${week_int}%${R}"
  w=$(( 3 + BAR_RL + 1 + ${#week_int} + 1 ))
  if [ -n "$wl_rst" ]; then
    s="${s} ${C_GRAY}${wl_rst}${R}"; w=$(( w + 1 + ${#wl_rst} ))
  fi
  add_seg "$s" "$w"
fi

# Session
[ -n "$session" ] && add_seg "${C_PINK}\"${session}\"${R}" $(( ${#session} + 2 ))

# Git branch
if [ -n "$git_branch" ] && [ "$git_branch" != "HEAD" ]; then
  add_seg "${C_YELLOW} ${git_branch}${R}" $(( ${#git_branch} + 1 ))
fi

# CWD
if [ -n "$cwd" ]; then
  short_cwd=$(echo "$cwd" | sed "s|^$HOME|~|" | sed 's|\\|/|g')
  add_seg "${C_WHITE}${short_cwd}${R}" "${#short_cwd}"
fi

# Time
time_now=$(date +%H:%M:%S)
add_seg "${C_GRAY}${time_now}${R}" "${#time_now}"

# ---------------------------------------------------------------------------
# Grid layout: determine rows, compute column widths, render with padding
#
# 1. Greedy-pack items into rows (like flexwrap)
#    Each pill has 2 chars padding (1 left + 1 right), plus 1 char separator
# 2. Find max width per column position across all rows
# 3. Render: each pill is padded to its column width with background color
# ---------------------------------------------------------------------------
n=${#all_display[@]}
PILL_PAD=2        # 1 space on each side inside the pill
SEP_W=1           # │ separator = 1 char

# Step 1: assign items to rows
row_of=()         # row_of[i] = which row item i is on
col_of=()         # col_of[i] = which column position item i is in
cur_row=0
cur_col=0
cur_w=0

for (( i=0; i<n; i++ )); do
  item_w=$(( all_widths[i] + PILL_PAD ))  # pill content + padding
  needed=$item_w
  if [ "$cur_col" -gt 0 ]; then
    needed=$(( needed + SEP_W ))  # separator before this pill
  fi

  if [ "$cur_col" -gt 0 ] && [ $(( cur_w + needed )) -gt "$COLS" ]; then
    # Wrap to next row
    cur_row=$(( cur_row + 1 ))
    cur_col=0
    cur_w=0
    needed=$item_w
  fi

  row_of+=("$cur_row")
  col_of+=("$cur_col")
  cur_w=$(( cur_w + needed ))
  cur_col=$(( cur_col + 1 ))
done

num_rows=$(( cur_row + 1 ))

# Step 2: find max content width per column position
max_col=$(( cur_col ))
for (( i=0; i<n; i++ )); do
  c=${col_of[$i]}
  [ "$c" -ge "$max_col" ] && max_col=$(( c + 1 ))
done

col_widths=()
for (( c=0; c<max_col; c++ )); do
  col_widths+=("0")
done

for (( i=0; i<n; i++ )); do
  c=${col_of[$i]}
  w=${all_widths[$i]}
  if [ "$w" -gt "${col_widths[$c]}" ]; then
    col_widths[$c]=$w
  fi
done

# Step 3: render row by row
for (( r=0; r<num_rows; r++ )); do
  line=""
  for (( i=0; i<n; i++ )); do
    [ "${row_of[$i]}" -ne "$r" ] && continue
    c=${col_of[$i]}
    target=${col_widths[$c]}
    content_w=${all_widths[$i]}
    pad=$(( target - content_w ))

    # Separator before pill (except first on row)
    if [ "$c" -gt 0 ]; then
      line="${line}${SEP_CH}"
    fi

    # Pill: BG + space + content + padding + space + reset
    line="${line}${BG} ${all_display[$i]}$(pad_spaces "$pad") ${R}"
  done
  printf '%b\n' "$line"
done
