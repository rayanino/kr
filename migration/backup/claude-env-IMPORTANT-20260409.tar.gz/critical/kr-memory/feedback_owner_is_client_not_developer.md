---
name: CRITICAL — Owner is the CLIENT, not the developer. Everything is agent-consumed.
description: Owner does NOT code, does NOT build, does NOT read code. LLMs and agents do ALL technical work. Owner provides input, purchases, sessions, relay. Every data structure must be MACHINE-FIRST, not human-browsable.
type: feedback
---

Owner ALL-CAPS correction (2026-04-07): "You need to understand that everything done in the repo is never for me. I'm not the one building this project. I'm not the one actively coding and building in the summer. I'm the owner / client this project is built for. It is completely driven by LLMs and agents. I'm just here for my input, purchases, sessions, relay... not the technical coding, data analysis... WHICH MEANS EVERY SINGLE QUESTION SHOULD BE ANSWERED FROM THE POV: WHAT IS THE MOST MACHINE FRIENDLY ANSWER?"

**Why:** CC keeps framing questions as if the owner is a developer who reads code, browses research archives, and builds features. He is NOT. The owner:
- Opens CC/Codex sessions and gives them direction
- Relays DR prompts
- Provides study-experience reactions
- Makes purchases (subscriptions, tools)
- That's it.

**Summer 24/7 means:** He runs CC and Codex sessions all day, not that he personally codes.

**How to apply:**
1. Dashboard: shows ONLY what the owner needs to see (status, DR relay queue, findings needing his input, system insights about his library)
2. All data structures: optimized for AGENT consumption, not human readability
3. Research archive: agents browse it, owner never touches it
4. Questions to owner: only about his EXPERIENCE as a user of the library, never about technical choices or data formats
5. "What is the most machine-friendly answer?" is the correct frame for every design decision
