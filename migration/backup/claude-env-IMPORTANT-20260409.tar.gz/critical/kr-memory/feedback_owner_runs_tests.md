---
name: Owner runs tests in terminal to save CC context
description: Owner prefers to run pytest/pyright themselves in a separate terminal, not CC. Saves context window and API usage.
type: feedback
---

The owner runs verification commands (pytest, pyright, integration tests) in their own terminal rather than having CC run them.

**Why:** CC running tests consumes context window with verbose output and burns API tokens on tool calls. The owner can run `python -m pytest engines/excerpting/tests/ -x -q` in a terminal and report pass/fail. CC should tell the owner WHAT to run, not run it.

**How to apply:** After code changes, tell the owner: "Run `<command>` in your terminal and let me know the result." Don't run pytest/pyright/integration tests via Bash unless the owner asks or unless CC needs to parse the output for debugging.
