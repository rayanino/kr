---
name: Headings Have Two Functions (Context + Hints)
description: Headings are never excerpts. Visible function: free context for teaching units. Invisible function: hints for tree construction and passage boundaries.
type: feedback
---

Headings (كتاب, باب, فصل) serve two functions:

1. **Visible — Context:** Enrich teaching units with positional metadata ("this was first under باب الوضوء" = importance signal). Free intelligence, costs nothing to preserve.

2. **Invisible — Hints:** Closest thing to tree structures. Scholar TOCs ≈ "how do you map this science?" Trees are like "very granular TOCs." But TOCs are rarely granular enough and represent one scholar's choices, not the science's structure.

**Why:** Owner (2026-04-08 Q-G6-01) explained headings should never be excerpts themselves but carry valuable context + tree-building hints.

**How to apply:** Passaging (headings hint at passage boundaries), taxonomy (headings hint at tree structure), excerpting (heading context enriches teaching units). Documented in `reference/FOUNDATIONAL_PRINCIPLES.md` as FP-3 + FP-4.
