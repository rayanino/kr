---
name: HARD RULE — prompt-architect before ALL prompts to ANY agent or coworker
description: EVERY prompt dispatched to ANY target (Codex, Gemini, DR relay, CC subagents) MUST pass through /prompt-architect first. No exceptions. Owner ALL-CAPS directive 2026-04-06. Quality surge confirmed empirically.
type: feedback
---

**HARD RULE: /prompt-architect before EVERY prompt dispatch. NO EXCEPTIONS.**

Every prompt that leaves CC — whether to Codex CLI, Gemini CLI, DR relay (ChatGPT/Claude/Gemini DR), CC subagents, or any other target — MUST be passed through `/prompt-architect` first. The optimized version is what gets dispatched. The draft version is NEVER sent directly.

**Why:** Owner directive (2026-04-06, ALL-CAPS emphasis = Tier 1 semantic content): "ALWAYS ALWAYS ALWAYS. The quality surge is immense. No calling of any agent except the prompt has gone through this, even if that would slow us down a little." Speed is explicitly NOT a constraint. Quality is the only constraint.

**How to apply:**
1. Draft the prompt (what you want the target to do)
2. Invoke `/prompt-architect` with the draft
3. Use the optimized output as the actual dispatch
4. This applies to ALL targets: `codex exec`, `gemini -p`, DR relay prompts given to owner, CC Agent() subagent prompts, any tool that takes a natural language instruction
5. The ONLY exception: trivial tool calls where the "prompt" is a file path or command flag (e.g., `python scripts/check_protocol_version.py`). If the input is natural language instructions to an agent, it goes through prompt-architect.

**Enforcement:** This is now HR-23 in the protocol (added to §3B.2 hard rules) and referenced in the Anti-Patterns section (§9). Violation = session failure, same severity as skipping coworker dispatch.

**Evidence:** Session 3 comparison:
- Raw Gemini prompt → "CONSISTENT / MINOR-ISSUES" (missed 6 real issues)
- Prompt-architect (RCoT) Gemini prompt → found 6 HIGH findings, all real, all fixed
- Same target, same file, same question. Only difference: prompt quality.
