---
name: Owner DR relay capacity — 10-20 per day, same-day turnaround
description: Owner can relay 10-20 DR prompts per day with same-day turnaround. Over 83 days this is 830-1660 research sessions. Bottleneck is system prompt generation quality, not owner availability.
type: project
---

Owner stated (2026-04-07): can relay 10-20 DR prompts per DAY. Same-day turnaround. Does not feel like a chore.

**Why this matters:** At this volume, the DR relay queue becomes the single highest-throughput research mechanism in the project. 10/day = 830 DRs before July. 20/day = 1,660 DRs. Even at 50% useful rate, that's 400-800 actionable research reports.

**How to apply:** The autonomous system's prompt generation must be the HIGHEST quality component. Every prompt goes through /prompt-architect. Prompts must be:
- Targeted to the RIGHT DR source (ChatGPT for architecture, Claude for scholarly reasoning, Gemini for Islamic methodology)
- Self-contained (owner pastes as-is, no editing needed)
- Specific enough to produce actionable findings (not vague "research X")
- Deduplicated (don't re-ask what a previous DR already answered)

The dashboard should show a clear relay queue with priority ordering. Owner processes top-to-bottom.
