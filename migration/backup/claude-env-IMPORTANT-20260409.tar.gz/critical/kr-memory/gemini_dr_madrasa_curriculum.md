---
name: Gemini DR Madrasa Curriculum Framework
description: 176-line scholarly report with 21 citations. Fiqh masking layer, mantiq as science #19, Basran terminology default, monthly collection calendar.
type: project
---

Gemini DR (2026-04-07, final coworker #5): Full classical Islamic curriculum framework for the digital library, grounded in academic pedagogy research.

**Most disruptive findings:**
1. **الفقه على المذاهب الأربعة is pedagogically dangerous** for a beginner. Requires a "masking layer" to suppress other schools until single-madhab mastery. This is the owner's priority book — he needs to decide.
2. **Mantiq (logic) = science #19** — non-negotiable prerequisite for usul al-fiqh and advanced aqidah. Not in current 18-science inventory.
3. **Basran terminology default** for nahw + Kufan synonym-mapping layer. No grammar school preference currently exists.
4. **Monthly calendar:** April=imla+sarf, May=nahw+balagha, June=fiqh+mantiq, July=usul+aqidah
5. **Fiqh before Usul** as structural dependency, not preference.

**Why:** This is the PEDAGOGICAL dimension that completes the 4-layer architecture. It adds 3 new architectural requirements none of the other 4 coworkers identified.

**How to apply:** Present the masking recommendation and mantiq finding to the owner as study-focused questions. These are NOT technical decisions — they're curriculum decisions only the owner (as student) can make. Then incorporate his answers into the collection roadmap.

**Files:** `engines/excerpting/reference/dr_reviews/GEMINI_DR_*` (2 files)
