---
name: DR40 Granularity Calibration (ChatGPT DR, 2026-04-08)
description: Pivotal DR that reversed FP-13 precedence, adopted DR-2 (evidence splitting), and introduced relationship links. Driven by 2 owner rejections of talaq excerpts.
type: project
---

DR40 was a ChatGPT Deep Research report that calibrated excerpting granularity based on 2 concrete owner rejections from 2026-03-31 (taysir, كتاب الطلاق).

## 5 Decisions Implemented (Session 20)

1. **Conditional evidence splitting (FP-24):** Evidence stays with ruling ONLY when syntactically inseparable, ≤15 words, or splitting breaks dialogue. Otherwise split by evidence type. Per-ayah for Quranic proofs.
2. **Definition pair splitting (FP-25):** لغة/شرعا definitions MUST be separate units. Bridging sentence stays with شرعا unit.
3. **Relationship links (FP-23):** companion_definition, evidence_for, condition_for links between split units. Emitted at Phase 2b time.
4. **FP-13 re-ranked:** Leaf-atomicity #4 (was #5). Pedagogical packaging demoted to #5 (UI concern).
5. **Regression fixtures:** 18 tests from 2 owner rejections.

## Key Insight
The old rule "ruling + evidence = one unit" was the pipeline producing book-page-sized excerpts. The owner said: "I might as well just take pictures of books." Over-granularity is recoverable (merge). Under-granularity blocks leaf-level comparison permanently.

## /codex-verify Findings (4 reviewers)
Caught 2 CRITICAL bugs: stale target_unit_index after merge reindexing, no bounds validation. Both fixed with _reindex_related_units() helper and I-TU-10 validation.

**Why this matters:** DR40 superseded the DR-2 deferral from 2026-04-01. The 6-reviewer consensus originally said "too risky." DR40 showed it's safe with conditional rules + relationship links. The owner's concrete rejections provided the calibration evidence that the original reviewers lacked.

**How to apply:** The rules are now in SPEC, prompts, contracts, and tests. Next: validate with a live LLM smoke test on the exact text that was rejected.
