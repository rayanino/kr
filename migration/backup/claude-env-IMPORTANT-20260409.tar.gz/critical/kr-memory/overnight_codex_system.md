---
name: Overnight Codex System
description: Codex-CLI-based overnight runner (3,470 lines) with worktree isolation, quality gate, WSL bootstrap. First run 2026-03-30.
type: project
---

New overnight system using Codex CLI as backend, separate from the original Claude-based `overnight_orchestrator.py`.

## Architecture (3,470 lines total)

- `scripts/overnight_codex_orchestrator.py` (2,221 lines) — core execution, worktree management, heartbeat, morning report
- `scripts/overnight_codex_common.py` (526 lines) — shared models, paths, utilities
- `scripts/overnight_codex_task_generator.py` (723 lines) — task discovery scanners
- `scripts/quality_gate.py` (335 lines) — shared pre/post-change verification (used by both Claude hooks and Codex)
- `scripts/append_codex_findings.py` — auto-update FINDINGS_TRACKER.md
- `scripts/overnight_codex_wsl_bootstrap.sh` — WSL2 launcher
- `scripts/overnight_codex_wsl_resume.ps1` — Windows resume script

## Key Design Decisions

- **Worktree isolation:** Each task gets its own git worktree (prevents cross-task interference)
- **Queue-only mode:** When repo is dirty, patches are queued to `overnight_codex/queue/` instead of applied
- **Allowlist enforcement:** Tasks that touch files outside their allowed prefixes are rejected
- **Shadow setup:** Codex operates in shadow mode while Claude is active authority

## First Run Results (2026-03-30)

- **3 completed:** layer-merge probe, recent review, contract validation
- **4 failed:** harden task (touched contracts.py outside allowlist + test failure), creative task (worktree creation failed on Windows), 2 others
- **1 queued:** text-integrity probe patched to queue/
- **Apply mode:** `queue_only` (repo was dirty at launch)

Key failure: `harden-recent-excerpting` modified `engines/excerpting/contracts.py` (blocked by allowlist) and caused `test_mismatched_count_accepted` to fail — the Codex task broke a Pydantic validator invariant.

## Runtime Directory

`overnight_codex/` — state.json, progress.md, MORNING_REPORT.md, queue/, results/, run_snapshots/

## WSL Bootstrap Worktree Support (2026-04-01)

- `overnight_codex_wsl_bootstrap.sh` now detects if the Windows source repo is a git worktree (`.git` file vs directory)
- Resolves Windows-format gitdir paths to WSL paths via `windows_path_to_wsl()`
- When source is a worktree, creates a proper standalone clone for the WSL target dir
- Resume script (`overnight_codex_wsl_resume.ps1`) gains `-RunCycle -Hours N -SingleTask <task>` parameters
- CR stripping added: `tr -d '\r'` before piping bootstrap script into bash
- Commands sanitized in `Invoke-WslBash` to strip carriage returns

## Shadow 24x7 Shape (from `docs/codex/shadow-24x7-runbook.md`)

- Recommended: `powershell ... -RunCycle -Hours 1.5` every 2 hours
- Overnight loop: `run_overnight_codex_shadow_loop.ps1 -TotalHours 8 -CycleHours 1.5 -IntervalMinutes 120`
- Pre-cutover: `shadow_setup` + `queue_only` only

**Why:** Original overnight system (overnight_orchestrator.py) uses Claude CLI, but the project is transitioning operational authority to Codex. This system proves Codex can do bounded hardening work safely.

**How to apply:** Review `overnight_codex/MORNING_REPORT.md` after any overnight run. Queue patches need manual review before applying. The shadow 24x7 runbook defines the scheduler shape for pre-cutover operation.
