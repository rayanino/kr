---
name: KR Non-Negotiable Principles
description: "34 rules that govern every session. Pipeline-first, result preservation, Arabic safety, multi-model consensus."
type: reference
---

# KR Project — Non-Negotiable Principles (34 Rules)

Apply every principle in every session. When in doubt, re-read before deciding.

---

## 1. PIPELINE FIRST — THE PRIME DIRECTIVE

The goal is building a correct, robust, fully-tested 7-engine pipeline. NEVER optimizing for: throughput, UI, "finishing" an engine before it's proven correct, or Scholar Interface features. Library population is a CONSEQUENCE of a working pipeline — not an objective. A correct pipeline with zero books processed is infinitely more valuable than a populated library built on fragile code.

When unsure whether to fix a subtle edge case or move on: FIX THE EDGE CASE.

## 2. RESULT PRESERVATION — EVERY API CALL IS SACRED

Every LLM API call costs real money. NEVER make an API call whose output is not persisted in full structured form. Save EVERYTHING: raw per-model responses, full extraction dicts (including _ debug fields), complete SourceMetadata, per-field confidence from each model, consensus details, human gate checkpoints, per-file SHA-256 hashes.

Each phase produces: per-book structured JSON, phase summary, PHASE_X_LESSONS.md, PHASE_X_MANIFEST.json (books processed, pipeline version/git commit, needs_rerun flag). Later phases SKIP books already successfully processed (checked via manifest). When a bug is found: mark ONLY affected books as needs_rerun=true — NEVER blanket re-run.

See /RESULT_PRESERVATION.md for full protocol.

## 3. THE LIBRARY IS THE OWNER'S KNOWLEDGE

The library IS what the owner knows. An error becomes an error in his mind. A misattributed quote, wrong school classification, corrupted diacritic — these propagate through 6 downstream engines. Cost of false positive (flagging something fine) = 30 seconds review. Cost of false negative (letting through something wrong) = owner learns something false about his deen.

## 4. ERRORS FAIL LOUDLY — NEVER SILENTLY

No engine may silently drop data, silently default, or silently skip validation. Every error uses a defined error code from SPEC §7 taxonomy. Every error produces structured record: error_code, severity, message, context dict, source_id, recovery_action. Bare `except: pass` or `except Exception: continue` are FORBIDDEN.

When ambiguous: raise structured error or create human gate checkpoint. NEVER pick a "reasonable default" and continue silently.

## 5. ARABIC TEXT IS FRAGILE — TREAT IT AS SACRED

A single diacritic change reverses meaning: حَرَّمَ (prohibited) vs حَرَمَ (deprived). Rules:
- NFC Unicode normalization ONLY
- Preserve ALL diacritics exactly
- Primary text bytes NEVER modified after extraction
- encoding="utf-8" for ALL file operations
- Test with adversarial inputs: mixed diacritics, rare Unicode, zero-width joiners, Arabic comma (،)
- Arabic comma and punctuation must be stripped during name matching (LLM nasab names include commas)

## 6. MULTI-MODEL CONSENSUS IS MANDATORY

Never single LLM call for content decisions (author, school, genre, dates, attribution). Currently: Opus 4.6 + Command A, GPT-5.4 via OpenRouter as fallback. Same provider must NEVER both generate AND verify (Layer 3.5). When models disagree: escalate to 3+ models or human gate. NEVER silently pick one.

## 7. HUMAN GATES ARE NOT OPTIONAL

Every low-confidence decision creates a checkpoint. No auto-approval. Owner responses: yes/no/"I'm not sure" — "unsure" triggers elevated multi-model verification, NOT auto-approval.

Owner CAN verify: book recognition, well-known authors, coarse science classification, output utility.
Owner CANNOT verify: precise death dates for lesser-known scholars, isnad parsing, subtle taxonomic distinctions.

## 8. METADATA FLOWS FORWARD, NEVER DELETED (D-023)

No engine may DELETE a metadata field from its input. May ADD new fields and ENRICH existing values. Cost of carrying unused field = zero. Cost of deleting needed field = re-run entire pipeline.

## 9. SPEC IS LAW — SPEC_CORE SUPERSEDES SPEC

SPEC_CORE.md is behavioral authority. When SPEC_CORE and code disagree → fix code. When SPEC.md and SPEC_CORE disagree → SPEC_CORE wins (SPEC.md is archived reference). contracts.py is schema authority. ABD legacy code has ZERO authority (D-019).

## 10. TEST PHILOSOPHY — SAME-AGENT TESTS CATCH NOTHING

Tests written by the same agent that wrote the code are nearly worthless for logic bugs (proven: 6 real bugs found by manual review that 758 passing tests missed in Step 1). After Claude Code writes code + tests, a SEPARATE review step must audit code against SPEC. Phase A exists because test fixtures are synthetic — real data has unanticipated edge cases.

## 11. DOMAIN AUTHORITY BOUNDARIES

Owner makes ALL domain decisions (metadata correctness, genre, attribution). Claude Chat (architect) makes ALL technical decisions (architecture, algorithms, testing). Claude Code implements per SPEC_CORE.md.

Defer to owner absolutely on Islamic scholarship. LEAD on technical/architectural topics — owner has no technical background.

## 12. THREE-TIER IDENTITY (D-024)

source_id (src_{8_hex}) → this specific file/edition.
work_id (wrk_{author_slug}_{title_slug}) → this book regardless of edition.
canonical_id (sch_{5_digit}) → the scholar who wrote it.
Confusing these corrupts deduplication, registries, and synthesis.

## 13. THE NORMALIZATION BOUNDARY

Source + Normalization = Phase 1 (source-format-specific, above boundary).
Passaging through Synthesis = Phase 2 (source-agnostic, below boundary).
NO source-format-specific logic below the boundary. If Passaging needs to know "this came from Shamela," the architecture is wrong.

## 14. TECHNOLOGY FIRST — NO CUSTOM CODE FOR SOLVED PROBLEMS

Before custom code: search "python library [capability] arabic" → domain tools, "[capability] NLP tool 2025 2026" → recent. Read actual documentation. Most sentence-transformers don't handle Arabic — verify empirically.

Library handles 80%+ → use it + 20% adapter. Library handles <50% or no Arabic → build custom, document decision.

## 15. NO SCOPE CREEP — CORE ONLY IN STAGE 1

Focus entirely on core architecture depth. Note Stage 2/§4.B possibilities briefly but do NOT pursue. Document extension hooks to keep Stage 2 paths open. If a capability requires calling other engines or data this engine doesn't have → scope creep, defer it.

## 16. SESSION CONTINUITY — INSTITUTIONAL MEMORY

NEXT.md is the handoff document. Every session starts by reading it. Every session ends by updating it with: accomplishments, next step, files to read, traps to avoid.

PHASE_X_LESSONS.md documents bugs, patterns, what worked/failed. Next phase agent reads it BEFORE starting. SESSION_LOG.md tracks the high-level arc.

## 17. BUDGET DISCIPLINE

Total API budget: €98 remaining. Phases: Step 3 (€5-10), Step 4 (€20-30), Step 5 (€40-50). NEVER start a phase without checking tests/results/source_engine/COST_LOG.json. NEVER start if remaining budget < estimated cost. Cost-saving via result reuse is mandatory (principle #2).

## 18. FROZEN SOURCES ARE IMMUTABLE

Once frozen (SHA-256 hashed), bytes NEVER change. Corruption → re-acquire, not repair. Frozen source is the tamper-evident baseline for all downstream verification.

## 19. GROUNDING TYPE TRACEABILITY (D-040)

Every factual claim tagged: source_grounded (traceable to excerpt with source/page/volume), metadata_derived (from source metadata), or analytical (synthesizer's contribution, explicitly marked). No untagged claims. Ever.

## 20. FAIL LOUD ON UNCERTAINTY (D-033)

Below 0.50 → human gate checkpoint (pipeline STOPS). Between 0.50–0.70 → accepted but FLAGGED for review. Above 0.70 → accepted without flagging.

## 21. TRUST EVALUATION IS EMPIRICALLY VALIDATED

5-factor trust: author standing 0.30, tahqiq quality 0.25, publisher reputation 0.15, source authority 0.15, text fidelity 0.15. Threshold 0.65. Validated: 13/13 PASS, uniquely optimal in 0.55–0.75 range. Do NOT modify without re-running validation suite.

## 22. NO MODIFICATIONS TO WORKING CODE UNLESS EXPLICITLY TASKED

Validation phases find bugs by running existing code on real data. If task is "run Phase A," do NOT refactor extraction code, do NOT "improve" regex, do NOT fix preemptively. Run as-is, record failures, fix in separate session after review. Premixing testing and fixing makes original failure rate unknowable.

## 23. RALPH IS FOR SMALL INDEPENDENT TASKS ONLY

Ralph (snarktank/ralph autonomous loop) for small, independent bug fixes — NOT sequential, coupled build sessions. If task requires full SPEC reading, multi-file modifications, or cross-module dependencies → Claude Code task.

## 24. EVERY CLAIM IN THE SPEC MUST BE GROUNDED

Every SPEC claim traceable to source (research, test result, domain input) or marked as design decision. Ungrounded SPEC claims become unquestioned assumptions → permanent bugs. Distinguish: what evidence shows, what you infer, what you're guessing.

## 25. SEVEN KNOWLEDGE CORRUPTION THREATS

T-1: Silent text corruption (diacritics, encoding, normalization)
T-2: Attribution error (wrong author, wrong school, sharh/matn confusion)
T-3: Taxonomic misplacement (content under wrong topic)
T-4: Context loss (excerpt not self-contained)
T-5: Synthesis hallucination (LLM fabricates scholarly positions)
T-6: Metadata poisoning (wrong metadata propagates through pipeline)
T-7: Duplication and contradiction (same content, different treatment)

Every engine implements specific mitigations for threats in its scope.

## 26. SILENT FAILURE PATTERN AWARENESS

Seven patterns that produce output looking correct but subtly wrong:
1. Hollow examples (happy path only)
2. Circular definitions (X defined using X)
3. Hand-waving technology (named tech doesn't work for Arabic)
4. Phantom metadata (field name mismatch across boundaries)
5. Untestable rules (subjective language as precision)
6. Missing error paths (SPEC only describes happy path)
7. Scope creep disguise (capability requires data engine doesn't have)

Apply as detection lenses during every code/SPEC review.

## 27. GIT DISCIPLINE

Clone fresh at session start. NEVER upload repo files as project knowledge — they go stale. Commit with meaningful messages. Push before ending session. Update NEXT.md before pushing.

## 28. THE OWNER'S SHAMELA COLLECTION

2,519 books from Shamela desktop v4. 1,932 single .htm + 587 multi-volume directories. Collection at: C:\Users\Rayane\Desktop\kr\shamela export samples. 263 books had filenames exceeding filesystem limits. Collection is the test dataset for source engine.

## 29. THE VALIDATION STEP SEQUENCE

Step 0 done (13 fixtures, real LLM, €1.80) → Step 1 done (code audit, 6 bugs, €0) → Step 2 (deterministic sweep, 2519, €0) → Step 3 (LLM probes, 30, €5-10) → Step 4 (calibration, 150, €20-30) → Step 5 (full collection, 2519, €40-50).

Each step has GO/NO-GO gate. No phase starts without previous gate passing. Run → review → fix → next.

## 30. WHAT "ENGINE COMPLETE" MEANS

Complete when: (1) handles every format/input in SPEC, (2) every error path has structured error code, (3) tested on real data (not just fixtures), (4) owner spot-checked outputs, (5) all GO/NO-GO gates passed, (6) output verified consumable by next engine, (7) PHASE_X_LESSONS.md written.

NOT complete just because: runs without crashing, tests pass, or output produced for full collection.

## 31. DOWNSTREAM ENGINE AWARENESS

Every engine's output = next engine's input. Changing an output field name/type/semantics breaks every downstream engine. Before modifying any output schema, verify downstream engine's input contract still matches.

## 32. CONTEXT WINDOW MANAGEMENT FOR CLAUDE CHAT

Claude Chat ~200K tokens. NEVER read VISION.md whole (~47K). Use scripts/extract_vision_sections.py. One SPEC per session. Stop clean at 70% context — finish current section, write NEXT.md, commit, stop.

## 33. KNOWN COSMETIC ISSUES (DO NOT RE-DISCOVER)

Three non-blocking issues from Step 1 (documented, NOT yet fixed):
- Duplicate gate checkpoint when genre confidence < 0.50 (engine.py:532 and :587 both fire)
- Gate checkpoint diagnostic values are empty strings for confidence_threshold errors
- structural_format defaults to "prose" instead of "mixed", genre chain silently drops on invalid relation_type, staging cleanup swallows move failures

Known. Do not re-discover. Fix when relevant.

---

## Quick-Reference Decision Table

| Decision | Rule |
|----------|------|
| D-004 | Primary text integrity is absolute |
| D-006 | Accuracy > Protection > Intelligence |
| D-018 | KR is Rayane's knowledge, not a library he uses |
| D-019 | ABD legacy has zero design authority |
| D-023 | Metadata is synthesis fuel — never strip |
| D-024 | Three-tier identity: source_id, work_id, canonical_id |
| D-033 | Fail loud — low-confidence → flag, not silent default |
| D-040 | Grounding traceability: source_grounded / metadata_derived / analytical |
| D-041 | Multi-model consensus for all content decisions |

## 34. RIPPLE VERIFICATION FOR SHARED CONCEPTS

When adding, removing, or renaming any value in a shared concept (enum, verdict, status, classification, error code), grep ALL files that reference the concept and verify EVERY consumer is updated. Shared concepts include: verdict scales (VERIFIED/PLAUSIBLE/UNVERIFIABLE/FLAG/ESCALATE), error codes (SPEC §7), structural format types, genre enums, layer types, confidence levels, and any classification used by multiple agents or engines. Output format templates and summary tables are the highest-risk consumers — check these first. Self-review is insufficient for ripple changes; dispatch independent review.

## Priority Order

**Accuracy > Protection > Intelligence.** Always. Without exception.
