---
name: Branching Model
description: "Claude commits directly to master. Codex creates branches merged via PR. Exception: hardening branches."
type: feedback
---

The branching model evolved with the Codex control plane:

- **Claude sessions (default):** Commit directly to master. No branches, no PRs. Review is embedded in session workflow.
- **Claude hardening lanes (exception):** When a formal takeover brief mandates a clean branch (e.g., `excerpting-foundations-hardening-20260404`), Claude works on that branch. This is per-lane, not a general change.
- **Codex sessions:** Create branches (e.g., `ops/bootstrap-kr-control-plane`) merged via GitHub PR.

**Why:** Claude is the active engineering authority with full context and human oversight. Direct master commits are safe. Codex operates in bounded shadow lanes where PRs provide a review gate. Hardening lanes get dedicated branches because they involve multi-day, experimental work that should be reviewable before merging to master.

**How to apply:** Default to master for Claude. Only create branches when a takeover brief or handoff document explicitly says so. When Codex work needs merging, use the PR workflow.
