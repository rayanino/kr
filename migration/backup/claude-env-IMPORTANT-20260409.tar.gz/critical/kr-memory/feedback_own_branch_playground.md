---
name: System should have its own branch — full autonomy within its playground
description: Owner concerned that "is the repo clean" check blocks the system when he's doing other work. Wants the system to have its own dedicated branch where it can do whatever it needs without safety bottlenecks.
type: feedback
---

Owner said (2026-04-07): "Why does it not have its own branch specifically for it to do whatever? This eliminates any safety features — the system has its own branch with own playground, do whatever it wants. 'Is this safe enough to implement' → it's your branch, you choose."

**Why:** The current "is the repo clean?" preflight check implies the system competes with the owner for the repo. If the owner is working on another branch (taxonomy, normalization, etc.), the system shouldn't be blocked. A dedicated branch means:
1. No conflict with owner's work
2. System can be more aggressive (implement freely on its branch)
3. Merge to master only when changes are validated
4. Owner's work is never affected by system activity

**How to apply:** The autonomous system should operate on a dedicated persistent branch (e.g., `autonomous/nightly`). It creates worktrees from this branch. Changes are accumulated on this branch. Merge to master happens through validated PRs, not direct commits. The "repo clean" check should only apply to the system's own branch state, not the overall repo.
