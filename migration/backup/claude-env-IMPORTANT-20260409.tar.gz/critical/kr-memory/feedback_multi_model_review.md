---
name: SUPERSEDED — merged into feedback_codex_reviewer.md
description: This memory was merged into feedback_codex_reviewer.md on 2026-04-04. See that file instead.
type: feedback
---

Merged into `feedback_codex_reviewer.md` on 2026-04-04. That file now contains the complete multi-model review policy including both CLI and DR coworkers.
