---
name: Gemini upgraded to Pro 3.1 — full coworker status
description: As of 2026-03-31, Gemini is upgraded to Google AI Pro (Gemini 3.1 Pro, top tier). It is now a MAJOR coworker equal to Codex and Claude, not a lightweight tool. Deep research mode available via Gemini chat.
type: feedback
---

Gemini is now running Google's top-tier model (Gemini 3.1 Pro) via Google AI Pro subscription. It is a FULL coworker, not a minor helper.

**Why:** Owner upgraded to Google AI Pro on 2026-03-31. Gemini 3.1 Pro is a frontier model comparable to Opus and GPT-5.4 in capability.

**How to apply:**
- Treat Gemini CLI and Gemini Chat as equal to Codex and Claude Chat in all dispatches
- Gemini Chat has deep research mode (like ChatGPT DR and Claude DR)
- Use Gemini for Arabic scholarly validation (it was already good; now it's top-tier)
- The full coworker team is now 5 tools across 3 providers:
  1. **Codex** (GPT-5.4) — CLI, repo access, code + analysis
  2. **Gemini CLI** (Gemini 3.1 Pro) — CLI, repo access, code + Arabic
  3. **ChatGPT** (GPT-5.4 Pro Extended / Deep Research) — chat/DR, repo access via DR
  4. **Claude Chat** (Opus / Deep Research) — chat/DR, repo access via DR
  5. **Gemini Chat** (Gemini 3.1 Pro / Deep Research) — chat/DR, repo access via DR
- At every major milestone: use ALL available tools. No single-model conclusions.
- Gemini CLI may have daily quota limits — if exhausted, use Gemini Chat DR instead
