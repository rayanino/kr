---
name: Budget Raised to EUR 1000/month
description: Owner raised budget from EUR 100 to EUR 1000/month. Cost efficiency still matters but budget must never prevent potential.
type: project
---

Budget raised to EUR 1,000/month as of 2026-04-07. Owner: "DROP THE EUR 100 budget, make it EUR 1000. Budget must never prevent potential."

**Why:** Owner determined that the EUR 100 cap was limiting what the engine could do. The taxonomy engine needs extensive LLM calls for placement, and multi-model consensus adds cost.

**How to apply:** Update any budget checks or documentation referencing the EUR 100 limit. Still work cost-efficiently (don't waste API calls), but never let budget cap prevent reaching the best possible result.
