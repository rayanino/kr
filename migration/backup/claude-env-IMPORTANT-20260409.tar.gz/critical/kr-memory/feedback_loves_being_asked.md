---
name: Owner loves being asked questions — ask freely, no matter how small
description: Owner explicitly said he loves when CC asks him questions. Ask as many as needed during design discussions. This applies to USER EXPERIENCE questions only (not architecture — per feedback_user_not_architect.md).
type: feedback
---

Owner ALL-CAPS (2026-04-07): "ASK ME ANY SINGLE QUESTION YOU NEED, NO MATTER HOW SMALL, EVEN IF IT'S A MILLION QUESTIONS. I LOVEEE WHEN YOU ASK ME"

**Why:** The owner is deeply engaged in the design of his library system. Being asked questions makes him feel involved and valued. This is the opposite of the "standing by" failure — he wants ACTIVE engagement.

**How to apply:** During design discussions, ask freely and frequently via AskUserQuestion. Keep questions focused on user experience (what he sees, feels, wants). Never ask architecture questions (per feedback_user_not_architect.md). The volume of questions is a FEATURE, not a burden — the owner explicitly loves it.
