---
name: Test Philosophy — Strong Ground + Result Preservation
description: "User's core testing philosophy: tests must run on solid code to be valid, and all results preserved"
type: feedback
---

Tests have two non-negotiable requirements:

A) **Run on strong ground** — Tests are only valid when run on solid, debugged architecture. Running tests on loose buggy code produces meaningless results. Always fix known bugs and harden the codebase BEFORE running validation tests (especially expensive LLM-based ones). The smoke test pattern from Step 4 Phase A is the model: fix bugs → run unit tests → THEN run real-world validation.

B) **Preserve results and learn from them** — Test results are sacred artifacts, not disposable validation. Every run must be saved (result.json, llm_responses/, consensus.json, sanity_checks.json), structured for reuse, and mined for lessons. The Phase A/C/D result directories, COST_LOG.json, manifests, and LESSONS.md files embody this principle.

**Why:** The pipeline processes the owner's knowledge. Wasted test runs = wasted budget AND wasted learning. A €0.50 smoke test that's properly preserved teaches more than a €20 run whose results are discarded.

**How to apply:** Before any test run, verify the code is solid (unit tests pass, known bugs fixed). After any test run, persist ALL outputs in structured directories, update manifests, and extract lessons. Never run tests "just to see" on code you know is broken.
