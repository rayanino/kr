---
name: Home Science Gateway — No Duplication, Use Ropes
description: Content lands at its HOME SCIENCE only. Other sciences reference it via cross-links ("ropes"). Never duplicate across trees. Source book's science is NOT the topic's home science.
type: feedback
---

When content from book X (e.g., aqidah) covers a topic that belongs to science Y (e.g., fiqh's حكم الصلاة), ALL excerpts land at the fiqh branch (home science). The aqidah branch gets a REFERENCE ("rope") to the fiqh branch, not its own copy.

**DANGEROUS BIAS:** "Excerpt is in book of science X → must land in tree X." This is WRONG. The topic's home science determines placement, NOT the source book's science.

**Why:** Owner (2026-04-08, ALL-CAPS): "THIS GOES COMPLETELY AGAINST THE IDEA OF: WHEN I WANT TO STUDY A TOPIC, I HAVE A LEAF READY WITH EVERY SINGLE EXCERPT I WOULD NEED." Splitting excerpts across trees by source book = "CATASTROPHIC AND EXTREMELY CONFUSING."

**How to apply:** (1) Determine the topic's HOME SCIENCE based on the topic itself, not the source book. (2) Place all excerpts at the home science leaf. (3) Other sciences that touch this topic get references/links ("ropes"), not duplicates. (4) Only use references for genuine "outliners" — not to make the library lazy with empty branches.

**CONTRADICTS:** Canon TC-018 ("content must physically exist AT every relevant leaf") and Q-G5-02/Q-G5-04 defaults which favor duplication. This owner answer overrides duplication defaults with a gateway + reference model. Must be validated by DR coworkers.
