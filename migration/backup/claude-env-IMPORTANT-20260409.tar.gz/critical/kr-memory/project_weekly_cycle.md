---
name: Owner's weekly CC budget cycle
description: Owner hits CC weekly limit by Wednesday. Resets Monday. Thu-Sun is offline owner time for reviewing excerpts, answering questionnaires. Monday = productive CC restart with all owner feedback in repo.
type: project
---

The owner's CC subscription has a weekly usage limit. Pattern:
- **Mon-Wed:** Active CC sessions, heavy development work
- **Wed evening:** ~90% of weekly limit used
- **Thu-Sun:** NO CC available. Owner works offline — reviewing excerpts, filling questionnaires, reading Arabic text
- **Monday:** Limit resets. Owner returns with all offline work committed to repo. Productive CC session starts immediately.

**How to apply:**
- By Wednesday, ensure all CC-dependent work is DONE
- Leave the owner with SELF-CONTAINED artifacts for offline work (rendered excerpts, multiple-choice forms, review packages)
- Never leave a blocker that requires CC interaction during Thu-Sun
- Monday sessions should start with `/catchup` and immediately use the owner's offline feedback
- The questionnaire and review packages at `integration_tests/questionnaire/` are designed for offline completion
