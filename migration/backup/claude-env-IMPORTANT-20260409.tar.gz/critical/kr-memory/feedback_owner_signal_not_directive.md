---
name: Owner answers are signal not directives
description: Owner Q&A answers are high-value signal and zero-authority implementation commands. Must be challenged, widened, counterexample-searched before any translation to code/SPEC.
type: feedback
---

Owner questionnaire answers are **high-value signal** and **zero-authority directives**.

They are feedback, not verdicts. Preferences, not final rules. Suggestions, not binding conclusions. The owner explicitly requested this treatment (2026-04-04, OWNER_FEEDBACK_GUARDRAIL.md).

**Why:** The owner is often answering correctly inside the local frame of the shown examples while lacking visibility into: the rest of the repo, adjacent engines, contract consequences, hidden edge cases, future corpus diversity, and long-horizon architecture costs. That is the expected division of labor — not a flaw. The burden is on the engineering team to correct for that narrowness.

**How to apply:**
- NEVER translate `owner answer → direct implementation`
- ALWAYS use: `owner answer → evaluated signal → challenged/refined interpretation → bounded rule`
- Before any owner answer becomes a SPEC rule, prompt rule, code change, or threshold: it must survive counterexample search, coworker challenge, feasibility review, and scholarly-integrity check
- When the owner says something "feels wrong" — identify whether the real fix belongs to: (1) display/presentation, (2) workflow/study mode, or (3) the excerpt boundary itself. A boundary change is the most expensive fix and least reversible.
- Scholarly invariants outrank owner preference. If a literal owner preference conflicts with attribution integrity, disagreement preservation, or knowledge-safety invariants, the invariant wins.
- Any owner answer may be: scholastically wrong, internally contradictory, too vague, too rigid, too expensive, good locally but harmful globally, or pointing at a deeper need than the literal answer states.
- Owner confidence is metadata, not proof. High confidence ≠ correct.
