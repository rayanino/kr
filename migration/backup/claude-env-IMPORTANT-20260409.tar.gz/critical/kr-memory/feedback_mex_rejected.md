---
name: mex Integration Rejected
description: mex (theDakshJaitly/mex) evaluated 2026-03-30 and rejected — KR's context system is more sophisticated, setup.sh would overwrite CLAUDE.md
type: feedback
---

User asked whether to integrate mex into KR. After thorough evaluation: **No.**

Key reasons:
1. `setup.sh` unconditionally overwrites project-root CLAUDE.md with a generic template — would destroy KR's 47K-token governance document
2. KR already has a 4-tier context system (CLAUDE.md -> MEMORY.md -> per-engine CLAUDE.md -> NEXT.md) that surpasses mex's 3-tier model
3. mex is 8 days old (v0.2.0), single maintainer — maturity mismatch with KR's 1,877+ test suite
4. The parent-level `C:\Users\Rayane\CLAUDE.md` is already an unfilled mex template (never populated)

The only genuinely useful mex concept: automated drift detection (verifying paths in docs still exist). This is trivially buildable as a native Python script in `scripts/`.

**Why:** KR's existing environment (14 hooks, 21 agents, 15 skills, 17 rules) already exceeds what mex provides. Adding a dependency on an immature external tool would add risk without meaningful benefit.

**How to apply:** Do not install mex in KR. If drift detection is needed, build it natively. The parent-level CLAUDE.md mex template can be cleaned up or left as-is since KR's project-level CLAUDE.md overrides it.
