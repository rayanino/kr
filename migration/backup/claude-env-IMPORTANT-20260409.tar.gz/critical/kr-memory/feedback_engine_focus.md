---
name: Engine Focus Discipline
description: Only the active engine is in scope. Currently excerpting (engine 3). Source + normalization are COMPLETE. Others have first-draft SPECs only.
type: feedback
---

Only work on the currently active engine unless explicitly told otherwise. As of 2026-04-07, the active engine is **excerpting** (engine 3). Source engine (1) and normalization engine (2) are COMPLETE. Engines 4-7 (taxonomy, synthesis, etc.) have first-draft SPECs only — no SPEC_CORE, no implementation worth testing.

**Why:** The user corrected the assumption that all 7 engines were in scope. Running quality checks, fixing SPEC defects, or building test infrastructure for engines that will be rewritten during their SPEC_CORE phase is wasted work.

**How to apply:** When looking for "useful work to do," focus on the excerpting engine and its hardening operation. Light research/prep for taxonomy (engine 4) is fine, but don't "fully build" anything ahead of the SPEC_CORE process. Don't treat first-draft SPECs as authoritative — they'll change.
