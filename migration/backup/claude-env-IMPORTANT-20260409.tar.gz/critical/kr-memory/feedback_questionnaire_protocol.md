---
name: Questionnaire Protocol — DR for Research, Owner for Preferences
description: Researchable objective questions go to DR coworkers. Owner is asked ONLY about personal preferences. Owner input on scholarly questions is just one source, not primary.
type: feedback
---

The owner explicitly corrected the Q&A approach: "FOR OBJECTIVE QUESTIONS THAT HAVE RESEARCHABLE ANSWERS THE COWORKERS ARE BETTER, BUT MY INPUT IS JUST ANOTHER SOURCE. But for questions relating specifically to Rayane (the owner, me), you ask me."

**Ask the owner:**
- Personal study preferences (platform, study habits, what feels confusing)
- Experience reactions ("when you see X, what do you think?")
- Priority choices ("which science first?")

**Ask DR coworkers (better at these):**
- How should Islamic sciences be organized? (scholarly research)
- What distinguishes beginner from intermediate students? (pedagogical research)
- How do scholars handle cross-science content? (methodology research)
- What is the scholarly consensus on X classification? (domain expertise)

**Why:** Owner (2026-04-08): "the DR coworkers are world class reasoners that could extensively answer these questions way better than you asking me a Q&A here." The system "CLEARLY FAILS IN IDENTIFYING THESE" bigger patterns because it asks the owner instead of researching.

**How to apply:** Re-triage the remaining 59 questionnaire questions. Route scholarly/objective ones to DR coworkers. Only present personal-preference questions to the owner. Owner answers on scholarly questions are treated as one input among many, not primary.
