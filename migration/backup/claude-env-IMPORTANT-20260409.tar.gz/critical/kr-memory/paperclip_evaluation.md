---
name: Paperclip Evaluation Results
description: Paperclip v2026.325.0 hands-on evaluation (2026-03-28) — EVALUATE_FURTHER. Good for dashboard/governance/cost. Windows broken. Does NOT replace orchestrator brain.
type: project
---

Full hands-on evaluation of Paperclip (https://github.com/paperclipai/paperclip) performed 2026-03-28. Report at `reference/factory_review/PAPERCLIP_EVALUATION_REPORT.md`.

## What Paperclip Is

Open-source Node.js server + React UI for orchestrating AI agents as a "company." Org charts, budgets, heartbeats, governance gates, task tracking. Think "JIRA for AI agents."

## Verdict: EVALUATE_FURTHER

Not ADOPT (too immature, Windows broken), not REJECT (genuine value for dashboard/scheduling).

## What Works

- **Dashboard + UI** (React SPA, PWA mobile) — saves Session 8 of factory roadmap
- **Governance gates** (hire_agent approval, board decisions, audit trail) — saves part of Session 8
- **Cost tracking** (per-agent, per-model, per-token with budget enforcement auto-pause)
- **Agent lifecycle** (idle/running/paused/error, heartbeat history)
- **Session persistence** (claude_local resumes CC session IDs between heartbeats)
- **Multi-adapter** (claude_local + codex_local work; process adapter as fallback)

## What's Broken (Windows-specific)

1. **Embedded PostgreSQL WIN1252 encoding** — Arabic text garbled, non-ASCII breaks DB queries. Root cause: PG cluster initialized with system locale instead of UTF-8.
2. **Symlink creation EPERM** — skill injection requires symlinks; Windows requires Developer Mode for symlinks. Without it, no agent can execute.
3. Both issues would NOT occur on Linux/WSL (which is where the factory runs per D-F012).

## What's Missing/Wrong

- `gemini_local` adapter doesn't exist despite documentation claiming it
- `issuePrefix` silently ignored on company creation
- `assigneeId` silently ignored (correct field: `assigneeAgentId`)
- No DAG-style task dependencies (only parent-child hierarchy)
- Managed AGENTS.md is generic boilerplate — no KR context injection
- Project is 3 weeks old (first release 2026-03-09) — high change velocity

## What Paperclip Does NOT Replace

Mode-selection state machine, findings database (7-stage lifecycle), synthetic adversarial data system, CLI abstraction layer, 19 Arabic text safety hooks, quality maturity model, SPEC-to-task decomposition, D-F018/D-F020 protocols.

## Recommended Path

1. Test on WSL2 to confirm Windows issues resolved
2. Test actual CC execution with CLAUDE.md context
3. Test Agent Teams inside a heartbeat
4. Don't adopt for Session 6 — too risky
5. Build orchestrator standalone, plug Paperclip in later for dashboard/scheduling (Sessions 8-9)
6. Re-evaluate at v2026.4xx (30 days maturity)

**Why:** Paperclip solves the plumbing (tracking, scheduling, dashboard) but not the domain logic (what to build, how to hunt, how to ensure scholarly correctness). Net savings if adopted: ~3-4 sessions. Net risk: dependency on a 3-week-old project.
