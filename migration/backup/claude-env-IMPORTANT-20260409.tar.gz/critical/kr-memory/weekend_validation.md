---
name: Weekend Corpus Validation and Transition Gate Results
description: Full 7,475-book corpus sweep results, bug fix verification, and calibration metrics — key data for passaging engine design
type: project
---

## Weekend Tasks 1-3 Complete (2026-03-21)

### Task 1: Dual-Engine Corpus Sweeps
- **Source engine**: 7,475 items, 100% success, 0 errors
- **Normalization engine**: 7,475 books, 7,474 OK, 1 crash, 48 zero-content (silent failure)

### Task 2: Bug Fix Sprint (€0 cost)
Two bugs fixed:
1. **Pageless books** (48 books): `_pass1_parse()` lacked pre-scan for `(ص: N)` markers. Books without page numbers had all pages classified as metadata → 0 content units. Fix: pre-scan + conditional metadata detection.
2. **Diacritics canary** (1 book): `_ARABIC_DIACRITICS` had 20 codepoints (broader than SPEC §5 range of 10). Canary used exact sequence match. Fix: aligned to 10 codepoints + ±1 count tolerance.

**Why:** Both classified as **logic changes** (not error-path-only) → required full re-sweep to verify.

### Task 3: Verification + Calibration
Full re-sweep (v2): **7,475 OK, 0 crashes, 0 zero-content.** All 49 previously-affected books verified individually.

### Calibration Metrics (for passaging design)
| Metric | Value |
|--------|-------|
| Total content units | 2,059,924 |
| Boundary continuity coverage | 97.4% |
| BC type: mid_sentence | 46.8% |
| BC type: section_break | 26.4% |
| BC type: mid_paragraph | 25.6% |
| BC type: mid_argument | 1.3% |
| Division overlap rate | 15.3% (consistent with 14% from 63-fixture evaluation) |
| Multi-layer detection rate | 5.4% (401 books) |
| Passaging contract: all-pass | 84.7% (check6 failures = division overlap) |
| check4/check5 failures | 0 (no engine bugs) |
| Arabic ratio < 70% | 1.4% (106 books) |
| Page loss = 1 (near-perfect) | 78.5% |
| Hadith pages | 38.0% of corpus |
| Quran pages | 20.3% |
| Verse/poetry pages | 15.8% |

**How to apply:** The passaging engine must handle 15.3% division overlap gracefully (use unit_index adjacency, not division tree). BC signals are rich (97.4% coverage) — passaging can rely on them for split decisions.

### Deliverables (in repo)
- `results/VERIFICATION_REPORT.md` — before/after comparison
- `results/CALIBRATION_REPORT.md` — 9-section analysis (B.1-B.9)
- `scripts/analyze_sweep_results.py` — reusable stdlib-only analysis tool
