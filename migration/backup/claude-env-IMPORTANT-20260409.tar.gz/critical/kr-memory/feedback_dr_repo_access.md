---
name: DR coworker repo access capabilities
description: Which DR coworkers can access the private rayanino/kr repo directly. ChatGPT DR and Claude DR CAN. Gemini DR CANNOT (needs file uploads). ChatGPT non-research CANNOT.
type: feedback
---

**ChatGPT DR** and **Claude DR** both CAN access the private `rayanino/kr` GitHub repo directly during deep research sessions. Do NOT paste full file contents into their prompts — just give file paths.

**Gemini DR** CANNOT access the repo. Needs file uploads.
**ChatGPT non-research** CANNOT access the repo. Needs files pasted.
**Gemini CLI** has local repo access via `gemini -p`.

**Why:** Owner corrected (2026-04-01) after CC wrongly told the owner to paste content into Claude DR. This wastes time and the owner's effort. NEVER make this mistake again — check this memory before writing DR relay prompts.

**How to apply:** When writing relay prompts for ChatGPT DR or Claude DR, give file paths (e.g., "Read `integration_tests/questionnaire/OWNER_QUESTIONNAIRE.md`"). For Gemini DR, prepare a file bundle for upload.
