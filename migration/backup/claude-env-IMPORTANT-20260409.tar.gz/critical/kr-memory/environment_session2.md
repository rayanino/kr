---
name: Environment Overhaul Session 2 (2026-03-26)
description: Session 2 of environment overhaul — added 3 domain-specialized agents, 4 new commands, 2 verification scripts, enhanced spec-writer and orchestrate. Agents now go 19→22, commands 18→22.
type: project
---

## What Happened

Session 2 focused on agents, commands, and verification infrastructure. Key theme: Session 1 created domain knowledge (4 Islamic sciences skills), but Session 2 makes that knowledge *actionable* through specialized agents and commands.

### New Agents (3)

1. **arabic-reviewer** (sonnet) — Deep Arabic text code review using all 4 domain skills + scholarly conventions rule. Reviews code for character safety (T-1), scholarly convention compliance, knowledge integrity threats (T-1..T-7), and domain-specific processing. Unlike code-reviewer's generic Arabic checks, this agent understands *consequences* (e.g., stripping diacritics from Quranic text violates T-1).

2. **regression-detector** (haiku) — Fast test regression detection between git refs. Compares test counts, classifies changes as REGRESSION/RECOVERED/PERSISTENT/NEW, supports flaky detection. Model is haiku for speed.

3. **evaluation-prep** (sonnet) — Pre-flight checklist for Phase C/D/E evaluation runs. Validates 6 categories: prerequisites, fixtures, budget, configuration, playbook, code readiness. Catches missing prerequisites BEFORE API budget is spent.

### Enhanced Agents (1)

4. **spec-writer** — Added domain knowledge integration: must read relevant skills before writing SPEC sections. Added self-review checklist (Arabic term precision, real text examples, calibration data).

### New Commands (4)

5. **/cost-report** — API cost breakdown from COST_LOG.json by model, phase, date. Budget warnings at 20%/10%/5% remaining.

6. **/eval-dashboard** — Evaluation progress dashboard: books processed, verdicts issued, consensus stats, cost, pending work. Box-drawing UI for quick orientation.

7. **/regression-check** — Compare test results between current state and a previous git ref. Default baseline HEAD~1. Detects REGRESSIONS, RECOVERED, PERSISTENT failures.

8. **/arabic-audit** — Comprehensive Arabic text safety audit with 4 levels: syntax safety, diacritic safety, domain conventions, knowledge integrity. 19 individual checks across all levels.

### Enhanced Commands (1)

9. **/orchestrate** — Added Chain C (eval-prep) and Chain D (arabic-review). Now has 4 chains: post-build, verify, eval-prep, arabic-review.

### Verification Scripts (2)

10. **scripts/validate_agent_definitions.py** — Validates all agent/command frontmatter: required fields, model names, tool names, description length. Handles legacy bare-format commands gracefully.

11. **scripts/check_test_regression.py** — Programmatic test regression comparison between git refs. Stash/checkout/test/restore workflow with safety guards.

## Why These Choices

- **arabic-reviewer**: The biggest gap from Session 1. Domain knowledge existed in skills but wasn't applied during code review. Now there's a specialized agent that reads all 4 Islamic sciences skills before reviewing.
- **evaluation-prep**: The orchestrate verify chain jumped straight to expensive API calls. Now there's a pre-flight check that catches missing prerequisites before burning budget.
- **regression-detector**: Test stability tracking was manual. Now automated with haiku for speed.
- **/cost-report** and **/eval-dashboard**: Essential for the upcoming LLM evaluation phase.
- **Verification scripts**: Config hygiene — catch typos in agent definitions before they silently fail at dispatch.

## Totals After Session 2

| Category | Before S1 | After S1 | After S2 |
|----------|-----------|----------|----------|
| Agents   | 17        | 19       | 22       |
| Commands | 15        | 18       | 22       |
| Skills   | 7         | 15       | 15       |
| Rules    | 8         | 17       | 17       |
| Hooks    | 6         | 14       | 14       |
| Scripts  | (many)    | (many)   | +2 new   |

## Remaining Sessions

- **Session 3:** External integrations (Usul.ai patterns, Sunnah.com, test fixtures) + evaluation scripts
- **Session 4:** Advanced (scholar authority heuristics, hallucination detection, Arabic embeddings)
