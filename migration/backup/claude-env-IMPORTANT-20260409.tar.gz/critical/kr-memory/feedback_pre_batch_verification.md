---
name: Verify Target Constraints Before Batch Operations
description: Before any batch operation affecting 3+ files, verify the target format/schema accepts what you're about to write. Test on one file first.
type: feedback
---

Before any batch modification touching 3+ files, verify the target accepts your intended change by testing on a single file or checking documentation.

**Why:** Before the fix session, verifying that agent frontmatter `model:` field accepts only short names (opus/sonnet) — not full API strings — prevented 17 invalid edits across all agent files. Without this check, every agent file would have been broken.

**How to apply:** When planning batch edits:
1. Identify the constraint/schema governing the target (frontmatter format, enum values, field types)
2. Verify by reading documentation OR testing on one file
3. If the constraint blocks your planned change, adjust the plan BEFORE starting, not mid-execution
