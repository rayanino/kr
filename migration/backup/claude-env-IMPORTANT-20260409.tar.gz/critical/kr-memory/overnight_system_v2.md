---
name: overnight_system_v2
description: KR Overnight Autonomous System v2 — orchestrator, task generator, hardening-only philosophy, cost tracking, bookend tasks
type: project
---

Overnight Autonomous System v2 built 2026-03-23, major bug fixes applied 2026-03-24.

**Architecture**: Python orchestrator (`scripts/overnight_orchestrator.py`) launches tasks via 3 backends:
1. `claude -p` CLI with `--agent` dispatch (primary — inherits settings.json hooks)
2. Claude Code SDK (`claude_code_sdk.query()`) for programmatic control
3. `codex exec --full-auto` for independent code-structural verification (D-041)

**Key files**:
- `scripts/overnight_orchestrator.py` — Core execution loop, quality gate, state, reporting
- `scripts/overnight_task_generator.py` — 7 scanners discover hardening work (research scanner removed)
- `scripts/start_overnight.sh` — Launch script with pre-flight
- `overnight/` — state.json, progress.md, manifest.json, results/, MORNING_REPORT.md

**Philosophy (user-directed):** Overnight is for HARDENING ONLY — code review, edge case tests, bug fixes, spec audits, validation. NEVER for feature implementation. Safety prompt explicitly forbids creating new source files or implementing new features.

**Task generator scanners**: recent changes review, test health, SPEC quality, code quality, corpus integrity, contract boundaries, known limitations, documentation, **creative** (added 2026-03-29). Category enforcement rejects implementation/research tasks.

**Creative task expansion** (added 2026-03-29, commits c7a1df20..a351d8f4):
- 7 creative templates in `overnight/creative_templates/`: 3 innovation, 2 adversarial, 1 spec challenge, 1 edge testing
- Creative scanner in task generator with template loading and cooldown tracking (`overnight/creative_run_log.json`)
- Post-run findings appender auto-updates FINDINGS_TRACKER.md
- Security review: 4 CRITICAL + 4 HIGH + 4 MEDIUM findings patched (path traversal, schema validation, dedup)
- Design spec: `docs/superpowers/specs/2026-03-29-creative-overnight-expansion-design.md`

**Bookend tasks**: `bookend=True` tasks (e.g., regression test) skip dependency propagation and always run last regardless of other task failures. The most important quality signal always fires.

**Task recycling**: When all manifest tasks resolve but time remains (>30 min), the orchestrator re-runs the task generator to discover new work created by the first batch.

**Quality gate (5 levels)**: L1 test suite, L2 git state, L3 compliance, L4 pyright, L5 Codex cross-verification (auto-disabled on Windows if Codex not on PATH).

**Cost tracking**: Reads `total_cost_usd` from Claude Code CLI JSON output. Fallback regex extraction from raw output.

**Bugs fixed 2026-03-24**: (1) cost_usd → total_cost_usd field name, (2) state initialization race (stale cleanup before init), (3) transitive skip propagation (skipped status now propagates), (4) max_turns truncation detection and logging.

**How to use**: PowerShell: `$env:KR_OVERNIGHT=1; $env:PYTHONIOENCODING="utf-8"; python scripts/overnight_orchestrator.py --manifest overnight/manifest.json --hours 8.5`

**Why:** Context degradation from v1 CronCreate system. v2 gives each task a fresh 1M-token context via separate `claude -p` invocations.

**Status (2026-03-30):** This Claude-based overnight system is being supplemented by the Codex-based `overnight_codex_orchestrator.py` (see `overnight_codex_system.md`). Both systems may coexist — Claude overnight for Claude-backed work, Codex overnight for hardening/shadow lanes.

**How to apply:** When user wants to start overnight work, generate manifest first (`python scripts/overnight_task_generator.py --output overnight/manifest.json`), review it, then launch orchestrator. Always review MORNING_REPORT.md the next morning.
