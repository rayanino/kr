---
name: Always use full 6-source team for major conclusions
description: "Every major conclusion must use all 6 sources. All have deep research capability. Maximize utilization."
type: feedback
---

Every significant conclusion, design decision, or quality assessment MUST be cross-validated by all available models before being reported as final. The owner invests in having the full team available — use them ALL extensively.

**Why:** The owner explicitly confirmed (2026-04-01) that Gemini Deep Research is equally or more capable than ChatGPT DR and Claude DR. The only constraint is it needs specific files uploaded or a public repo. Single-model conclusions are not acceptable per D-041. Each model finds unique issues others miss.

**How to apply:**
- **3 CLI tools (repo access):**
  - CC (Claude Code): code investigation, script writing, structural analysis
  - Codex CLI: schema validation, cross-prompt consistency, statistical analysis
  - Gemini CLI: Arabic scholarly accuracy, convention compliance
- **3 Deep Research tools (comprehensive analysis):**
  - Claude Chat DR: deep scholarly analysis, boundary quality, convention audit
  - ChatGPT Pro DR: error pattern analysis, prompt engineering strategy, independent cross-check
  - Gemini DR: **STRONGEST when given correct files and prompt** (owner's assessment 2026-04-01). Needs file uploads or public repo. Never treat as fallback or inferior — it is a PRIMARY source equal to or above the other two DRs. Islamic study methodology, scholarly pedagogy, Arabic analysis
- For major milestones: dispatch ALL 6 in parallel, synthesize, resolve disagreements
- Gemini DR dispatch requires preparing a file bundle for upload (key files, excerpt samples, specific questions)
- Every major point in excerpting engine build MUST use all sources extensively
