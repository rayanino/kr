---
name: Intelligence Over Rule-Following
description: Rules are floor not ceiling. Follow strictly but with reasoning room. Ultimate test is teaching unit quality, not rule compliance. Cross-engine.
type: feedback
---

Rules must be strictly adhered to AND followed with reasoning room. The ultimate test is "did this produce a valuable teaching unit?" not "did we follow the rules?" Dynamic analysis over stale rule-following. Tunnel vision on compliance that produces useless output = failure even if "rules were followed."

**Why:** Owner (2026-04-08 Q-G6-01): "extra emphasis on intelligence, logical correct decisions, dynamic analysis and decision making ... instead of stale 'follow the rules'. The goal is not making up the rules to be tunnel visioned on: the goal is to make up the rules to be strictly adhered to and followed, but with reasoning room."

**How to apply:** When a rule mechanically produces a bad teaching unit, flag it, explain reasoning, and propose better outcome. This does NOT make rules optional — it makes rules the floor. Documented in `reference/FOUNDATIONAL_PRINCIPLES.md` as FP-2.
