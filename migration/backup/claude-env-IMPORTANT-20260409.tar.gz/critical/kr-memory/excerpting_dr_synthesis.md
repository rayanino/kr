---
name: Excerpting DR Synthesis — 5 Adversarial Reviews
description: What each of the 5 DR reviews uniquely found during session 2 hardening. Critical for understanding WHY each FP has specific clauses.
type: project
---

## The 5 DRs and Their Unique Contributions (2026-04-04)

Session 2 collected 5 independent adversarial reviews. Each found issues the others missed — validating the multi-coworker mandate.

| DR | Source | Unique Finding | Applied To |
|----|--------|---------------|-----------|
| DR-1 | ChatGPT, Batch 1 | FP-19 text mutation trap — inserting `[...]` into primary_text IS corruption | FP-19 display-layer constraint |
| DR-2 | Claude, Batch 1 | FP-5/FP-21 governance conflict + three-class error provenance (A/B/C) + genre-sensitive severity (isnād error = existential) | FP-5 three-class system, FP-21 genre map |
| DR-3 | ChatGPT, Batch 1+2 | Flag laundering / alarm fatigue — "visible" flags become invisible at scale | FP-21 no-study-surface + flag budget |
| DR-4 | Claude, Batch 1+2 | LLM decoy confession + severity deflation incentive + closed-loop self-validation | FP-19 materiality threshold, FP-21 severity rate floor |
| DR-5 | Claude, self-hardened | Rule A inter-phase contradiction + Rule B 3 exploits + Rule D 80% redundant + SPEC-prompt drift | Moved Rule A to CLASSIFY, removed D, tightened B |

## Key Concepts Introduced by DRs

- **Flag laundering** (DR-3): When flag volume causes alarm fatigue, "visible failure" collapses into de facto "silent corruption." Mitigated by no-study-surface rule and flag budget.
- **Decoy confession** (DR-4): LLM confesses trivial omissions while hiding significant ones. Mitigated by materiality threshold (>25 contiguous words).
- **Severity deflation** (DR-4): LLM under-classifies to avoid costly "existential" pathway. Mitigated by Bayesian prior (expect ≥5% medium-or-above flags per untested book).
- **Three-class provenance** (DR-2): Class A (engine-introduced → halt), Class B (source-inherited systematic like tashkeel → flag only), Class C (source-inherited idiosyncratic → quarantine volume).
- **Tashkeel phantom cascade** (DR-2): Without Class B, ~90% of Arabic prose triggers false halt because undiacritized text is ambiguous.

## DR Files (archived, committed)

All 5 at `engines/excerpting/reference/dr_reviews/DR{1-5}_*.md`

**How to apply:** When implementing or modifying any FP, check which DR contributed the specific clause being changed. The DR file has the full reasoning and Arabic examples. When writing new FPs, check all 5 DRs for relevant failure scenarios.
