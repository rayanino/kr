---
name: Taxonomy Deep Build Plan
description: Strategic plan for taxonomy engine — deep trees, unbiased placement, tree evolution, aqidah first. 15 sections in .ultraplan/.
type: project
---

Taxonomy engine deep build plan established 2026-04-07. Key architectural decisions:

1. **Tree evolution is MUST HAVE** — owner was emphatic: static trees cause knowledge corruption (excerpts bend to fit wrong structure). The v1 SPEC's "no tree evolution" must be revised.

2. **Unbiased placement** — Three-phase: (a) LLM reasons independently where excerpt belongs WITHOUT seeing tree, (b) match against tree, (c) if no match → propose tree growth with human gate.

3. **Deep trees with content-type sub-branches** — Topic → definition/proof/examples/opinions/conditions as tree nodes. Trees grow from ~200 to ~500-1000+ leaves per science.

4. **Aqidah priority #1** — Owner's top study science. Build first deep tree here.

5. **Questions before building** — Owner: "Ask me a thousand questions. Every question closes an ambiguity." Questionnaire BEFORE engine code.

**Why:** Owner said "INTELLIGENT TREE EVOLUTION SHOULD NOT BE A NICE TO HAVE... NOT HAVING THIS WILL RESULT IN CORRUPTION." The entire plan was restructured around this.

**How to apply:** Read `.ultraplan/` files at session start. Execute one section per session. Each session makes one piece bulletproof before moving on. 15 sections, 76 tasks, 9 batches.
