---
name: DR18 Norm Persistence Enforcement Infrastructure
description: ChatGPT DR report on why behavioral norms decay across LLM sessions (Lost-in-Middle, RLHF anti-priors) and 5 ranked enforcement mechanisms. 4 scripts built (S-09 to S-12), HR-24 added.
type: project
---

DR18 (ChatGPT Deep Research) analyzed 2026-04-06. Archived at `engines/excerpting/reference/dr_reviews/DR18_chatgpt_norm_persistence_enforcement.md`.

**Why:** Owner's two critical directives (autonomous operation + prompt-architect) were cosmetic — written in 5+ places but zero mechanical enforcement. DR18 provides the engineering framework to convert honor-system norms into gated infrastructure.

**How to apply:**
- 4 new scripts (S-09 to S-12) implement DR18's top 4 mechanisms
- HR-24: session must pass lint_session_norms.py before ending
- §0 item 1B: audit prior session before proceeding
- §7.2: Session Scorecard with quantitative Norm 1/Norm 2 metrics
- Hash-chain attestation (Mechanism 3) deferred to later — needs key management
- Total scripts in project: 12 (S-01 to S-12)
