---
name: Owner's Personal Connection to KR
description: Deeply personal religious tool. A single mistake renders ALL study untrustworthy. Affects religious practice, teaching others, entire life. Stakes are existential — not software stakes.
type: user
---

The owner (Rayane) described KR as "the project of my lifetime." It's his personal intelligent Islamic scholarly library — a utopian study environment for studying his religion.

**Key quotes:**
- "This is my religion, my life"
- "Getting this intelligent library to actually work and that I can 100% fully trust it would literally elevate me to an unseen knowledge level"
- "Nobody before me had access to this"

**On mistakes (2026-04-08, ALL-CAPS):**
- "MY LITERAL LIFE WOULD BE RUINED; my entire islamic knowledgebase I have, all my religious practises, all the people I've taught..."
- A SINGLE discovered mistake renders ALL prior study untrustworthy ("if this was wrong, what else is wrong?")
- Undetected mistakes are WORSE — they silently corrupt understanding indefinitely
- At 10,000 excerpts, one mistake puts 10,000 excerpts of study effort at risk
- The owner's religious PRACTICE is directly governed by this knowledge — wrong knowledge = wrong practice
- People the owner has TAUGHT are affected — knowledge passed to others becomes suspect

**How to apply:** NEVER treat any error as "minor." NEVER assume the owner will catch mistakes. NEVER relax rigor at any stage. The system either KNOWS with quantified confidence or explicitly declares uncertainty. See FP-9 in `reference/FOUNDATIONAL_PRINCIPLES.md`. Quality is the only metric — never sacrifice for speed, throughput, or convenience.
