---
name: Always dispatch ALL available coworkers on every major question
description: Never hold back a dispatch because "3 is enough." If 5 coworkers are available, use all 5. The owner pays for them specifically for this purpose. Each gets a unique complementary angle.
type: feedback
---

When a major question arises, dispatch ALL available coworkers immediately in the FIRST round. Do not wait to see if 3 responses are "enough" before considering a 4th or 5th.

**Why:** The owner explicitly called this out — "Something wrong with your understanding of max use of coworkers???" Claude DR was held back from the granularity question dispatch despite being the strongest scholarly reviewer, and the owner had to ask why. This wastes time and misses the point of having a full team.

**How to apply:**
- For ANY major design/architectural question: dispatch Codex + Gemini CLI + ChatGPT DR + Claude DR + Gemini DR (if available) simultaneously
- Each coworker gets a UNIQUE complementary angle (not the same prompt)
- Never reason "we already have 3 perspectives, that's enough" — the owner bought 5 tools, use all 5
- Present all dispatches in ONE message so the owner can start them all in parallel
- If a coworker can't access the repo (e.g., Gemini DR can't read GitHub), adapt the delivery (CLI instead), don't skip the coworker
