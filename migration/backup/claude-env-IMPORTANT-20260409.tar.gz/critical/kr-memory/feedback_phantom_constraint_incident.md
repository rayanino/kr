---
name: CRITICAL — Phantom Constraint Incident (1500-word cap)
description: A number appeared informally in a document and was treated as a hard constraint, driving quality-losing compression. Structural guardrails now in place. Every threshold must be traceable.
type: feedback
---

A "1500-word prompt cap" was never formally decided. It emerged from an informal note ("1484/1500") that was progressively treated as a hard constraint. An entire DR (DR21) was commissioned to solve the "problem" of exceeding this phantom limit. The prompt was compressed 45%, Gemini CLI found 2 quality gaps immediately, and the owner challenged the engineering judgment — explicitly stating loss of trust.

**Why:** The pattern is the most dangerous class of engineering error in this project: it looks like diligent work (research → compress → test) while actively harming output quality. The models handle 128K+ context — 1500 words was never a real limit.

**How to apply:**
1. Before treating ANY number as a constraint, ask: "Who decided this? When? Based on what data?" If the answer is "it appeared in a document," it is NOT a constraint.
2. Check `engines/excerpting/reference/CONSTRAINT_REGISTRY.md` — every threshold must have an entry with origin, calibration status, and risk level.
3. Follow `.claude/rules/constraint-origin-trace.md` — the rule that prevents this pattern.
4. Round numbers (50, 100, 500, 1000, 5000) are suspect until calibrated against real data.

**Guardrails deployed (2026-04-07):**
- CONSTRAINT_REGISTRY.md: 38 thresholds documented with origin + calibration status
- constraint-origin-trace.md rule: prevents informal numbers from becoming phantom constraints
- 3-coworker foundation audit: Explore agent (38 thresholds), Codex CLI (FP doctrine: 18 ALIGNED, 4 DRIFT), Gemini CLI (Arabic constraints: 8/10 UNSOUND)
