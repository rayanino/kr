---
name: taxonomy_session1
description: Taxonomy engine Session 1 (deterministic infrastructure) completion status and key decisions
type: project
---

Taxonomy engine Session 1 complete (2026-03-30). All deterministic infrastructure built.

**Why:** Last engine before v1 E2E pipeline. Session 1 builds all non-LLM logic; Session 2 adds prompts and LLM calls.

**How to apply:** Session 2 drops in an `LLMPlacementAdapter` implementing the `PlacementAdapter` Protocol. No restructuring needed — just implement `run_stage1()` and `run_stage2()` methods using `CLIInstructorAdapter`.

## Deliverables
- 6 source modules: tree_loader, placer, validator, writer, diagnostics, engine (~1,387 lines)
- 7 test files: conftest + 6 test files (~1,458 lines)
- 118 tests, 0 failures, pyright 0 errors
- All 5 science trees load: nahw(226), sarf(226), balagha(335), imlaa(105), aqidah(30) = 922 total

## Key Architectural Decisions
- **PlacementAdapter Protocol pattern**: placer.py defines a Protocol interface. Session 1 uses StubPlacementAdapter (raises NotImplementedError). Tests use MockPlacementAdapter (returns configurable scores). Session 2 adds LLMPlacementAdapter.
- **v0/v1 tree normalization**: Both YAML formats normalize to TreeNode dataclass. v0 (aqidah) has special rules: `__overview` double-underscore keys ARE children; single-underscore keys (except `_label`/`_leaf`) are metadata; top-level key is envelope.
- **D-023 merge pattern**: `{**excerpt, **additions.model_dump(mode="json")}` — taxonomy fields overwrite same-key upstream fields per collision policy.
- **Byte-identical verification**: After every file write, read back and verify primary_text matches exactly (T-1 defense).

## What Session 2 Must Do
1. Implement `LLMPlacementAdapter` in placer.py (or new file)
2. Build `build_stage1_prompt()` and `build_stage2_prompt()` — Arabic prompt construction
3. Wire CLIInstructorAdapter with model `anthropic/claude-opus-4`, timeout 600s
4. Add gold baseline tests (10-15 excerpts with known correct leaves)
5. Run a small pilot batch and evaluate accuracy
