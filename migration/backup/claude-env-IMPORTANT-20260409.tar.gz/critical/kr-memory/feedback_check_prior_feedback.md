---
name: Always check owner feedback before selecting excerpts
description: Before selecting excerpts for owner review, always read owner_feedback.jsonl to exclude previously reviewed excerpts and learn from prior verdicts
type: feedback
---

Before selecting excerpts for owner reader feedback, ALWAYS read `integration_tests/campaign_20260331/taysir/owner_feedback.jsonl` first. The owner already gave detailed feedback on specific excerpts — re-showing a previously REJECTED excerpt is a serious failure that wastes the owner's time and breaks trust.

**Why:** Session 19 selected Excerpt A (the talaq definition) which the owner had already rejected with extensive commentary explaining exactly what was wrong with it. The owner's prior feedback is the most valuable data in the project — ignoring it is inexcusable.

**How to apply:** Before ANY excerpt selection for owner review: (1) load owner_feedback.jsonl, (2) exclude all previously reviewed excerpt_ids, (3) read the prior verdicts and comments to understand what the owner considers good/bad quality, (4) select only from fresh, never-reviewed excerpts.
