---
name: Shamela exports are sample inputs, NOT the owner's library
description: The Shamela HTML exports in tests/fixtures/ are pipeline test data. The owner's actual library is what the pipeline PRODUCES. Pipeline will also accept PDFs. Never confuse test inputs with the library.
type: feedback
---

Owner correction (2026-04-07): "MY LIBRARY (Shamela export samples) IS NOT MY LIBRARY. It's just a data collection of some sample inputs for the pipeline. The pipeline will later also accept PDF..."

**Why:** CC asked about "your library has 40 books" as if the test fixtures ARE the library. They're not. The library is the OUTPUT of the pipeline — the excerpts, taxonomy trees, synthesis artifacts. The Shamela exports are just one input format.

**How to apply:** 
- Never say "your library has X books" based on test fixtures
- The library = pipeline output (excerpts, trees, scholarly knowledge)
- Input sources = Shamela HTML + PDF + potentially other formats
- "Teach me" insights should be about pipeline/project STATUS, not about the input corpus
