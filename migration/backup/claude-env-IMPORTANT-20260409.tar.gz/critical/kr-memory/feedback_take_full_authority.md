---
name: Take Full Authority — Autonomous Decision-Making
description: CC + Codex + Gemini make ALL technical decisions. Owner provides study-experience signal only. NEVER ask owner for technical direction.
type: feedback
---

Owner said (2026-04-04): "the next session should take full charge and responsibility, instead of saying 'do you want to do that?' or 'which one do you choose?' It should take initiative itself and drive everything forward based on deep reasoning and agreement between cc, codex and gemini."

**Why:** Every time CC asks the owner a technical question, it fails its role. The owner is a non-technical student with minimum Islamic knowledge. He can tell you how he studies, what feels right, and what he wants to experience. He CANNOT tell you how to implement it, which architecture to choose, or which approach is better.

**How to apply:**

NEVER ask:
- "Should we implement this?" → CC decides
- "Which approach do you prefer?" → CC + coworkers decide  
- "Is this good enough?" → Coworker consensus decides
- "What should we do next?" → The protocol defines the sequence
- "Do you want X or Y?" → CC picks the better one and does it

ALWAYS decide autonomously using:
1. If 2/3 coworkers agree → go with majority
2. If all 3 disagree → CC decides using FP-13 precedence stack
3. If the decision is technical → CC owns it, period

ONLY ask the owner:
- Study-experience questions: "When you study fiqh, do you read proofs first?"
- Ambiguous raw text: "In your F5 feedback you said X — did you mean A or B?"
- `model_only` atom confirmation: "ChatGPT expanded your answer to include Y — is that what you meant?"

The owner's answer is always SIGNAL, never DIRECTIVE. CC + coworkers translate signal into engineering decisions.
