---
name: Excerpting Engine Progress
description: Excerpting engine — 1006 tests, build COMPLETE, DR40 granularity calibration implemented. FP-23/24/25 added. Relationship links between split excerpts. Campaign rerun validated 5 structural fixes.
type: project
---

Excerpting engine absorbs the old passaging + atomization engines (architecture decision 2026-03-22).
Three internal phases: Phase 1 (deterministic assembly), Phase 2 (LLM classification/grouping), Phase 3 (metadata enrichment + consensus + validation).

## Current State (after Session 20, 2026-04-08)

- **SPEC:** COMPLETE + HARDENED (2900+ lines, 25 FPs in §1.1b, §6.1-§6.25 domain rules)
- **All 3 phases:** COMPLETE + HARDENED
- **Test count:** 1006 passed, 4 xfail, 0 failures
- **Prompt:** DR28 architecture (CONSTITUTION + progressive disclosure). DR40 rules (conditional evidence split, definition pair split, relationship links).
- **Branch:** `excerpting-foundations-hardening-20260404`
- **Key models:** Primary OpenAI GPT-5.4 (classify/group/enrich), Verify Anthropic Opus 4.6, Escalation Mistral Large

## Key Session 20 Changes (DR40, 2026-04-08)
- FP-13 re-ranked: leaf-atomicity promoted to #4, pedagogical packaging demoted to #5
- FP-23: relationship links between split excerpts (companion_definition, evidence_for, condition_for)
- FP-24: conditional evidence splitting (replaces unconditional "evidence stays with ruling")
- FP-25: definition pair splitting (لغة/شرعا must be separate units)
- §6.24 (DP-SPLIT-1) + §6.25 (EV-SPLIT-1) domain rules
- Contracts: RelationshipType enum, UnitRelationship model, related_units on TeachingUnit + ExcerptRecord
- I-TU-10 validation: bounds + self-ref checks for related_units
- _reindex_related_units() helper: remaps indices during merge, drops absorbed/self-ref/dupes
- 18 regression tests from 2 owner rejections (taysir talaq definition + ruling)

## Campaign Rerun (Session 19, 2026-04-08)
- 1,491 excerpts vs 1,283 baseline
- Sub-MV-1: 244 → 0 (PERFECT). SC FULL: 68.7% → 85.4%. Avg words: 74.8 → 123.0
- 5 Session 18 structural fixes validated. Grouping granularity untouched (addressed by DR40).

**How to apply:** Next session should run a targeted smoke test on taysir talaq chapter with updated prompts to verify LLM actually produces the expected splits and relationship links.
