---
name: Owner is the USER — never ask architecture questions
description: Owner corrected CC for asking implementation/architecture questions about the overnight system. CC should decide launch method, lid-close behavior, etc. with coworkers. Owner answers only usage-experience questions.
type: feedback
---

Owner explicitly said: "Don't ask me technical questions, this is a system implementation / architectural choice you and your coworkers are better at deciding. Look at it from the POV of the system, not me. I'M THE USER."

**Why:** CC asked 4 questions about the overnight system. 2 were valid (frequency, visibility — user experience). 2 were invalid (launch method, lid-close behavior — architecture decisions). The owner cannot and should not answer how to handle laptop lid closure or what CLI command to use.

**How to apply:** Before asking the owner ANY question, filter: "Can only the owner answer this, based on his EXPERIENCE using the library?" If the answer could be decided by CC + coworkers based on system quality, don't ask. Only ask about: reading experience, study habits, what confuses him, what he wants to see. Never ask about: technical implementation, architecture, error handling, data formats, system behavior.
