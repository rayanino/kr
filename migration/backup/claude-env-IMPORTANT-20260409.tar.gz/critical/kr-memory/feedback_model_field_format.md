---
name: "Agent model: Field Accepts Only Short Names"
description: "Claude Code agent frontmatter model: field accepts only short aliases (opus, sonnet, haiku) — NOT full API model IDs like claude-opus-4-6"
type: feedback
---

The `model:` field in Claude Code agent definition frontmatter (`.claude/agents/*.md`) accepts ONLY short model aliases:
- `opus` (not `claude-opus-4-6`)
- `sonnet` (not `claude-sonnet-4-6`)
- `haiku` (not `claude-haiku-4-5`)

**Why:** In the fix session (2026-03-17), the Architect's NEXT.md specified changing all `model: opus` to `model: claude-opus-4-6`. Pre-planning verification discovered that Claude Code only recognizes short names. This prevented 17 invalid edits that would have broken every agent file.

**How to apply:** If any task spec asks to update model strings to full API IDs, SKIP IT — the short names are correct. Verify by checking what existing agents use before making batch model changes.
