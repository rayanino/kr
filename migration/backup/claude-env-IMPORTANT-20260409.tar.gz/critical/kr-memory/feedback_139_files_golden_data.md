---
name: 139 Files Are Golden Data — Read ALL of Them
description: CRITICAL — The 8 F-collection directories contain 139 files of structured owner feedback, NOT just raw notes. Read EVERY file. Session 1 nearly lost this data by only reading 15/139 files.
type: feedback
---

The owner spent an ENTIRE WEEKEND (15+ hours) working with ChatGPT to produce 139 files of structured, machine-readable feedback in `engines/excerpting/chatgpt_f{1-8}_collection/`. These are NOT just raw notes + cleaned answers — they contain:

- Decision ladders (step-by-step reasoning)
- Nonnegotiables (absolute constraints → hard SPEC rules)
- Red-team tests (adversarial cases → must become pytest cases)
- Linking dependency analysis (specific Arabic words + referents + failure modes)
- Function placement analysis (where excerpts belong in taxonomy)
- Granularity analysis (split/merge decisions with rationale)
- Priority matrices (what matters most)
- Traceability (links every claim to owner signal)
- Open questions (unresolved issues needing attention)
- Hard judgments (calls needing validation)

**Why:** The owner said: "if any potential is lost because of this, I will burn down your servers." This is literally the most valuable input the project has ever received. Session 1 nearly wasted it by only reading ~15 of 139 files (the raw sources + cleaned answers), missing 90% of the structured analysis.

**How to apply:**
- At session start: verify ALL 8 collection directories exist and read the `ATOM_PROTOCOL.md`
- For EVERY atom: go back to the ORIGINAL collection file, don't just read the extraction summary
- Process atoms one at a time with ALL THREE coworkers (Codex CLI, Gemini CLI, DR)
- Each coworker gets ALL THREE research prompts (repo + scholarly + adversarial) = x3 research depth
- Never finalize an atom without 3 coworker reports
- The 81-atom extraction is a FLOOR, not a ceiling — the next session may find more by reading files the agent summarized
