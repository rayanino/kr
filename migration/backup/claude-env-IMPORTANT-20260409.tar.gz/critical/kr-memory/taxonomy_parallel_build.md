---
name: Taxonomy engine building in parallel — trees NOT trustworthy yet (2026-04-01)
description: Taxonomy engine is under active construction. Trees are NOT production-ready. Nahw base tree nearly final. Do not rely on taxonomy placement results until owner confirms trees are validated.
type: project
---

As of 2026-04-01, the taxonomy engine is being built in parallel with excerpting evaluation. Key status:

- Taxonomy engine: Session 1 DONE (118 tests, deterministic infrastructure), Session 2 pending (LLM prompts + gold baseline)
- Nahw base taxonomy tree: nearly final (owner building it)
- Other science trees: NOT started or NOT trustworthy yet
- Excerpting does NOT depend on taxonomy trees (VISION §5.2 taxonomy-independence rule)
- BUT: the deferred DR-2 decision (evidence-type splitting) depends on knowing whether evidence-type leaves exist in the taxonomy — this can only be answered once trees are finalized

**Why:** Owner explicitly noted "taxonomy trees ARE NOT TRUSTWORTHY yet." Any evaluation of excerpt placement or leaf-level comparison views must wait until trees are validated.

**How to apply:**
- Excerpting engine work proceeds independently (taxonomy-independent by design)
- Do NOT evaluate excerpt taxonomy placement until trees are confirmed
- The DR-2 pilot (deferred evidence splitting) should wait for taxonomy trees
- Nahw tree being nearly final means ibn_aqil excerpt evaluation can include placement testing soon
