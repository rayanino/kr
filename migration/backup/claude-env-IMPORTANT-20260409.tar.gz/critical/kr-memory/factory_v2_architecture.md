---
name: Factory v2 Architecture
description: KR Factory Roadmap v2 (2026-03-27) — GOVERNING documents for autonomous factory. 6 operating modes, CC Agent Teams, synthetic adversarial data, findings DB, 14-17 session build plan.
type: project
---

Three GOVERNING documents created 2026-03-27/28 after triple adversarial review (Claude Chat 7 CRITICAL + 9 HIGH, Claude Code 21 findings, GPT-5.4 10 failure modes):

1. `reference/FACTORY_ROADMAP_v2.md` — Setup plan (sessions 1-10, ~14-17 total sessions)
2. `reference/AUTONOMOUS_QUALITY_SYSTEM.md` — Ongoing operation (6 modes, synthetic data, findings lifecycle)
3. `reference/TEAM_ARCHITECTURE.md` — Agent collaboration (never solo, always a team)

## Key Architectural Decisions

- **D-F012:** WSL2 is the mandatory execution environment (Windows only invokes WSL via Task Scheduler)
- **D-F017:** CLI abstraction layer with per-CLI adapters (Claude Code, Codex CLI, Gemini CLI)
- **D-F018:** Structured response contract between CC and orchestrator
- **D-F020:** SPEC ambiguity escalation protocol (never silently resolve)
- **D-F021:** CC must NOT build what CC is evaluated by (benchmark independence)
- **D-F024:** Owner growth path is a prerequisite, not a side effect

## 6 Operating Modes (priority order)

```
FIX (known bugs) > BUILD (SPECs) > EVALUATE (owner review) > HUNT (default) > CROSS-ENGINE (weekly) > BENCHMARK (monthly)
```

HUNT is the default mode — the factory never idles. When nothing needs building or fixing, it generates synthetic adversarial Arabic data and runs it through the pipeline to find corruption.

## CC Agent Teams (primary collaboration)

All factory operations use Agent Teams (2-16 agents per team, peer-to-peer messaging). Every operation includes at least one cross-provider check (Codex or Gemini invoked by a teammate). Team compositions vary by mode: BUILD (4 teammates), HUNT (3), FIX (3), EVALUATE (2), BENCHMARK (1+subagents).

## Synthetic Adversarial Data System

Heart of the quality system. 7 threat templates (T-1 through T-7) + cross-engine + full-pipeline. Codex/Gemini generate test data (NEVER CC — same blind spots). CC processes it. Automated comparison against ground truth. Findings enter 7-stage lifecycle: DISCOVERED → CLASSIFIED → TRIAGED → FIXING → FIXED → VERIFIED → HARDENED.

## Build Plan Timeline

| Session | Content |
|---------|---------|
| 1 | Operational truth + doc reconciliation |
| 2 | CI/CD + policies + hook fixes |
| 2.5 | WSL setup (owner) |
| 3 | CLI abstraction + Gemini dispatch |
| 4 | Benchmark design (Codex+Gemini, NOT CC) |
| 4.5 | Synthetic data infrastructure + findings DB |
| 5 | Run benchmark + routing table |
| 6 | Orchestrator 6 modes + response contracts |
| 7 | Scheduler + recovery |
| 8 | Dashboard + human gate + findings UI |
| 9 | 15-point acceptance + hunt/fix cycle testing |
| 10 | Health monitoring + sustained hunting |

**Why:** The v1 roadmap had 21 findings from adversarial review (7 CRITICAL, 9 HIGH, 3 will-cause-failure). v2 addresses all of them with verified CLI capabilities and realistic constraints.

**How to apply:** All factory sessions reference these three documents as authority. The existing `scripts/overnight_orchestrator.py` (1,287 lines) is the starting point — extended, not rewritten.
