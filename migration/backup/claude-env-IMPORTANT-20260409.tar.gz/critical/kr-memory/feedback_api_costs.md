---
name: API costs are negligible for development
description: Full 5-package excerpting run costs €2.93 via OpenRouter API in 33 minutes. Use API for all development, CLI only for final permanent runs.
type: feedback
---

The API backend via OpenRouter is dramatically cheaper than expected. Full run data (2026-03-31):

| Package | Excerpts | Time | Cost |
|---------|----------|------|------|
| ibn_aqil_v1 | 19 | 3m | €0.32 |
| ibn_aqil_v3 | 44 | 14m | €1.08 |
| taysir | 28 | 8m | €0.78 |
| ext_39_masala | 22 | 4m | €0.34 |
| ext_46_qa | 20 | 5m | €0.41 |
| **TOTAL** | **133** | **33m** | **€2.93** |

Cost per excerpt: €0.022. Full 280-chunk production run estimate: €6-8.

**Why:** Previously assumed API would cost $292 per full run. That estimate was wrong — it was based on Claude Opus as primary for everything. With GPT-5.4 as primary via OpenRouter, costs are ~100x lower.

**How to apply:** ALWAYS use `--backend api` for development/testing. Use `--backend cli` only for final permanent production runs where cost is zero but speed doesn't matter. The $120 budget covers ~40 full runs.
