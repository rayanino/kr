---
name: DR18 Owner Decision Map Summary
description: Claude DR mapped 42 owner-dependent decisions across all 5 engines with critical path and tedious/summer classification
type: project
---

Claude DR (DR18, 2026-04-07) produced an exhaustive owner decision map. CC verification confirmed 26/31, corrected 2, found 11 gaps. Revised total: **42 owner-dependent decision points.**

**Critical path (blocks everything):**
1. SRC-D-004 (science scope ranking) → TAX-D-001 (tree formation) → SYN-D-001 (synthesis config)
2. SRC-D-010 (book priority) → normalization order → excerpting batch composition
3. PP-001 (muhaqiq list) → trust_tier → all downstream quality

**Why:** These 3 decisions cascade through all 5 engines. Until science scope is ranked, trees can't be finalized. Until book priority is set, normalization can't order processing. Until muhaqiq trust is established, quality signals are unreliable.

**How to apply:**
- ~5 hours of tedious collection across 5 sessions (Sessions A-E) in first 2-3 weeks
- ~20-30 hours of summer evaluation requiring real pipeline output
- 12 preferences are PERMANENTLY owner-dependent (never automate)
- 7 decisions are AUTOMATABLE after sufficient training data (100+ excerpt judgments, 50+ calibration pairs, etc.)
- First 4 critical-path items can be collected in a SINGLE 2-hour session

**Files:** `engines/excerpting/reference/dr_reviews/DR18_*` (4 files: report, verification, gaps, interview crossref)
