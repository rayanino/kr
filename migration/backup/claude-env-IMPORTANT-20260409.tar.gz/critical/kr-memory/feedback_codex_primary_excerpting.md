---
name: Codex preferred for excerpting engine
description: Owner strongly prefers Codex/GPT-5.4 over Claude for excerpting - Claude burns through subscription at unfathomable rate
type: feedback
---

Use Codex (GPT-5.4 via `codex exec`) as the primary model for the excerpting engine pipeline, NOT Claude.

**Why:** Claude CLI burns through the user's subscription quota at an extreme rate during batch processing. The excerpting engine makes many LLM calls per chunk (classify, group, enrich, verify) and Claude's rate limits make it unusable for this volume. The user expressed genuine frustration: "I genuinely hate Claude to be in the excerpting engine."

**How to apply:** When configuring excerpting runs, set CLASSIFY_MODEL, GROUP_MODEL, and ENRICH_MODEL to `openai/gpt-5.4`. Keep Claude for lower-volume roles (verify, escalation tiebreak) where it won't hit rate limits. Quality must not be sacrificed — monitor self-containment, scholar resolution, and scholarly function distributions.
