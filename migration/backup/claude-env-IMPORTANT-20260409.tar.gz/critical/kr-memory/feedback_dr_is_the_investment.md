---
name: CRITICAL — DR is the #1 investment. System uses it far too little. Summer blocker if not done now.
description: Owner's strongest frustration: not enough Deep Research deployed. DR takes 10min-1hr per prompt and is too slow for summer. The autonomous system MUST maximize DR usage before July. CC thinking alone is insufficient.
type: feedback
---

Owner ALL-CAPS (2026-04-07): "PLEASE UNDERSTAND AND INSIST TO DEATH ON USING THE DR; IT IS EXTREMELY STRONG AND WILL GENUINELY ELEVATE THIS PROJECT. BUT IT TAKES TIME TO GENERATE, WHICH IS A MAJOR SLOWER IN THE SUMMER!!!!!!! PROBABLY THE BEST INVESTMENT OF TIME!!!!!!!!!!!!"

Also: "Not enough Deep Research to solve problems; it's always CC alone thinking, or at best CC with the CLI coworkers."

**Why:** DR (ChatGPT/Claude/Gemini Deep Research mode) produces research that CC cannot replicate — it accesses web sources, reasons deeply over documents, and produces multi-thousand-word analyses. But each prompt takes 10-60 minutes of real time (owner relay + DR processing). In summer when every hour counts, DR becomes a bottleneck.

**How to apply:**
1. The autonomous system's PRIMARY mission: generate and queue DR prompts at maximum throughput
2. Every unresolved question, design decision, or research gap → generate a DR prompt
3. Owner relays 10-20/day → 830-1660 DRs before summer
4. CC should NEVER conclude major analysis without DR backing. "CC alone thinking" is the failure mode.
5. The DR relay queue should always have prompts ready. If the queue is empty, the system has failed to identify research needs.
6. This is the owner's #1 frustration and #1 investment priority.
