---
name: Coworker Orchestra + Session Intelligence
description: Git-native coworker coordination system (.kr/runtime/) with per-worker leases, unified cost tracking, dispatch commands, and hook health dashboard
type: project
---

## Coworker Orchestra + Session Intelligence (2026-04-01)

Built a git-native coordination layer under `.kr/runtime/` for Claude Code + Codex CLI + Gemini CLI.

**Why:** The three coworkers worked in silos with fragmented cost tracking, no shared decision trail, and manual session continuity. Codex and Gemini were both consulted during design and independently recommended the git-native approach over background daemons.

**How to apply:**
- **Shared state:** `.kr/runtime/` has per-worker leases, events.jsonl, cost_events.jsonl, session_context.json
- **All writes** go through `python .kr/scripts/kr_state.py` (atomic, schema-validated)
- **Commands:** `/review-with-codex`, `/review-with-gemini`, `/consensus-3way`, `/hook-health`
- **Scripts:** `kr_state.py` (writer), `kr_validate.py` (validator), `kr_cost.py` (aggregator), `kr_resume.py` (context builder), `kr_fanout.py` (parallel dispatch), `kr_hook_health.py` (dashboard)
- **Hooks enhanced:** prompt-context.sh (coworker state + cost warnings), pre-compact-checkpoint.sh (serializes to session_context.json), post-compact-recovery.sh (structured restore)
- **Gemini control plane:** `.gemini/hooks.json` + `.gemini/hooks/session_start.py`
- **Human-authoritative layer** (CHARTER, ACTIVE, HANDOFF, DECISIONS) is unchanged
