---
name: Verify Fixture Fidelity Before Implementing Against Them
description: Hand-crafted test fixtures often diverge from real data format — verify against reference documentation before writing implementation code.
type: feedback
---

Before implementing against hand-crafted test fixtures, verify the fixture matches the real data format. Hand-crafted fixtures often diverge from production data in subtle ways that cause false implementation decisions.

**Why:** In Session 2, the ibn_aqil fixture had a PageNumber span on the metadata page (real Shamela metadata pages have NO page number). This led to implementing page-number removal logic that wouldn't have been needed for real data. Fixture 13 used Western digits instead of Arabic-Indic, requiring regex expansion. Both were fixture bugs, not SPEC requirements.

**How to apply:** When a fixture's HTML structure doesn't match the reference documentation (SHAMELA_HTML_REFERENCE.md for Shamela, ABD code patterns for behavior), fix the fixture FIRST. Don't add defensive code to handle fixture quirks that don't exist in real data.
