---
name: No drift from active mission
description: When building system X, do NOT mix in work on system Y even if "the data just arrived." One mission per session. Owner caught Session 14 drift.
type: feedback
---

Do not mix missions within a session. If the active mission is "build the autonomous system," every task must serve that mission. Even if DR data arrives that could resolve excerpting SPEC open questions, defer it — it belongs in a hardening session, not an autonomous system session.

**Why:** Session 14 was supposed to build the autonomous system. Instead, 1 of 4 tasks was excerpting SPEC work (OQ-001-004), and verification rounds consumed time that should have gone to the dashboard. The owner called it "disappointing."

**How to apply:** At session start, name the mission. Before every task, ask: "Does this serve the mission?" If no, log it as deferred work in NEXT.md and move on. The dashboard — the owner's interface — should have been built before developer tools (gap scanner, response processor).
