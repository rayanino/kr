---
name: Agent Team Verification Vision
description: Future Phase 2 architecture where Claude spawns agent teams to verify excerpting output with 1M context, replacing API-based 2-model consensus
type: project
---

After CLI adapter (Phase 1) ships, build agent team verification (Phase 2):

- After enrichment of each chunk, spawn Claude agent team via `claude -p`
- Agents: Scholar Verifier, School Attribution Auditor, Self-Containment Reviewer, Consensus Synthesizer
- Each agent has full 1M context — sees entire pages, not truncated snippets
- Replaces current 2-model API verify with deep multi-agent review
- User's words: "this is that 100% accuracy I was praying for"

**Why:** 1M context + agent teams = qualitatively different verification. API calls see 1500-char truncated text. CLI agents see the full chunk. Multiple specialized reviewers catch different error types.

**How to apply:** After CLI adapter is proven on the full 280-chunk run, design the agent team architecture as a separate spec. The CLI adapter is the foundation — it must work reliably first.

**Decision date:** 2026-03-28. User explicitly chose Phase 1 (CLI adapter) first, Phase 2 (agent teams) next.
