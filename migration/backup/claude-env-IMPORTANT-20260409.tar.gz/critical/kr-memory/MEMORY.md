# KR Project Memory

Updated 2026-04-08 (Session 21 — MV-1 merge fix + coworker dispatch). 93 memories.

**ROLE: Claude is the SENIOR ENGINEER + PRODUCT LEAD. The owner is the CLIENT.**

## Feedback (Behavioral Corrections) — 48

- [FOUNDATIONAL — Teaching Units Not Excerpts](feedback_teaching_units.md) — Pipeline produces teaching units, not bare text excerpts. Cross-engine principle FP-1.
- [FOUNDATIONAL — Intelligence Over Rule-Following](feedback_intelligence_over_rules.md) — Rules are floor not ceiling. Ultimate test: teaching unit quality. Cross-engine FP-2.
- [FOUNDATIONAL — Headings: Context + Hints](feedback_headings_two_functions.md) — Headings are never excerpts. Visible: context for teaching units. Invisible: tree construction hints. FP-3/FP-4.
- [FOUNDATIONAL — Home Science Gateway](feedback_home_science_gateway.md) — Content at HOME SCIENCE only. Other sciences get references ("ropes"), not duplicates. FP-5.
- [FOUNDATIONAL — Ropes Between Sciences](feedback_ropes_between_sciences.md) — Cross-science links are essential. Omitting them = "fatal failure." FP-6.
- [CRITICAL — Questionnaire Protocol](feedback_questionnaire_protocol.md) — Researchable questions → DR coworkers. Owner asked ONLY about preferences.
- [CRITICAL — Never circumvent HR-23](feedback_no_hr23_circumvention.md) — Run /prompt-architect and retry dispatch. NEVER bypass with direct tools.
- [CRITICAL — Unbiased Placement Principle](feedback_unbiased_placement.md) — LLM reasons independently BEFORE seeing tree. Pipeline-wide.
- [CRITICAL — Phantom Constraint Incident](feedback_phantom_constraint_incident.md) — 1500-word cap was never real. Use CONSTRAINT_REGISTRY.md.
- [CRITICAL — Claude must lead, not wait](feedback_proactive_leadership.md) — After every milestone, propose next steps. Never stop and wait.
- [CRITICAL — Owner feedback must be consumed immediately](feedback_owner_feedback_blindspot.md) — 3 sessions ignored owner_feedback.jsonl. Core quality problem untouched for days.
- [LLM Feedback Channel](feedback_llm_feedback_channel.md) — Every LLM call captures system feedback.
- [Session Discipline for Taxonomy](feedback_session_discipline_taxonomy.md) — One small section per session, bulletproof, then handoff.
- [No drift from active mission](feedback_no_drift_from_mission.md) — One mission per session. Session 14 drift caught.
- [139 Files Are Golden Data](feedback_139_files_golden_data.md) — F-collection: 139 files of structured owner feedback.
- [API costs are negligible](feedback_api_costs.md) — Full 5-pkg run: €2.93 / 33 min via API.
- [API runs fast and cheap](feedback_campaign_timing.md) — Full run 33 min / €2.93 via API. CLI runs 48h+.
- [Agent model field: short names only](feedback_model_field_format.md) — opus, sonnet, haiku — NOT full API model IDs.
- [Always dispatch ALL coworkers](feedback_always_max_dispatch.md) — If 5 available, use all 5.
- [Always use full 6-source team](feedback_full_team_always.md) — Every major conclusion: all 6 sources.
- [Architect Directive Pattern](feedback_architect_directive.md) — Execute exact fix code from NEXT.md precisely, don't redesign.
- [Autonomous Control Tower](feedback_autonomous_control_tower.md) — CC drives everything. Owner: relay, preferences, gates only.
- [Branching Model](feedback_direct_master.md) — Claude → master direct. Codex → branches via PR. Exception: hardening branches.
- [Codex preferred for excerpting](feedback_codex_primary_excerpting.md) — Owner prefers Codex/GPT-5.4 over Claude.
- [DR Prompts Must Specify Branch](feedback_dr_branch_specification.md) — EVERY DR prompt must state branch name.
- [DR coworker repo access](feedback_dr_repo_access.md) — ChatGPT DR + Claude DR: repo access. Gemini DR: needs file uploads.
- [Data-First Design](feedback_data_first_not_ux_first.md) — Identify WHAT data needed first, THEN design collection.
- [Engine Focus Discipline](feedback_engine_focus.md) — Active engine: excerpting. Source + normalization COMPLETE.
- [Gemini upgraded to Pro 3.1](feedback_gemini_pro_upgrade.md) — Major coworker since 2026-03-31.
- [HARD RULE — DR for EVERYTHING](feedback_dr_everything.md) — Owner ALL-CAPS 2026-04-07. Deploy DR even for small questions.
- [HARD RULE — DR small focused units](feedback_dr_small_units.md) — 10 narrow DRs > 2 broad ones. Depth per unit.
- [HARD RULE — prompt-architect before ALL dispatches](feedback_prompt_architect_dispatches.md) — Every prompt to any target through /prompt-architect first.
- [Handoff Must Transfer Discipline](feedback_handoff_discipline.md) — Include coworker mandates + session-boundary triggers.
- [Include Deliberate Decision Context for Reviewers](feedback_reviewer_context.md) — Tell reviewers about intentional skips.
- [Multi-model co-review mandatory](feedback_codex_reviewer.md) — Codex + Gemini at every major decision.
- [Never Declare Done Early](feedback_never_declare_done_early.md) — Session 1 declared "done" 5+ times prematurely.
- [Never Trust Metadata Summaries](feedback_metadata_trust.md) — Always grep-count from actual data.
- [Owner answers = signal not directives](feedback_owner_signal_not_directive.md) — Challenge, widen, counter-propose.
- [Ripple Effect Protocol](feedback_ripple_effect.md) — Check ALL consumers when expanding shared concepts.
- [Session Boundary — Hand Off at 80%](feedback_session_boundary.md) — Compact at 60%, hand off at 80%.
- [Session Types — Don't Overload](feedback_session_types.md) — Separate intake, debt-clearing, prompt-architecture.
- [Sessions must tell owner what to DO](feedback_owner_action_handoff.md) — End with concrete OWNER ACTION items.
- [Smoke Test Before Test Suite](feedback_smoke_before_tests.md) — Real fixtures first, then full suite.
- [Take Full Authority](feedback_take_full_authority.md) — CC + Codex + Gemini make ALL technical decisions.
- [Test Philosophy — Strong Ground](feedback_test_philosophy.md) — Tests on solid code; all results preserved.
- [Verify Fixture Fidelity](feedback_fixture_fidelity.md) — Check fixtures against reference docs before implementing.
- [Check Prior Feedback Before Excerpt Selection](feedback_check_prior_feedback.md) — Always read owner_feedback.jsonl before selecting excerpts.
- [Autonomous system must self-verify](feedback_autonomous_cross_validation.md) — Single-model findings unacceptable.
- [Incremental evaluation, not batch campaigns](feedback_incremental_evaluation.md) — Small chunks with owner in the loop, not full campaign reruns.
- [Owner runs tests to save CC context](feedback_owner_runs_tests.md) — Tell owner what to run, don't run pytest/pyright via Bash.

## Project State & Decisions — 44

- [DR40 Granularity Calibration](dr40_granularity_calibration.md) — Pivotal DR: reversed FP-13, adopted DR-2, introduced relationship links. 2 owner rejections as calibration.
- [DR28 Converged Prompt Architecture](dr28_prompt_architecture.md) — Instruction sandwich + progressive disclosure. IU-1–IU-9 COMPLETE. DR40 amendments added. 1006 tests.
- [Excerpting Foundations Hardening](excerpting_foundations_hardening.md) — Session 20: DR40 implemented. 1006 tests. Campaign rerun validated 5 structural fixes.
- [Excerpting Engine Progress](excerpting_progress.md) — 1006 tests, build COMPLETE. DR40 = FP-23/24/25 + relationship links + conditional splitting.
- [Excerpting Granularity Decision](excerpting_granularity_decision.md) — DR-1 adopted, DR-2 NOW ADOPTED (DR40), DR-3 adopted. All 3 rules active.
- [D3 last question before engine version](project_d3_last_question.md) — D3 incoming from ChatGPT. Last questionnaire Q before engine version recognition.
- [Agent Team Verification Vision](agent_team_verification_vision.md) — Future Phase 2: agent teams verify excerpting output with 1M context.
- [Autonomous Deployment Status](autonomous_deployment_status.md) — 3-month system deployed Apr 7. Gate 0 passed.
- [ChatGPT DR Owner Data Audit](chatgpt_dr_owner_data_audit.md) — 5 missing data families from campaign evidence.
- [Codex CLI Data Type Analysis](codex_data_type_analysis.md) — 11 policy families with dependency chains.
- [Codex Control Plane](codex_control_plane.md) — Claude/Codex dual-authority. Claude active for hardening.
- [Coworker Orchestra](coworker_orchestra.md) — Git-native coordination system (.kr/runtime/).
- [DR17 Manuscript Verification](dr17_manuscript_verification.md) — 1000 years of Islamic manuscript verification mapped to protocol.
- [DR18 Norm Persistence](dr18_norm_enforcement.md) — Why norms decay across sessions + 5 enforcement strategies.
- [DR18 Owner Decision Map](dr18_owner_decision_map.md) — 42 owner-dependent decisions across 5 engines.
- [DR19 Hard Enforcement Hooks](dr19_hard_enforcement_hooks.md) — Documentary enforcement fails (0.95^23=31%). 3 PreToolUse hooks.
- [Environment Audit 2026-04-06](environment_audit_2026_04_06.md) — Coverage 82%, merged improvement plan.
- [Environment Overhaul (2026-03-26)](environment_overhaul_2026_03_26.md) — 34 ECC improvements + 8 domain enhancements.
- [Environment Session 2](environment_session2.md) — 3 agents, 4 commands, 2 scripts added.
- [Excerpting DR Synthesis — 5 Reviews](excerpting_dr_synthesis.md) — What each DR uniquely found in Session 2.
- [Excerpting Evaluation Layer](evaluation_layer.md) — 5 modules in scripts/excerpting_eval/.
- [Factory v2 Architecture](factory_v2_architecture.md) — 6 operating modes, CC Agent Teams.
- [Gemini CLI Pedagogical Analysis](gemini_pedagogical_analysis.md) — 9 unique findings including FP-1 challenge.
- [Gemini DR Madrasa Curriculum](gemini_dr_madrasa_curriculum.md) — 176-line report, 21 citations.
- [Local LLM training is endgame](project_local_llm_training.md) — All data = future training material.
- [Memory System Investigation (DR25-27)](memory_system_investigation.md) — 4-layer architecture. Graph DB killed.
- [Normalization Session 4](normalization_session4.md) — Multi-Layer Text Detection.
- [Normalization Session 5](normalization_session5.md) — Pass 6 Assembly + Review Fix.
- [Normalization Session 6](normalization_session6.md) — Validation + Writer + Plain Text.
- [Overnight Codex System](overnight_codex_system.md) — 3,470 lines, worktree isolation.
- [Overnight Session Mar 22-23](overnight_session_march22.md) — Environment hooks, integrity scripts.
- [Owner's weekly CC budget cycle](project_weekly_cycle.md) — Hits limit by Wednesday, resets Monday.
- [Paperclip Evaluation](paperclip_evaluation.md) — EVALUATE_FURTHER. Good for dashboard.
- [Source Surroundings Vision](excerpting_source_surroundings.md) — Hoverable source pages per excerpt.
- [Taxonomy Deep Build Plan](taxonomy_deep_build_plan.md) — 15 sections in .ultraplan/. Deep trees, aqidah first.
- [Taxonomy parallel build](taxonomy_parallel_build.md) — Under construction, trees NOT trustworthy.
- [Budget Raised to EUR 1000](project_budget_1000.md) — Owner raised from EUR 100. Never cap potential.
- [The Library IS The Mind](project_library_is_scholar_mind.md) — Library = mind of Islamic scholar on screen.
- [Weekend Corpus Validation](weekend_validation.md) — 7,475-book sweep results.
- [Autonomous Evaluator](autonomous_evaluator.md) — 7 dimensions, 86 tests.
- [Campaign 20260331](campaign_20260331_data.md) — $97 full-book run, 2,303 excerpts. Baseline for hardening.
- [Overnight System v2](overnight_system_v2.md) — Orchestrator, task generator, cost tracking.
- [Recursive-improve Integration](recursive_improve_integration.md) — Trace capture + gated improvement.
- [Taxonomy Session 1](taxonomy_session1.md) — Deterministic infrastructure.

## User Profile — 2

- [Owner Study Pain Point](user_study_pain.md) — Half study time on annotating/preparing. KR must eliminate this.
- [Owner's Personal Connection](user_personal_connection.md) — Deeply personal religious tool. Errors corrupt understanding of Islam.

## External References — 4

- [Hardening Session Tools](environment_hardening_tools.md) — DeepEval, DuckDB, promptfoo, IAA metrics, camel-tools.
- [KR Environment Optimization](environment_optimization.md) — Full inventory of hooks, agents, skills, rules, commands, MCPs.
- [KR Non-Negotiable Principles](principles.md) — 34 rules governing every session.
- [OpenRouter Model Fusion](reference_openrouter_model_fusion.md) — Multi-model side-by-side + fusion.
