---
name: Autonomous system must self-verify with coworkers
description: Single-model findings from overnight runs are unacceptable. The system must dispatch Gemini CLI (or another coworker) automatically to cross-validate before marking findings as confirmed.
type: feedback
---

The autonomous system (launch_autonomous.py → orchestrator → bridge) currently runs Codex tasks and ingests findings from a single source. This violates the project's no-single-model-conclusion rule (D-041, OPS-DEC-006).

**Why:** Owner pointed out (2026-04-08) that the system itself should use coworkers rigorously as a pair of fresh eyes — not just run Codex alone and mark findings as PRELIMINARY. The cross-validation should be built into the pipeline, not done manually in a follow-up session.

**How to apply:** The bridge (`codex_kb_bridge.py`) or a new post-bridge step should automatically dispatch Gemini CLI (`gemini -p`) to verify HIGH/CRITICAL findings before they enter the KB as confirmed. Codex-only findings should be marked PRELIMINARY in the KB itself, and the dashboard should show verification status (PRELIMINARY vs CONFIRMED vs DISPUTED).
