---
name: Data-First Design, Not UX-First
description: When designing data collection systems, identify WHAT data is needed first (with coworkers), THEN design HOW to collect it. Owner corrected CC for inverting this.
type: feedback
---

When designing feedback collection or data intake systems, ALWAYS start with "what data does the pipeline need?" (an engineering question requiring coworker input) BEFORE designing "how should the owner provide it?" (a UX question).

**Why:** On 2026-04-06, CC designed a three-channel feedback system optimized for owner comfort (daily reviews, deep questions, calibration) WITHOUT first identifying what data the pipeline actually needs. The owner caught this: "Let's stop looking at 'can the owner handle this' and look at 'we are in the summer, what is the best data-starting point'." He called it "disappointing" and noted CC didn't dispatch coworkers first despite being told to.

**How to apply:** For any data collection design:
1. First: dispatch coworkers to identify WHAT data is needed (engineering question)
2. Second: synthesize findings into a complete data inventory
3. Third: classify data by difficulty (tedious vs non-tedious)
4. Fourth: ONLY THEN design collection mechanisms optimized for the owner
Never skip to step 4. The owner's UX preferences constrain the HOW, not the WHAT.
