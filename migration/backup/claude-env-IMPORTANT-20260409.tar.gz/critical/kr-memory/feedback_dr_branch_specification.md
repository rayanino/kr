---
name: DR Prompts Must Specify Branch
description: EVERY DR relay prompt must explicitly state the branch name. ChatGPT DR and Claude DR default to master if not specified, which has outdated code.
type: feedback
---

EVERY DR relay prompt that references the rayanino/kr repository MUST explicitly state: "branch: excerpting-foundations-hardening-20260404" (or whatever the active branch is at the time).

**Why:** ChatGPT DR and Claude DR default to the repo's default branch (master) when no branch is specified. The active hardening work lives on a feature branch. Without the branch specification, DRs read outdated protocol versions and produce findings against the wrong code. The owner caught this — it almost caused 3 DR sessions to analyze the wrong files.

**How to apply:** Before writing ANY DR relay prompt, check `git branch --show-current` and include the result in the prompt. Format: "Read from the rayanino/kr repository, branch `[BRANCH_NAME]` (not master):" at the top of every DR prompt. For Gemini DR (file uploads), this doesn't apply since files are uploaded directly.
