---
name: Smoke Test Real Fixtures Before Writing Test Suite
description: Run quick smoke tests on real fixtures immediately after implementing a module, before writing the full test suite — catches structural bugs early.
type: feedback
---

After implementing a major module, run a quick smoke test on real fixtures BEFORE writing the test suite. This catches structural issues (wrong output shape, missing transformations, encoding errors) early — before they propagate into dozens of failing tests.

**Why:** In Session 2 (Shamela Passes 1-3), a 5-line smoke test on ibn_aqil and multi-volume fixtures immediately caught: (1) page number text leaking into primary_text, (2) Western digit page numbers not matching regex. Without this early check, the 65-test suite would have had ~20 widespread failures requiring investigation one at a time.

**How to apply:** After writing the main implementation file and before writing `test_*.py`, run the NEXT.md verification smoke tests (usually 2-3 quick Python one-liners that parse a fixture through the pipeline and print key fields). Fix any issues found, THEN write the full test suite against working code.
