---
name: Environment Audit 2026-04-06
description: Debiased two-session environment audit — coverage baseline (82%), tool activation, merged improvement plan with 17 gaps across 8 dimensions
type: project
---

# Environment Audit (2026-04-06)

## What Was Done

Debiased two-session audit: Session 1 (2026-04-04) breadth-first, Session 2 (2026-04-06) depth-first. Independent analyses merged.

**Why:** Owner mandate F1 ("ANYTHING that can be beneficially used MUST be identified") and F7 ("no limiting factor").

## Key Finding: 12 of 13 Installed Tools Were UNUSED

camel-tools, hypothesis, mutmut, pytest-xdist, coverage, transformers+torch, scikit-learn, promptfoo, repomix, ace-framework, fastmcp — all installed, zero imports. Only recursive-improve was actually used.

**How to apply:** Before installing any new tool, check if an existing installed tool already covers the need. Wire new tools into hooks/commands/CI on install day.

## First-Ever Coverage Baseline

**Excerpting engine: 82% overall (914 tests pass)**

| Module | Coverage | Note |
|--------|----------|------|
| phase3_deterministic.py | 98% | Strongest |
| phase1_assembly.py | 94% | Strong |
| parallel_orchestrator.py | 56% | Needs work — concurrency layer |
| tracer.py | 0% | Completely untested (possibly dead code) |

Run: `pytest engines/excerpting/tests/ --cov=engines/excerpting/src --cov-branch --cov-report=term-missing`

## Tools Activated This Session

1. **pytest-cov** — installed, config in pyproject.toml, baseline established
2. **DeepEval** — installed, test_llm_eval.py with 3 GEval metrics (boundary, self-containment, speaker-role)
3. **DuckDB** — installed, verified querying COST_LOG.json works
4. **promptfoo** — config created at engines/excerpting/promptfooconfig.yaml
5. **IAA metrics** — scripts/measure_consensus_quality.py with Cohen's kappa
6. **mutmut** — config added to pyproject.toml
7. **camel-tools** — verified working (tokenization, normalization, dediac). Upgrade blocked by C++ deps on Windows.

## context-mode Plugin: DO NOT INSTALL

Real tool (6,600 stars) but conflicts with KR: WebFetch interception breaks agents, hook collision with 30 KR hooks, SQLite crash bug, CVE attack surface, unverified "3-hour" marketing claim. KR's existing compaction infrastructure (/smart-compact, pre/post-compact hooks) already solves the problem.

## Merged Plan Location

Full plan: `reference/handoffs/environment_merged_plan_2026-04-06.md`
Prior session research: `reference/handoffs/environment_prior_session_research.md`

## MCP Cleanup Needed (owner action)

Dead weight to remove: exa (duplicates Tavily), plugin:context7 (duplicate), fetch (failed), office-word (failed), codex MCP (failed).
