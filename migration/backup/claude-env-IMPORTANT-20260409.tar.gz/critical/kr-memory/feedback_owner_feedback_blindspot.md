---
name: CRITICAL — Owner feedback files must be consumed immediately
description: 3 sessions (17-19) saw the owner_feedback.jsonl pointer in NEXT.md and none opened the file. The core quality problem went unaddressed for 3 sessions.
type: feedback
---

Owner feedback files (owner_feedback.jsonl) MUST be consumed in the FIRST session after they appear. Not the second. Not the third. The FIRST.

**Why:** The owner reviewed 2 taysir excerpts on 2026-03-31 and wrote detailed rejection commentary in `integration_tests/campaign_20260331/taysir/owner_feedback.jsonl`. NEXT.md pointed to this file. Sessions 17, 18, and 19 all saw the pointer and none opened the file. The campaign rerun in Session 19 reproduced the rejected excerpt BYTE-IDENTICAL — the 5 structural fixes addressed different problems, not the grouping granularity the owner actually complained about.

**How to apply:** At every session start, after reading NEXT.md: (1) check if any owner_feedback.jsonl files exist in integration_tests/, (2) if they contain unaddressed feedback (no corresponding SPEC/prompt changes), that becomes the #1 priority — above campaign reruns, above structural fixes, above everything else. Owner feedback is the most expensive signal in the project (costs owner time and attention). Ignoring it is the most wasteful failure mode.
