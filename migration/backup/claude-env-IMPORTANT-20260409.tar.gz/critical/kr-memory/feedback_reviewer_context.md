---
name: Include Deliberate Decision Context When Dispatching Reviewers
description: Code reviewers need to know about intentionally skipped items or deliberate deviations, otherwise they generate false positive CRITICAL findings.
type: feedback
---

When dispatching code review agents, always include context about:
- Items deliberately skipped and WHY
- Intentional deviations from the task spec and WHY
- Pre-planning discoveries that changed the scope

**Why:** In the fix session review, a reviewer flagged Fix Group N (model string updates) as CRITICAL missing because they didn't know it was intentionally skipped after discovering the model: field only accepts short names. This wasted review attention on a false positive.

**How to apply:** In every code review dispatch prompt, add a "Deliberate Decisions" section listing anything that was intentionally NOT done and the reason.
