---
name: Ripple Effect Protocol for Shared Concepts
description: When expanding any shared concept (enum, verdict, status, classification), check ALL consumer files — not just the definition site. Prevents output template gaps.
type: feedback
---

When adding, removing, or renaming a value in any shared concept (enum, verdict, status, classification, error code), you MUST check every file that references that concept.

**Why:** In the fix session (2026-03-17), adding UNVERIFIABLE to the verdict system updated definitions and comparison tables but missed the output format templates in verifier-a.md and verifier-b.md. The gap was only caught by independent code review, not by 3 rounds of self-review.

**How to apply:** Before committing any shared-concept change, run:
1. Grep for the concept name across all agent definitions, reference docs, and code
2. For each file found, verify the new value appears in ALL relevant contexts (definitions, tables, templates, examples, documentation)
3. Specifically check: output format templates, comparison/mapping tables, validation logic, test expectations, summary tables, and documentation examples
