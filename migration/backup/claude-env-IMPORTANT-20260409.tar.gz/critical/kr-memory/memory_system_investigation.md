---
name: Memory System Investigation (DR25-DR27)
description: 6-source investigation of ideal KR memory architecture. 4-layer result. Graph DB killed by Gemini CLI. Kunnash concept from Gemini DR. Layer 1 (AGENTS.md) implemented 2026-04-07.
type: project
---

## Investigation: Ideal Memory System for KR (2026-04-07)

6-source parallel investigation triggered by evaluating mempalace (github.com/milla-jovovich/mempalace).

### Sources and Key Findings

| Source | DR# | Key Finding |
|---|---|---|
| Claude DR | DR25 | 3 critical failures: 200-line ceiling, 6.3% retrieval, cross-agent blackout |
| ChatGPT DR | DR26 | Two-plane architecture: append-only history + curated doctrine. Event sourcing. Found 5-vs-7 engine contradiction. |
| Gemini DR | DR27 | Islamic scholarly traditions: Kunnash (student notebook), Ijazah (certification), Sanad (provenance), Ta'liqat (non-destructive layering), Ishkalat (uncertainty as pedagogy) |
| Gemini CLI | — | REFUTED graph DB, flat files optimal for current stage, academic patterns premature |
| Codex CLI | — | AGENTS.md verified, 32KiB configurable default, Basic Memory viable, Codex SQLite exists but empty |

### Final 4-Layer Architecture

1. **AGENTS.md** — universal cross-tool surface (IMPLEMENTED 2026-04-07, 6.7KB)
2. **Schema-governed doctrine** — typed markdown with required frontmatter + auto-generated index (PENDING)
3. **Append-only event log** — JSONL via session_stop.py (PENDING)
4. **Derived indexes** — SQLite FTS5 when corpus grows (DEFERRED)

### What Was Killed

- Graph databases (Gemini CLI: flat files optimal)
- ChromaDB/vector search (DR26 + Gemini CLI)
- AAAK compression (DR26: proven lossy)
- Academic-scale NLP patterns (Gemini CLI: premature for personal library)
- Additional MCP servers (DR26: harmful)
- mempalace integration (original question: NO)

### Cultural Concepts Adopted

- **Kunnash** — new memory type for student-facing pedagogical observations
- **Sanad** — provenance metadata in frontmatter (source_agent, confirmed_by)
- **Ta'liqat** — corrections layer over originals, never overwrite
- **Ishkalat** — low-confidence pipeline outputs become student study questions
- **Bridge mechanism** — AI pattern discovery → student study materials (FUTURE)

**Why:** Owner challenged quick dismissal of mempalace. Led to comprehensive audit that found real problems (200-line ceiling, cross-agent blindness, invariant contradictions) and a domain-grounded architecture.

**How to apply:** Layers 2-3 are follow-up session work. Layer 4 is deferred post-pipeline. The investigation DRs are at `engines/excerpting/reference/dr_reviews/DR25-DR27*.md`.
