---
name: Incremental evaluation, not batch campaigns
description: Owner wants small chunk-by-chunk evaluation with UI review, not full campaign reruns
type: feedback
---

Run excerpting in small manageable chunks (one division at a time), not full campaign reruns.

**Why:** Full campaign reruns (1,491 excerpts, 4.4 hours, €2.93) produce overwhelming output that nobody reviews carefully. The owner wants to be in the loop — see each chunk's output, evaluate it, give feedback before the next chunk runs. Three sessions of batch-run-then-analyze missed the core MV-1 merge bug because nobody looked at the specific passage the owner rejected.

**How to apply:**
- Run `--div-id` targeting one division at a time
- CC does critical verification and analysis on the output
- Owner reviews in a UI (adapt the questionnaire UI for excerpt viewing)
- Evaluate together before running the next chunk
- Never run a full campaign rerun without owner agreement
