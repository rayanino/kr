---
name: Handoff Must Transfer Discipline, Not Just State
description: Session handoffs must include coworker mandates, session-boundary triggers, research-before-implementation rules, and owner role — not just task lists and state tables.
type: feedback
---

Session 2 handoff was initially inadequate — it transferred STATE (what files exist, what tests pass) but not DISCIPLINE (how to work, when to stop, who to dispatch).

**Why:** A cold-starting session with only state knows WHAT to do but not HOW. It won't dispatch coworkers, won't know when to hand off to the next session, and won't follow research-before-implementation.

**How to apply:** Every session handoff must include these sections (from the session 2→3 overhaul):
1. "STOP — read in this exact order" with `/catchup` first
2. Coworker mandate with per-phase dispatch table (which coworker, what to ask — specific, not vague)
3. "Research first, implementation second" with ready-to-use coworker prompts
4. Session boundary awareness: when to `/smart-compact` (60%), when to STOP and hand off (80%), natural milestone handoff points
5. Post-milestone protocol: summarize/identify/propose/execute after every phase
6. Owner role: available for DR relay and study questions, NOT for technical direction
7. Budget table with API cost estimates
8. Tools table with commands
9. Full finalization standard (11+ item checklist, not a summary)
10. DR contribution table (what each DR uniquely found)
11. Deferred work section (questionnaire, book digester, etc.)
12. Dispatch logging requirement (`.kr/runtime/dispatch_log.jsonl`)
13. N-1 fallback rule (if coworker unavailable after 48h)

The session 2→3 handoff was verified by Codex (2 passes, 9 checks each) and Gemini (5 checks). All findings were fixed before closing session 2.
