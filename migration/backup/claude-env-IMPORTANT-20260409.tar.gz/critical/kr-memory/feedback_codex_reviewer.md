---
name: Multi-model co-review is mandatory
description: MUST use Codex (codex exec) AND Gemini (gemini -p) as independent reviewers at every major decision. Also relay to Claude Chat + ChatGPT Pro for deep review. ALL 6 sources for major conclusions.
type: feedback
---

At EVERY significant point in a session, use ALL available models as independent reviewers:

**Direct CLI access (use proactively, no asking):**
- `codex exec` — GPT-5.4 at unlimited rates, read-only by default
- `gemini -p` — Gemini, `-y --output-format text` flags

**Relay via owner (give exact copy-paste prompts):**
- Claude Chat (claude.ai) — deep 200K context scholarly review
- ChatGPT Pro (Deep Research) — error patterns, feasibility, architecture. HAS repo access.
- Claude DR (Deep Research) — scholarly reasoning, boundary quality. HAS repo access.
- Gemini DR — Islamic pedagogy, study methodology. NEEDS file uploads.

**Minimum for major conclusions:** At least 2 independent sources. For phase gates and hardening atoms: all 6 sources.

**Why:** Owner mandated on 2026-03-31: "MAKE MAX USE OF CODEX AS YOUR COWORKER, REVIEWER, ARCHITECT HELP" and expanded to all coworkers. Single-model work is unacceptable. CC solo analysis is NEVER sufficient for content quality conclusions.

**How to apply:** At every major milestone (analysis, plan, code, evaluation finding, hardening atom), dispatch Codex AND Gemini at minimum. For content quality judgments: at least one non-Claude challenge on theory, one on implementation/risk. Err on the side of too many reviews.
