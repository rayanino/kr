---
name: Normalization Session 6 — Validation + Writer + Plain Text + Dispatcher
description: Session 6 completed §5 validation (10 checks), atomic writer, plain text normalizer, dispatcher wiring, and shamela diacritics integration. 334 tests pass, 12 skipped. Smoke test 63/63 PASS. L-010 added.
type: project
---

## Normalization Engine — Session 6 Complete (2026-03-20)

### What Was Built
- **Validation system** (`validation.py`, ~350 lines): 10 self-validation checks per §5. Page count tolerance (10%), Arabic ratio (70%), structure completeness, matn proportion (40% sharh/hashiyah), division overlap (WARNING not FATAL), layer coverage, footnote integrity, diacritics preservation (check 8), fidelity metadata, boundary continuity.
- **Atomic writer** (`writer.py`, ~150 lines): temp dir → manifest.json + content.jsonl → shutil.move → cleanup. ADV-047 crash recovery tested.
- **Plain text normalizer** (`plain_text.py`, ~200 lines): CRLF normalization (D6-6), paragraph splitting (merge <1000, split >3000 at ~2000), keyword structure discovery, charset_normalizer fallback.
- **Dispatcher wiring** (`dispatcher.py` updates): `normalize_and_write()` end-to-end function, format registry with Shamela + plain text.
- **Shamela changes** (4 edits): `DIACRITICS_CHECK8` constant (10 codepoints, distinct from canary set), diacritics source storage in `_pass1_parse`, integration into `_pass6_assemble`, `normalize_and_write` delegation.
- **Test factories**: `_make_normalized_package()`, `_make_content_unit()` in conftest.py.

### Test Metrics
- 334 tests collected, 334 pass, 12 skipped, 0 failures
- New tests: validation (~50), writer (~20), plain text (~15), dispatcher (~8)
- Smoke test: 63/63 real + extended fixtures PASS, 50/50 local 20K samples PASS
- 39 total warnings across fixtures (division overlap, low Arabic ratio, division gaps, high matn ratio)

### Key Decisions
- **D6-1:** Division overlap = WARNING not FATAL (L-010). Content units unaffected by tree metadata issues.
- **D6-3:** Check 8 diacritics set (10 codepoints: U+064B–U+0652, U+0670, U+0640) is DISTINCT from shamela.py canary set (20 codepoints). Different purposes.
- **D6-5:** `page_count` accessed via `getattr(metadata, "page_count", None)` — field not on SourceMetadata Pydantic model.
- **D6-6:** CRLF → LF normalization in plain text normalizer (Windows .txt files).

### SPEC Notes for Architect
1. Division overlap severity should be explicit in §7 error code table (recommend WARNING).
2. `page_count` should be added to `SourceMetadata` as `Optional[int] = None`.
3. Check 8 vs shamela canary diacritics sets should be clarified in SPEC to prevent future confusion.

### Known Limitations Added
- L-010: Division tree overlap downgraded from FATAL to WARNING (14% of extended fixtures affected)

### Confidence Levels for Session 7
- validation.py: 95% (thresholds calibrated on 113 fixtures)
- writer.py: 98% (atomic write + recovery tested)
- plain_text.py: 80% (no real .txt fixtures exist yet — paragraph heuristics untested on real data)
- dispatcher.py: 99% (thin routing layer)

### Smoke Test Findings
- 7/50 extended fixtures have division overlap warnings (same-page heading collisions)
- ~10 pages across fixtures have low Arabic ratio (metadata pages, Latin publisher names)
- 3 fixtures have high matn ratio in sharh genre (ext_41, ext_42) — threshold may need raising to 50%
- 1 hadith collection sample: 153 warnings (dense chain-of-narrators pages)
