---
name: Session Boundary Awareness — Hand Off at 80%
description: Session 2 ran to near-exhaustion of context. Future sessions must compact at 60% and hand off at 80%. Never deplete context.
type: feedback
---

Session 2 ran to near-exhaustion of context (20+ commits, 5 DRs synthesized, massive file reads). The owner explicitly flagged this as a mistake.

**Why:** When context is nearly depleted, the session loses access to critical earlier decisions, SPEC rules, and coworker findings. Mistakes increase. Handoff quality drops because there's no context left to write a good one.

**How to apply:**
- At ~60% context: use `/smart-compact` proactively. After compaction, re-read: NEXT.md, engine CLAUDE.md, SPEC §1.1b, active phase checkpoint, MERGED_ATOM_QUEUE active section, ledger recent entries, current GROUP_SYSTEM_PROMPT.
- At ~80% context: STOP current work immediately. Write session N+1 handoff (same structure as session 3 kickoff). Commit. Push. EXIT.
- Natural handoff points: after completing a phase, after launching a smoke run (waiting = dead context), after processing a DR that fills context.
- The next session's handoff MUST include the same structure: reading order, coworker mandate, what went right/wrong, session-end triggers.
