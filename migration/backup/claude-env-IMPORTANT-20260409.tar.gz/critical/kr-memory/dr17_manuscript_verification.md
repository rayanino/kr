---
name: DR17 Manuscript Verification Scholarly Reference
description: Claude DR report mapping 1000 years of Islamic manuscript verification (muqabalah, shahadah, istidrak, N-version) to KR protocol. Validates 11 requirements, adds 8 new (R-19 to R-26). Gemini-corrected 5 of 8.
type: project
---

DR17 (Claude Deep Research) analyzed 2026-04-06. Archived at `engines/excerpting/reference/dr_reviews/DR17_claude_manuscript_verification_scholarly.md`.

**Why:** Provides the scholarly grounding layer for the v5.0 Batch Lifecycle Protocol. Unlike DR12-DR16 (which found specific gaps), DR17 maps the entire classical Islamic manuscript verification tradition to validate and deepen the protocol's design.

**How to apply:**
- R-20 (Expansion Fidelity Indicator / او كما قال) is the most CRITICAL addition — prevents interpretation drift across sessions. Mandatory exact-match for devotional formulae and jawami' al-kalim.
- R-25 (Lahn Severity) is SCIENCE-SPECIFIC — "tolerable = cosmetic" only applies to hadith fada'il and fiqh implementation details. In Qira'at, Nahw, and Aqidah, almost all errors are fatal. Gemini CLI confirmed.
- R-22 (Variant Preservation) must be authority-ordered (asl = body text, variants = margins), not flat egalitarian. Gemini CLI confirmed.
- Full analysis: `.claude/plans/replicated-drifting-candle.md`
- Plan with all 52 requirements: `.claude/plans/protocol-v50-batch-lifecycle.md`
