---
name: Session Discipline for Taxonomy Build
description: Each CC session focuses on ONE small section, makes it bulletproof, reviews it, then hands off. Owner is ready for 1000 sessions if needed.
type: feedback
---

For the taxonomy engine build, each session focuses on ONE small part from the .ultraplan/ plan, makes it absolutely bulletproof and reviewed, then hands off to the next session.

**Why:** Owner 2026-04-07: "The work that needs to be done should be split across multiple sessions, each session focusing on 1 (small) part, making sure it is absolutely bulletproof and reviewed and ready to build on, then hand me off to the next. I'm ready to start a thousand cc sessions if needed."

**How to apply:** At session start, read NEXT.md which points to the next .ultraplan/ section to execute. Complete that section fully, get it reviewed (coworkers at milestone gates), commit, update NEXT.md, stop. Don't overload sessions.
