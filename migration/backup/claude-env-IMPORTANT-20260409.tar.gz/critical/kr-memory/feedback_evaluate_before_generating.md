---
name: Evaluate existing data before generating more
description: Owner frustrated that $97 campaign (2,303 excerpts) sits unused while we plan more runs. Evaluate 1 book thoroughly, not 10 superficially. CC evaluates, owner only sees study-experience questions.
type: feedback
---

Never run large batch generations before thoroughly evaluating existing output. The $97 campaign (2026-03-31, 2,303 excerpts from 5 books) was never properly evaluated — excerpts were shown to the owner in a UI that overwhelmed him.

**Why:** Generating more data before analyzing existing data is waste. The owner explicitly said "don't waste." The previous UI-based evaluation approach failed because it dumped everything on the owner.

**How to apply:**
1. Start with 1 book from existing campaign data, not new runs
2. CC + coworkers evaluate against the 22 FPs and 17 domain rules — this is what the doctrine is FOR
3. Only surface to the owner what needs study-experience judgment ("does this serve your study?")
4. Learn from that one book's evaluation before touching another
5. Never plan a "10-book smoke run" — start with 1, prove the evaluation pipeline works
