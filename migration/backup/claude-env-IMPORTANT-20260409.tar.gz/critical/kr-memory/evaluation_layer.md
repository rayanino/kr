---
name: Excerpting Evaluation Layer
description: Post-run analysis infrastructure for excerpting integration tests — 5 modules in scripts/excerpting_eval/, 3 CLI entry scripts
type: project
---

Built 2026-03-29/30 via PRs #2 and #3. Bug fixes in commit `049e167b`.

## Structure

Shared package `scripts/excerpting_eval/`:
- `models.py` — data models (dataclasses, enums, TypedDicts)
- `ingest.py` — data loading + canonical per-unit ledger construction
- `analysis.py` — anomaly + concern detection logic
- `packet.py` — markdown + JSON output formatting
- `KNOWN_LIMITATIONS.md` — acknowledged gaps

CLI entry scripts:
- `scripts/analyze_excerpting_run.py` — per-book analyzer
- `scripts/analyze_excerpting_campaign.py` — campaign aggregator
- `scripts/export_excerpting_review_packet.py` — review packet exporter

## Purpose

Reads existing run directories (read-only), builds a canonical per-unit ledger, detects anomalies with classified evidence basis, and produces structured outputs for human review. Designed to turn the upcoming 280-chunk campaign into decision-grade evidence.

## Runner Observability Patches

`scripts/run_integration_test.py` was patched with: failure ledgers, validation drop tracking, gate verification, trace metadata, call-level error propagation.

**Why:** The evaluation brief identified that raw integration test output was insufficient for deciding whether the excerpting pipeline was ready for production. The system needed structured post-run analysis, not just pass/fail.

**How to apply:** After any integration test run, use `analyze_excerpting_run.py` on the output directory. Before a full campaign, run the campaign aggregator on accumulated results.
