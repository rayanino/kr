---
name: Source Surroundings Vision
description: Every excerpt should have a hoverable box showing surrounding pages from the original source — converts excerpts from detached fragments into "windows into the source"
type: project
---

Owner idea (2026-04-04, during Atom 2 hardening):

Every excerpt should be accompanied by its relevant surroundings from the original source. A hoverable/expandable box showing the previous page, current page, and next page.

**Owner's words:** "it would be so nice if EVERY excerpt could have a small box that I can hover open and that would open the entire page, previous page and next page from the source ... then the excerpts are not 'here is the excerpt, deal with it', but more like 'you want to study this topic, here is the relevant excerpt from the book, but you still have access to its surroundings incase you would want to read the book instead of the excerpt'"

**Why:** This is transformative because:
- Eliminates self-containment anxiety for ALL excerpts, not just PARTIAL ones
- No AI generation needed — actual frozen source bytes
- Makes the library "source-first" instead of "fragment-only"
- Aligns with "ALWAYS KEEP THINGS AS CLOSE TO THE ORIGINAL AUTHORS WORDINGS"

**How to apply:** Already technically feasible — ExcerptRecord carries source_id, div_id, physical_pages, chunk_index. Normalization preserves full source text. The surrounding text is ALREADY in the pipeline — it just needs a display mechanism in synthesis/UI.

**Implementation surface:** synthesis engine or UI layer, NOT excerpting engine. The excerpting engine already produces all metadata needed. This is downstream work.
