---
name: Unbiased Placement Principle
description: CRITICAL — LLM reasons independently BEFORE seeing tree. Never bend placements to fit static structure. Source book's science does NOT determine placement. Pipeline-wide.
type: feedback
---

Two dimensions of unbiased placement:

1. **Tree bias:** LLM reasons about WHAT an excerpt is (topic, content type, depth) BEFORE seeing the tree, then matches. Never bend placement to fit existing structure. If no match → propose tree evolution.

2. **Source bias (FP-5, added 2026-04-08):** The source book's science does NOT determine where content lands. An aqidah book discussing حكم الصلاة produces FIQH excerpts. Always follow the TOPIC's home science, not the source book's science. Owner (ALL-CAPS): "DANGEROUS BIAS: EXCERPT IS IN BOOK OF A SPECIFIC SCIENCE → MUST LAND IN THAT TREE."

**Why:** Owner PRD review 2026-04-07 + Q-G6-02 response 2026-04-08. Biased placement corrupts the owner's understanding. Wrong-science placement teaches content in the wrong mental context (FP-7: the library eliminates friction, not adds it). Splitting excerpts by source book = "CATASTROPHIC AND EXTREMELY CONFUSING."

**How to apply:** (1) Independent reasoning phase before tree matching. (2) Topic determines home science, not source book. (3) Both biases are equally dangerous — test for both. (4) This applies to ALL engines and ALL placement decisions.
