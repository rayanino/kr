---
name: Teaching Units Not Excerpts
description: Pipeline produces teaching units (context-rich study material), not bare text excerpts. Owner would rename "excerpts" to "teaching units" if starting over. Cross-engine principle.
type: feedback
---

Pipeline output is a TEACHING UNIT, not a paste-and-place excerpt. A teaching unit = literal text chunk + contextual metadata + placement intelligence + provenance. The goal is the most optimal study environment where the owner only memorizes and understands — everything else served on a plate.

**Why:** Owner expressed (2026-04-08 Q-G6-01) that if starting over, he'd call excerpts "teaching units" and the literal text chunk "excerpt." The distinction is fundamental: the goal is not well-formed quotes, it's maximally productive study sessions.

**How to apply:** Every engine decision should ask "does this produce a better teaching unit?" not "does this satisfy the rule?" Applies to excerpting (boundary decisions), taxonomy (placement enrichment), synthesis (final assembly). Documented in `reference/FOUNDATIONAL_PRINCIPLES.md` as FP-1.
