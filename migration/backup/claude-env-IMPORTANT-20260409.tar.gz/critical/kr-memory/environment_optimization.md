---
name: KR Environment Optimization
description: Complete inventory of hooks, agents, skills, rules, commands, MCPs — updated 2026-03-26 after ECC-based overhaul + domain knowledge encoding session
type: reference
---

# KR Environment Optimization (updated 2026-03-26)

## Major Overhaul — 2026-03-26

Analyzed [affaan-m/everything-claude-code](https://github.com/affaan-m/everything-claude-code) (Anthropic hackathon winner) and adopted 34 improvements: security hardening, hook improvements, new rules, enhanced agents/commands, future-proofing. Then performed domain knowledge encoding session adding 4 Islamic sciences skills and 2 domain hooks.

## Hooks (14 active in .claude/hooks/ — was 6 pre-overhaul)

| Hook | Trigger | Purpose |
|------|---------|---------|
| config-protection.sh | PreToolUse (Write/Edit) | Blocks edits to settings.json/hooks. Escape: KR_CONFIG_EDIT=1 |
| pre-commit-check.sh | PreToolUse (git commit) | 10 checks: frozen sources, tests, Arabic safety, secrets, function length, TODOs |
| circuit-breaker.sh | PreToolUse (Bash) | Blocks after 3 consecutive same-pattern failures |
| cost-guard.sh | PreToolUse (Bash) | Blocks API calls when budget >= EUR limit |
| no-ask-human.sh | PreToolUse (AskUserQuestion) | Blocks during overnight (KR_OVERNIGHT=1) |
| ruff-format.sh | PostToolUse (Write/Edit) | Runs ruff check --fix then black on .py |
| arabic-safety-check.sh | PostToolUse (Write/Edit) | 8 checks including invisible Unicode detection |
| pyright-check.sh | PostToolUse (Write/Edit) | Type checking with RAPID_MODE skip + scope filter |
| auto-test.sh | PostToolUse (Write/Edit) | Runs pytest on affected module |
| boundary-check.sh | PostToolUse (Write/Edit) | D-023 metadata flow verification |
| diacritic-preservation.sh | PostToolUse (Write/Edit) | T-1 defense: detects Arabic diacritic count decrease |
| spec-coverage-check.sh | PostToolUse (Write/Edit) | Warns when SPEC rule references decrease in tests |
| Auto-staging | PostToolUse (Write/Edit) | Background git add of modified files |
| session_stop.py | Stop | Saves state including cost_summary, CB triggers, print warnings |

**New since overhaul:** config-protection, ruff-format, diacritic-preservation, spec-coverage-check. Also: --no-verify blocking in PreToolUse Bash regex, secret detection in pre-commit, function length advisory, invisible Unicode detection in arabic-safety, RAPID_MODE skip in pyright, enhanced stop hook with cost/CB/print fields, budget display in startup hook, session state in compact recovery hook.

## Agents (21 active + 3 archived — was 17+3)

**Session 1 additions (2):**
- **quick-check** (haiku) — Fast smoke-check: pyright + tests + Arabic safety. Use for in-progress work instead of full code-reviewer.

**Session 2 additions (3):**
- **arabic-reviewer** (sonnet) — Deep Arabic text code review using all 4 domain skills. Reviews for character safety, scholarly conventions, knowledge integrity threats, domain-specific processing.
- **regression-detector** (haiku) — Fast test regression detection between git refs. Compares outcomes, classifies as REGRESSION/RECOVERED/NEW/PERSISTENT.
- **evaluation-prep** (sonnet) — Pre-flight checklist for Phase C/D/E evaluation. Validates prerequisites, fixtures, budget, configuration, playbook, code readiness.

**Session 1 enhancements (4):**
- **code-reviewer** — Added: confidence >80% threshold, function complexity limits (50 lines, 5 params), wildcard import ban, performance awareness
- **test-engineer** — Added: mandatory edge case checklist (8 categories), coverage targets (80%/100% for critical)
- **spec-adversary** — Added: Category 6 (Input Injection/LLM Manipulation)
- **build-prober** — Added: PERFORMANCE and FLAKY_TEST finding categories

**Session 2 enhancements (1):**
- **spec-writer** — Added: domain skill integration (reads Islamic sciences/attribution/glossary skills before writing), self-review checklist

## Skills (15 custom — was 7 pre-overhaul)

**Original 7:** arabic-text, codex-verify, consensus-pattern, domain-glossary, evaluation-methodology, scholarly-design, spec-examples, technology-survey

**Added 2026-03-26 (domain knowledge encoding):**
- **islamic-sciences-classification** (264 lines) — Per-science text structure, terminology, processing rules, cross-science rules
- **scholarly-attribution** (182 lines) — Arabic naming conventions, signal locations, disambiguation, confidence scoring, common errors
- **arabic-text-quality** (141 lines) — OCR corruption patterns, encoding issues, diacritic assessment, Shamela-specific issues
- **quranic-text-handling** (308 lines) — Quran detection, preservation rules, cross-references, processing implications

**Enhanced:** knowledge-safety — added concrete implementation patterns and test strategies per threat

## Rules (17 files — was 8)

**Original 8:** python-code, quality-workflow, regex-arabic-digits, result-preservation, session-discipline, shared-concept-changes, spec-writing, testing

**Added 2026-03-26:**
- input-sanitization — External text safety (invisible Unicode, encoding validation)
- context-management — Token awareness, MCP limits, compaction strategy
- commit-format — Conventional commits with KR-specific types
- e2e-testing — Playwright + Arabic RTL patterns (dormant until UI phase)
- frontend-development — TypeScript + Arabic display rules (dormant until UI phase)
- arabic-scholarly-conventions — Bismillah, colophons, abbreviations, honorifics, transmission formulas
- llm-call-optimization — Temperature, caching, Arabic prompting, cost management

**Enhanced:** python-code (+complexity limits), testing (+coverage targets, flaky protocol), quality-workflow (+severity classification, pre-merge checklist)

## Commands (22 custom — was 15)

**Session 1 additions (3):** /build-fix (iterative error resolution, max 3 cycles), /tdd (Red-Green-Refactor SPEC-driven), /ui-test (dormant until UI phase)
**Session 1 enhancements:** /quality-gate (+complexity+coverage), /catchup (+budget+CB+prints), /commit (+validation), /smart-compact (+cost+CB save)

**Session 2 additions (4):**
- **/cost-report** — API cost breakdown from COST_LOG.json by model, phase, date. Budget warnings.
- **/eval-dashboard** — Evaluation progress dashboard: books, verdicts, consensus stats, cost, pending.
- **/regression-check** — Compare test results between current and previous git ref. Default HEAD~1.
- **/arabic-audit** — Comprehensive 4-level Arabic text safety audit (syntax, diacritics, domain, integrity).

**Session 2 enhancements:**
- **/orchestrate** — Added Chain C (eval-prep) and Chain D (arabic-review). Now 4 chains total.

## Verification Scripts (new Session 2)

- **scripts/validate_agent_definitions.py** — Validates all agent/command frontmatter consistency
- **scripts/check_test_regression.py** — Programmatic test regression comparison between git refs

## MCP Servers (3 active in .mcp.json)

context7 (library docs), tavily (web research), memory (knowledge graph)

## Ruff Integration (new 2026-03-26)

pyproject.toml now has [tool.ruff] config: F, E, W, I, UP, B, SIM rules enabled. ruff-format.sh hook runs on every .py edit before black. Ruff was already in the allow list (line 48) but never wired — now active.

## Plugins

oberskills@rtd (custom KR skills plugin)

## Key Settings.json Changes (264 lines — was 233)

- PreToolUse: 7 matchers (was 6) — added config-protection + --no-verify block
- PostToolUse: 9 matchers (was 7) — added diacritic-preservation + spec-coverage
- Stop: enhanced with cost/CB/print fields in session_state.json
- Startup: budget display on session start
- Compact: session state display after compaction
