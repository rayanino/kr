---
name: DR19 Hard Enforcement Hooks — Prevention Layer
description: Claude DR report proving documentary enforcement fails (0.95^23=31%). 3 PreToolUse hooks built for hard enforcement of autonomy + prompt-architect norms. Defense-in-depth complete.
type: project
---

DR19 (Claude Deep Research) analyzed 2026-04-06. Archived at `engines/excerpting/reference/dr_reviews/DR19_claude_norm_persistence_hooks.md`.

**Why:** DR19 mathematically proved that 23 rules at 95% individual compliance = 31% full-session compliance. Documentary enforcement (rules in files) has a structural ceiling. Only architectural enforcement (hooks that block tool calls) achieves 90%+.

**How to apply:**
- 3 hooks in `.claude/hooks/`: enforce-autonomy.sh (blocks technical questions), enforce-prompt-architect.sh (blocks Agent dispatch without prior optimization), track-prompt-architect.sh (records /prompt-architect invocations)
- Wired in `.claude/settings.json`: PreToolUse on AskUserQuestion + Agent, PostToolUse on Skill
- HR-25: hooks must NEVER be disabled. HR-26: cross-model auditing mandatory.
- Combined with DR18's detection layer (S-09 to S-12), forms complete defense-in-depth: Prevention → Detection → Verification → Measurement

**Key research citations for future reference:**
- "Curse of Instructions" (ICLR 2025): P(all N) = P(individual)^N
- IFScale (Jaroslawicz 2025): 3 degradation patterns, best model 68% at 500 instructions
- "Lost in the Middle" (Liu, TACL 2024): U-shaped attention, middle dead zone
- "Context Rot" (Hong 2025): degradation with every length increment
- Sycophancy (Sharma, ICLR 2024): matching user views is #1 RLHF preference predictor
- Same-model blindness (DeepMind Dec 2025): 17.2x error amplification
