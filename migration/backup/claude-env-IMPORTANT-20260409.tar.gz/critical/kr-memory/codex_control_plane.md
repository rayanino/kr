---
name: Codex Control Plane
description: Claude/Codex dual-authority model with .kr/ control plane. Claude active for excerpting hardening (2026-04-04). Codex cutover planned 2026-04-09.
type: project
---

Established 2026-03-29/30 via PR #1 (`ops/bootstrap-kr-control-plane`).

## Authority Model

`ACTIVE_AUTHORITY.md` (repo root) defines who is the active engineering authority:
- **Claude** (active as of 2026-04-04): excerpting foundations hardening lane
- **Codex** (after cutover ~2026-04-09): hardening, regression growth, audits, bounded features, unattended runtime
- `runtime_mode: shadow_setup` means Codex can only work in queue-only/read-only shadow lanes
- `runtime_mode: autonomous_codex` (post-cutover) allows auto-applying bounded changes

## Current State (2026-04-04)

Claude formally took over the excerpting foundations hardening lane on 2026-04-04 with an explicit handoff package:
- `reference/handoffs/excerpting_foundations_claude_hardening_takeover_2026-04-04.md`
- Codex prepared the handoff: preserved F1-F8 evidence, created the takeover brief
- Codex scope: shadow/setup only, shadow repo challenge, contract pressure, regression validation

## .kr/ Control Plane (6 files)

| File | Purpose |
|------|---------|
| `CHARTER.md` | Durable mission, principles, worker roles, quality bar |
| `ACTIVE.md` | Single current frontier + deliverable |
| `HANDOFF.md` | Session resume state (never overrides ACTIVE.md) |
| `DECISIONS.md` | Strategic/methodological decisions log |
| `README.md` | Control plane documentation |

## Doctrine Stack (autonomous period 2026-04-09 to 2026-07-01)

Council-reviewed (all 6 models) governance docs:
- `docs/codex/autonomous-doctrine-2026-04-09-to-2026-07-01.md` — governing doctrine, "stagnation over corruption"
- `docs/codex/operating-model.md` — operational procedures
- Governing stance: "Stagnation over corruption" — delayed runs acceptable, silent epistemic corruption is not

## Backend Proof (2026-04-01)

CLI backend proven: taysir + ibn_aqil_v3 passed end-to-end. WSL runtime mechanically viable.

**Why:** The project needed a formal model for dual-agent development. Without explicit authority boundaries, Codex and Claude sessions could make conflicting architectural decisions.

**How to apply:** Always check `ACTIVE_AUTHORITY.md` at session start. Currently Claude is active for excerpting hardening. Codex is shadow-only. After cutover (~2026-04-09), Claude Code sessions defer to Codex on operational matters.
