---
name: ChatGPT DR Owner Data Audit
description: Only coworker to inventory what's ALREADY collected. 5 missing data families from campaign evidence. Bundle format evaluation with 4 weaknesses.
type: project
---

ChatGPT DR (2026-04-07) produced a 313-line owner-dependent data audit for the excerpting engine.

**Unique contribution:** The ONLY coworker that inventoried what's ALREADY COLLECTED (F1-F8, G1-G4, SC1). Others focused on what's NEEDED. Key finding: "highest-stakes values already integrated" — FP-1..22 encode foundational doctrine. Remaining gaps are calibration + special cases.

**5 missing data families (with campaign evidence):**
1. S-1 (conflict resolution priority) — "Not yet defined" in TEAM_TRANSLATION_GUIDE
2. FP-18 (study-ready vs acceptable) — all 4 coworkers converge on this
3. K-1..K-3 (khilaf/tarjih) — speaker-role inversion risk
4. E-1..E-3 (evidence organization) — linguistic cohesion vs granularity
5. D-1..D-3 (definition splitting) — orphaned conjunction risk

**Bundle format evaluation:** 4 weaknesses (schema inconsistency, path instability, F-series discontinuity, missing integrity manifest). 3 proposed additions (final-decisions file, evidence tagging, inventory.json).

**Why:** Completes the picture — other coworkers said what's NEEDED, ChatGPT DR says what ALREADY EXISTS. The delta between the two is the actual collection work.

**How to apply:** When designing collection sessions, check the "Already In Bundles" column in the synthesis before adding new questions. Many items are PARTIAL — they need calibration, not re-collection.

**Files:** `engines/excerpting/reference/dr_reviews/CHATGPT_DR_*` (2 files)
