---
name: autonomous_evaluator
description: Creative evaluator hardened via 3-coworker audit — 7 dimensions, H2 claim verification, 12 bypasses blocked, 86 tests
type: project
---

Deterministic quality evaluator for autonomous creative output. 4 hardening sessions on 2026-04-06.

**State (end of H2 session):**
- 7 dimensions: repo_grounding, structural_completeness, strategic_depth, concreteness, evidence_fidelity (H2), novelty, inflation_check
- Max score: 28 (7 × 4). Pass threshold: ALL dims must pass.
- 12 adversarial bypass payloads tested (A-F + Gemini-1), ALL REJECT
- Golden example: PASS (21/28). Manual benchmark: PASS (26/28, major class).
- 86 tests (47 evaluator + 39 runtime), 0 failures, pyright clean.

**H2 claim-contract verification (CRITICAL gap closed):**
- AST-parses all 7 engine contracts.py → SYMBOL_FIELDS registry (class → field names)
- Detects negative claims ("X discards/lacks Y") and verifies Y against actual fields
- Two-tier matching: compounds use substring, single words require exact match
- Blocks Bypass D ("ExcerptRecord discards argument structure") and F ("TeachingUnit lacks scholarly function weighting")

**Remaining gaps:** H3 (template detection, MEDIUM), H4 (risk specificity, LOW), H6 (auto-registry refresh, LOW), INFRA-1 (Windows long path blocker for orchestrator, HIGH)

**Next:** Fix INFRA-1 (Arabic filenames in tests/results/ exceed 260 chars on Windows). Then run first real automated Codex benchmark. Then dispatch coworkers on hardened evaluator for 5th-gen bypass testing.
