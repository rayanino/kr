---
name: Codex CLI Data Type Analysis
description: 11 policy families (DT-01..11) with dependency chains, FP-gap finding, and two-layer insight (policy precedes decisions)
type: project
---

Codex CLI (2026-04-07) analyzed bundle schemas, SPEC requirements, and contracts.py to map 11 data type families the pipeline needs from the owner.

**Key unique findings (not in DR18):**
- DT-01 (user model) is the ROOT dependency — all other decisions depend on it
- DT-02 (quality rubric priority S-1) is "Not yet defined" in TEAM_TRANSLATION_GUIDE
- DT-05/06/07 (evidence, khilaf, genre policies) are distinct families mapped to specific questionnaire items
- DT-08 (study-readiness) is SEPARATE from self-containment (FP-18 gap)
- TEAM_TRANSLATION_GUIDE has ZERO FP-13..22 mappings (pre-hardening)
- Only FP-8 and FP-18 need owner calibration; rest are implementable

**Two-layer insight:** Codex + DR18 together reveal policy layer (what owner WANTS) must precede decision layer (what pipeline NEEDS). You can't set thresholds until you've defined quality rubrics.

**Why:** This changes collection order — formalize user model first, then quality rubric, then cascading policies, then calibration.

**How to apply:** When planning collection sessions, start with DT-01/DT-02 (policy root), then DR18's critical path (science scope, book priority, muhaqiq). The Codex dependency chain is: DT-01 → DT-02 → DT-10 → DT-03 → DT-04 → DT-05/06/07 → DT-08 → DT-09 → DT-11.

**Files:** `engines/excerpting/reference/dr_reviews/CODEX_CLI_*` (2 files)
