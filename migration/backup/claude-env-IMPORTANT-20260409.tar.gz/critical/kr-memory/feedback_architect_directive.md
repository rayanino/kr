---
name: Architect Directive Pattern
description: When NEXT.md contains exact fix code from architect review, execute precisely without redesigning — the thinking is already done
type: feedback
---

When the architect review produces a fix directive with exact code (copy-pasteable snippets, precise line numbers, explicit pass criteria, "Do NOT Do" fence), execute it directly without re-designing.

**Why:** The architect who found the issue has already done the analysis — quantified evidence, traced the code, verified test impact, and specified the fix. Re-designing wastes time and risks introducing divergence from the reviewed solution. The Session 5 review fix (commit e07ac6e) was executed in under 15 minutes with zero issues because NEXT.md was exceptionally precise.

**How to apply:** When NEXT.md has copy-pasteable code, follow it exactly. When NEXT.md gives general guidance ("fix the boundary check"), design the solution. The distinction is: does the directive specify the code, or just the goal?
