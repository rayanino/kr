---
name: Dashboard insights must reflect persistent internal data, not transient display
description: Every insight shown on the dashboard must be backed by a persistent data structure. Nothing is "shown and forgotten." The dashboard is a VIEW onto the system's knowledge base.
type: feedback
---

Owner stated (2026-04-07): "MAKE SURE THIS IS NOT JUST SHOWN TO ME AND FORGOTTEN: instead, it should be a reflection of an internal data-saving."

**Why:** The system accumulates knowledge over months. If an insight is generated for the dashboard but not persisted, it's lost after the page refreshes. The dashboard must be a window into persistent state, not a generator of ephemeral content.

**How to apply:**
1. Every dashboard metric is derived from a stored data structure (JSON, JSONL, or database)
2. Historical insights are queryable — agents can access them in future sessions
3. The dashboard never computes on-the-fly what could be pre-computed and stored
4. This is consistent with Rule 13 (ALL data is future training material)
