---
name: Hardening Session Tools (updated 2026-04-06)
description: Environment audit complete. Coverage 82%, DeepEval, DuckDB, promptfoo configured, IAA metrics, mutmut, camel-tools verified. context-mode REJECTED. Merged plan at reference/handoffs/environment_merged_plan_2026-04-06.md.
type: reference
---

## Environment Improvement Session (2026-04-06)

Debiased two-session audit. Merged plan: `reference/handoffs/environment_merged_plan_2026-04-06.md`

### Now ACTIVE (use these)
- `pytest --cov` — 82% baseline. Config in pyproject.toml.
- `scripts/measure_consensus_quality.py` — Cohen's kappa for D-041
- `mutmut run` — mutation testing for F-DET fields
- `engines/excerpting/tests/test_llm_eval.py` — DeepEval GEval metrics
- `engines/excerpting/promptfooconfig.yaml` — 5 regression test cases
- `camel-tools` — tokenize, normalize, dediacritize (v1.4.1, works)
- `duckdb` — SQL over JSONL result files

### REJECTED: context-mode (DO NOT INSTALL)

### Dead MCP to remove: exa, fetch, office-word

Tools installed 2026-04-04 for excerpting atom processing sessions:

| Tool | Version | Purpose | Command |
|------|---------|---------|---------|
| promptfoo | 0.121.3 | Automated prompt regression testing against OpenRouter | `promptfoo eval` |
| pytest-xdist | 3.8.0 | Parallel test execution (4+ workers) | `pytest -n 4` or `pytest -n auto` |
| hypothesis | 6.151.10 | Property-based testing — auto-generate test inputs | `@given(...)` decorator in tests |
| polyfactory | 3.3.0 | Pydantic model factories for hypothesis | Bridge between Pydantic models and hypothesis |
| repomix | (installed) | Context compression — compile workspace to XML | `repomix --include "engines/**/*.py"` |
| atom_test.py | (custom) | Empirical Phase 2 validation on real Arabic chunks | `python scripts/atom_test.py --package taysir --chunk 5` |
| check_prompt_spec_sync.py | (custom) | Detect prompt-SPEC drift | `python scripts/check_prompt_spec_sync.py` |

**How to apply:** Use promptfoo for any prompt change. Use pytest -n 4 instead of plain pytest. Use atom_test.py for empirical validation. Use check_prompt_spec_sync.py after every prompt edit.
