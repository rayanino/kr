---
name: API runs are fast and cheap — always ask before CLI runs
description: Full 5-pkg run is 33 min / €2.93 via API. CLI runs take 48h+. Ask before launching either.
type: feedback
---

Full excerpting campaign timing (2026-03-31 measured data):
- **API backend** (`--backend api`): 33 minutes, €2.93. Use for ALL development.
- **CLI backend** (`--backend cli`): 48+ hours, €0. Use ONLY for final permanent production run.

**Why:** The API cost was 100x lower than estimated ($292 → €2.93). The owner confirmed API is the default for development. CLI is only for the final production run where cost=0 matters more than speed.

**How to apply:** Always use `--backend api` unless explicitly told otherwise. Still ask before launching any run (the user may want to review/fix something first). Budget: €120 allocated = ~40 full API runs.
