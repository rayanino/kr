---
name: Ropes Between Sciences — Cross-Science Links Are Essential
description: The library needs explicit cross-science links ("ropes") beyond parent-child branches. These visualize bigger pictures that make scholars scholars. Fatal failure to omit.
type: feedback
---

Branches only tell parent-child relationships. They miss the BIGGER PICTURE: how sciences connect laterally. "Ropes" are explicit cross-science links that show: "this aqidah branch references this fiqh branch because the topic belongs to fiqh."

**Why:** Owner (2026-04-08): "This would be a fatal failure for us; to not include these BIGGER PICTURES... This is what MAKES A SCHOLAR A SCHOLAR." The library aims to solve real study problems: eliminating gaps, eliminating the need to maintain mental tables of which book covers which topic.

**How to apply:** (1) When content at branch A references a topic owned by branch B (possibly in another science), create an explicit link. (2) Links are NOT lazy — only where a branch is a genuine "outliner" from its host science. (3) These links visualize the boundaries between Islamic sciences, which is itself valuable scholarly knowledge. (4) This is a research topic for DR coworkers: "what makes a scholar vs a student of knowledge" maps directly to understanding these cross-science connections.

**Documented in:** `reference/FOUNDATIONAL_PRINCIPLES.md` (to be added as FP-5).
