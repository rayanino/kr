---
name: Session Types — Don't Overload One Session
description: Codex insight validated by Session 2 failure — separate intake, debt-clearing, prompt refactoring, and atom processing into distinct session types instead of cramming everything into one session
type: feedback
---

Don't mix intake, debt-clearance, prompt architecture, atom processing, and validation into one session. Each is a distinct unit of work requiring different context profiles.

**Why:** Session 2 tried to do everything (process atoms, synthesize DR reviews, refactor prompts, write handoffs) in one session and hit 96% context at atom ~20. Codex diagnosed the root cause: "Most of your amendments treat token pressure as the disease. The deeper disease is wrong unit-of-work design." The owner confirmed: infinite session availability means smaller, focused sessions are better than overloaded ones.

**How to apply:** At session start, declare a session type (intake-only, debt-clearance, prompt-architecture, full-atom, validation-only). A session that discovers mid-work it should be a different type STOPS and hands off. Never combine intake-only with full-atom — new atoms from intake are not processed in the same session. See HARDENING_SESSION_PROTOCOL.md v4.0 §1.5.
