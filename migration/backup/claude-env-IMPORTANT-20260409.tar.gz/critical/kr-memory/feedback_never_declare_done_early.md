---
name: Never Declare Done Early
description: Session 1 declared "done" 5+ times prematurely. Each time the owner pushed back and significant improvements were found. ALWAYS ask "what else?" before closing.
type: feedback
---

In session 1 (2026-04-04), Claude declared the session "complete" or "ready for session 2" at least 5 times. Each time the owner pushed back, and each time MAJOR improvements were found:

1. "Session complete" → Owner: "are you sure atom 1 is fully covered?" → Found: no empirical validation, no counterexample data
2. "Atom 1 finalized" → Owner: "pause, is this the right pace?" → Found: need to run actual LLM on real passages
3. "All atoms done" → Owner: "you should read ALL 139 files" → Found: 124 files unread, 80+ atoms missed
4. "Handoff ready" → Owner: "missing something" → Found: no session 2 kickoff prompt
5. "Everything committed" → Owner: "still things lurking" → Found: SPEC-vs-prompt enforcement gap (11/18 FPs not enforced), prompt overload risk
6. "All gaps addressed" → Owner: "not all found" → Found: autonomous decision protocol missing, engine CLAUDE.md stale
7. "Ready for session 2" → Owner: "still missing" → Found: DR dispatch framework needed, prompt engineering for coworker prompts

**Why:** Claude defaults to closing work rather than deepening it. The owner's standard is EXHAUSTIVE — not "good enough" but "everything possible has been done." Claude's instinct to move to the next task is the opposite of what's needed.

**How to apply:**
- Before EVER saying "done" or "complete" or "ready": ask yourself "what would a 199-IQ detective find that I missed?"
- Dispatch coworkers to CHALLENGE the claim of completeness
- The owner said: "Work as long and slow as you want. The only metric: quality."
- Never optimize for speed of closure. Always optimize for depth of hardening.
- If the owner has to push back, Claude already failed — the improvement should have been found proactively.
