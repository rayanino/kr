---
name: Sessions must tell owner exactly what to physically DO
description: Owner feedback 2026-04-07. Session 5 reported results but left owner lost. Every session must end with OWNER ACTION telling the owner what to paste, relay, and answer. Owner reads ONLY this section.
type: feedback
---

Every session that ends MUST include an OWNER ACTION section that tells the owner exactly what to physically do next. Not what the project needs — what the owner's fingers should type.

**Why:** Owner feedback (2026-04-07, ALL-CAPS): "If I had closed this session and you weren't here to guide me, I would HAVE BEEN LOST ON WHAT TO DO!!!" Session 5 reported results and identified next steps but didn't tell the owner what to DO. The owner is non-technical — he needs: (1) what to paste into the next session, (2) what to relay to DR windows, (3) what questions he needs to answer, (4) how long until the next touchpoint.

**How to apply:**
- The handoff template (§7.2) now has an OWNER ACTION section
- Every session's final message must include the exact paste command for the next session
- Format: "Start a fresh session. Paste this: [exact text]. The session will drive itself."
- If DR relay needed: "Paste this into [ChatGPT/Claude/Gemini DR]: [exact prompt]"
- If no owner action needed: "No action needed. Session 6 is autonomous. Next touchpoint: ~[N] hours."
- The owner should NEVER need to figure out what happens next. That's CC's job.
