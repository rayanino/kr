---
name: Summer 2026 vision — owner runs sessions 24/7, agents build, pipeline must be solid
description: In summer the owner will run CC/Codex sessions full-time. Agents build. The autonomous system's #1 job: make excerpting + taxonomy engines reliable and edge-case-free before July.
type: project
---

Owner stated (2026-04-07):
- Summer = "I will give my ALL: 24/7 full attention to the project, full presence"
- This means: running CC and Codex sessions all day, not personal coding
- "By then I will open a new CC session, brief it about the summer plan and the autonomous session results"
- 10x wish: "Anything related to getting the engines — ESPECIALLY excerpting and taxonomy — to work reliably and accurately. Discovering edge cases. The creative work is nothing if the base pipeline is not solid."

**How to apply:** The autonomous system must prioritize:
1. Excerpting engine edge cases and reliability
2. Taxonomy engine edge cases and reliability
3. Research that eliminates summer blockers
4. Pre-building components agents can use

NOT: creative features, UI, synthesis engine, or anything that doesn't serve pipeline correctness.
