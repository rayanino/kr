---
name: OpenRouter Model Fusion for multi-model consensus
description: OpenRouter offers "Model Fusion" — runs multiple models side-by-side, analyzes results, and fuses into the best result. Directly relevant to D-041 consensus pattern. Evaluate before building custom consensus logic.
type: reference
---

OpenRouter provides a feature called **Model Fusion** that runs multiple models on the same prompt, analyzes their outputs, and fuses them into the best result.

**Why:** This is directly relevant to KR's D-041 multi-model consensus requirement. Currently, consensus is implemented via custom LiteLLM + Instructor code that calls 2+ models and compares outputs. Model Fusion could potentially replace or augment this with a provider-native solution.

**How to apply:**
- Before implementing any NEW multi-model consensus call, check whether OpenRouter Model Fusion can do it natively
- Evaluate for: genre classification, author identification, science scope, madhab attribution, death date extraction
- Compare cost: Model Fusion pricing vs individual API calls to 2+ models
- Compare quality: does the "fused" result outperform our custom 2-model agreement check?
- Key question: does Model Fusion give us access to the individual model outputs (needed for our disagreement analysis) or only the fused result?
- This needs a technology survey (`.claude/skills/technology-survey/SKILL.md`) before adoption — Rule 9
- Document: OpenRouter docs for Model Fusion feature
