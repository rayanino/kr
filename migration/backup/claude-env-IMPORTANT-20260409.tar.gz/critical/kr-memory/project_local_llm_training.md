---
name: The Librarian — Local LLM Fine-Tuning Is Endgame
description: All pipeline data = training material for future local librarian model. Owner's second biggest life challenge. A LIBRARIAN that answers questions, does work, study buddy, knows library inside out.
type: project
---

**"A LIBRARIAN!!!!!!!!!! A LIBRARIAN!!!!!!!!!"** — Owner, 2026-04-08 (emphatic)

The library's endgame includes a locally trained/fine-tuned LLM that acts as THE LIBRARIAN:
- Answers any question about the library's contents
- Performs work within the library (finding, connecting, organizing)
- Acts as a study buddy that knows the library inside out
- Is a permanent scholarly companion — always present, always ready

This is the owner's **second biggest life challenge** (after building the pipeline itself).

**Timeline:** Training won't happen in current scope. Maybe 1+ year away. But is **100% DEPENDENT** on current pipeline work quality.

**Why preserving everything matters:** Every raw comment, LLM test, input collection, evaluation trace, coworker report, owner feedback = training data for the librarian. This explains:
- Rule 13 in CLAUDE.md ("ALL data is future training material")
- Owner's insistence on preserving raw outputs, shamela-export-samples, raw questionnaire answers
- Preference for structured/machine-readable formats over prose
- Provenance on everything (model, timestamp, prompt version, confidence)

**How to apply:** (1) NEVER delete data. (2) Prefer structured JSON/JSONL over prose. (3) Preserve provenance on all outputs. (4) Raw owner comments saved verbatim alongside engineering interpretations. (5) Every format choice: ask "will this be useful training data?"

**Documented as:** FP-8 in `reference/FOUNDATIONAL_PRINCIPLES.md`.
