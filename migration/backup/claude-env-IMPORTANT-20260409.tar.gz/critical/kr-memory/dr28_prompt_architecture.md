---
name: DR28 Converged Prompt Architecture
description: Instruction sandwich + progressive disclosure. IU-1–IU-9 COMPLETE. All 3 LLM call sites. DR40 rules added (FP-24/25 in FIQH module, relationship links in output). 1006 tests.
type: project
---

## Architecture (converged from ChatGPT DR + Claude DR)

**2-message instruction sandwich:**
- Message 1 (system, STABLE, CACHED): Constitution — role, hard invariants, conflict resolution, XML-tagged
- Message 2 (user, DYNAMIC): Active rules (core + conditional modules) + input data + critical reminders at end

**Progressive disclosure:** Compute flags from chunk metadata (has_verse, has_isnad, has_fiqh, has_dialectical, has_definition) → load only relevant rule modules. DEFINITION now triggers FIQH rules (FP-25 definition pair splitting, added DR40).

**CONSTITUTION precedence stack (re-ranked by DR40 2026-04-08):**
1. Speaker-role correctness
2. Dialogue completeness
3. Textual/grammatical integrity
4. Leaf-atomicity (was: self-containment)
5. Pedagogical packaging (was: granularity — lowest)

**Key findings:**
- Multi-turn splitting degrades 39% (Laban et al. 2025)
- English instructions outperform Arabic even for Arabic tasks (2024 study)
- XML tags: up to 40% variation from format (He et al.)
- Claude recency compliance advantage — end-positioned rules effective
- Irrelevant rules demonstrably hurt (ICML 2023, IFScale NeurIPS 2025)

**Implementation status:**
- IU-1–IU-9: COMPLETE (Sessions 12-13)
- DR40 amendments: COMPLETE (Session 20) — conditional evidence split, definition pair split, relationship links in output format
- IU-10 (A/B test): PENDING — needs ~EUR 10 budget

**How to apply:** The prompt architecture is stable. Future changes should be module-level (adding/modifying GROUP rule modules), not structural. New rules go in the appropriate conditional module.
