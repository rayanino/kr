---
name: research_sprint_findings
description: Key findings from 2026-03-28 research sprint (19 tasks, 9300 lines) — bugs, tools, optimizations, domain gaps
type: project
---

Research sprint (commit 07ed999b) produced 18 files across Claude/Codex/Gemini. Tracked in FINDINGS_TRACKER.md.

**Critical bugs found:**
- TermVariant model incompatible between excerpting and taxonomy contracts (will crash at runtime)
- GapType enum: taxonomy has 6 values, synthesis only 3
- Consensus failures silently absorbed (invisible in Phase3Result.errors)
- word_count not enforced at AssembledChunk construction (I-AC-1 gap)

**Top tools to integrate:**
- Tanzil Quran text for deterministic citation detection (zero LLM cost)
- usul-data authors.json (6,236 scholar records, MIT license) for scholar_authority
- GATE Arabic embeddings for taxonomy pre-filtering (80-90% fewer LLM calls)
- CAMeL Tools / CAMeLBERT-CA for classical Arabic NLP

**Key validated insight:** IslamicLegalBench shows best single LLM achieves only 68% accuracy with 21% hallucination on Islamic legal content — independently validates KR's multi-model consensus approach (D-041).

**Only optimization that matters:** Parallel execution via ThreadPoolExecutor(4) gives 4-8x speedup with zero accuracy risk. All other optimizations (batching, caching, embeddings) are marginal or rejected.

**Why:** These findings represent ~1.1M tokens of research investment. FINDINGS_TRACKER.md ensures they're visible in every session.

**How to apply:** Check FINDINGS_TRACKER.md at session start alongside NEXT.md. Fix BUG items first, then IMP items, then TAX items before taxonomy build.
