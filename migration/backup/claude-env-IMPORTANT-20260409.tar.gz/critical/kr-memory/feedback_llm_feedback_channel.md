---
name: LLM Feedback Channel Principle
description: Every engine LLM call should capture system feedback from the LLM itself — it has unmatched insights from literally doing the work. Pipeline-wide principle.
type: feedback
---

Allow LLMs doing excerpting/taxonomy/synthesis to give feedback on the system alongside their task output. The LLMs processing text have "unmatched insights; they are LITERALLY DOING IT."

**Why:** Owner PRD review 2026-04-07. "there should be - especially in this development phase of the pipeline - always some kind of 'feedback: ...' response, possibly by sending a follow-up prompt. THIS IS THE WAY TO IMPROVE THE PIPELINE."

**How to apply:** Every LLM call in the pipeline captures a feedback field: missing tree branches, structural suggestions, quality observations, edge cases noticed. This feedback is logged and reviewed during hardening cycles. NOT acted on automatically — but collected as improvement signal.
