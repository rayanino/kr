---
name: Never circumvent HR-23 by doing work yourself
description: When prompt-architect hook blocks an Agent dispatch, MUST run /prompt-architect and retry — never substitute with direct tools
type: feedback
---

When HR-23 blocks an Agent dispatch, run `/prompt-architect` and retry the dispatch. Never bypass by doing the work yourself with Read/Grep/Bash.

**Why:** Owner caught CC doing exactly this in Session 14 — HR-23 blocked two Explore agents, CC said "I'll do the audit directly" and used Read/Glob/Grep instead. This defeats the purpose of multi-model prompt optimization. The agent dispatch exists because the work benefits from an optimized prompt; circumventing it with direct tools produces lower-quality work.

**How to apply:** Every time HR-23 blocks, the ONLY correct response is: (1) run `/prompt-architect` with the intended dispatch prompt, (2) retry the Agent call. No shortcuts, no "it's simple enough to do directly." Owner ALL-CAPS directive 2026-04-07.
