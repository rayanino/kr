---
name: Owner ideas are INSPIRATION not instructions — must be researched and validated
description: Every owner idea submitted through the dashboard must be critically evaluated, researched via DR, and validated before implementation. Owner explicitly says his ideas could be harmful if implemented blindly.
type: feedback
---

Owner ALL-CAPS (2026-04-07): "ALWAYS REMEMBER THAT MY IDEAS ARE NOT INSTRUCTIONS; THEY ARE JUST INSPIRATION, NEED CRITICAL AND DEEP RESEARCH AND EVALUATION. I MAY AS WELL DIG MY OWN GRAVE WITH AN IDEA."

**Why:** The owner has minimum Islamic knowledge and zero technology skills. His ideas come from user experience intuition, which is valuable as SIGNAL but dangerous as DIRECTIVES. An idea like "split all excerpts shorter" might destroy scholarly unit integrity.

**How to apply:**
1. Receive and acknowledge the idea
2. Deploy DR for critical evaluation (ChatGPT for feasibility, Claude for scholarly impact, Gemini for pedagogical alignment)
3. Coworker consensus before any implementation
4. The idea pipeline is: received → researched → validated → implemented (or rejected with explanation)
5. DR should be deployed for ANYTHING that benefits from advanced reasoning, not just "research topics"

This extends feedback_owner_signal_not_directive.md with the explicit "DIG MY OWN GRAVE" warning.
