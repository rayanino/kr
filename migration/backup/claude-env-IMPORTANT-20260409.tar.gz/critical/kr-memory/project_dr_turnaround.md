---
name: DR turnaround is 10min-1hr, not days. Owner relays without reading.
description: DR responses arrive within 10-60 minutes. Owner downloads file and relays path without reading content. System processes everything. At 10-20 relays/day this is near-real-time research throughput.
type: project
---

Owner stated (2026-04-07): "A DR prompt takes 10 minutes, up to 1 hour at worst (ChatGPT / Claude Chat / Gemini DR mode). I don't read it, I just download it and relay it."

**Implications:**
- DR is near-synchronous, not async. Owner can relay morning prompts and have results by lunch.
- At 10-20 relays/day × 10-60 min each, the system can queue batches and receive results in hours.
- Owner is a pure relay — download file, tell system the path. Zero cognitive load.
- The system must process DR responses automatically when the owner provides the file path.
