---
name: Excerpting Foundations Hardening Program
description: Multi-session hardening. Session 20 COMPLETE — DR40 granularity calibration implemented. 1006 tests. Campaign rerun validated 5 structural fixes. Next = smoke test on taysir talaq with new split rules.
type: project
---

## Status (Session 20, 2026-04-08)

Protocol v5.0.2. All 4 OQs RESOLVED. DR40 implemented. 1006 tests pass.

### Session 20 accomplishments (DR40 implementation)
- All 5 DR40 decisions implemented: SPEC (FP-13/23/24/25, §6.24/6.25, PS-1), contracts (RelationshipType, UnitRelationship, related_units), prompts (CONSTITUTION, GROUP rules), phase3 propagation, 18 regression tests
- 4-reviewer /codex-verify: 2 CRITICAL (stale index after merge, no bounds validation), 3 HIGH (self-ref, duplicates, validation gap) — all fixed
- _reindex_related_units() helper, I-TU-10 validation, ge=0 on target_unit_index

### Session 19 (campaign rerun, 2026-04-08)
- Campaign rerun: 1,491 excerpts. Sub-MV-1: 244→0. SC FULL: 68.7%→85.4%
- CRITICAL: 3 sessions (17-19) ignored owner_feedback.jsonl — core quality problem untouched
- 10 Gemini DR Batch 2 responses ingested (taxonomy decisions)

### Session 17 (campaign evaluation, 2026-04-07)
- 10 taysir excerpts deep-evaluated. 6/6 coworkers. Verdict: 4 PASS, 3 ADVISORY, 3 FAIL
- 5 CONFIRMED findings (numbered-list frag, SC misrating, FR-1 gate, OCR corruption, المعنى الإجمالي)

### Next steps
1. Smoke test on taysir talaq chapter with updated prompts (verify LLM produces splits + links)
2. Dispatch Gemini CLI + Codex CLI for cross-validation of new split rules
3. Full campaign rerun to measure impact on all 1,491 excerpts

## Key Artifacts

| Artifact | Location |
|----------|----------|
| DR40 report | `reference/dr_reviews/DR40_granularity_calibration_chatgpt.md` |
| Owner feedback | `integration_tests/campaign_20260331/taysir/owner_feedback.jsonl` |
| Campaign eval report | `integration_tests/campaign_20260331/taysir/CAMPAIGN_EVAL_SESSION16.md` |
| Branch | `excerpting-foundations-hardening-20260404` |

**How to apply:** Next session: targeted smoke test on taysir talaq chapter, then full campaign rerun.
