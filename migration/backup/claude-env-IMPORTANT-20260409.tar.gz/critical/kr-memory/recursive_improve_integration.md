---
name: recursive-improve Integration
description: recursive-improve (kayba-ai) integrated for LLM call trace capture, analysis, and benchmarking — gated improvement with content safety constraints
type: project
---

recursive-improve (v0.1.0) integrated 2026-03-28 for trace capture and analysis of pipeline LLM calls.

**Architecture:**
- **Trace bridge** (`shared/llm/ri_trace_bridge.py`) hooks into CLI adapter events (completion:kwargs/response/error) to capture subprocess-based LLM calls in ri format
- **ri.patch()** captures SDK-based calls (consensus module's Instructor, OpenRouter) natively
- Both feed into `ri.session()` context manager → JSON traces in `eval/traces/`
- 7 KR-specific detectors in `eval/compute_baselines.py` (json_retry, validation_retry, consensus_disagreement, arabic_encoding, human_gate, low_confidence, attribution_conflict)

**Safety constraints:**
- `/ratchet` NEVER used for content classification prompts (genre/author/science/school)
- `scripts/ri_review.py` auto-rejects content-affecting proposals
- All improvement proposals require human review before application

**Usage:** `--traces eval/traces/` flag on `run_pipeline.py` and `run_integration_test.py`

**Why:** KR had result persistence but no systematic trace analysis or improvement benchmarking across runs. ri fills this gap while respecting human gate invariant.

**How to apply:** Use `--traces` flag on every pipeline run with LLM calls. Run `recursive-improve eval` after accumulating traces. Use `recursive-improve benchmark` to compare across improvement cycles.
