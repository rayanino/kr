---
name: DR dispatch must use small focused units
description: Owner praised Batch 2's 10 separate DR prompts each focusing deeply on one topic. This is the correct DR scale — many small units, not few large ones.
type: feedback
---

DR dispatches must be broken into SMALL FOCUSED UNITS — one topic per DR session, researched deeply. The owner's strongest positive reaction (ALL-CAPS praise, 2026-04-08) was to Batch 2's pattern: 10 separate Gemini DR prompts, each with a narrow deep-dive focus.

**Why:** Small units let DR go deep on each topic rather than superficially covering many. The owner said "THIS IS THE SCALE I'M TALKING ABOUT" — meaning previous DR usage was too consolidated. Every major question should be its own DR session.

**How to apply:** When preparing DR dispatches, decompose the research surface into the smallest independent questions possible. 10 prompts with 1 question each > 2 prompts with 5 questions each. Depth per unit matters more than breadth per prompt. Apply to all DR targets (ChatGPT, Claude, Gemini).
