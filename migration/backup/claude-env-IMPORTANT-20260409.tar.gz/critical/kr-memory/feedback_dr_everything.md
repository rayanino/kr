---
name: HARD RULE — Deploy Deep Research for EVERYTHING, not just major questions
description: Owner ALL-CAPS directive 2026-04-07. DR reports are the highest-ROI activity in the project. Deploy DR for even small questions. The quality surge is transformative. Every CC session must maximize DR deployment.
type: feedback
---

**HARD RULE: Deploy Deep Research for EVERYTHING. Not just major questions — EVERYTHING.**

Owner directive (2026-04-07, ALL-CAPS = Tier 1 semantic content): "LITERALLY FORCE DR EVEN FOR THE SILLIEST THINGS ... WOWW"

**Why:** The owner observed that DR reports consistently produce transformative results:
- DR17 grounded the entire protocol in 1000 years of practice
- DR18 built the detection enforcement layer (4 scripts)
- DR19 built the prevention enforcement layer (3 hooks) + proved documentary enforcement fails mathematically
- DR20-DR22 (in flight) target book selection, prompt compression, and multi-layer text detection
- Every single DR changed the project more than multiple sessions of direct coding

**How to apply:**
- At EVERY decision point, ask: "Would a DR report give us better information than CC + coworkers alone?"
- The answer is almost always YES. DR has access to academic papers, primary sources, cross-domain knowledge, and deep research capability that CLI coworkers lack.
- Deploy DR even for seemingly small questions: "How should we name this enum?" → DR on naming conventions in Arabic NLP. "What test fixtures do we need?" → DR on representative corpus selection (DR20).
- The cost is ZERO (owner has unlimited DR access). The only cost is time (15-30 min per report) and the owner's relay effort. The owner explicitly said he is willing.
- **Every CC session should deploy at minimum 1 DR per major milestone.** If a session ends without having deployed any DR, that is a missed opportunity, not efficiency.

**Enforcement:**
- This is now HR-27 in the protocol
- The handoff template self-audit should include: "DRs deployed this session: [count]. Topics: [list]."
- The session scorecard (S-12) should track DR deployment rate

**The 3 DR sources and their strengths:**
- ChatGPT DR: Error patterns, architectural analysis, feasibility, book/corpus knowledge
- Claude DR: Scholarly reasoning, boundary quality, edge cases, academic research synthesis
- Gemini DR: Islamic study methodology, pedagogical design, Arabic analysis (STRONGEST for Islamic domain per owner assessment)
