---
name: GOVERNING MISSION — Autonomous system exists to eliminate summer time-waste
description: The 3-month autonomous period has ONE purpose: do everything that would waste summer time NOW, while time is cheap and quality can be maximized. Three pillars: DR research, pipeline hardening, creative idea generation.
type: project
---

Owner ALL-CAPS directive (2026-04-07): "THE MAIN FOCUS IS ON NOT LOSING TIME IN THE SUMMER. LONG TEDIOUS TASKS ELIMINATED RIGHT NOW."

## The Three Pillars

### Pillar 1: Deep Research (highest priority)
- DR takes ~30 minutes per prompt on average
- In summer, 30 minutes per DR is CATASTROPHIC — every hour counts
- The autonomous system must generate and queue DR prompts at maximum throughput
- Owner relays 10-20/day. 3 months = 830-1660 DRs. All research done before July.
- "PROBABLY THE BEST INVESTMENT OF TIME"

### Pillar 2: Pipeline Hardening (equally important)
- Make sure what EXISTS works reliably: excerpting engine, taxonomy engine, normalization
- The summer will BUILD ON TOP of what's here — if the foundation is bugged, everything built on it is corrupt
- Focus: edge cases, reliability, error handling, test coverage
- NOT feature-richness. A reliable engine with fewer features beats a feature-rich engine that silently corrupts data
- "Even if an engine is not crazy-feature-rich, it still works reliable"

### Pillar 3: Creative Ideas (the summer to-do list)
- Generate big, creative, out-of-the-box ideas that take DAYS OR WEEKS to fully develop
- These are the "what to build in summer" items
- Quick ideas are NOT the focus — those can be generated in summer
- The value is in ideas that need long gestation: architecture proposals, novel approaches, cross-engine innovations
- "These ideas may take up to days or weeks to be fully generated. Which in the summer cannot be done."

## The Governing Principle

Time is the scarce resource. The autonomous system has 3 months where:
- Speed doesn't matter (autonomous, owner is not waiting at screen)
- Quality is unlimited (can iterate, re-run, validate)
- 3 months is plenty for slow, thorough work

In summer:
- Speed matters enormously (owner running sessions 24/7, every hour counts)
- Quality must be INSTANT (no waiting 30 min for a DR, no discovering a base engine is bugged)
- Time is the bottleneck

Therefore: everything SLOW goes into the autonomous period. Everything FAST stays for summer.
