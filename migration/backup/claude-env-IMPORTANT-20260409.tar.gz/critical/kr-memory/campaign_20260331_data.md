---
name: campaign_20260331 ($97 full-book excerpt run)
description: Accidental full-book excerpting run on 2026-03-31 costing $97 — 2,303 excerpts preserved with 1,100 raw LLM responses. DO NOT DELETE. Use as BEFORE baseline for prompt hardening comparison.
type: project
---

On 2026-03-31, an unintended full-book excerpting campaign ran all 5 test packages through the pipeline using Opus as primary model ($97 total via OpenRouter). The run was started by a prior session (not the evaluation orchestrator session). All data is preserved at `integration_tests/campaign_20260331/`.

**Why:** The contracts.py model defaults had Opus as primary (expensive) instead of GPT-5.4 (cheap). The v1 smoke run only cost €3 because it used explicit CLI overrides. The campaign didn't have those overrides. Defaults were fixed in commit `9c074239`.

**How to apply:**
- This data is the BEFORE baseline for prompt hardening comparison (2,303 excerpts with OLD prompts)
- After hardened-prompt re-run, compare campaign_20260331 vs campaign_v2 at 3 levels: chunk-level, excerpt-level, gold-level
- Use Codex's comparison methodology: McNemar for paired pass/fail, Wilcoxon for paired metrics, bootstrap 95% CIs
- The 1,100 raw LLM responses contain token/cost/latency data worth extracting
- Gemini confirmed full-book data is BETTER than smoke data ("atomized scholarly units" vs "fragments")
- A gold_core_100 set should be built from this data (30 taysir + 30 ibn_aqil + 20 ext_39 + 20 ext_46)

| Package | Excerpts | Cost | Genre |
|---------|----------|------|-------|
| taysir | 1,283 | $58.12 | hadith sharh (Hanbali fiqh) |
| ibn_aqil_v3 | 282 | $10.47 | nahw sharh |
| ext_46_qa | 300 | $10.60 | usul al-nahw |
| ibn_aqil_v1 | 241 | $11.04 | nahw sharh |
| ext_39_masala | 197 | $6.65 | fiqh masala |

Analysis artifacts should be at: `integration_tests/campaign_20260331/analysis/`
Gemini's scholarly advice: `integration_tests/campaign_20260331/gemini_analysis_advice.md`
