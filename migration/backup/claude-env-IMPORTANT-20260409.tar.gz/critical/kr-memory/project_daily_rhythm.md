---
name: Owner daily rhythm — breakfast dashboard, university study, evening review
description: Owner opens dashboard at breakfast, starts system, studies university (NOT Islamic studies) while system runs, reviews after run. System only notifies when it NEEDS something.
type: project
---

Owner described ideal daily flow (2026-04-07):
1. **Breakfast**: Open browser dashboard, review what system did yesterday, leave ideas/feedback/comments
2. **Launch**: Start the system run manually
3. **Study**: Work on university degree (slides, lectures) — NOT Islamic study. Laptop is open.
4. **System runs silently** in background. NO progress notifications. ONLY notify if it NEEDS owner action (DR relay, decision, error).
5. **After run finishes**: Check and review findings, leave comments
6. **Repeat daily**

**Critical clarification**: When owner says "studying" he means his college degree, not Islamic texts. The KR library is a personal project alongside university. The system must not interfere with university work.

**Notification model**: Silent by default. Only interrupt for owner-needs (not progress updates). Owner checks results at his own pace (breakfast + evening).
