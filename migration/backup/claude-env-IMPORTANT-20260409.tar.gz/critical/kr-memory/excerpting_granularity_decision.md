---
name: Excerpting granularity decision — DR-1 adopted, DR-2 NOW ADOPTED (DR40), DR-3 adopted
description: DR-2 (evidence splitting) SUPERSEDED by DR40 on 2026-04-08. All 3 rules now adopted. Definition pairs split, evidence split by type, khilaf preserved. Relationship links (FP-23) replace bundling.
type: project
---

On 2026-04-01, the owner reviewed taysir excerpts and found them too coarse. This triggered 3 domain rules.

**DR-1 (Definition Pairs): ADOPTED** (2026-04-01, 4-1 conditional)
- Split لغة/شرعا definitions. Now formalized as FP-25 and §6.24 (DR40).

**DR-2 (Evidence Splitting): ADOPTED** (2026-04-08, DR40 superseded the deferral)
- Originally deferred (2-3 against). DR40 (ChatGPT Deep Research) demonstrated that conditional splitting is safe: evidence stays with ruling ONLY when syntactically inseparable, ≤15 words, or splitting breaks dialogue integrity. Otherwise split by type.
- Formalized as FP-24 and §6.25.
- Relationship links (FP-23) connect split evidence units back to their ruling.
- Owner's 2 concrete rejections (2026-03-31) provided the calibration evidence.

**DR-3 (Khilaf Preservation): ADOPTED** (2026-04-01, 5-0 unanimous)
- Scholarly disagreement passages stay together.

**Key architectural change (DR40):** The old "evidence stays with ruling" was REPLACED by a conditional rule. FP-13 precedence stack re-ranked: leaf-atomicity now #4 (above pedagogical packaging). Over-granularity is recoverable; under-granularity blocks synthesis permanently.

**Why:** Owner feedback (2 rejections, 2026-03-31): "I might as well just take pictures of books." The pipeline was producing page-sized excerpts indistinguishable from photographing source pages. Leaf-level comparison requires atomic function-scoped units.

**How to apply:** FP-24/25 are now in SPEC, prompts, and contracts. Next: validate with targeted smoke test on the taysir talaq chapter to confirm LLM compliance.
