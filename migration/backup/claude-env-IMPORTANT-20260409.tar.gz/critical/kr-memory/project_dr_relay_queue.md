---
name: CRITICAL IDEA — Autonomous system prepares DR relay prompts for owner
description: The system should identify research needs, draft optimized prompts for ChatGPT/Claude/Gemini DR, and queue them for the owner to relay. Goal: all research done before summer 2026.
type: project
---

Owner ALL-CAPS idea (2026-04-07): "THE AUTONOMOUS SYSTEM CAN HAVE A SECTION 'RESEARCH' THAT PREPARES PROMPTS FOR ME TO RELAY TO CHATGPT DR/CLAUDE DR/GEMINI DR, SO THAT BY THE SUMMER WE HAVE ALL RESEARCH NEEDED!!!"

**Why:** The #1 hard blocker for summer full-build is unfinished research: questionnaires, data analysis, taxonomy tree research, scholarly methodology questions. The owner's time is the bottleneck. DR relays are zero-cost (free with subscriptions) but require the owner to physically paste prompts. The system can prepare optimized prompts and the owner can relay them during downtime.

**How to apply:**
1. The autonomous system identifies research gaps (from SPEC, from hardening, from engine status)
2. It drafts prompts targeting the RIGHT DR source (ChatGPT for architecture, Claude for scholarly reasoning, Gemini for Islamic methodology)
3. Each prompt goes through /prompt-architect optimization
4. Prompts are queued in the dashboard with: target DR, estimated value, what it unblocks
5. Owner relays at his convenience (lectures, commute, downtime)
6. Owner pastes the DR response back into the dashboard
7. System processes the DR response and integrates findings

**Summer readiness target:** By July 1, all research needed for the full-build is complete. Zero "we need to research this first" blockers remain.
