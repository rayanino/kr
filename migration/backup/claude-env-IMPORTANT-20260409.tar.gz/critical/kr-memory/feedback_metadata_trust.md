---
name: Never Trust Metadata Summaries — Always Derive from Source
description: File headers, summary tables, and aggregated counts can be stale or wrong. Always grep-count from the actual data before updating.
type: feedback
---

Never assume that a file's header counts, summary table, or aggregated statistics are correct. Always derive counts from the actual data.

**Why:** The adversarial catalog header claimed "silent_corruption: 9" when grep showed 13 cases. The initial update blindly added to the wrong base number, propagating the error. Only self-review Round 3 (grep-and-count verification) caught it.

**How to apply:** When updating any summary, count, or aggregate:
1. Grep the actual data (e.g., `grep -c "pattern" file`)
2. Compare against the existing summary
3. If they differ, the EXISTING summary is wrong — fix it, don't propagate
4. Include the verification command in your self-review checklist
