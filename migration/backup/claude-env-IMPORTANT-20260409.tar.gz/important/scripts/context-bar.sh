#!/bin/bash

# Claude Code Status Line
# Style: Oh My Posh-inspired (username | folder | git | model | context | time)

# ── Colors (256-color, dimmed to suit status bar rendering) ──────────
C_RESET='\033[0m'
C_YELLOW='\033[38;5;178m'   # username  — mirrors OMP yellow session segment
C_ORANGE='\033[38;5;173m'   # path      — mirrors OMP orange path segment
C_GREEN='\033[38;5;71m'     # git       — mirrors OMP green git segment
C_BLUE='\033[38;5;74m'      # model/accent
C_GRAY='\033[38;5;245m'     # separators and secondary text
C_DIM='\033[38;5;240m'      # time      — mirrors OMP right-prompt dim
C_BAR_EMPTY='\033[38;5;238m'
C_WARN='\033[38;5;208m'
C_CRIT='\033[38;5;196m'

input=$(cat)

# ── Segment 1: Username (yellow — OMP session segment) ───────────────
username=$(whoami 2>/dev/null || echo "?")

# ── Segment 2: Current folder (orange — OMP path/folder segment) ─────
cwd=$(echo "$input" | jq -r '.cwd // empty')
dir=$(basename "$cwd" 2>/dev/null || echo "?")

# ── Segment 3: Git branch + status (green — OMP git segment) ─────────
branch=""
git_marker=""
if [[ -n "$cwd" && -d "$cwd" ]]; then
    branch=$(git -C "$cwd" --no-optional-locks rev-parse --abbrev-ref HEAD 2>/dev/null)
    [[ "$branch" == "HEAD" ]] && branch=$(git -C "$cwd" --no-optional-locks rev-parse --short HEAD 2>/dev/null)
    if [[ -n "$branch" ]]; then
        porcelain=$(git -C "$cwd" --no-optional-locks status --porcelain -uall 2>/dev/null)
        staged=$(echo "$porcelain" | grep -c '^[MADRC]'  || true)
        unstaged=$(echo "$porcelain" | grep -c '^.[MD]'  || true)
        untracked=$(echo "$porcelain" | grep -c '^??' || true)

        markers=""
        [[ "$staged"    -gt 0 ]] && markers+=" +${staged}"
        [[ "$unstaged"  -gt 0 ]] && markers+=" ~${unstaged}"
        [[ "$untracked" -gt 0 ]] && markers+=" ?${untracked}"

        # Ahead/behind (skip lock, best-effort)
        counts=$(git -C "$cwd" --no-optional-locks rev-list --left-right --count HEAD...@{upstream} 2>/dev/null)
        if [[ -n "$counts" ]]; then
            ahead=$(echo "$counts" | cut -f1)
            behind=$(echo "$counts" | cut -f2)
            [[ "$ahead"  -gt 0 ]] && markers+=" ↑${ahead}"
            [[ "$behind" -gt 0 ]] && markers+=" ↓${behind}"
        fi

        git_marker="${branch}${markers}"
    fi
fi

# ── Segment 4: Model (blue — accent) ─────────────────────────────────
model=$(echo "$input" | jq -r '.model.display_name // .model.id // "?"')

# ── Segment 5: Context bar (color-shifts at 75 % / 90 %) ─────────────
max_context=$(echo "$input" | jq -r '.context_window.context_window_size // 200000')
max_k=$((max_context / 1000))
transcript_path=$(echo "$input" | jq -r '.transcript_path // empty')

calc_bar() {
    local pct=$1 prefix=$2 bar_width=10 bar="" color="$C_BLUE"
    [[ $pct -gt 100 ]] && pct=100
    [[ $pct -ge 75 ]] && color="$C_WARN"
    [[ $pct -ge 90 ]] && color="$C_CRIT"
    for ((i=0; i<bar_width; i++)); do
        local progress=$((pct - i * 10))
        if   [[ $progress -ge 8 ]]; then bar+="${color}█${C_RESET}"
        elif [[ $progress -ge 3 ]]; then bar+="${color}▄${C_RESET}"
        else                              bar+="${C_BAR_EMPTY}░${C_RESET}"
        fi
    done
    echo "${bar} ${C_GRAY}${prefix}${pct}% of ${max_k}k"
}

baseline=20000
ctx=""
pct=0
if [[ -n "$transcript_path" && -f "$transcript_path" ]]; then
    context_length=$(jq -s '
        map(select(.message.usage and .isSidechain != true and .isApiErrorMessage != true)) |
        last |
        if . then
            (.message.usage.input_tokens // 0) +
            (.message.usage.cache_read_input_tokens // 0) +
            (.message.usage.cache_creation_input_tokens // 0)
        else 0 end
    ' < "$transcript_path" 2>/dev/null)
    if [[ "$context_length" -gt 0 ]]; then
        pct=$((context_length * 100 / max_context))
        ctx=$(calc_bar "$pct" "")
    else
        pct=$((baseline * 100 / max_context))
        ctx=$(calc_bar "$pct" "~")
    fi
else
    pct=$((baseline * 100 / max_context))
    ctx=$(calc_bar "$pct" "~")
fi

# ── Session cost (optional, from transcript) ──────────────────────────
session_cost=""
if [[ -n "$transcript_path" && -f "$transcript_path" ]]; then
    cost_val=$(jq -s '[.[] | select(.costUSD != null) | .costUSD] | add // 0' \
               < "$transcript_path" 2>/dev/null)
    if [[ -n "$cost_val" ]] && (( $(echo "$cost_val > 0" | bc -l 2>/dev/null || echo 0) )); then
        cost_fmt=$(printf "%.2f" "$cost_val" 2>/dev/null || echo "$cost_val")
        session_cost="\$${cost_fmt}"
    fi
fi

# ── Segment 6: Time (dimmed — OMP right-prompt time segment) ─────────
now_time=$(date +"%H:%M:%S")

# ── Separator glyph ───────────────────────────────────────────────────
SEP="${C_GRAY} | ${C_RESET}"

# ── Line 1: main status bar ───────────────────────────────────────────
line1=""
line1+="${C_YELLOW}${username}${C_RESET}"
line1+="${SEP}${C_ORANGE}${dir}${C_RESET}"
[[ -n "$git_marker" ]] && line1+="${SEP}${C_GREEN}${git_marker}${C_RESET}"
line1+="${SEP}${C_BLUE}${model}${C_RESET}"
line1+="${SEP}${ctx}${C_RESET}"
[[ -n "$session_cost" ]] && line1+="${SEP}${C_GRAY}${session_cost}${C_RESET}"
line1+="${SEP}${C_DIM}${now_time}${C_RESET}"

printf '%b\n' "$line1"

# ── Line 2: last user message (truncated to match line 1 width) ───────
if [[ -n "$transcript_path" && -f "$transcript_path" ]]; then
    plain_ref="${username} | ${dir}"
    [[ -n "$git_marker" ]] && plain_ref+=" | ${git_marker}"
    plain_ref+=" | ${model} | xxxxxxxxxx ${pct}% of ${max_k}k tokens | ${now_time}"
    max_len=${#plain_ref}

    last_user_msg=$(jq -rs '
        def is_unhelpful:
            startswith("[Request interrupted") or
            startswith("[Request cancelled") or
            . == "";
        [.[] | select(.type == "user") |
         select(.message.content | type == "string" or
                (type == "array" and any(.[]; .type == "text")))] |
        reverse |
        map(.message.content |
            if type == "string" then .
            else [.[] | select(.type == "text") | .text] | join(" ") end |
            gsub("\n"; " ") | gsub("  +"; " ")) |
        map(select(is_unhelpful | not)) |
        first // ""
    ' < "$transcript_path" 2>/dev/null)

    if [[ -n "$last_user_msg" ]]; then
        if [[ ${#last_user_msg} -gt $max_len ]]; then
            echo "  ${last_user_msg:0:$((max_len - 3))}..."
        else
            echo "  ${last_user_msg}"
        fi
    fi
fi
