# Plan: Optimize Owner Questionnaire for Offline Completion

## Goal
Make the questionnaire fully self-contained and efficient for the owner to complete alone over Thu-Sun without CC available.

## Files to Modify
1. `C:\Users\Rayane\Desktop\kr\integration_tests\questionnaire\OWNER_QUESTIONNAIRE.md`
2. `C:\Users\Rayane\Desktop\kr\integration_tests\questionnaire\RESPONSE_FORMAT.md`

## Changes

### 1. Quick Reference Card (top of OWNER_QUESTIONNAIRE.md)

Add a bordered quick-reference section at the very top, before the current "What This Is" section. Contents:
- Total interactions: ~35 (count from document)
- Estimated time: 15-25 hours across Thu-Sun
- Response format: multiple-choice REQUIRED + optional detailed text
- How to save progress: just save the file after each answer
- When done: commit to repo, or leave in place for CC on Monday
- Tip: work in any order -- phases are independent

### 2. Multiple-Choice Options Added to Specific Interactions

For each interaction listed below, add a multiple-choice block BEFORE the existing response template. The MC block uses the format:

```
**Quick answer (required):**
- [ ] A) ...
- [ ] B) ...
- [ ] C) ...
```

The existing "Tell me everything you are thinking" or question text stays. The MC is an additional first-pass response mechanism.

Interactions to convert (per the task spec):
- **G-1** (short excerpt): A) Yes, keep as its own entry / B) No, too short to be useful / C) Depends -- explain
- **G-3** (numbered points): A) One entry for all points / B) Each point is its own entry / C) Group related points together
- **G-4** (exception): A) Keep together always / B) Separate, with link / C) Depends on length -- explain
- **SC-1** (summary note): A) The summary is enough / B) I need more context / C) I'd rather see the full original
- **SC-2** (backward reference): A) Acceptable / B) Frustrating, needs resolution / C) Depends -- explain
- **D-1** (definition split): A) Keep together / B) Split into two linked entries / C) Depends on length -- explain
- **E-1** (multiple citations): A) All evidence together / B) Each type separate / C) Each individual verse/hadith separate
- **E-2** (hadith + ruling): A) Together always / B) Separate with link / C) Depends -- explain
- **K-1** (debate): A) All positions together / B) Each position separate with links / C) Depends on length
- **K-3** (linked positions): A) Useful -- I'd navigate between them / B) Confusing -- keep together / C) Useful for some, confusing for others
- **GN-1** (genre): A) Same approach for all sciences / B) Different sciences need different approaches / C) Not sure -- explain
- **L-1** (editor commentary): A) Part of the main entry / B) Separate linked entry / C) Hidden unless I ask
- **L-3** (footnotes): A) Part of the main entry / B) Separate linked entry / C) Hidden unless I ask
- **SC-4** (system uncertainty): A) Show with warning / B) Hide until reviewed / C) Show but mark clearly
- **S-1b** (cost of granularity): A) More entries is better / B) Fewer entries is better / C) Balance -- explain threshold
- **CJ-1**: Already has A/B/C -- keep as is, just ensure format consistency

Interactions explicitly NOT converted (open-ended, would lose signal):
- F-1, F-2, F-7 (foundational open-ended)
- S-2, S-3 (synthesis open-ended)
- F-3, F-4, F-5, F-6 (initial reactions to excerpts -- need unbiased open text)
- F-8 (design exploration)
- G-2, D-2, D-3, E-3, K-2, GN-2, QA-1, L-2, SC-3, CJ-2, CJ-3, CJ-4, S-1, S-1c (various -- either already structured, placeholder, or open-ended by necessity)

### 3. RESPONSE_FORMAT.md Simplification

Rewrite to make the three-tier response clear:
1. **Multiple-choice** (REQUIRED where provided) -- circle/select A/B/C/D
2. **Immediate reaction** (REQUIRED) -- 1-2 sentences gut feeling
3. **Detailed analysis** (OPTIONAL but encouraged) -- as long as you want
4. **Verdict + Confidence** (REQUIRED) -- keep existing checkboxes
5. **Edge case fields** (REQUIRED for [EDGE CASE] only) -- keep

Add a note: "For interactions WITHOUT multiple-choice options, start with your immediate reaction."

### 4. Arabic Text Verification

Scan all interactions for any that say "read this file" or "open this JSONL" or reference external files for Arabic text. Based on my read-through:
- All Arabic text IS inline in the document already
- No interaction references external files for reading
- The only external reference is `RESPONSE_FORMAT.md` which is the format guide, not content
- CJ-2 and CJ-3 are placeholders ("will be filled in") -- these are fine, they don't ask the owner to read external files

Result: No changes needed for item 4. All Arabic is inline.

## Execution Order

1. Edit RESPONSE_FORMAT.md first (simpler, establishes the format the questionnaire references)
2. Edit OWNER_QUESTIONNAIRE.md:
   a. Add Quick Reference Card at the top
   b. Update the "How to respond" paragraph to reference the new format
   c. Add multiple-choice blocks to each of the ~16 interactions listed above
   d. Verify CJ-1 formatting consistency

## Risk Assessment

- LOW: Multiple-choice options might bias the owner toward listed options. Mitigated by keeping the open-ended text fields and adding "C) Depends -- explain" as an escape hatch on most questions.
- LOW: Owner might only fill in MC and skip detailed text. Mitigated by marking immediate reaction as REQUIRED and noting that detailed text is where the real signal lives.
- NONE: Arabic text is already inline -- no changes needed there.

## Estimated Edit Count
- RESPONSE_FORMAT.md: 1 full rewrite (small file, 53 lines)
- OWNER_QUESTIONNAIRE.md: ~18 edits (1 insertion at top + 1 paragraph update + 16 MC block insertions)
