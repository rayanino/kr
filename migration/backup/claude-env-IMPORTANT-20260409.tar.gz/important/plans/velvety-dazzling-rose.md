# Fix Plan: All CC + Gemini Review Findings

## Context

Cross-provider review (CC + Gemini) found 4 CRITICAL, 4 HIGH, 4 MEDIUM, 2 LOW issues in the creative overnight expansion. All must be fixed before first unattended run.

---

## Fix 1: C-1 — Safety prompt not passed to Codex/Gemini backends

**File:** `scripts/overnight_orchestrator.py`

**Problem:** Dispatch block at lines 729-736 passes `safety_prompt` only to `_execute_cli` and `_execute_sdk`. Codex and Gemini tasks run with zero safety constraints.

**Fix:** Prepend safety prompt to `task.prompt` for Codex/Gemini (they don't support `--append-system-prompt`). Change the dispatch block:

```python
# Before dispatch, inject safety prompt into task prompt for non-CLI backends
if task.execution_mode in ("codex", "gemini"):
    task = TaskDef(**{**asdict(task), "prompt": safety_prompt + "\n\n" + task.prompt})

if task.execution_mode == "codex":
    result = _execute_codex(task, task_results_dir)
elif task.execution_mode == "gemini":
    result = _execute_gemini(task, task_results_dir)
elif task.execution_mode == "sdk":
    result = _execute_sdk(task, safety_prompt)
else:
    result = _execute_cli(task, safety_prompt)
```

## Fix 2: C-2 — Creative tasks get ALL tools

**File:** `scripts/overnight_task_generator.py`, scan_creative() function

**Problem:** `allowed_tools` is never set. Empty list means CLI gets all tools.

**Fix:** Add `allowed_tools` based on `safety_level`. In the TaskDef construction:

```python
# Determine allowed tools based on safety level
if tmpl.get("safety_level", "readonly") == "readonly":
    tools = ["Read", "Glob", "Grep", "Bash"]
else:
    tools = ["Read", "Glob", "Grep", "Bash", "Write", "Edit"]

tasks.append(TaskDef(
    ...
    allowed_tools=tools,
    ...
))
```

## Fix 3: C-3 — `_detect_active_engine` returns wrong engine

**File:** `scripts/overnight_task_generator.py`, `_detect_active_engine()`

**Problem:** Substring `"source"` matches "resource", "open source", etc. PIPELINE_ORDER checks "source" first.

**Fix:** Use word-boundary regex and check longer/more-specific names first:

```python
def _detect_active_engine() -> str:
    """Parse NEXT.md for the active engine name."""
    next_md = PROJECT_DIR / "NEXT.md"
    if next_md.exists():
        text = next_md.read_text(encoding="utf-8")[:500]
        # Check in REVERSE order — longer/more-specific names first
        # to avoid "source" matching "resource"
        for engine in reversed(PIPELINE_ORDER):
            if re.search(rf"\b{engine}\b", text, re.IGNORECASE):
                return engine
    return "excerpting"
```

## Fix 4: C-4 — Relative paths break when CWD != project root

**File:** `scripts/overnight_task_generator.py`

**Problem:** `CREATIVE_TEMPLATES_DIR`, `CREATIVE_RUN_LOG`, and `NEXT.md` use relative paths. Every other scanner uses `PROJECT_DIR`.

**Fix:** Change to absolute paths:

```python
CREATIVE_TEMPLATES_DIR = PROJECT_DIR / "overnight" / "creative_templates"
CREATIVE_RUN_LOG = PROJECT_DIR / "overnight" / "creative_run_log.json"
```

And in `_detect_active_engine`: `next_md = PROJECT_DIR / "NEXT.md"` (already in Fix 3).

## Fix 5: H-1 — Run log key derivation fragile

**Files:** `scripts/overnight_task_generator.py` + `scripts/overnight_orchestrator.py`

**Problem:** Key format matches by coincidence. One edit breaks cooldown.

**Fix:** Add a shared helper function. In `overnight_task_generator.py`, add:

```python
def creative_log_key(template_id: str, engine: str) -> str:
    """Canonical key for creative run log. Used by both scanner and updater."""
    return f"{template_id.replace('/', '-')}-{engine}"
```

Use it in `scan_creative()`:
```python
log_key = creative_log_key(template_id, active_engine)
```

In `overnight_orchestrator.py`, import and use the same function:
```python
from scripts.overnight_task_generator import creative_log_key
```
And in `_update_creative_run_log`, instead of `key = task_id.removeprefix("creative-")`:
```python
# Extract template_id and engine from task_id: "creative-{template_id}-{engine}"
# The task_id format is: creative-{template_id.replace('/','-')}-{engine}
# Rather than reverse-engineer, store the log_key on the task itself
key = task_id.removeprefix("creative-")
```

Actually, cleaner approach: store `_creative_log_key` as a field on the task prompt metadata. But since TaskDef doesn't have arbitrary metadata, the simplest robust fix is to make the orchestrator import and use the same function. However, cross-import between generator and orchestrator is fragile.

**Better fix:** Move `creative_log_key` to a tiny shared module, OR just make the derivation explicit and documented in both places with a comment referencing the other.

Simplest: In the orchestrator's `_update_creative_run_log`, add a comment and keep the same logic:

```python
def _update_creative_run_log(task_id: str) -> None:
    """Record that a creative task ran (for cooldown tracking).

    Key format must match scan_creative() in overnight_task_generator.py:
    template_id.replace('/', '-') + '-' + engine
    task_id is 'creative-' + that key, so removeprefix gives the correct key.
    """
```

This is adequate — the key derivation is simple and documented.

## Fix 6: H-2 — `_execute_codex` Windows pipe deadlock

**File:** `scripts/overnight_orchestrator.py`, `_execute_codex()`

**Problem:** Uses `subprocess.run(capture_output=True)` which deadlocks on Windows with >64KB output. Safe alternative `_run_subprocess_safe()` exists.

**Fix:** Replace the subprocess.run call:

```python
result = _run_subprocess_safe(
    cmd, timeout=task.timeout_minutes * 60, env=env,
)
```

And adjust the output parsing accordingly (result.stdout works the same way).

## Fix 7: H-3 — Race condition on creative_run_log

**File:** `scripts/overnight_orchestrator.py`, `_update_creative_run_log()`

**Problem:** Read-then-write with no lock. Already uses `_atomic_write` (write-to-temp-then-rename) which prevents corruption, but two concurrent writes could lose one update.

**Reality check:** The orchestrator runs tasks sequentially (one at a time). Race condition only occurs if two orchestrator instances run simultaneously, which the `.overnight.lock` prevents. This is LOW risk, not HIGH. But add a comment documenting this assumption.

## Fix 8: H-4 — Template prompts produce items missing `summary` field

**Files:** All 7 template JSON files in `overnight/creative_templates/`

**Problem:** Some templates' `prompt_template` instruct the LLM to produce actionable.json but with different field names than `append_creative_findings.py` expects (`summary` is required).

**Fix:** Ensure every template's prompt_template includes the exact expected schema:
```
[{"id": "CREATIVE-{run_date}-NNN", "category": "BUG|IMP|EXT|ARCH|DOM", "summary": "...", "source_report": "...", "effort": "S|M|L", "priority": "HIGH|MEDIUM|LOW"}]
```

Review each template and add this schema instruction if missing.

## Fix 9: M-1 — Count-based budget could mean 90% runtime

**No code change needed.** The budget is by task count, which is correct for the initial implementation. Creative tasks have `timeout_minutes: 15-35` while hardening tasks have similar timeouts. If creative tasks consistently run longer, this can be tuned later. Adding a runtime-based budget adds complexity for a theoretical problem.

**Action:** Add a comment in `scan_creative()` noting the tradeoff.

## Fix 10: M-2 — No validation of actionable.json

**File:** `scripts/append_creative_findings.py`

**Fix:** Add size check and schema validation:

```python
def collect_actionable_items() -> list[dict]:
    items: list[dict] = []
    for f in sorted(OVERNIGHT_RESULTS.rglob("actionable.json")):
        if f.stat().st_size > 1_000_000:  # 1MB limit
            print(f"  WARNING: Skipping oversized {f} ({f.stat().st_size} bytes)")
            continue
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, dict) and item.get("summary"):
                        items.append(item)
        except (json.JSONDecodeError, OSError):
            continue
    return items
```

## Fix 11: M-3 — collect_actionable_items scans ALL, not just creative

**File:** `scripts/append_creative_findings.py`

**Problem:** Docstring says "creative runs" but scans all actionable.json files.

**Fix:** This is actually fine — non-creative tasks rarely produce actionable.json. But tighten the filter to only scan `creative-*` directories:

```python
for f in sorted(OVERNIGHT_RESULTS.rglob("actionable.json")):
    # Only process creative task outputs
    if "creative" not in f.parent.name:
        continue
```

## Fix 12: M-4 — Unreplaced template variables silently pass through

**File:** `scripts/overnight_task_generator.py`, `_instantiate_prompt()`

**Fix:** After replacement, check for remaining `{` patterns:

```python
def _instantiate_prompt(prompt_template: str, variables: dict[str, str]) -> str:
    result = prompt_template
    for key, value in variables.items():
        result = result.replace(f"{{{key}}}", value)
    result = result.replace("{run_date}", date_type.today().isoformat())
    # Warn on unreplaced variables (but don't fail — could be literal JSON)
    import re as _re
    unreplaced = _re.findall(r"\{[a-z_]+\}", result)
    if unreplaced:
        print(f"  WARNING: Unreplaced template variables: {unreplaced}")
    return result
```

## Fix 13: L-1 — Timezone at midnight

**No change.** `date.today()` returns local date. The cooldown is 14-21 DAYS — a few hours of timezone drift at midnight is irrelevant for multi-day cooldowns.

## Fix 14: L-2 — Variable injection via str.replace

**No change.** The variables come from trusted sources (active_engine detection, literal values in templates). No user input reaches the variable system. `str.replace` is safe here.

---

## Verification

After all fixes:
```bash
python -c "import scripts.overnight_orchestrator; print('orchestrator OK')"
python -c "import scripts.overnight_task_generator; print('generator OK')"
PYTHONIOENCODING=utf-8 python -c "
from scripts.overnight_task_generator import scan_creative
tasks = scan_creative()
print(f'Tasks: {len(tasks)}')
# Verify allowed_tools is set
for t in tasks:
    assert t.allowed_tools, f'{t.task_id} missing allowed_tools'
    assert 'Write' not in t.allowed_tools, f'{t.task_id} has Write in readonly mode'
print('All tasks have correct allowed_tools')
# Verify active engine detection
from scripts.overnight_task_generator import _detect_active_engine
engine = _detect_active_engine()
print(f'Detected engine: {engine}')
assert engine != 'source', 'Engine detection still returns source!'
print('OK')
"
python scripts/append_creative_findings.py  # Verify appender still works
```
