# Excerpting Engine contracts.py Rewrite — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Delete the stale 557-line `engines/excerpting/contracts.py` (old 7-engine architecture) and write from scratch: all Pydantic models, enums, sub-types, validators, error codes, config, and test factories for the new excerpting engine data pipeline.

**Architecture:** The new contracts define a 4-stage data pipeline: `NormalizedPackage → AssembledChunk → ClassifiedSegment → TeachingUnit → ExcerptRecord`. Plus 7 LLM response schemas, 28 error codes, 18 config parameters, 6 standalone validator functions, and 4 test factory helpers. All normalization types are imported, never redefined.

**Tech Stack:** Python 3.13, Pydantic v2 (BaseModel, Field, model_validator), `from __future__ import annotations`

---

## Context

The excerpting SPEC (2387 lines, 12 sections) is COMPLETE. The integrity audit and deep review are DONE. But the existing `contracts.py` defines types from the old architecture (`LifecycleStage`, `ContextAtomRole`, `ExcerptStatus`) that no longer exist. The new SPEC uses a completely different data model. A patch would leave dead code and be more work than a rewrite.

This contracts.py will be the foundation for 5-7 future build sessions. Every wrong field type or optionality silently propagates downstream into the owner's knowledge library.

---

## 1. File Structure

### Delete
- `engines/excerpting/contracts.py` (557 lines — all dead code)

### Create
- `engines/excerpting/contracts.py` (~900-1100 lines) — all types, validators, error codes, config
- `engines/excerpting/tests/conftest.py` (replacing the 5-line stub) — 4 factory helpers

### Import FROM (never modify)
- `engines.normalization.contracts`:
  - `StructuralFormat` (enum — excerpting inherits, does NOT redefine)
  - `TextLayerSegment` (used in AssembledChunk.text_layers)
  - `Footnote` (used in AssembledChunk.footnotes, ExcerptRecord.footnotes_relevant)
  - `ContentFlags` (used in AssembledChunk.content_flags)
  - `PhysicalPage` (used in AssembledChunk.physical_pages)
  - `BoundaryContinuityType` (used in JoinPoint.boundary_type)
  - `LayerType` (used only in test factory for default text_layers)

---

## 2. Type Definition Order (Dependency-Sorted)

The file uses `# ═══` section blocks matching normalization contracts.py style.

```
Section 1: Imports
  - from __future__ import annotations
  - from enum import Enum
  - from typing import Optional
  - import logging
  - from pydantic import BaseModel, Field, model_validator
  - from engines.normalization.contracts import (7 types listed above)

Section 2: Enumerations (2 enums)
  1. ScholarlyFunction(str, Enum)  — 16 values
  2. SelfContainmentLevel(str, Enum)  — 3 values
  (StructuralFormat is IMPORTED, not redefined)

Section 3: Sub-types — basic (10 models, no internal deps)
  3.  PageRange
  4.  AuthorAttribution
  5.  ScholarAttribution
  6.  EvidenceRef
  7.  TakhrijEntry
  8.  CrossReference          ← target_div_id defaults to None (Risk 5)
  9.  TermVariant
  10. ConsensusDecision
  11. ConsensusRecord          ← depends on ConsensusDecision
  12. SplitInfo

Section 4: Sub-types — assembly (2 models, depend on normalization types)
  13. JoinPoint                ← depends on BoundaryContinuityType (imported)
  14. AssemblyMetadata          ← depends on JoinPoint

Section 5: Intermediate types (3 models)
  15. AssembledChunk (16 fields) ← depends on AssemblyMetadata, SplitInfo, + normalization types
      model_validators: I-AC-5, I-AC-6, I-AC-7
  16. ClassifiedSegment (6 fields) ← depends on ScholarlyFunction
  17. TeachingUnit (10 fields)  ← depends on ScholarlyFunction, SelfContainmentLevel
      model_validators: I-TU-6, I-TU-7

Section 6: Output type (1 model)
  18. ExcerptRecord (33 fields) ← depends on almost everything
      model_validators: I-ER-4, I-ER-5

Section 7: LLM Response Schemas (7 models)
  19. ResolvedScholar           ← no internal deps
  20. UnitEnrichment            ← depends on TakhrijEntry, TermVariant, CrossReference, ResolvedScholar
  21. EnrichmentResult          ← depends on UnitEnrichment
  22. ClassificationResult      ← depends on ClassifiedSegment
  23. ExtractionResult          ← depends on TeachingUnit
  24. VerificationItem          ← no internal deps
  25. VerificationResult        ← depends on VerificationItem

Section 8: Error Codes
  26. ExcerptingErrorCodes      ← class with 28 string constants

Section 9: Configuration
  27. ExcerptingConfig          ← BaseModel with 18 defaults

Section 10: Standalone Validator Functions (6 functions)
```

---

## 3. DD8 Nullable Field Mapping Table

### On ExcerptRecord (33 fields)

| Field | DD8 Pattern | Pydantic Code | Why |
|-------|------------|---------------|-----|
| `school` | **Pattern 1** (required=yes, nullable, NO default) | `Optional[str]` | Callers MUST explicitly pass None; omitting is an error |
| `physical_pages` | Pattern 2 (required=no, nullable) | `Optional[PageRange] = None` | May be omitted entirely |
| `attribution_confidence` | Pattern 2 | `Optional[float] = None` | Null for deterministic LA-1/2/4 |
| `school_confidence` | Pattern 2 | `Optional[float] = None` | Null when school is null |
| `takhrij_data` | Pattern 2 | `Optional[list[TakhrijEntry]] = None` | Null when no hadith content |
| `consensus_metadata` | Pattern 2 | `Optional[ConsensusRecord] = None` | Null when no consensus needed |
| `self_containment_notes` | **Pattern 3** (conditional + model_validator) | `Optional[str] = None` | Non-null when PARTIAL/DEPENDENT (I-ER-4) |
| `context_hint` | **Pattern 3** (conditional + model_validator) | `Optional[str] = None` | Non-null when PARTIAL + LLM succeeded (I-ER-4) |
| `merge_history` | Pattern 2 | `Optional[list[str]] = None` | On AssembledChunk, not ExcerptRecord |
| `split_info` | Pattern 2 | `Optional[SplitInfo] = None` | On AssembledChunk, not ExcerptRecord |

### On UnitEnrichment (9 fields — DIVERGES from ExcerptRecord)

| Field | Pattern | Pydantic Code | Divergence from ExcerptRecord |
|-------|---------|---------------|------|
| `school` | Pattern 1 | `Optional[str]` (no default) | Same as ExcerptRecord |
| `school_confidence` | **Pattern 1** | `Optional[float]` (no default) | **DIFFERS**: ExcerptRecord is Pattern 2 (`= None`) |
| `takhrij_data` | **NOT nullable** | `list[TakhrijEntry] = []` | **DIFFERS**: ExcerptRecord is nullable `Optional[list] = None` |
| `context_hint` | Pattern 1 | `Optional[str]` (no default) | ExcerptRecord is Pattern 3 (conditional) |

### On other sub-types

| Type.Field | Pydantic Code | Notes |
|-----------|--------------|-------|
| `PageRange.volume` | `Optional[int] = None` | Not all sources have volumes |
| `ScholarAttribution.resolved_name` | `Optional[str] = None` | Null if unresolvable |
| `EvidenceRef.surah/ayah_start/ayah_end` | `Optional[int] = None` | Null for non-Quran evidence |
| `EvidenceRef.marker_text/scope` | `Optional[str] = None` | May not be present |
| `TakhrijEntry.grade/grade_source` | `Optional[str] = None` | May not be stated |
| `CrossReference.target_description` | `Optional[str] = None` | May not be identifiable |
| `CrossReference.target_div_id` | `Optional[str] = None` | **MUST default to None** (Risk 5) |
| `ConsensusDecision.verifier_value/verifier_agrees/escalation_value` | `Optional[...] = None` | May not have verifier/escalation |
| `VerificationItem.alternative` | `Optional[str] = None` | Null when verifier agrees |
| `ResolvedScholar.resolved_name` | `Optional[str] = None` | Null if unresolvable |
| `AssemblyMetadata.footnote_renumber_map` | `Optional[dict[str, str]] = None` | Null when no renumbering |
| `TeachingUnit.self_containment_notes` | `Optional[str] = None` | Pattern 3 — model_validator enforces I-TU-6/I-TU-7 |

---

## 4. model_validator List

### AssembledChunk — 3 model_validators

| Validator | Invariant | Behavior |
|-----------|-----------|----------|
| `check_split_chunk_id` | I-AC-5 | If `split_info` present, `chunk_id` must end with `_chunk_{split_info.chunk_index}`. Raises `ValueError`. |
| `check_merge_history` | I-AC-6 | If `merge_history` present, `len >= 2` and `merge_history[0] == div_id`. Raises `ValueError`. |
| `check_mutual_exclusion` | I-AC-7 | `merge_history` and `split_info` cannot both be non-None. Raises `ValueError`. |

### TeachingUnit — 1 model_validator (covers 2 invariants)

| Validator | Invariant | Behavior |
|-----------|-----------|----------|
| `check_self_containment_notes` | I-TU-6 + I-TU-7 | FULL → notes must be None. PARTIAL/DEPENDENT → notes must be present and non-empty. Raises `ValueError`. |

### ExcerptRecord — 2 model_validators

| Validator | Invariant | Behavior |
|-----------|-----------|----------|
| `check_self_containment_consistency` | I-ER-4 | FULL → no notes, no context_hint. PARTIAL → notes present; context_hint present unless `llm_enrichment_failed` in review_flags. DEPENDENT → notes present, no context_hint. Raises `ValueError`. |
| `check_attribution_completeness` | I-ER-5 | `primary_author_layer.layer_id` and `author_id` must be non-null (non-empty str). Raises `ValueError`. |

### NOT model_validators (by design)

| Invariant | Why not model_validator | Where checked |
|-----------|----------------------|---------------|
| I-AC-1 (word_count/total_tokens) | Cross-field but computed from assembled_text; would prevent overriding for test fixtures | Standalone `validate_ac_invariants` |
| I-AC-2 (text_layers coverage) | Requires complex range computation | Standalone `validate_layer_coverage` |
| I-CS-1 through I-CS-5 | Require the full list of segments | Standalone `validate_cs_invariants` |
| I-CS-6 (confidence range) | Handled by `Field(ge=0.0, le=1.0)` | Field constraint + standalone |
| I-TU-1 through I-TU-5 | Require full list of units + segments | Standalone `validate_tu_invariants` |
| I-TU-8 (description word count) | WARNING only, not rejection | Standalone `validate_tu_invariants` (logs warning) |
| I-TU-9 (primary_function in segments) | Requires segment list | Standalone `validate_tu_invariants` |
| I-ER-1, I-ER-3 | Require full collection of records | Standalone `validate_er_collection_invariants` |

---

## 5. Standalone Validator Functions

### `validate_ac_invariants(chunk: AssembledChunk) -> None`
Checks: I-AC-1, I-AC-5, I-AC-6, I-AC-7
- I-AC-1: Compute word_count from assembled_text (tokens with ≥1 char in U+0600–U+06FF), compare with chunk.word_count. Compute total_tokens from `len(assembled_text.split())`, compare with chunk.total_tokens.
- I-AC-5, I-AC-6, I-AC-7: Same checks as model_validators (defense in depth)
- All raise `ValueError` with invariant code prefix

### `validate_layer_coverage(text_layers: list[TextLayerSegment], assembled_text_len: int) -> None`
Checks: I-AC-2
- Union of `[seg.start, seg.end)` ranges must exactly cover `[0, assembled_text_len)`. No gaps, no overlaps.
- Raises `ValueError` with `I-AC-2` prefix

### `validate_cs_invariants(segments: list[ClassifiedSegment], total_tokens: int) -> None`
Checks: I-CS-1 through I-CS-6
- I-CS-1: `segments[i].segment_index == i`
- I-CS-2: `segments[i+1].start_word == segments[i].end_word + 1`
- I-CS-3: `segments[0].start_word == 0`
- I-CS-4: `segments[-1].end_word == total_tokens - 1`
- I-CS-5: Full coverage (implied by I-CS-2 + I-CS-3 + I-CS-4 but checked explicitly)
- I-CS-6: `0.0 <= seg.confidence <= 1.0` (redundant with Field constraint, defense in depth)
- All raise `ValueError` with invariant code prefix

### `validate_tu_invariants(units: list[TeachingUnit], segments: list[ClassifiedSegment], total_tokens: int) -> None`
Checks: I-TU-1 through I-TU-9
- I-TU-1: `units[i].unit_index == i`
- I-TU-2: Each unit's `segment_indices` is contiguous ascending
- I-TU-3: Union of all `segment_indices` == `{0, ..., len(segments)-1}`
- I-TU-4: `units[i+1].start_word == units[i].end_word + 1`
- I-TU-5: `start_word == segments[segment_indices[0]].start_word` etc.
- I-TU-6: FULL → notes None (redundant with model_validator, defense in depth)
- I-TU-7: PARTIAL/DEPENDENT → notes present (redundant, defense in depth)
- **I-TU-8: WARNING only** — count Arabic words in `description_arabic`, if outside 5-35 range use `logging.getLogger(__name__).warning(...)`, do NOT raise
- I-TU-9: `primary_function` must appear in constituent segments' functions

### `validate_er_invariants(record: ExcerptRecord) -> None`
Checks: I-ER-4, I-ER-5
- Same checks as model_validators (defense in depth)
- Raises `ValueError` with invariant code prefix

### `validate_er_collection_invariants(records: list[ExcerptRecord]) -> None`
Checks: I-ER-1, I-ER-3
- I-ER-1: No duplicate `excerpt_id` values
- I-ER-3: Records ordered by `(div_id, chunk_index, unit_index)`
- Raises `ValueError` with invariant code prefix

---

## 6. Factory Strategy

### File: `engines/excerpting/tests/conftest.py`

Pattern: Exact copy of `engines/normalization/tests/conftest.py` lines 59-107 structure:
```python
def _make_<type>(**overrides: Any) -> <Type>:
    defaults: dict[str, Any] = { ... }
    defaults.update(overrides)
    return <Type>(**defaults)
```

### `_make_assembled_chunk(**overrides) -> AssembledChunk`

Default text: `"بسم الله الرحمن الرحيم الحمد لله رب العالمين"`

Computed at module level (not per-call):
```python
_DEFAULT_AC_TEXT = "بسم الله الرحمن الرحيم الحمد لله رب العالمين"
_DEFAULT_AC_TOKENS = _DEFAULT_AC_TEXT.split()
_DEFAULT_AC_TOTAL_TOKENS = len(_DEFAULT_AC_TOKENS)  # 8
_DEFAULT_AC_WORD_COUNT = sum(
    1 for t in _DEFAULT_AC_TOKENS
    if any('\u0600' <= c <= '\u06FF' for c in t)
)  # 8
```

Defaults dict:
- `chunk_id="div_test_1_0"`, `source_id="src_test"`, `div_id="div_test_1_0"`, `div_path=["باب الاختبار"]`
- `assembled_text=_DEFAULT_AC_TEXT`
- `word_count=_DEFAULT_AC_WORD_COUNT`, `total_tokens=_DEFAULT_AC_TOTAL_TOKENS`
- `text_layers=[TextLayerSegment(layer_type=LayerType.MATN, author_canonical_id=None, start=0, end=len(_DEFAULT_AC_TEXT), confidence=1.0)]` — single segment covering full text (I-AC-2)
- `footnotes=[]`
- `content_flags=ContentFlags()` — all False defaults
- `physical_pages=[PhysicalPage(volume=1, page_number_display="١", page_number_int=1)]`
- `structural_format=StructuralFormat.PROSE`
- `heading_alignment_ok=True`
- `assembly_metadata=AssemblyMetadata(constituent_unit_indices=[0], join_points=[], layer_split_points=[], footnote_renumber_map=None)`
- `merge_history=None`, `split_info=None` — (I-AC-7 satisfied)

### `_make_classified_segment(**overrides) -> ClassifiedSegment`

Defaults:
- `segment_index=0`, `start_word=0`, `end_word=4`
- `text_snippet="بسم الله الرحمن الرحيم الحمد"[:50]`
- `scholarly_function=ScholarlyFunction.DEFINITION`, `confidence=0.9`

### `_make_teaching_unit(**overrides) -> TeachingUnit`

Defaults:
- `unit_index=0`, `segment_indices=[0]`, `start_word=0`, `end_word=4`
- `text_snippet="بسم الله الرحمن الرحيم الحمد لله رب العالمين"[:80]`
- `primary_function=ScholarlyFunction.DEFINITION`, `secondary_functions=[]`
- `description_arabic="وصف عربي قصير للاختبار يتضمن عدة كلمات"` (≥5 Arabic words for I-TU-8)
- `self_containment=SelfContainmentLevel.FULL`, `self_containment_notes=None` (I-TU-6)

### `_make_excerpt_record(**overrides) -> ExcerptRecord`

**CRITICAL defaults — must satisfy I-ER-4, I-ER-5, DD8:**

```python
defaults = {
    # Identification (6)
    "excerpt_id": "exc_src_test_div_test_0_0",
    "source_id": "src_test",
    "div_id": "div_test",
    "chunk_index": 0,
    "unit_index": 0,
    "div_path": ["باب الاختبار"],
    # Text (6)
    "primary_text": "بسم الله الرحمن الرحيم",
    "text_snippet": "بسم الله الرحمن الرحيم"[:80],
    "start_word": 0,
    "end_word": 3,
    "segment_indices": [0],
    "physical_pages": None,          # DD8 Pattern 2
    # Classification (4)
    "primary_function": ScholarlyFunction.DEFINITION,
    "secondary_functions": [],
    "content_types": [ScholarlyFunction.DEFINITION],
    "description_arabic": "وصف عربي قصير للاختبار يتضمن عدة كلمات",
    # Self-containment (3) — I-ER-4: FULL → no notes, no hint
    "self_containment": SelfContainmentLevel.FULL,
    "self_containment_notes": None,   # DD8 Pattern 3 (OK for FULL)
    "context_hint": None,             # DD8 Pattern 3 (OK for FULL)
    # Attribution (5) — I-ER-5: non-null layer_id/author_id
    "primary_author_layer": AuthorAttribution(
        layer_id="layer_matn",
        author_id="sch_test",
        coverage_pct=1.0,
        rule_applied="LA-1",
    ),
    "attribution_confidence": None,   # DD8 Pattern 2 (null for LA-1)
    "quoted_scholars": [],
    "school": None,                   # DD8 Pattern 1 — MUST be explicitly passed
    "school_confidence": None,        # DD8 Pattern 2
    # Topic (2)
    "excerpt_topic": ["اختبار"],
    "terminology_variants": [],
    # Evidence (4)
    "evidence_refs": [],
    "takhrij_data": None,             # DD8 Pattern 2
    "cross_references": [],
    "footnotes_relevant": [],
    # Metadata (3)
    "consensus_metadata": None,       # DD8 Pattern 2
    "gate_flags": [],
    "review_flags": [],
}
```

---

## 7. Judgment Calls and Uncertainties

### 7a. I-ER-5 model_validator — technically redundant
`AuthorAttribution.layer_id` and `author_id` are typed as `str` (not Optional[str]), so Pydantic already rejects None. The model_validator is pure defense-in-depth. **Decision: include it.** It documents the invariant and catches future accidental changes to the AuthorAttribution type.

### 7b. I-TU-8 as model_validator vs standalone only
A model_validator that logs warnings (rather than raising) is unusual. The normalization engine doesn't have any. **Decision: standalone only.** The warning is for informational monitoring, not data integrity. Logging during construction could create noise in tests.

### 7c. I-CS-6 enforcement mechanism
Confidence [0.0, 1.0] can be enforced via `Field(ge=0.0, le=1.0)` OR model_validator. **Decision: Field constraint (matches normalization pattern).** Also checked in standalone validator for defense-in-depth.

### 7d. Arabic word count function — inline or utility
The word-counting logic (count tokens with ≥1 char in U+0600–U+06FF) is used in I-AC-1, I-TU-8, and the factory. **Decision: define a private helper `_count_arabic_words(text: str) -> int` in contracts.py.** Used by validators and documented with the Arabic range. This is NOT a utility — it's an internal contracts implementation detail.

### 7e. Cross-engine import structure
NEXT.md says to import `NormalizedPackage` — but contracts.py doesn't directly reference it (engine code does). **Decision: do NOT import NormalizedPackage in contracts.py.** Only import the 7 types actually used as field types or in validators.

### 7f. ExtractionResult.notes field optionality
SPEC §5.3.4 says `notes: str (optional)`. NEXT.md line 266 says `notes: Optional[str] = None`. **Decision: `Optional[str] = None`** — matches the "LLM may or may not provide it" semantics.

---

## 8. Critical Files Reference

| File | Role | Lines |
|------|------|-------|
| `NEXT.md` | Complete directive with all 15 verification checks | 891 |
| `engines/excerpting/SPEC.md` | Behavioral authority — specific sections listed in NEXT.md | 2387 |
| `engines/excerpting/CLAUDE.md` | Engine orientation | 109 |
| `engines/normalization/contracts.py` | Style reference + import source | 725 |
| `engines/normalization/tests/conftest.py` | Factory pattern reference | ~300 |
| `engines/excerpting/contracts.py` | **DELETE then CREATE** | 557 → ~1000 |
| `engines/excerpting/tests/conftest.py` | **REPLACE stub** | 5 → ~160 |

---

## 9. Verification

All 15 checks from NEXT.md must pass before committing. The checks are copy-pasteable Python one-liners. Summary:

1. Clean import: `from engines.excerpting.contracts import *`
2. All factories instantiate + validators pass on factory output
3. All 6 validator functions pass on valid data
4. Error code count = 28, all strings match SPEC exactly
5. Both enum value sets match SPEC exactly
6. Cross-engine imports resolve with correct field types
7. I-AC-7 and I-AC-1 reject invalid data
8. ExcerptRecord has exactly 33 fields with correct names
9. I-TU-6 and I-TU-7 reject invalid data
10. ScholarlyFunction values match SPEC (dedicated check)
11. All sub-type field counts and names correct
12. DD8 Pattern 1: school is required (omitting fails)
13. CrossReference.target_div_id defaults to None
14. All 7 LLM schema field counts correct
15. Config defaults match SPEC sentinel values

Plus manual visual verification of error code format, DD8 patterns, and factory I-ER-4/I-ER-5 compliance.

**Post-verification:** Run `python -m pyright engines/excerpting/contracts.py` and `python -m pyright engines/excerpting/tests/conftest.py` per quality-workflow rules.

---

## 10. Commit

Single commit, message from NEXT.md:
```
rewrite excerpting contracts.py: all types from SPEC §2.2/§2.3/§5/§7/§8

Delete old 7-engine-era contracts.py (557 lines) and rewrite from scratch.
New contracts define the 5-engine architecture data model:

- 2 enums (ScholarlyFunction 16 values, SelfContainmentLevel 3 values)
- 12 sub-types (PageRange, AuthorAttribution, ScholarAttribution, etc.)
- 4 main types (AssembledChunk 16 fields, ClassifiedSegment 6 fields,
  TeachingUnit 10 fields, ExcerptRecord 33 fields)
- 7 LLM response schemas (ClassificationResult, ExtractionResult,
  EnrichmentResult, UnitEnrichment, ResolvedScholar, VerificationResult,
  VerificationItem)
- 28 error codes (EX-A/C/M/V/G)
- Invariant validators for 29 invariants (I-AC/CS/TU/ER)
- 18 static configuration parameters
- 4 test factory helpers in conftest.py
```

---

## 11. Risk Mitigations (5 High-Risk Areas)

### Risk 1: DD8 Nullable field mapping
**Mitigation:** Section 3 above provides an exhaustive table. Verification check #12 specifically tests that `school` has no default. Every nullable field is mapped to exactly one of the 3 patterns.

### Risk 2: UnitEnrichment vs ExcerptRecord divergence
**Mitigation:** Section 3 has a dedicated UnitEnrichment table highlighting the 3 divergences:
- `takhrij_data`: `list[TakhrijEntry] = []` (not nullable) vs `Optional[list] = None`
- `school_confidence`: Pattern 1 (no default) vs Pattern 2 (`= None`)
- `context_hint`: Pattern 1 (no default) vs Pattern 3 (conditional)

### Risk 3: model_validator vs standalone
**Mitigation:** Section 4 is an exhaustive inventory. I-TU-8 is explicitly WARNING-only in standalone. 6 model_validators on 3 models + 6 standalone functions with defense-in-depth overlap for per-instance invariants.

### Risk 4: Factory _make_excerpt_record defaults
**Mitigation:** Section 6 provides the complete defaults dict with comments showing I-ER-4, I-ER-5, and DD8 compliance per field. `school=None` is explicitly passed (DD8 Pattern 1).

### Risk 5: CrossReference shared
**Mitigation:** ONE CrossReference class with `target_div_id: Optional[str] = None`. Verification check #13 confirms it. LLM schema and ExcerptRecord both use the same class.
