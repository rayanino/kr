# Excerpting Engine Prompt Hardening — 8 Tier-1 Fixes

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Harden the excerpting engine's prompts and fix schema/threshold bugs based on 5-reviewer diagnostic evaluation of the first 133-excerpt API run.

**Architecture:** Schema split for verifier output (H-1), SPEC-compliant threshold fix (H-7), grouping rules for numbered items and derived benefits (H-2/H-3), few-shot examples for 3 prompt files (H-4/H-5/H-6), copy-fidelity rule (H-8). Implementation order follows dependency chain: H-1 → H-7 → H-2+H-3 → H-4 → H-5 → H-6 → H-8.

**Tech Stack:** Python 3.11+, Pydantic v2, LLM system prompts (Arabic scholarly text), pytest

---

## Context

Phase 1 evaluated 133 excerpts from 5 packages. The engine's SPEC rules and prompt structures are strong, but prompts have ZERO worked examples. A prior CC session fixed 3 mechanical bugs (BUG-001/002/003) with uncommitted changes — H-1 supersedes the BUG-002 regex band-aid with a proper schema split.

**Root cause of BUG-002:** The `VerificationItem.alternative` field is a single `Optional[str]` that receives BOTH the proposed value AND explanatory prose from the verifier LLM. Example from gate_queue: `"This should be attributed to ابن عقيل (layer sharh). The text contains clear sharh markers..."` when it should be just `"ابن عقيل"`. The regex function `_extract_author_from_prose()` tries to parse this but is fragile.

## Design Decision: Simpler Schema (no `rationale` field)

The original diagnostic proposed splitting `alternative` into `alternative_value` + `rationale`. After analysis, **we use only `alternative_value`** (no `rationale`):

1. `reasoning` already captures the disagree explanation — cached data confirms models put full justification in `reasoning`
2. Three text fields (reasoning + rationale + alternative_value) confuse structured-output models via Instructor
3. The root fix is the `Field(description=...)` which tells the LLM via schema injection exactly what format to use per verification type
4. If the LLM still puts prose in `alternative_value`, the vote won't match → no_majority → gate → human review (correct fail-loud behavior)

## Mandatory Co-Reviewer Protocol

After EACH few-shot example: `codex exec` for schema validation, `gemini -p` for Arabic scholarly accuracy.
After ALL changes: `codex exec` for cross-prompt consistency, `gemini -p` for SPEC amendment review.

## File Map

| File | Tasks | Changes |
|------|-------|---------|
| `engines/excerpting/contracts.py:676-688` | H-1 | `alternative` → `alternative_value` with structured Field description |
| `engines/excerpting/src/phase3_consensus.py` | H-1, H-6 | 7 consumer sites + remove `_extract_author_from_prose` + VERIFY_SYSTEM_PROMPT update + few-shots |
| `engines/excerpting/src/phase3_deterministic.py:234` | H-7 | Add `top_coverage >= 0.6` guard on LA-2 |
| `engines/excerpting/src/phase2_group.py:43-126` | H-2, H-3, H-8 | Numbered-item rule, derived-benefits rule, copy-fidelity rule |
| `engines/excerpting/src/phase2_classify.py:41-71` | H-4, H-8 | 3 few-shot examples + copy-fidelity rule |
| `engines/excerpting/src/phase3_enrichment.py:59-177` | H-5 | 2 few-shot examples |
| `engines/excerpting/SPEC.md:935,1823` | H-3, H-1 | §5.3.2 grouping amendment + VerificationItem schema table |
| `engines/excerpting/tests/test_phase3_consensus.py` | H-1 | 9 locations: `alternative=` → `alternative_value=` |
| `engines/excerpting/tests/test_batch_escalation.py` | H-1 | 3 locations: `alternative=` → `alternative_value=` |
| `engines/excerpting/tests/test_state_machine_edge.py` | H-1 | 2 locations: `alternative=` → `alternative_value=` |
| `engines/excerpting/tests/test_phase3_deterministic.py` | H-7 | Add 2-layer <60% coverage test |

---

## Task 1: H-1 — Verifier Schema Split

**Files:**
- Modify: `engines/excerpting/contracts.py:676-688`
- Modify: `engines/excerpting/src/phase3_consensus.py` (lines 48-78, 339, 345, 356-357, 408, 479, 578-627, 662)
- Modify: `engines/excerpting/SPEC.md:1823`
- Modify: `engines/excerpting/tests/test_phase3_consensus.py` (9 locations)
- Modify: `engines/excerpting/tests/test_batch_escalation.py` (3 locations)
- Modify: `engines/excerpting/tests/test_state_machine_edge.py` (2 locations)

- [ ] **Step 1: Update VerificationItem schema in contracts.py**

Replace the `alternative` field (line 681) with:

```python
    alternative_value: Optional[str] = Field(
        None,
        description="If disagrees: the bare corrected value only. "
        "For AUTHOR_ATTRIBUTION: author name (e.g., 'ابن عقيل'). "
        "For SCHOOL_ATTRIBUTION: school name or 'cross_school'. "
        "For SELF_CONTAINMENT: one of FULL, PARTIAL, DEPENDENT. "
        "No prose, no explanation — put reasoning in 'reasoning' field.",
    )
```

Run: `python -m pyright engines/excerpting/contracts.py`

- [ ] **Step 2: Update VERIFY_SYSTEM_PROMPT output instructions**

In `phase3_consensus.py`, replace the last paragraph of VERIFY_SYSTEM_PROMPT (lines ~73-78):

```python
# OLD:
Express your assessment as agree or disagree with brief reasoning. \
If you disagree, provide your alternative. Include your confidence \
(0.0 to 1.0).

# NEW:
For each item, respond with:
- item_index: the index of the verification item
- agrees: true or false
- alternative_value: if you disagree, provide ONLY the corrected value \
as a bare string. For author attribution: the author name (e.g., \
"ابن عقيل"). For school attribution: the school name or "cross_school". \
For self-containment: "FULL", "PARTIAL", or "DEPENDENT". \
Do NOT include explanatory text — put all explanation in reasoning.
- confidence: your confidence from 0.0 to 1.0
- reasoning: brief reasoning for your assessment
```

- [ ] **Step 3: Update all 7 consumer sites in phase3_consensus.py**

Mechanically rename `vi.alternative` → `vi.alternative_value` at these locations:

```python
# Line 339 (_resolve_school warning):
    vi.alternative_value,

# Line 345 (ConsensusDecision construction):
    verifier_value=vi.alternative_value or "",

# Lines 356-357 (EX-G-003 gate check):
    and vi.alternative_value
    and vi.alternative_value != source_school

# Line 408 (_resolve_attribution — REPLACE the _extract_author_from_prose call):
    verifier_val = vi.alternative_value  # H-1: direct use, no prose extraction

# Line 479 (escalation prompt):
    f"Model 2 says: {vi.alternative_value or 'unknown'} "

# Line 662 (_resolve_self_containment):
    verifier_level = _parse_self_containment(vi.alternative_value)
```

- [ ] **Step 4: Remove `_extract_author_from_prose()` function**

Delete the entire function at lines 578-627. This is the BUG-002 regex band-aid that H-1 supersedes. With the structured `alternative_value` field + improved prompt, the model returns bare values. If it doesn't, the vote comparison fails → no_majority → gate → human review (correct fail-loud behavior per Principle 3).

- [ ] **Step 5: Grep for any remaining `.alternative` references**

Run: `grep -rn "\.alternative" engines/excerpting/src/ engines/excerpting/tests/`

Update ALL remaining references. Check `writer.py` specifically (confirmed: does NOT reference VerificationItem.alternative, but verify after uncommitted changes).

- [ ] **Step 6: Update SPEC.md VerificationItem schema table**

At line ~1823, update the field name from `alternative` to `alternative_value` with updated description.

- [ ] **Step 7: Update test files (14 locations across 3 files)**

In all 3 test files, replace `alternative=` with `alternative_value=`:

- `test_phase3_consensus.py`: 9 locations (lines ~57, 65, 191, 202, 212, 250, 279, 326, 339)
- `test_batch_escalation.py`: 3 locations (lines ~303, 328, 358)
- `test_state_machine_edge.py`: 2 locations (lines ~384, 391)

Also remove any tests for `_extract_author_from_prose` (function names like `test_extract_author_from_prose*`).

Add new schema validation test:

```python
def test_verification_item_alternative_value_schema():
    """H-1: alternative_value holds bare value, reasoning holds explanation."""
    vi = VerificationItem(
        item_index=0,
        agrees=False,
        alternative_value="ابن عقيل",
        confidence=0.92,
        reasoning="The enrichment assigned 'unknown' but text shows sharh markers.",
    )
    assert vi.alternative_value == "ابن عقيل"
    assert len(vi.alternative_value) < 30  # bare value, not prose
```

- [ ] **Step 8: Run tests and type check**

```bash
python -m pyright engines/excerpting/contracts.py engines/excerpting/src/phase3_consensus.py
python -m pytest engines/excerpting/tests/test_phase3_consensus.py engines/excerpting/tests/test_batch_escalation.py engines/excerpting/tests/test_state_machine_edge.py -x -q
```

---

## Task 2: H-7 — LA-3 Threshold Fix

**Files:**
- Modify: `engines/excerpting/src/phase3_deterministic.py:234`
- Modify: `engines/excerpting/tests/test_phase3_deterministic.py`

- [ ] **Step 1: Add coverage guard to LA-2 condition**

In `phase3_deterministic.py` line 234, add `top_coverage >= 0.6`:

```python
# OLD (line 234):
    if len(coverages) == 2:

# NEW:
    if len(coverages) == 2 and top_coverage >= 0.6:
```

Per SPEC §6.2: "if the dominant layer has <60% coverage ... flag the unit with EX-M-001 (attribution ambiguous) for multi-model consensus verification." Currently, 2-layer cases with <60% dominance get LA-2 (silent default to outermost layer), bypassing the gate. This fix routes them to LA-3 for human review.

Evidence: ibn_aqil_v3 excerpt `_0_3` has `coverage_pct=0.591` but got LA-2.

- [ ] **Step 2: Add boundary tests**

```python
def test_la3_triggered_for_two_layers_below_60_pct():
    """H-7: 2 layers with dominant <60% → LA-3, not LA-2 (SPEC §6.2 line 1281)."""
    layers = [
        TextLayerSegment(
            layer_type=LayerType.SHARH,
            author_canonical_id="author_sharh",
            start=0, end=59, confidence=0.95,
        ),
        TextLayerSegment(
            layer_type=LayerType.MATN,
            author_canonical_id="author_matn",
            start=59, end=100, confidence=0.95,
        ),
    ]
    result = assign_author_attribution(layers, char_start=0, char_end=100)
    assert result.rule_applied == "LA-3"
    assert result.coverage_pct < 0.6


def test_la2_still_works_above_60_pct():
    """LA-2 still fires for 2 layers when dominant ≥60% but <80%."""
    layers = [
        TextLayerSegment(
            layer_type=LayerType.SHARH,
            author_canonical_id="author_sharh",
            start=0, end=70, confidence=0.95,
        ),
        TextLayerSegment(
            layer_type=LayerType.MATN,
            author_canonical_id="author_matn",
            start=70, end=100, confidence=0.95,
        ),
    ]
    result = assign_author_attribution(layers, char_start=0, char_end=100)
    assert result.rule_applied == "LA-2"
    assert result.coverage_pct == pytest.approx(0.7)
```

- [ ] **Step 3: Run tests**

```bash
python -m pyright engines/excerpting/src/phase3_deterministic.py
python -m pytest engines/excerpting/tests/test_phase3_deterministic.py -x -q
```

---

## Task 3: H-2 + H-3 — Grouping Rules

**Files:**
- Modify: `engines/excerpting/src/phase2_group.py:43-126` (GROUP_SYSTEM_PROMPT)
- Modify: `engines/excerpting/SPEC.md` (§5.3.2, around line 935)

- [ ] **Step 1: Amend hadith grouping rule (H-3, line 56)**

```python
# OLD (line 56):
- A hadith + its chain + commentary = one unit

# NEW:
- A hadith + its chain + commentary = one unit (for hadith citations \
within broader discussions — NOT for derived benefits sections)
```

- [ ] **Step 2: Add derived benefits rule (H-3) after line 61**

Insert after the structural_transition rule (line 61), before "DECONTEXTUALIZATION PREVENTION":

```python

DERIVED BENEFITS RULE:
- Sections opening with "ما يؤخذ من الحديث:" or "فوائد:" are derived \
benefits — each numbered item is a separate teaching unit.
- Split per numbered item (1-, 2-, 3-...) even though all items derive \
from the same hadith. Each item teaches a distinct ruling or benefit.
- Do NOT merge multiple numbered benefits into one mega-unit.
```

- [ ] **Step 3: Add numbered item boundary rule (H-2) after derived benefits rule**

```python

NUMBERED ITEM BOUNDARIES:
- Numbered items (1-, 2-, 3-... or فائدة/مسألة + number) are strong \
unit boundary markers. Each numbered item is a separate teaching unit \
unless it explicitly continues the same argument as the previous item \
(e.g., a multi-paragraph proof for a single point).
- Two numbered items covering different topics MUST NOT be merged. \
Example: items about void bequests and burial are separate units.
```

- [ ] **Step 4: Amend SPEC §5.3.2**

Find the hadith grouping rule (around line 935) and add the matching amendments:

```markdown
- A hadith + its chain + commentary = one unit (for hadith citations
  within broader discussions — NOT for derived benefits sections).
- **Derived Benefits Rule:** Sections opening with "ما يؤخذ من الحديث:"
  or "فوائد:" split per numbered item. Each numbered benefit is a
  separate teaching unit.
- **Numbered Item Boundaries:** Numbered items (1-, 2-, 3-... or
  فائدة/مسألة + numbering) are strong unit boundary markers. Each is a
  separate unit unless explicitly continuing the same argument.
```

- [ ] **Step 5: Validate**

```bash
python3 scripts/check_spec_quality.py engines/excerpting/SPEC.md
python -m pyright engines/excerpting/src/phase2_group.py
```

- [ ] **Step 6: Gemini scholarly review**

```bash
gemini -p "Review these grouping rules for Islamic scholarly text:
1. Sections headed 'ما يؤخذ من الحديث:' (derived benefits from hadith) should split per numbered item — each is a separate teaching unit. Is this consistent with how scholars structure derived benefits?
2. Numbered items (1-, 2-, 3-... or فائدة/مسألة + number) are strong unit boundary markers. Does this match scholarly text conventions?
3. The hadith + chain + commentary rule is qualified: it applies to citations within broader discussions, NOT to derived benefits sections. Is this distinction valid?"
```

---

## Task 4: H-4 — Classification Few-Shot Examples (3)

**Files:**
- Modify: `engines/excerpting/src/phase2_classify.py:41-71` (CLASSIFY_SYSTEM_PROMPT)

**Source data:**
- Example 1: taysir excerpt `_6_000_0_11` (rule_statement from ما يؤخذ من الحديث)
- Example 2: taysir excerpt `_6_000_0_12` (definition from غريب الحديث section)
- Example 3: taysir excerpt `_6_000_0_10` (editorial_note authorial remark)

- [ ] **Step 1: Insert 3 examples after segment boundary rules**

After line 59 ("Consecutive sentences serving the same function may form one segment if they are tightly bonded"), insert:

```python

WORKED EXAMPLES (from real scholarly texts):

Example 1 — Derived rulings are rule_statement, NOT evidence_hadith:
  Input: "ما يؤخذ من الحديث:\\n1- التغليظ في نجاسة الكلب، لشدة قذارته."
  → scholarly_function: "rule_statement"
  These are derived rulings (أحكام مستنبطة) extracted from the hadith, \
not the hadith narrative itself. The header "ما يؤخذ من الحديث:" signals \
derived fiqh rulings.

Example 2 — Term definitions are definition, NOT evidence_hadith:
  Input: "غريب الحديث:\\n1- \\"وَضوء\\": بفتح الواو. الماء الذي يتوضأ به."
  → scholarly_function: "definition"
  The "غريب الحديث:" section defines vocabulary terms. It is a definition \
even though it appears in a hadith commentary.

Example 3 — Authorial remarks are editorial_note, NOT structural_transition:
  Input: "اختلاف العلماء:\\nهناك خلافات للعلماء في أشياء.\\nمنها: هل يجب \
التسبيع والتتريب؟\\nولما كان القول الحق، هو ما يستفاد من هذا الحديث \
الصحيح الواضح، ضربنا عن الإطالة بذكرها صفَحاً"
  → scholarly_function: "editorial_note"
  "اختلاف العلماء:" is NOT a section header here — the author is making \
an editorial remark about deliberately omitting a discussion. The phrase \
"ضربنا عن الإطالة بذكرها صفَحاً" is authorial commentary.

```

- [ ] **Step 2: Validate with Codex**

```bash
codex exec "Verify these classification examples use valid ScholarlyFunction enum values. The 16 valid values are: definition, rule_statement, evidence_quran, evidence_hadith, evidence_ijma, evidence_qiyas, evidence_rational, opinion_statement, refutation, example, condition_exception, cross_reference, narration, editorial_note, structural_transition, unclassified. Check: rule_statement (example 1), definition (example 2), editorial_note (example 3)."
```

- [ ] **Step 3: Validate with Gemini**

```bash
gemini -p "Review these Arabic scholarly text classification examples for accuracy:
1. 'ما يؤخذ من الحديث: 1- التغليظ في نجاسة الكلب' classified as rule_statement (not evidence_hadith) — correct?
2. 'غريب الحديث: 1- وَضوء: بفتح الواو' classified as definition (not evidence_hadith) — correct?
3. 'اختلاف العلماء: هناك خلافات... ضربنا عن الإطالة بذكرها صفَحاً' classified as editorial_note (not structural_transition) — correct?"
```

- [ ] **Step 4: Run tests**

```bash
python -m pyright engines/excerpting/src/phase2_classify.py
python -m pytest engines/excerpting/tests/ -x -q -k "classify"
```

---

## Task 5: H-5 — Enrichment Few-Shot Examples (2)

**Files:**
- Modify: `engines/excerpting/src/phase3_enrichment.py:59-177` (ENRICH_SYSTEM_PROMPT)

**Source data:**
- Example 1: taysir excerpt `_6_000_0_13` (cross-school debate on الاستنشاق)
- Example 2: ibn_aqil_v3 excerpt `_3_000_0_0` (grammar definition of حروف الجر)

- [ ] **Step 1: Insert 2 examples after terminology_variants section**

After line 153 ("Only include genuine terminology equivalences. Empty list is acceptable for units with no notable term variants."), insert:

```python

WORKED EXAMPLES (from real scholarly texts):

Example 1 — Cross-school fiqh survey (school = "cross_school"):
  Input text: "اختلاف العلماء:\\nذهب الأئمة، أبو حنيفة، ومالك، والشافعي، \
وسفيان، وغيرهم، إلى أن الاستنشاق مستحب في الوضوء لا واجب.\\n\
والمشهور عند الإمام \\"أحمد\\" الوجوب"
  Source metadata: author school = حنبلي
  Expected enrichment:
  {{"excerpt_topic": ["حكم الاستنشاق في الوضوء"], \
"school": "cross_school", "school_confidence": 0.95, \
"resolved_scholars": [\
{{"mention_text": "أبو حنيفة", "resolved_name": "أبو حنيفة النعمان بن ثابت", \
"role": "quoted_opinion", "confidence": 0.99}}, \
{{"mention_text": "مالك", "resolved_name": "مالك بن أنس", \
"role": "quoted_opinion", "confidence": 0.98}}, \
{{"mention_text": "الشافعي", "resolved_name": "محمد بن إدريس الشافعي", \
"role": "quoted_opinion", "confidence": 0.98}}, \
{{"mention_text": "الإمام \\"أحمد\\"", "resolved_name": "أحمد بن حنبل", \
"role": "quoted_opinion", "confidence": 0.98}}], \
"terminology_variants": []}}
  Why school = "cross_school": The passage presents positions from \
أبو حنيفة, مالك, الشافعي, and أحمد in comparison. Even though the \
author (البسام) is Hanbali, this unit surveys positions across schools. \
Attribute the POSITION, not the AUTHOR.

Example 2 — Grammar text (school = null):
  Input text: "حروف الجر\\nهاك حروف الجر وهي من إلى … حتى خلا حاشا \
عدا في عن على\\nهذه الحروف العشرون كلها مختصة بالأسماء وهي تعمل فيها الجر"
  Source metadata: science = نحو, author school = null
  Expected enrichment:
  {{"excerpt_topic": ["حروف الجر", "اختصاصها بالأسماء"], \
"school": null, "school_confidence": null, \
"resolved_scholars": [], \
"terminology_variants": [\
{{"term": "حروف الجر", "variants": ["حروف الخفض", "حروف الإضافة"]}}]}}
  Why school = null: Grammar (nahw) texts do not have madhhab \
attribution. The terminology_variants field captures the alternative \
names for حروف الجر used in different grammatical traditions.

```

- [ ] **Step 2: Validate with Codex**

```bash
codex exec "Verify these enrichment JSON examples match the ENRICH_SYSTEM_PROMPT schema. Required fields per unit: excerpt_topic (list of Arabic strings), school (string|null, valid values: حنفي, مالكي, شافعي, حنبلي, ظاهري, cross_school, null), school_confidence (float 0-1 | null), resolved_scholars (list with mention_text, resolved_name, role in [quoted_opinion, classification_frame, refuted_position], confidence), terminology_variants (list with term, variants list)."
```

- [ ] **Step 3: Validate with Gemini**

```bash
gemini -p "Review these enrichment examples for Arabic scholarly accuracy:
1. Cross-school survey about الاستنشاق في الوضوء: Is أبو حنيفة correctly resolved as أبو حنيفة النعمان بن ثابت? Is مالك correctly مالك بن أنس? Is school='cross_school' correct when comparing 4 schools' positions?
2. Grammar text from شرح ابن عقيل on حروف الجر: Is school=null correct for a nahw text? Are حروف الخفض and حروف الإضافة accurate alternative terms for حروف الجر?"
```

- [ ] **Step 4: Run tests**

```bash
python -m pyright engines/excerpting/src/phase3_enrichment.py
python -m pytest engines/excerpting/tests/ -x -q -k "enrich"
```

---

## Task 6: H-6 — Verifier Few-Shot Examples (2)

**Depends on:** Task 1 (H-1 schema split must be complete — examples use `alternative_value`)

**Files:**
- Modify: `engines/excerpting/src/phase3_consensus.py` (VERIFY_SYSTEM_PROMPT)

**Source data:**
- Example 1: ibn_aqil_v3 gate_queue entry 1 (author attribution, excerpt `_3_000_0_8`)
- Example 2: taysir excerpt `_6_000_0_8` consensus_metadata (school attribution disagreement)

- [ ] **Step 1: Insert 2 examples after the output format instructions added in Task 1**

Append to VERIFY_SYSTEM_PROMPT after the output format section:

```python

WORKED EXAMPLES:

Example 1 — Author attribution (disagree, bare value):
  Source: شرح ابن عقيل على ألفية ابن مالك (science: نحو)
  Decision: author_attribution = "unknown"
  Text: "ولا تجر رب إلا نكرة نحو رب رجل عالم لقيت وهذا معنى قوله \
وبرب منكرا أي واخصص برب النكرة"
  Correct response:
    agrees: false
    alternative_value: "ابن عقيل"
    confidence: 0.92
    reasoning: "Text contains sharh markers: 'وهذا معنى قوله' (referring \
to ابن مالك's matn verse), 'أي واخصص برب النكرة' (explanatory gloss). \
This is ابن عقيل's commentary layer."
  NOTE: alternative_value is "ابن عقيل" — NOT "This should be \
attributed to ابن عقيل (layer sharh). The text contains..."

Example 2 — School attribution (disagree, bare value):
  Source: تيسير العلام شرح عمدة الأحكام (science: فقه, author school: حنبلي)
  Decision: school_attribution = "حنبلي"
  Text: "ما يؤخذ من الحديث:\\n1- النهي عن البول في الماء الذي لا يجرى \
وتحريمه"
  Correct response:
    agrees: false
    alternative_value: "cross_school"
    confidence: 0.75
    reasoning: "The passage presents general fiqh rulings derived from \
the hadith without attributing them to a specific school. The numbered \
items are universally applicable."
  NOTE: alternative_value is "cross_school" — NOT "cross_school أو عام \
(لا ينسب لمذهب بعينه)".

```

- [ ] **Step 2: Validate with Codex**

```bash
codex exec "Verify these verifier few-shot examples match the updated VerificationItem schema. Fields: item_index (int), agrees (bool), alternative_value (bare string — no prose, max ~30 chars for author names, enum values for school/self-containment), confidence (float 0-1), reasoning (string). Confirm alternative_value contains ONLY the value, no explanatory text."
```

- [ ] **Step 3: Validate with Gemini**

```bash
gemini -p "Review these verifier examples for Arabic scholarly accuracy:
1. Author attribution for شرح ابن عقيل: Is 'وهذا معنى قوله' correctly identified as a sharh marker referring to ابن مالك's Alfiyya? Should this text be attributed to ابن عقيل as the sharh author?
2. School attribution for تيسير العلام 'ما يؤخذ من الحديث': Is it correct to classify these derived rulings (النهي عن البول في الماء الراكد) as cross_school rather than حنبلي? Are these general rulings or Hanbali-specific positions?"
```

- [ ] **Step 4: Run tests**

```bash
python -m pyright engines/excerpting/src/phase3_consensus.py
python -m pytest engines/excerpting/tests/test_phase3_consensus.py -x -q
```

---

## Task 7: H-8 — text_snippet Copy Fidelity

**Files:**
- Modify: `engines/excerpting/src/phase2_classify.py` (CLASSIFY_SYSTEM_PROMPT)
- Modify: `engines/excerpting/src/phase2_group.py` (GROUP_SYSTEM_PROMPT)

**Evidence:** 4 EX-V-002 validation drops caused by newline collapse in `text_snippet`.

- [ ] **Step 1: Add copy-fidelity rule to classify prompt**

After line 67 ("This field is used for alignment; exact copying is critical."), insert:

```python
  COPY FIDELITY: text_snippet MUST be an exact character-for-character \
copy from the input text. Preserve all newlines (\\n) exactly as they \
appear in the source. Do NOT reflow whitespace or collapse \\n to space. \
If the source text has a newline at position N, the snippet must have \
that same newline.
```

- [ ] **Step 2: Add copy-fidelity rule to group prompt**

After line 115 ("preserve all diacritics, punctuation, and whitespace."), insert:

```python
  COPY FIDELITY: text_snippet MUST be an exact character-for-character \
copy from the input text. Preserve all newlines (\\n) exactly as they \
appear. Do NOT reflow whitespace or collapse \\n to space.
```

- [ ] **Step 3: Run tests**

```bash
python -m pyright engines/excerpting/src/phase2_classify.py engines/excerpting/src/phase2_group.py
python -m pytest engines/excerpting/tests/ -x -q -k "classify or group"
```

---

## Final Validation

- [ ] **Step 1: Full test suite**

```bash
python -m pytest engines/excerpting/tests/ -v --tb=short
```

Expected: 900+ tests pass, 0 failures.

- [ ] **Step 2: Pyright on all modified files**

```bash
python -m pyright engines/excerpting/contracts.py engines/excerpting/src/phase2_classify.py engines/excerpting/src/phase2_group.py engines/excerpting/src/phase3_enrichment.py engines/excerpting/src/phase3_consensus.py engines/excerpting/src/phase3_deterministic.py
```

- [ ] **Step 3: Cross-prompt consistency review (Codex)**

```bash
codex exec "Review these 4 prompt files for cross-prompt consistency:
1. phase2_classify.py CLASSIFY_SYSTEM_PROMPT
2. phase2_group.py GROUP_SYSTEM_PROMPT
3. phase3_enrichment.py ENRICH_SYSTEM_PROMPT
4. phase3_consensus.py VERIFY_SYSTEM_PROMPT

Check:
- Are ScholarlyFunction enum values consistent across classify and group? (16 types)
- Are school values consistent across enrich and verify? (حنفي, مالكي, شافعي, حنبلي, ظاهري, cross_school)
- Are self_containment values consistent? (FULL, PARTIAL, DEPENDENT)
- Any conflicting rules between prompts?
- Any duplicate or contradictory few-shot examples?"
```

- [ ] **Step 4: SPEC amendment scholarly review (Gemini)**

```bash
gemini -p "Review the excerpting SPEC §5.3.2 amendments for consistency with Islamic scholarly convention:
1. Hadith + chain + commentary = one unit for citations, NOT for derived benefits. Correct?
2. 'ما يؤخذ من الحديث:' and 'فوائد:' sections split per numbered item. Matches scholarly text structure?
3. Numbered items (1-, 2-, 3-...) are strong unit boundaries. Consistent with how scholars number their points?"
```

- [ ] **Step 5: Do NOT commit**

Report: which files were changed, test results (count + pass/fail), pyright results, co-reviewer validation outcomes.
