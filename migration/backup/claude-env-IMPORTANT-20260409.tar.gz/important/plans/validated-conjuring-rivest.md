# Adversarial Audit: phase3_enrichment.py + phase3_consensus.py

## Context

Deep adversarial analysis of Phase 3.2 (enrichment) and Phase 3.3 (consensus) modules.
Goal: find bugs, weak tests, and invariant violations — NOT fix them.
Method: construct specific inputs for every model_copy, branch, and test; trace multi-model flows.

---

## Finding 1 — CRITICAL: 2/3 majority does NOT update `primary_author_layer`

**File:** `phase3_consensus.py:337-347`
**SPEC:** §7.3.3 line 1844: "If 2 of 3 models agree → **use the majority attribution**."

**Trace:** Enrichment sets `author_id="author_A"` via LA-3. Verifier disagrees, says `"author_B"`. Escalation agrees with verifier: `"author_B"`.

```
votes = ["author_A", "author_B", "author_B"]
_find_majority → "author_B"
```

Code then does:
```python
updates["attribution_confidence"] = 0.67
decision = ConsensusDecision(..., final_value="author_B", ...)
```

But `updates` never sets `"primary_author_layer"`. The `model_copy(update=updates)` at line 233 leaves `primary_author_layer.author_id = "author_A"` — the **loser** of the vote.

**Result:** `ConsensusDecision.final_value = "author_B"` but `ExcerptRecord.primary_author_layer.author_id = "author_A"`. The record carries a stale author attribution that contradicts its own consensus metadata.

**Why it's hard to fix:** `primary_author_layer` is an `AuthorAttribution` object with `layer_id`, `author_id`, `coverage_pct`, `rule_applied`. The consensus code only has author_id strings from the vote — not the corresponding `layer_id` or `coverage_pct` for the majority winner. Updating just `author_id` while keeping the wrong `layer_id` creates a different kind of inconsistency.

**SPEC line 1845 (all-3-disagree) explicitly says:** "Set `primary_author_layer` to the enrichment model's assessment" — which is what the code does by default. But line 1844 (2/3) says "use the majority attribution" — which the code does NOT do.

---

## Finding 2 — HIGH: Verification items matched by position, not by `item_index`

**File:** `phase3_consensus.py:714-726`

```python
vi_iter = iter(vr_result.items)           # ← positional iterator
for exc, items in excerpts_with_items:
    for item in items:
        vi = next(vi_iter)                # ← consumes by position
        vis.append((vi, item["verification_type"]))
```

The `item_index` field on `VerificationItem` is **never used for matching**. Items are consumed purely by iterator position.

**Adversarial input:** Verification LLM returns items in reverse order:
```
items = [
  VerificationItem(item_index=2, agrees=True, ...),   # meant for excerpt B school
  VerificationItem(item_index=1, agrees=False, ...),   # meant for excerpt A attribution
  VerificationItem(item_index=0, agrees=True, ...),   # meant for excerpt A school
]
```

`next(vi_iter)` assigns:
- item_index=2 (excerpt B's school verdict) → excerpt A's school slot
- item_index=1 (excerpt A's attribution verdict) → excerpt A's attribution slot (coincidentally correct)
- item_index=0 (excerpt A's school verdict) → excerpt B's school slot

**Result:** Wrong verdicts applied to wrong decisions. Silent corruption — no error raised.

**Why this matters:** LLMs do not guarantee output ordering. The `item_index` field exists precisely for matching, but the code ignores it. The correct approach is to build a dict `{vi.item_index: vi}` and look up by index.

---

## Finding 3 — HIGH: `apply_enrichment` has no fallback for None `context_hint` on PARTIAL units

**File:** `phase3_enrichment.py:280-282`

```python
context_hint: Optional[str] = None
if exc.self_containment == SelfContainmentLevel.PARTIAL:
    context_hint = ue.context_hint       # ← could be None if LLM omits it
```

Then at line 284-286, the `"llm_enrichment_failed"` flag is **removed** (enrichment succeeded). The model_copy sets `context_hint=None` and `review_flags` without the exemption flag.

**I-ER-4 validator** (contracts.py:549-555):
```python
if self.context_hint is None and "llm_enrichment_failed" not in self.review_flags:
    raise ValueError("I-ER-4: PARTIAL -> context_hint required ...")
```

**Result:** If the LLM returns `context_hint=None` for a PARTIAL unit, the ExcerptRecord violates I-ER-4. `model_copy` doesn't run validators, so the violation is silent until `model_validate()` runs (e.g., in Phase 3.4 validation or output writer).

**Contrast with consensus path:** `_repair_context_hint` (line 521-534) has three fallbacks — `self_containment_notes`, verifier reasoning, hardcoded Arabic text. The enrichment path has **zero** fallbacks.

---

## Finding 4 — MEDIUM: `takhrij_data` empty-list→None coercion loses semantic distinction

**File:** `phase3_enrichment.py:296`

```python
"takhrij_data": ue.takhrij_data if ue.takhrij_data else None,
```

`UnitEnrichment.takhrij_data` defaults to `Field(default_factory=list)` — an empty list. But `[]` is falsy, so:

```python
[] if [] else None  →  None
```

**ExcerptRecord** has `takhrij_data: Optional[list[TakhrijEntry]] = None`.

**Result:** The semantic distinction between "no takhrij data found" (empty list `[]`) and "not processed yet" (None) is lost. Both become None on the ExcerptRecord. This survives round-trip validation (None is valid), but downstream code cannot distinguish the two states.

---

## Finding 5 — MEDIUM: `_repair_context_hint` FULL→PARTIAL branch is dead code

**File:** `phase3_consensus.py:515-534`

```python
elif (
    new_level == SelfContainmentLevel.PARTIAL
    and excerpt.self_containment == SelfContainmentLevel.FULL
):
```

This branch fires when consensus downgrades FULL to PARTIAL. But `_needs_consensus` (line 78-80) only triggers self-containment consensus for PARTIAL and DEPENDENT — **FULL is excluded**:

```python
if excerpt.self_containment in (SelfContainmentLevel.PARTIAL, SelfContainmentLevel.DEPENDENT):
```

No other resolve function sets `updates["self_containment"]`. Therefore, the FULL→PARTIAL branch can never be reached through any code path.

**Result:** 20 lines of dead code. The test `test_full_to_partial_generates_hint_from_notes` tests unreachable code — it constructs inputs that can never occur in the real pipeline.

---

## Finding 6 — MEDIUM: `vi.alternative or "unknown"` creates phantom voter

**File:** `phase3_consensus.py:330`

```python
verifier_val = vi.alternative or "unknown"
```

When the verifier disagrees but provides no alternative (`vi.alternative=None`), the code substitutes the string `"unknown"` as the verifier's "vote".

**Scenario:**
```
enrichment_val = "ibn_qudama"
verifier: agrees=False, alternative=None  →  verifier_val = "unknown"
escalation returns "al_nawawi"
votes = ["ibn_qudama", "unknown", "al_nawawi"]
_find_majority → None  →  all 3 "disagree"  →  EX-G-001 gate triggered
```

But this is really a 2-way disagreement (ibn_qudama vs al_nawawi), not 3-way. The phantom "unknown" voter artificially prevents a 2/3 majority between enrichment and escalation from forming when they differ, and blocks enrichment+escalation agreement from being detected when one matches.

Wait — correction: if enrichment="ibn_qudama" and escalation="ibn_qudama", `_find_majority` returns "ibn_qudama" (`votes[0]==votes[2]`). So the phantom voter doesn't block same-value matches. The real problem is:

1. `ConsensusDecision` records `verifier_value="unknown"` — misleading for human gate review
2. If escalation coincidentally returns `"unknown"` string, it forms a false majority with the phantom vote

---

## Finding 7 — MEDIUM: No cross-field validation between `school` and `school_confidence`

**File:** `contracts.py` (ExcerptRecord validators)

The ExcerptRecord has two validators: `check_self_containment_consistency` and `check_attribution_completeness`. Neither validates `school` ↔ `school_confidence` consistency.

**Adversarial input:** Enrichment LLM returns `school=None, school_confidence=0.85`.

**Result:** `apply_enrichment` sets both values via model_copy. The ExcerptRecord carries `school=None` with `school_confidence=0.85` — semantically nonsensical (confidence in what?). No validator catches this. Survives round-trip.

**Inverse case:** `school="حنبلي", school_confidence=None` — a positive attribution with no confidence value.

---

## Finding 8 — LOW: `resolve_consensus` creates `ConsensusRecord` twice; returned copy is always discarded

**File:** `phase3_consensus.py:231,234`

```python
updates["consensus_metadata"] = ConsensusRecord(decisions=decisions)   # ← goes into ExcerptRecord
consensus_record = ConsensusRecord(decisions=decisions) if decisions else None  # ← returned
```

In `run_consensus` (line 737):
```python
updated, _cr, gate_codes = resolve_consensus(...)  # _cr is never used
```

Two identical `ConsensusRecord` objects are created. The returned one is always discarded. Wasteful but not buggy.

---

## User Question 1: model_copy round-trip survival

### apply_enrichment model_copy (line 290-302) — 9 fields

| Field | Round-trip safe? | Issue |
|-------|:---:|-------|
| excerpt_topic | Yes | list[str], no validator |
| school | Yes | Optional[str] |
| school_confidence | **Partial** | No school↔confidence cross-validation (Finding 7) |
| quoted_scholars | Yes | list[ScholarAttribution] |
| takhrij_data | **Partial** | Empty list becomes None (Finding 4) |
| terminology_variants | Yes | list[TermVariant] |
| cross_references | Yes | list[CrossReference] |
| context_hint | **FAILS** | None for PARTIAL violates I-ER-4 (Finding 3) |
| review_flags | Yes | list[str] |

### _merge_scholars model_copy (line 330) — 1 field

| Field | Round-trip safe? | Issue |
|-------|:---:|-------|
| mention_text | Yes | str field, Instructor enforces non-null |

### resolve_consensus model_copy (line 233) — dynamic fields

| Field | Round-trip safe? | Issue |
|-------|:---:|-------|
| school_confidence | Yes | float |
| attribution_confidence | Yes | float |
| self_containment | **Conditional** | If downgrade PARTIAL→DEPENDENT, repair sets context_hint=None ✓ |
| context_hint | Yes | _repair_context_hint handles all reachable cases |
| review_flags | Yes | list[str] |
| consensus_metadata | Yes | ConsensusRecord |

### run_consensus gate_flags model_copy (lines 744, 758) — 1 field

| Field | Round-trip safe? | Issue |
|-------|:---:|-------|
| gate_flags | Yes | Dedup check at lines 564, 572, 584, 757 prevents duplicates |

---

## User Question 2: Conditional branch verification (against SPEC §7.2-§7.3)

### _needs_consensus branches

| Branch | Trigger | SPEC-compliant? |
|--------|---------|:-:|
| school non-null | `excerpt.school is not None` | Yes (§7.3.1) |
| LA-3 attribution | `rule_applied == "LA-3"` | Yes (§7.3.1) |
| PARTIAL/DEPENDENT SC | `self_containment in (P, D)` | Yes (§7.3.1) |
| FULL SC | Not triggered | Yes — FULL excluded per §7.3.1 |

### _resolve_attribution branches

| Branch | Trigger | SPEC-compliant? |
|--------|---------|:-:|
| Verifier agrees | `vi.agrees` | Yes — sets confidence=1.0 |
| 2/3 majority | `majority is not None` | **NO** — does not update primary_author_layer (Finding 1) |
| All 3 disagree | `majority is None` | Yes — sets confidence=0.0, gate EX-G-001 |
| No escalation client | `escalation_value is None` (from no client) | Yes — falls back to enrichment with 0.5 confidence |

### _resolve_self_containment branches

| Branch | Trigger | SPEC-compliant? |
|--------|---------|:-:|
| Agreement | `vi.agrees` | Yes |
| Verifier more conservative | `verifier_level < enrichment_level` | Yes — uses lower level |
| Verifier less conservative | `verifier_level >= enrichment_level` | Yes — keeps enrichment |
| Parse failure | `_parse_self_containment returns None` | Yes — defaults to enrichment |
| Final is DEPENDENT | `final_level == DEPENDENT` | Yes — triggers EX-G-002 |

### apply_enrichment branches

| Branch | Trigger | SPEC-compliant? |
|--------|---------|:-:|
| No enrichment for unit | `ue is None` | Yes — keeps deterministic |
| PARTIAL context_hint | `self_containment == PARTIAL` | **Partial** — no fallback for LLM None (Finding 3) |
| Non-PARTIAL | else | Yes — context_hint stays None |

---

## User Question 3: Weak test analysis — "What broken implementation would still pass?"

### Enrichment tests

| Test | What broken implementation passes? |
|------|-----|
| `test_apply_updates_all_fields` | Hardcodes `school="حنبلي"` for any input (fixture uses exactly this value) |
| `test_apply_with_takhrij_data` | Only checks `len==1` and first collection name; other TakhrijEntry fields could be wrong |
| `test_apply_context_hint_only_for_partial` | Only checks None for FULL; doesn't verify PARTIAL *gets* a hint (tested implicitly by first test, but fragile) |
| `test_apply_multiple_units` | Only checks `excerpt_topic`; school, confidence, scholars etc. could all be wrong |
| `test_enrichment_failure_emits_ex_m_002` | Only checks error code string in logs; doesn't verify log level (could be DEBUG not ERROR) |
| `test_retry_count_respected` | Only checks call count=3; doesn't verify retries use same inputs or have any delay |
| `test_duplicate_scholar_not_added_twice` | Doesn't verify `role` field is preserved from structural entry |
| `test_enrich_chunk_calls_correct_model` | Doesn't verify system/user message content, max_tokens, or timeout |
| `test_multiple_chunks_each_get_one_call` | Only checks call count=2; doesn't verify correct chunk text was sent to each call |

### Consensus tests

| Test | What broken implementation passes? |
|------|-----|
| `test_school_disagreement_keeps_enrichment_school` | A no-op implementation that does nothing on disagreement passes — enrichment value is the default |
| `test_2_of_3_majority_wins` | Doesn't check which author_id won; hardcoding confidence=0.67 whenever escalation runs passes |
| `test_all_3_disagree_triggers_gate` | Doesn't verify `final_value` in ConsensusDecision |
| `test_consensus_with_school_agreement` | Only checks `consensus_metadata is not None`; empty ConsensusRecord would pass |
| `test_la3_triggers_author_attribution` | Doesn't test LA-2, LA-4 — impl that triggers for all non-LA-1 rules passes |
| `test_gate_trigger_ex_g_001` | Only checks gate code presence; doesn't verify gate entry JSON structure per §7.3.4 |
| `test_verification_failure_adds_flag` | Only checks flag presence; doesn't verify deterministic fields survived, or that retry happened |
| `test_full_to_partial_generates_hint_from_notes` | Tests dead code (Finding 5) — branch is unreachable in real pipeline |
| `test_downgrade_partial_to_dependent` | Doesn't verify context_hint was nullified (I-ER-4 requires hint=None for DEPENDENT) |
| `test_find_majority_2_of_3` | Doesn't test 3-of-3 same value (should return that value) |

**Strongest tests** (hard to bypass with broken code):
- `test_apply_empty_enrichment_keeps_deterministic` — object identity check (`result[0] is exc`)
- `test_apply_mismatched_unit_index_keeps_original` — identity check
- `test_never_upgrade_partial_to_full` — verifies conservative principle correctly
- `test_school_disagreement_lowers_confidence` — exact numeric check `== 0.7`

---

## User Question 4: Three-model disagreement trace

**Setup:**
- Phase 3.1 deterministic: `primary_author_layer = AuthorAttribution(layer_id="L1", author_id="author_A", coverage_pct=0.52, rule_applied="LA-3")`
- Phase 3.2 enrichment: does NOT modify primary_author_layer (not in update fields)
- Phase 3.3 consensus: `_needs_consensus` sees `rule_applied=="LA-3"` → triggers AUTHOR_ATTRIBUTION

**Verification call:**
- Verifier (model_B) responds: `agrees=False, alternative="author_B"`

**`_resolve_attribution` execution:**
```
vi.agrees = False → enters disagreement branch
enrichment_val = excerpt.primary_author_layer.author_id → "author_A"
verifier_val = vi.alternative or "unknown" → "author_B"
escalation_client is not None → calls _call_escalation
_call_escalation returns "author_C"
votes = ["author_A", "author_B", "author_C"]
_find_majority(votes):
  votes[0]=="author_A" == votes[1]=="author_B"? NO
  votes[0]=="author_A" == votes[2]=="author_C"? NO
  votes[1]=="author_B" == votes[2]=="author_C"? NO
  → returns None
```

**All 3 disagree path:**
```
updates["attribution_confidence"] = 0.0
gates.append(EX_G_001)
decision = ConsensusDecision(
    final_value="author_A",          ← enrichment kept as final_value
    resolution_method="all_3_disagree_gate"
)
```

**Back in resolve_consensus:**
```python
updated = excerpt.model_copy(update=updates)
# updates = {attribution_confidence: 0.0, review_flags: [...], consensus_metadata: ...}
# primary_author_layer is NOT in updates
```

**Final state:**
```
updated.primary_author_layer.author_id = "author_A"     ← unchanged from Phase 3.1
updated.attribution_confidence = 0.0                     ← signals unreliable
updated.consensus_metadata.decisions[0].final_value = "author_A"
updated.gate_flags = ["EX-G-001"]                        ← human review required
```

**SPEC compliance:** §7.3.3 line 1845 says "Set `primary_author_layer` to the enrichment model's assessment" — which is what happens (by default, since it was never changed). **Compliant for all-3-disagree.**

**But for 2/3 majority (if votes were ["author_A", "author_B", "author_B"]):**
```
final state: primary_author_layer.author_id = "author_A"  ← WRONG, should be "author_B"
             ConsensusDecision.final_value = "author_B"    ← correct
```
**Non-compliant.** See Finding 1.

---

## User Question 5: Reverse-order verification items

**Setup:** Two excerpts, 3 verification items total:
- Excerpt A (unit_index=0): school + attribution → 2 items (item_index 0, 1)
- Excerpt B (unit_index=1): school → 1 item (item_index 2)

**`_build_verification_user_message` assigns:**
```
item_index=0 → Excerpt A school
item_index=1 → Excerpt A attribution
item_index=2 → Excerpt B school
```

**LLM returns in reverse order:**
```python
vr_result.items = [
    VerificationItem(item_index=2, agrees=True,  ...),  # intended: B school
    VerificationItem(item_index=1, agrees=False, ...),  # intended: A attribution
    VerificationItem(item_index=0, agrees=True,  ...),  # intended: A school
]
```

**`run_consensus` execution (lines 714-726):**
```python
vi_iter = iter(vr_result.items)  # [VI(idx=2), VI(idx=1), VI(idx=0)]

# Excerpt A has 2 items:
next(vi_iter) → VI(item_index=2, agrees=True)   → paired with "SCHOOL_ATTRIBUTION"
next(vi_iter) → VI(item_index=1, agrees=False)  → paired with "AUTHOR_ATTRIBUTION"

# Excerpt B has 1 item:
next(vi_iter) → VI(item_index=0, agrees=True)   → paired with "SCHOOL_ATTRIBUTION"
```

**Result:**
- Excerpt A's school: gets VI(idx=2) which was meant for Excerpt B's school → **WRONG verdict applied**
- Excerpt A's attribution: gets VI(idx=1) which was meant for Excerpt A's attribution → **correct by coincidence**
- Excerpt B's school: gets VI(idx=0) which was meant for Excerpt A's school → **WRONG verdict applied**

**Impact:** If Excerpt A school should have been rejected (agrees=False) but Excerpt B school was approved (agrees=True), the swap silently applies the wrong verdict to both. No error is raised. The `item_index` field is present but completely ignored.

---

## Summary of Findings by Severity

| # | Severity | Finding | File:Line |
|---|----------|---------|-----------|
| 1 | **CRITICAL** | 2/3 majority doesn't update primary_author_layer.author_id | consensus:337-347 |
| 2 | **HIGH** | Verification items matched by position, not item_index | consensus:714-726 |
| 3 | **HIGH** | No fallback for None context_hint on PARTIAL (I-ER-4 violation) | enrichment:280-282 |
| 4 | MEDIUM | takhrij_data `[]`→None coercion loses semantics | enrichment:296 |
| 5 | MEDIUM | FULL→PARTIAL repair branch is dead code | consensus:515-534 |
| 6 | MEDIUM | `"unknown"` phantom voter in attribution | consensus:330 |
| 7 | MEDIUM | No school↔school_confidence cross-validation | contracts.py |
| 8 | LOW | Duplicate ConsensusRecord creation, returned copy always discarded | consensus:231,234 |

**Tests with zero-bug-detection power (test dead/unreachable code):**
- `test_full_to_partial_generates_hint_from_notes`

**Tests that are necessary but too weak to catch real bugs:**
- `test_2_of_3_majority_wins` — doesn't verify which author_id won
- `test_school_disagreement_keeps_enrichment_school` — passes with no-op implementation
- `test_consensus_with_school_agreement` — only checks `is not None`
- `test_downgrade_partial_to_dependent` — doesn't verify context_hint repair
