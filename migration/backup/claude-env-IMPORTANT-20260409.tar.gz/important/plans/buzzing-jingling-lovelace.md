# Plan: Taxonomy Feedback Intake Protocol — Adapted from Excerpting

## Context

The owner flagged that the excerpting engine has an exhaustive, battle-tested protocol (HARDENING_SESSION_PROTOCOL.md v5.0.2) for ingesting owner feedback from ChatGPT batch collections. Our Section 01 feedback mining was an ad-hoc bulk extraction — we read 6 of ~40 files initially, then found 34 more findings in a supplementary pass. The excerpting protocol was specifically designed to prevent this kind of incomplete extraction (v3.3 was created after Session 1 only read 15/139 files).

**The gap:** We have good thematic synthesis documents (6 files, 1017 lines) but lack:
- Per-file coverage verification (did we read every file? how many atoms per file?)
- MCU-level traceability (verbatim anchors + line ranges for every finding)
- A completion gate (script-verified, not "we think we got it all")
- A canon structure (distilled principles promoted through verification)
- Authority-level tagging on every finding (owner_explicit vs model_inference)

**The goal:** Establish a taxonomy-adapted intake protocol, apply it to verify our current extraction, fill gaps, and gate the questionnaire (Section 02) on intake completeness.

---

## Plan: 4 Steps

### Step 1: Create the Taxonomy Feedback Intake Protocol

**File:** `engines/taxonomy/reference/FEEDBACK_INTAKE_PROTOCOL.md`

Adapt the excerpting protocol's key mechanisms for taxonomy's needs:

| Excerpting Mechanism | Taxonomy Adaptation |
|---|---|
| Per-file atom extraction | Per-file taxonomy-atom extraction (lighter — design preferences, not behavioral rules) |
| MCU model (verbatim anchor + lines) | TAU model (Taxonomy Atom Unit) with: quote, file, line range, authority level |
| 3 authority levels | Same: `owner_explicit` > `owner_consistent_inference` > `model_only` |
| Batch Completion Gate (5 conditions) | Taxonomy Coverage Gate: every file classified as MINED/EMPTY/NOT_TAXONOMY_RELEVANT |
| Canon concept (distilled principles) | Taxonomy Canon: distilled placement rules promoted to SPEC constraints |
| Per-file coverage table | Same: file → atom count → status (MINED/SKIPPED/NEEDS_REREAD) |
| Emphasis = semantic content | Same: ALL-CAPS and intensity markers preserved |

**Key differences from excerpting protocol:**
- No per-atom lifecycle (atoms feed into questionnaire design, not SPEC changes)
- No consensus voting on atoms (they inform questions, not engine behavior)
- Lighter verification standard (Faqīh, not Ḥāfiẓ — meaning-preserving, not word-for-word)
- Output is reference documents + questionnaire input, not prompt modifications

### Step 2: Generate Per-File Coverage Table

**File:** `engines/taxonomy/reference/owner_feedback/COVERAGE_TABLE.md`

For ALL files across all 16 collections + F1 canon + DR reviews:
- Run parallel agents to scan each collection
- For each file: classify as TAXONOMY_RELEVANT / NOT_RELEVANT / PARTIALLY_RELEVANT
- For relevant files: count how many TAUs our existing 6 documents captured vs. how many exist
- Flag files where our existing extraction got 0 atoms but the file has taxonomy content (red flags)
- Flag files with high keyword density but low extraction coverage

The coverage table looks like:

```
| Collection | File | Taxonomy Relevance | TAUs in Existing Docs | Estimated TAUs Remaining | Status |
|---|---|---|---|---|---|
| D3 | 09_attribution_and_proof_coupling.jsonl | HIGH | 4 (reinforcing) | 0 | COMPLETE |
| G2 | g2_owner_raw_reaction.txt | HIGH | 12 (new) | ~2 | NEEDS_REREAD |
| F4 | f4_owner_raw_reaction.txt | LOW (3 hits) | 0 | ~1 | QUICK_SCAN |
...
```

### Step 3: Fill Coverage Gaps

Based on the coverage table from Step 2:
- Any file classified as NEEDS_REREAD → dispatch targeted extraction agent
- Any file with 0 TAUs but keyword hits > 5 → dispatch extraction agent
- Low-density files (1-4 keyword hits) → batch into one quick-scan agent
- Each new TAU gets: quote, source file, line range, authority level, NEW/REINFORCES tag

New findings get appended to `supplementary_batch_findings.md` or create a new doc if a major theme emerges.

### Step 4: Produce Taxonomy Canon + Coverage Gate

**Files:**
- `engines/taxonomy/reference/owner_feedback/TAXONOMY_CANON.yaml` — machine-readable distilled placement rules
- `engines/taxonomy/reference/owner_feedback/COVERAGE_GATE.md` — gate report

The **canon** extracts the ~20-30 hardest placement rules from all our findings and structures them as:
```yaml
- id: TC-001
  rule: "Proofs must be organized by opinion first, then by individual proof"
  authority: owner_explicit
  source: G2 raw reaction
  quote: "umrah is mandatory -> own branch, with own 'proof'-leaf..."
  questionnaire_question_needed: false  # Already explicit
```

The **coverage gate** verifies:
1. Every file in all 16 collections has a coverage status
2. Every HIGH-relevance file has been read and atoms extracted
3. Zero NEEDS_REREAD files remain
4. The canon YAML covers all owner_explicit rules

Only after this gate passes does Section 02 (questionnaire design) begin.

---

## Files Modified/Created

| File | Action |
|---|---|
| `engines/taxonomy/reference/FEEDBACK_INTAKE_PROTOCOL.md` | CREATE — adapted protocol |
| `engines/taxonomy/reference/owner_feedback/COVERAGE_TABLE.md` | CREATE — per-file coverage |
| `engines/taxonomy/reference/owner_feedback/supplementary_batch_findings.md` | UPDATE — gap fills |
| `engines/taxonomy/reference/owner_feedback/TAXONOMY_CANON.yaml` | CREATE — machine-readable rules |
| `engines/taxonomy/reference/owner_feedback/COVERAGE_GATE.md` | CREATE — gate report |

---

## Verification

1. Coverage table has a row for every file across all 16 collections
2. Zero HIGH-relevance files have status NEEDS_REREAD
3. TAXONOMY_CANON.yaml is valid YAML, parseable by Python
4. Every canon entry has a `source` field tracing to a specific file
5. Commit: `docs(taxonomy): establish feedback intake protocol + coverage gate`

---

## Execution Approach

- Steps 1-2 can run in parallel (protocol writing + coverage scanning)
- Step 3 depends on Step 2 output (gaps identified)
- Step 4 depends on Step 3 completion (all gaps filled)
- Dispatch Codex CLI for structural review of the protocol + canon
- Dispatch Gemini CLI for scholarly accuracy review of the canon
- Total: 3-4 parallel agent waves, then 2 coworker reviews
