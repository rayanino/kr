# Plan: Batch Lifecycle Protocol v5.0 — Verification Architecture

---
title: "feat: Batch Lifecycle Protocol with Muqābalah verification + Batch Completion Gate"
type: feat
status: active
date: 2026-04-06
origin: engines/excerpting/reference/dr_reviews/DR12_chatgpt_batch_lifecycle_v50.md (to be archived)
---

## Context

The owner identified that F1-F2 foundational notes had ZERO atoms extracted (65 gaps, 52% of all documented gaps). Investigation confirmed: no batch-level completeness gate exists, only 32% of atoms at terminal closure, and the protocol has no mechanism to verify ALL feedback was captured before moving on.

ChatGPT DR (DR12) produced a complete, ready-to-implement "Batch Completeness Verification Amendment v5.0" with:
- Formal batch lifecycle: A (Intake) → C (Verification) → B (Hardening) — verification BEFORE hardening
- MCU-based traceability (Meaningful Content Units mapped to MAQ/META/REJECT entries)
- Batch Completion Gate with script-enforced pass/fail
- 5 new scripts for deterministic verification
- 13-cause pre-mortem with mitigations
- Ready-to-paste protocol sections

Gemini DR (DR13) produced a complementary pedagogical framework: 6-phase lifecycle grounded in Ibn Jamāʿah and al-Zarnūjī, bifurcated Murājaʿah standards (Ḥāfiẓ for F1/F2, Faqīh for F3-F8), structured Reverse ʿArḍ format (visual + questions + omission confession), 7 named anti-patterns, and 4-lock Ijāzah gate.

Claude DR (DR14) produced the deepest scholarly grounding: 8-category corruption taxonomy from ḥadīth sciences (nuqṣān, takhfīf, taḥrīf, idrāj, inqiṭāʿ, taṣḥīf, qalb + empirical LLM bias data), 3 grades of collation (bi-l-aṣl / bi-nuskha / ʿalā al-shaykh), 5-phase muqābala procedure, 6 named verification artifacts (Daftar, Shahāda, Jihāz, Sijill, Miftāḥ, ʿArḍ Record), 3-state implementation tracking (tathbīt ≠ taḥrīr), N-version architecture recommendation, and emphasis-as-semantic-content principle.

Earlier inputs: Gemini CLI (Muqābalah, HALT, ADDED/INTERPOLATED 4th category, synthesis of DR12+DR13), Codex CLI (dispatched).

## Problem Frame

The protocol (v4.3) has world-class per-atom gates but zero batch-level verification. This allows entire files to be silently excluded from extraction — the exact failure that happened with F1-F2. The owner's feedback window is finite; lost notes are permanently lost.

## Owner Directives (this session)

1. **Session count is UNLIMITED.** The owner will start a new CC session per atom if needed. The protocol must NEVER constrain session count — it constrains QUALITY per session. 1 atom done perfectly > 8 atoms done adequately.

2. **Empirical testing is a CORE PHASE.** After hardening atoms into prompt/SPEC, real LLM calls via OpenRouter must verify the excerpts actually reflect the hardening. OpenRouter API key topped up with generous budget specifically for this. Testing is not optional — it's the computational equivalent of taḥrīr (DR14): establishing the correct reading means nothing if the engine still produces corrupt excerpts.

These directives modify the batch lifecycle: the hardening phase must include test→evaluate→iterate loops PER ATOM (or per small group), not just a final smoke run.

## Batch Lifecycle (6 phases, synthesized from DR12+DR13+DR14+Owner)

```
A (Intake) → C (Verification/Muqābalah) → B (Hardening+Testing) → D (Adversarial DR) → F (Ijāzah/Finalization)
```

| Phase | Name | Purpose | Sessions |
|-------|------|---------|----------|
| **A** | Intake (التلقي) | Extract every atom from every file | 1-2 sessions |
| **C** | Verification (المقابلة) | Line-by-line Muqābalah: map every MCU to MAQ/META/REJECT. Ḥāfiẓ standard for F1/F2, Faqīh for F3-F8. | C1, C2, ... (as many as needed) |
| **B** | Hardening+Testing (المدارسة+التجريب) | Per-atom 7-stage lifecycle. 1-3 atoms/session. After EVERY prompt-affecting atom: run `atom_test.py` via OpenRouter, evaluate output, iterate if non-adherent. | B1, B2, B3, ... (unlimited — even 1 atom/session) |
| **D** | Adversarial DR (المعارضة) | Independent DR sampling of verification + hardening artifacts | DR relay (recommended) |
| **F** | Finalization (الإجازة) | 4-lock Ijāzah gate + owner Reverse ʿArḍ sign-off | 1 session |

**Empirical testing is INTEGRATED into Phase B, not a separate phase.** After implementing a prompt-affecting atom (Stage 6), the session:
1. Runs `atom_test.py --package taysir --chunk 0` (or other fixture) via OpenRouter
2. Evaluates: does the excerpt reflect the hardened rule?
3. If YES → proceed to Stage 7 (CLOSED)
4. If NO → iterate (re-enter Stage 3 or 5), adjust the rule, re-test
5. If REGRESSION → halt, investigate, fix before proceeding

**Session count = driven by quality, not throughput.** 1 atom done perfectly in a dedicated session > 8 atoms crammed into one context window. The owner will start unlimited sessions.

## Key Decision: Adopt DR12 Architecture

The DR12 report is the most detailed and implementable DR we've received. Rather than designing from scratch, we adopt its architecture with targeted amendments from Gemini CLI's scholarly methodology:

**A→C→B ordering (DR12 + DR13 consensus):** Verification before hardening. DR12: "If capture completeness is wrong, per-atom rigor only hardens the wrong target." DR13: "أثبت العرش ثم انقش — establish the throne, then engrave." Gemini CLI: "من ضيع الأصول حُرم الوصول."

**MCU granularity (DR12) + Bifurcated Murājaʿah (DR13):**
- F1/F2 (foundational vision = the *matn*): **Ḥāfiẓ + Muḥaddith standard** = per-sentence, verbatim verification. Every ALL-CAPS directive mapped word-for-word.
- F3-F8 (structured Q&A = the *sharḥ*): **Faqīh standard** = per-concept, thematic verification. Verify the legal rule/concept was captured, not every sentence.
- Gap categories: MISSED/SOFTENED/DISTORTED/**ADDED-INTERPOLATED** (Gemini CLI's 4th category: Mudraj — LLM hallucinated content not in owner's original)

**Global session numbering (DR12 + DR13 consensus):** Both DRs agree. Keep global numbering with per-batch artifact directories.

**TWO GATES, not one (Gemini CLI synthesis — they operate at different lifecycle positions):**

**Gate 1: Batch Completion Gate (DR12) = Entry-to-Hardening**
Executes AFTER Intake+Verification, BEFORE Hardening begins:
- 100% file coverage (every file in inventory VERIFIED)
- 0 unresolved MISSED/SOFTENED/DISTORTED/ADDED gaps
- All MCUs mapped to MAQ/META/REJECT
- `verify_batch_completion_gate.py` exits 0

**Gate 2: Ijāzah Gate (DR13) = Exit-to-Production**
Executes at END of batch lifecycle, BEFORE declaring batch terminal:
1. **Mulāzamah proof** = 100% file coverage confirmed (re-verified post-hardening)
2. **Taḥqīq clearance** = 0 SOFTENED items remaining in final SPEC/prompt
3. **Mudhākarah consensus** = at least 2 coworkers attested on final batch state
4. **ʿArḍ validation** = owner sign-off via Reverse ʿArḍ (visual + questions + omission confession)

**Reverse ʿArḍ format (DR13):** 3-part owner briefing:
1. *Matn Reflection*: visual side-by-side (owner's raw note | system's capture) with green/yellow/red coding
2. *Taḥqīq Clarification*: targeted questions for ambiguous items
3. *Amānah Checklist*: honest list of deferred/rejected items with justification

**7 Anti-Patterns Appendix (DR13):** Add to protocol as §Appendix C — named anti-patterns from classical pedagogy mapped to computational failure modes.

## Requirements Trace

- R1. Every batch follows A→C→B lifecycle (intake → verification → hardening)
- R2. Verification = MCU-level Muqābalah with verbatim anchors per DR12 §3.4
- R3. Batch Completion Gate blocks per-atom work until script-verified complete
- R4. F-batch verification happens FIRST (HALT on G/SC until F verified)
- R5. 5 new scripts for deterministic verification pipeline
- R6. 3 new Hard Rules (no atoms without BCV, no VERIFIED without MCU trace, Layer A before Layer B)
- R7. `verification-only` session type added to §1.5
- R8. Gap classification: MISSED/SOFTENED/DISTORTED/ADDED-INTERPOLATED/SKIPPED-FILE with severity levels
- R9. Emotional intensity preserved as epistemic weight (ALL-CAPS = CRITICAL severity)
- R10. Bifurcated Murājaʿah: Ḥāfiẓ standard for F1/F2, Faqīh standard for F3-F8 (DR13)
- R11. Reverse ʿArḍ format: visual side-by-side + targeted questions + Amānah checklist (DR13)
- R12. 7 anti-patterns appendix (DR13)
- R13. 4-lock Ijāzah gate (DR13 framing + DR12 mechanics)
- R14. 8-category corruption taxonomy with classical Arabic names (DR14: nuqṣān, takhfīf, taḥrīf, idrāj, inqiṭāʿ, taṣḥīf, qalb, + systematic LLM takhfīf bias)
- R15. 3 grades of collation with KR equivalents: bi-l-aṣl (raw .txt), bi-nuskha (Layer A vs B), ʿalā al-shaykh (owner review) (DR14)
- R16. 6 named verification artifacts: Collation Register, Collation Certificate (binding attestation), Variant Apparatus, Gap Remediation Tracker, Key to Symbols, Owner Review Record (DR14)
- R17. 3-state implementation tracking: State 1 (in original only) → State 2 (extracted not implemented) → State 3 (implemented) (DR14)
- R18. N-version verification for F1/F2 critical files (2 independent agents + comparison), single-agent for F3-F8 (DR14)
- R19. 3 priority tiers based on owner emphasis: Tier 1 (ALL-CAPS/PLEASE), Tier 2 (normal directives), Tier 3 (observations) (DR14)
- R20. Formal Owner Review Record (Sijill al-ʿArḍ) as mandatory artifact (DR14 — MISSING from plan, flagged by explore agent)
- R21. N-version verification MANDATORY for F1/F2 (2 independent agents + comparison) — currently only "recommended" (DR14 — PARTIAL, flagged)
- R22. Session D (Adversarial DR) elevated from "optional" to "recommended for critical files" (DR13 — PARTIAL, flagged)
- R23. Collation Certificate with formal attestation language: "بلغت المقابلة بأصله" template (DR14 — PARTIAL, flagged)
- R24. State 2 remediation deadline: atoms stuck in "extracted but not implemented" for >3 sessions must be escalated (DR14 — PARTIAL, flagged)
- R25. 7 anti-patterns as formal protocol Appendix C (DR13 — PARTIAL, flagged)
- R26. Scholarly precedent reference section preserved in protocol (DR14 §8 — MISSING, flagged)
- R27. Calibration File (Nuskha Miʿyāriyyah) for drift detection: re-extract from fixed file every 5th session, compare baseline (DR15 — novel mechanism)
- R28. Architecture D (Hybrid Serial Muqābalah): agent 1 extracts with checklist → agent 2 hunts gaps. REPLACES Claude DR's N-version for default. N-version reserved for F1/F2 only if Architecture D insufficient. (DR15 — resolves DR12 vs DR14 divergence)
- R29. 8 automated anti-pattern tests (T01-T08) with concrete detection logic (DR15 — ready for implementation as scripts)
- R30. 8th anti-pattern: Idṭirāb al-Matn (internal contradiction between F3-F8 and F1/F2) (DR15)
- R31. Partial Certification (Ijāzah Muʿayyanah): owner can approve subsets (DR15)
- R32. Revocation Policy (Rujūʿ): Ijāzah revocable if subsequent processing reveals foundational distortion (DR15)
- R33. Absolute Reopen Authority (Ḥaqq al-Istidrāk): verification can reopen ANY finalized atom violating F1/F2 (DR15)
- R34. Impact Evidence Requirement: prompt-affecting atoms need before/after output delta proof (DR16-Q1-1, CRITICAL)
- R35. Regression Gate: mandatory re-run of ALL prior atom tests after ANY prompt change (DR16-Q1-2, CRITICAL — ranked #1 cascade risk)
- R36. Anchor-Bound Expansion Rule: expansions must cite verbatim MCU anchors + mark inferences explicitly (DR16-Q1-4, CRITICAL)
- R37. Cross-Batch Coherence Gate: doctrine contradiction scan before starting next batch (DR16-Q1-5, CRITICAL)
- R38. Empirical Equivalence Contract: all test runs record model_id, prompt_hash, spec_hash, sampling params (DR16-Q1-7, CRITICAL)
- R39. Coverage-Claim Validation: "already covered by FP" requires FP citation + counterexample + test linkage (DR16-Q1-3, HIGH)
- R40. Fan-In Threshold: >5 MCUs mapping to 1 atom → split or add Sub-Claim Table (DR16-Q1-6, HIGH)
- R41. 4 additional scripts: run_regression_suite.py, prompt_coherence_lint.py, atom_impact_diff.py, spec_test.py (DR16-Q2)
- R42. Canonical Regression Fixture = taysir + Matched Fixture Policy per atom category (DR16-Q3)
- R43. 3 new fixture packages needed: hadith_collection [ENT], tarajim_dictionary [ENT], tasawwuf_maqamat [SEQ] (DR16-Q3-4)
- R44. Archive DR12 + DR13 + DR14 + DR15 + DR16, version bump to v5.0

## Scope Boundaries

- Protocol amendments + scripts only (no engine code, no SPEC, no prompt changes)
- F-batch verification execution is a SEPARATE session (not this session)
- Claude DR and Gemini DR responses on batch lifecycle will be integrated as v5.1 when they arrive

## Implementation Units

### Phase 1: Archive + Protocol Amendments

- [ ] **Unit 1: Archive DR12**

**Files:**
- Create: `engines/excerpting/reference/dr_reviews/DR12_chatgpt_batch_lifecycle_v50.md`

---

- [ ] **Unit 2: Add §3.4 Batch Completeness Verification (BCV)**

**Files:**
- Modify: `engines/excerpting/reference/HARDENING_SESSION_PROTOCOL.md`

**Approach:** Insert DR12's §3.4 specification after existing §3.3 (Intake Quality Gate). Includes: MCU definition, per-file verification loop (bind → enumerate → trace → classify → disposition → close), Layer A first ordering, meta-directive handling, context budget management via stateful artifact pipeline.

---

- [ ] **Unit 3: Add Batch Completion Gate to §1.6**

**Files:**
- Modify: `engines/excerpting/reference/HARDENING_SESSION_PROTOCOL.md` §1.6

**Approach:** Insert gate after bundle intake inventory (existing gate 5) and before prompt refactor (existing gate 6): "BATCH COMPLETENESS VERIFICATION GATE — if active batch not BCV-VERIFIED per verify_batch_completion_gate.py, session type MUST be verification-only." Renumber existing gates 6→7, 7→8, 8→9.

---

- [ ] **Unit 4: Add `verification-only` session type to §1.5**

**Files:**
- Modify: `engines/excerpting/reference/HARDENING_SESSION_PROTOCOL.md` §1.5

**Approach:** Add verification-only row to session type table. Add to compatibility matrix as FORBIDDEN with all other types (standalone only, like intake-only).

---

- [ ] **Unit 5: Add 3 new Hard Rules to §1.4**

**Files:**
- Modify: `engines/excerpting/reference/HARDENING_SESSION_PROTOCOL.md` §1.4

**Approach:** Add:
- "Never begin per-atom processing on a batch until BCV is complete and Batch Completion Gate passes."
- "Never mark a file VERIFIED without MCU trace records with verbatim anchors and line ranges."
- "Never verify Layer B without verifying Layer A; Layer A coverage required for gate pass."

---

- [ ] **Unit 6: Add queue audit methodology (MISSED/SOFTENED/DISTORTED/SKIPPED-FILE + severity)**

**Files:**
- Modify: `engines/excerpting/reference/HARDENING_SESSION_PROTOCOL.md`

**Approach:** Insert DR12's category definitions and severity levels as a subsection of §3.4. Include disposition workflow (MISSED → new MAQ/META/REJECT; SOFTENED → correction delta; DISTORTED → halt + escalate).

---

- [ ] **Unit 7: Update NEXT.md for F-batch verification first**

**Files:**
- Modify: `NEXT.md`

**Approach:** Session 3 = F-batch verification (verification-only), NOT G/SC intake. The F-batch must be verified before any new batch work begins.

---

### Phase 2: Scripts

- [ ] **Unit 8: Build 5 verification scripts**

**Files:**
- Create: `scripts/batch_inventory.py`
- Create: `scripts/batch_verification_init.py`
- Create: `scripts/batch_compute_coverage.py`
- Create: `scripts/batch_generate_trace_report.py`
- Create: `scripts/verify_batch_completion_gate.py`

**Approach:** Follow DR12's pseudocode sketches. Core logic:
- `batch_inventory.py`: enumerate collection files, compute bytes/lines/SHA-256 per file, output inventory.json
- `batch_verification_init.py`: initialize verification_status.json from inventory
- `batch_compute_coverage.py`: file coverage + MCU coverage + severity-weighted gaps
- `batch_generate_trace_report.py`: generate verification_report.md from JSON artifacts
- `verify_batch_completion_gate.py`: deterministic pass/fail (exit 0 = pass, exit 1 = fail)

---

### Phase 3: Version Bump

- [ ] **Unit 9: Version bump v4.3 → v5.0 + version history**

**Files:**
- Modify: `engines/excerpting/reference/HARDENING_SESSION_PROTOCOL.md` (title, frontmatter, version history)
- Modify: `NEXT.md`

**Approach:** This is v5.0 (not v4.4) because it's a major structural addition (new session type + batch lifecycle + gate + scripts), not an incremental patch.

---

## Coworker Validation Status

| Source | Status | Key finding |
|--------|--------|-------------|
| Gemini CLI | COMPLETE | Muqābalah methodology, A→C→B confirmed, HALT on G/SC, independent verifier |
| Codex CLI | DISPATCHED (pending) | Validating gate integration, MCU definition, script redundancy |
| Gemini CLI (DR12 validation) | DISPATCHED (pending) | Validating MCU granularity, scholarly completeness of categories |
| ChatGPT DR | **DR12 = THIS REPORT** | Complete batch lifecycle amendment |
| Claude DR | DISPATCHED (awaiting relay) | Scholarly muqābalah methodology |
| Gemini DR | DISPATCHED (awaiting relay) | Pedagogical batch lifecycle |

## Gemini CLI Integration Review — Concerns Addressed

Gemini CLI raised 5 concerns. Resolution:

1. **"Breaks Hard Rule 11"** → INVALID. Verification checks extraction completeness, not atom processing. The 7-stage lifecycle runs AFTER verification. No bulking.
2. **"Redundant artifacts"** → PARTIALLY VALID. Consolidate: use existing MERGED_ATOM_QUEUE + ledger + coverage table. Add only genuinely new: `mcu_trace.jsonl`, Collation Certificate, Gap Remediation Tracker. Don't create 6 standalone files.
3. **"Infeasible per-atom testing"** → ADDRESSED. Owner topped up API key. Only prompt-affecting atoms tested. Protocol §4.6 already requires this.
4. **"Pipeline paralysis (15-30 sessions)"** → ADDRESSED. Owner: unlimited sessions. 15-30 sessions for F-batch is acceptable vs losing 124 gaps permanently.
5. **"Taxonomy incomplete for LLM"** → PARTIALLY VALID. The 8-category taxonomy covers EXTRACTION fidelity. LLM excerpt failures (boundary splitting, decontextualization) are covered by existing §4.3 (30 indivisible units) and §4.13 (scholarly integrity). Add explicit note: "This taxonomy governs verification of extraction fidelity. Excerpt quality failures are governed by §4.3 + §4.13."

## Risks & Dependencies

| Risk | Mitigation |
|------|------------|
| F-batch verification discovers 100+ new atoms | This is the POINT — better now than lost forever |
| MCU definition too subjective → inconsistent segmentation | DR12's pre-mortem: density heuristics + second-pass sampling |
| 5 new scripts to build | Follow existing script patterns (verify_atom_closure_minimal.py) |
| Layer confusion regression (verify Layer B, miss Layer A) | Hard Rule + script enforcement: gate fails if any Layer A file unverified |
| Context exhaustion during verification | Session C spans multiple sessions (C1, C2...); progress in JSON artifacts |

## Sources & References

- **Origin:** ChatGPT DR (DR12) — complete batch lifecycle amendment
- **Gemini CLI:** Muqābalah methodology, HALT recommendation, independent verifier
- **Codex CLI:** Pending validation
- **Protocol:** `engines/excerpting/reference/HARDENING_SESSION_PROTOCOL.md` v4.3
- **Audit:** `engines/excerpting/reference/QUEUE_AUDIT_RAW_VS_EXTRACTION.md` (124 gaps)
