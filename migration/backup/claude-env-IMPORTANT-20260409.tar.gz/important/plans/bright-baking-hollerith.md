# Plan: Session 6 Review Fixes — L-011, Comment, Smoke Test Multi-Layer

## Context
Session 6 review ACCEPTED at 344cd5d. Post-review deep analysis (committed at 7878ec2) found 3 issues. All fixes are architect-specified with exact code — no design decisions needed.

## Changes (4 edits across 4 files)

### 1. `engines/normalization/src/writer.py` — L-011 prev-only orphan recovery
- **Lines 192-193**: Replace bare `return False` with prev-only orphan detection + restore logic
- Uses existing `_parse_timestamp_from_dirname`, `shutil`, `logger` — no new imports

### 2. `engines/normalization/tests/test_writer.py` — L-011 test
- **After line 200** (end of `TestRecoverInterruptedWrite`): Add `test_l011_prev_only_orphan_recovery`
- Creates orphaned prev dir, verifies recovery restores it to `normalized/`

### 3. `engines/normalization/src/validation.py` — Comment fix
- **Line 119**: Replace misleading "Non-fatal checks accumulate warnings" with accurate "Remaining checks (may add warnings or fatals, but don't short-circuit)"

### 4. `tools/smoke_test_validation.py` — Multi-layer fixture support
- **Line 40**: Add `is_multi_layer: bool = False` param to `_make_smoke_metadata`
- **Line 58**: Pass `is_multi_layer=is_multi_layer` instead of hardcoded `False`
- **Line 82**: Add `is_multi_layer: bool = False` param to `run_fixture`
- **Line 88**: Pass `is_multi_layer` to `_make_smoke_metadata`
- **Line 127**: Detect `02_nahw_muhaqiq` as multi-layer, pass to `run_fixture`

## Verification
```bash
python -m pytest engines/normalization/tests/ -v --tb=short   # 335 passed, 12 skipped
python tools/smoke_test_validation.py                          # 63/63 PASS
```

## Commit
`fix: Session 6 review fixes — L-011 recovery, comment, smoke test multi-layer`
