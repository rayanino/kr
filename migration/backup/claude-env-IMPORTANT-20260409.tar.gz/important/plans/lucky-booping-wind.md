# CLI Adapter SPEC Compliance Fixes

## Context

Adversarial audit of commit 2a8560b4 (CLIInstructorAdapter) found 4 SPEC-code divergences.
All 30 adapter tests and 768 excerpting tests pass — no logic bugs, only SPEC mismatches.
The SPEC was amended post-commit (§14.4), and the implementation wasn't updated to match.

Claude Chat requested empirical verification of Finding 4 (envelope) before fixing.

## Findings to Fix

| # | Severity | SPEC Section | Issue |
|---|----------|-------------|-------|
| F1 | HIGH | §4.5 | `extract_json()` returns `str`, SPEC says `dict \| list` |
| F2 | HIGH | §3.1 | `_resolve_backend()` missing WARNING log on unknown prefix |
| F3 | MEDIUM | §5.1 | Empty system message produces leading `\n\n` |
| F4 | MEDIUM | §3.2 | No envelope extraction for `claude --output-format json` |

## Step 0: Empirical Envelope Test (determines F4 fix scope)

Run live:
```bash
ANTHROPIC_API_KEY=$(python -c "import json; d=json.load(open('$HOME/.claude/.credentials.json')); print(d['claudeAiOauth']['accessToken'])") \
claude -p "Say hello" --bare --no-session-persistence --max-turns 2 --output-format json --model opus --system-prompt "Reply with just the word hello"
```

**If raw text** (e.g. `hello`): F4 is a false alarm for current CLI version. Add a code comment noting the assumption + a defensive TODO.
**If JSON envelope** (e.g. `{"type":"result","result":"hello"}`): F4 is real. Implement envelope extraction.

## Step 1: Fix F1 — `extract_json()` return type

**File:** `shared/llm/cli_adapter.py`

Change `extract_json` to return `dict | list` instead of `str`:
- Change return annotation: `-> dict | list`
- Replace all `return stripped` / `return candidate` / `return fenced` with `return json.loads(...)` (using the already-validated parse)
- Remove the redundant `json.loads(json_str)` at line 324 in `create()`
- Update the JSONDecodeError raise to match (already fine)

**Caller change in `create()`:**
```python
# Before (lines 323-324):
json_str = extract_json(raw_output)
json_data = json.loads(json_str)

# After:
json_data = extract_json(raw_output)
```

**Test impact:** Tests that call `extract_json` directly (test_json_extraction_strips_markdown, test_json_extraction_finds_object) currently do `json.loads(result)` on the string return. After fix, `result` IS the dict — update tests to assert on dict directly.

## Step 2: Fix F2 — `_resolve_backend()` WARNING log

**File:** `shared/llm/cli_adapter.py`

Add WARNING log before the fallback return in `_resolve_backend()`:
```python
def _resolve_backend(model: str, default_backend: str) -> str:
    for prefix, backend in _PROVIDER_MAP.items():
        if model.startswith(prefix):
            return backend
    logger.warning(
        "Unknown model prefix for model '%s', falling back to %s backend",
        model, default_backend,
    )
    return default_backend
```

**Test addition:** Add test to verify WARNING is logged (use `caplog` fixture).

## Step 3: Fix F3 — Empty system message leading `\n\n`

**File:** `shared/llm/cli_adapter.py`

Replace lines 278-285:
```python
# Before:
schema_directive = "\n\nOUTPUT FORMAT: ..."
system_with_schema = original_system + schema_directive

# After:
schema_directive_text = (
    "OUTPUT FORMAT: You are a JSON API. You MUST output ONLY "
    "valid JSON matching this exact schema. No markdown, no "
    "explanation, no code fences — just the raw JSON object."
    f"\n\nJSON SCHEMA:\n{schema_str}"
)
if original_system:
    system_with_schema = original_system + "\n\n" + schema_directive_text
else:
    system_with_schema = schema_directive_text
```

**Test addition:** Test that empty system message produces no leading whitespace.

## Step 4: Fix F4 — Envelope extraction (conditional on Step 0)

**File:** `shared/llm/cli_adapter.py` — `_invoke_claude()` method

If envelope exists (Step 0), add before `return result.stdout`:
```python
stdout = result.stdout
try:
    parsed = json.loads(stdout)
    if isinstance(parsed, dict) and "result" in parsed and "type" in parsed:
        logger.debug("Extracting text from claude JSON envelope")
        stdout = parsed["result"]
except json.JSONDecodeError:
    pass
return stdout
```

If no envelope (raw text), add a comment:
```python
# Note: claude --bare --output-format json currently returns raw model text,
# not a JSON envelope. If future CLI versions wrap output, add envelope
# extraction here. See SPEC §3.2 implementation note.
return result.stdout
```

## Verification

1. `PYTHONPATH=. python -m pytest shared/llm/tests/ -v --tb=short` — all 30+ tests pass
2. `PYTHONPATH=. python -m pytest engines/excerpting/tests/ -v --tb=short 2>&1 | tail -5` — 768 pass, 0 fail
3. `PYTHONPATH=. python -c "from shared.llm.cli_adapter import extract_json; r = extract_json('{\"a\":1}'); print(type(r).__name__)"` — prints `dict`
4. `git diff HEAD -- engines/` — EMPTY (zero engine changes)
