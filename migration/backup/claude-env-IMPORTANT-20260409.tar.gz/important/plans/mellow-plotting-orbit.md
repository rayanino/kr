# Plan: Fix 2 Remaining Integrity Audit Gaps in Normalization SPEC

## Context

The integrity audit found 2 gaps neither auditor caught. A 3rd item (_note cleanup) was already fixed earlier. These are the last fixes before Probe 1 is fully closed.

## Fix 1: Add NORM_FOOTNOTE_CLASSIFICATION_FAILED error code

**Why:** §4.B.4 uses LLM fallback for ambiguous footnote classification, but §7 has no error code for when the LLM call fails or returns unparseable output. Footnotes would silently remain `unknown_footnote_type` without logging.

**Where:** `engines/normalization/SPEC.md` §7 error table, after line 1586 (`NORM_DISCOURSE_INCONSISTENT`)

**New row:**
```
| `NORM_FOOTNOTE_CLASSIFICATION_FAILED` | Info | LLM fallback for footnote classification returns error, timeout, or unparseable response | Footnote retains coarse classification (`tahqiq_editor`/`author_original`/`unknown_footnote_type`). Log the LLM error. Classification method recorded as `"pattern_only"`. Does not block normalization — footnote is usable with coarse type. |
```

## Fix 2: Add structural_format_proposed to §3 and contracts.py

**Why:** The M-31 fix (§4.B.2) creates a `structural_format_proposed` field when auto-detection disagrees with upstream classification, but this field was never added to the §3 manifest schema or the Pydantic model. An implementer building §4.B.2 would produce a field that fails schema validation.

**Where (SPEC):** `engines/normalization/SPEC.md` §3 manifest field list, after line 86 (`structural_format`)

**New line:**
```
   - `structural_format_proposed`: Optional string or null. When §4.B.2 auto-detection disagrees with the source engine's classification, this field contains the normalizer's proposed format. Null when there is no disagreement. The `structural_format` field retains the source engine's classification until a human gate resolves the disagreement. [AUDIT FIX M-31 completion]
```

**Where (contracts.py):** `engines/normalization/contracts.py` after line 655 (`structural_format`)

**New field:**
```python
    structural_format_proposed: Optional[StructuralFormat] = Field(
        None,
        description="Normalizer's proposed format when auto-detection disagrees with source engine"
    )
```

## Fix 3: _note cleanup — ALREADY DONE

The `_note` audit comments were removed in the earlier self-review pass. Verified: `grep '_note.*REMOVED' SPEC.md` returns no matches.

## Files to modify

1. `engines/normalization/SPEC.md` — 2 insertions (§3 line 86, §7 line 1586)
2. `engines/normalization/contracts.py` — 1 insertion (line 655)

## Verification

- `grep NORM_FOOTNOTE_CLASSIFICATION_FAILED engines/normalization/SPEC.md` returns the new error code
- `grep structural_format_proposed engines/normalization/SPEC.md` returns the §3 entry
- `grep structural_format_proposed engines/normalization/contracts.py` returns the Pydantic field
- JSON in §3 is consistent with contracts.py field name and type
