# Plan: What To Do Next — Data-First with Preserved Intent

## Context

The environment overhaul Sessions 1 & 2 are complete (21 agents, 22 commands, 15 skills, 14 hooks, 17 rules). The excerpting engine has 595 tests passing, 0 failures, all 3 critical bugs fixed, and 5 test packages ready. The question is: should we do Sessions 3 & 4 (integrations + advanced) before or after the first real LLM evaluation?

**Core insight:** Every Session 3/4 item is either (a) a verification tool that needs real LLM data to calibrate, or (b) an integration that can be built more effectively after you know what the LLM actually gets wrong. None of them block the first LLM call.

## Recommendation: Approach E — Commit, Capture, Evaluate, Then Triage

### Step 1: Commit S1/S2 Environment Work

Commit all uncommitted changes (~48 files) as 2 logical commits:
- **Commit A:** Session 1 — ECC infrastructure + domain knowledge encoding (hooks, rules, skills, basic agent/command enhancements)
- **Commit B:** Session 2 — New agents (arabic-reviewer, regression-detector, evaluation-prep), new commands (/cost-report, /eval-dashboard, /regression-check, /arabic-audit), verification scripts, spec-writer enhancement, orchestrate enhancement

### Step 2: Write SESSION_3_4_BACKLOG.md

Preserve S3/S4 intent as a structured document with trigger conditions. For each item:
- What it is
- Why it matters (which threat model entry)
- What triggers it (what LLM evaluation finding makes it urgent)
- What it depends on (what real data is needed)
- Estimated effort

This gets committed alongside S1/S2. The ideas are preserved, nothing is lost.

Items to capture:
| Item | Trigger Condition | Depends On |
|------|------------------|------------|
| Usul.ai scholar verification | LLM gets death dates or attributions wrong in >20% of cases | Real Phase C results |
| Sunnah.com hadith lookup | Hadith evidence references systematically wrong | Real excerpting results on hadith-heavy texts |
| Automated hallucination detector | Patterns emerge in LLM fabrication across 5+ books | Corpus of known hallucinations from evaluation |
| Scholar authority heuristics | Gate abort rate >30% due to missing scholar data | Real Phase D/E gate abort patterns |
| Arabic embeddings | Taxonomy engine needs semantic dedup | Not relevant until taxonomy engine starts |

### Step 3: Update NEXT.md

Replace the stale compute_page_range task with the first real LLM call:
- Smoke test: `--real --max-chunks 1` on ibn_aqil_v1 (EUR ~0.20)
- Full run: all chunks on ibn_aqil_v1 (EUR ~0.50-1.00)
- Expand to 2-3 more packages for format diversity
- Follow LLM_INTEGRATION_TEST_PROTOCOL.md

### Step 4: Start New Session → First Real LLM Call

The new session:
1. `/catchup` to reload context
2. Run `evaluation-prep` agent for pre-flight checks
3. Smoke test with `--max-chunks 1`
4. If passes, full run on ibn_aqil_v1
5. Review results per LLM_INTEGRATION_TEST_PROTOCOL Phase C
6. Run 2-3 more packages
7. Document findings

### Step 5: After Real Data — Triage S3/S4

Read SESSION_3_4_BACKLOG.md, check which triggers fired, implement what's needed.

## Why This Order

1. **The LLM call is the highest-information action available.** One real run tells you more than 20 hours of speculative infrastructure.
2. **CLAUDE.md priority #1 is pipeline progress.** The excerpting engine has been "mock mode works" for days. The first real call is the biggest pipeline step available.
3. **S3/S4 tools are verification, not pipeline.** The pipeline produces output without them. Manual verification (per the protocol) covers Round 1.
4. **Budget favors data-first.** EUR 63 remaining. Better spent on evaluation rounds than speculative tools.
5. **The protocol is already complete.** LLM_INTEGRATION_TEST_PROTOCOL.md + evaluation-methodology skill + evaluation-prep agent = everything needed.

## What You Don't Lose

- S3/S4 ideas are captured in SESSION_3_4_BACKLOG.md with trigger conditions
- Each item will be built when real data proves it's needed, making it MORE effective (calibrated to actual errors)
- Sessions 3/4 become "implement what the data revealed" rather than "guess what might be needed"

## Budget Projection

| Phase | Cost |
|-------|------|
| Commit + backlog | EUR 0 |
| Smoke test (1 chunk) | EUR 0.10-0.30 |
| Full runs (3-4 packages) | EUR 1-5 |
| S3/S4 selective implementation | EUR 0-3 |
| **Total** | **EUR 1.10-8.30** |
| **Remaining** | **EUR 55-62** |

## Files to Modify

- All `.claude/` uncommitted files → commit
- `NEXT.md` → update for first real LLM call
- New: `SESSION_3_4_BACKLOG.md` → capture deferred intent
- `scripts/run_integration_test.py` → already ready (--real mode)

## Verification

After committing and updating NEXT.md:
1. `git log --oneline -5` confirms clean commits
2. `python -m pytest engines/excerpting/tests/ -q` confirms 595 passing
3. `python scripts/validate_agent_definitions.py` confirms all agents valid
4. `python scripts/run_integration_test.py --mock --package-path experiments/format_diversity_test/packages/ibn_aqil_v1 --max-chunks 1` confirms mock still works
