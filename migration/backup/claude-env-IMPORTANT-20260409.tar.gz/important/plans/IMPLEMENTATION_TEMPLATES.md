# Implementation Templates — Copy-Paste Ready
**For:** 5 highest-impact Claude Code improvements
**Time:** ~60 minutes to integrate all 5

---

## Template 1: Metadata Flow Validator Hook

**Add to:** `.claude/settings.json` → `PostToolUse` hooks

**Where in file:** After the existing `pyright-check.sh` hook entry

```json
{
  "matcher": "Write|Edit|MultiEdit",
  "hooks": [
    {
      "type": "command",
      "command": "FILE=\"$CLAUDE_TOOL_FILE_PATH\"; if echo \"$FILE\" | grep -q 'contracts.py'; then echo '=== D-023 Metadata Flow Check ==='; cd \"$CLAUDE_PROJECT_DIR\" && python3 scripts/verify_metadata_flow.py 2>&1; if [ $? -ne 0 ]; then echo 'METADATA FLOW VIOLATION DETECTED — see above'; exit 1; fi; fi",
      "timeout": 30,
      "statusMessage": "Verifying metadata preservation (D-023)..."
    }
  ]
}
```

**Verification:** After integration, edit any `contracts.py` file and the hook should run automatically.

---

## Template 2: Circuit Breaker (3+ Failures Stop Autonomous Work)

**Add to:** `.claude/settings.json` → `PreToolUse` hooks

**Where in file:** In the existing `Bash(git push*)` hook section, BEFORE the test runner

```json
{
  "matcher": "Bash(git push*)",
  "hooks": [
    {
      "type": "command",
      "command": "cd \"$CLAUDE_PROJECT_DIR\" && RECENT_FAILS=$(git log --oneline -30 | grep -c 'BLOCKED:\\|Tests failing:\\|pre-commit'); if [ \"$RECENT_FAILS\" -ge 3 ]; then echo ''; echo '⚠️  CIRCUIT BREAKER TRIGGERED'; echo 'Detected 3+ recent test failures in git log.'; echo 'Stopping autonomous work to prevent infinite loops.'; echo 'Manual review required before continuing.'; echo ''; echo 'Recent failures:'; git log --oneline -10 | head -5; exit 1; fi",
      "timeout": 10
    }
  ]
}
```

**Verification:** After 3 failed pushes, the 4th will be blocked with circuit breaker message.

---

## Template 3: Cost Overspend Guard

**Add to:** `.claude/settings.json` → `PreToolUse` hooks

**Where in file:** New section or in existing `Bash(python *) | Bash(git *)` hook

```json
{
  "matcher": "Bash(python * scripts/run_pipeline.py*)|Bash(python3 * scripts/*api*)",
  "hooks": [
    {
      "type": "command",
      "command": "cd \"$CLAUDE_PROJECT_DIR\" && if [ -f 'scripts/COST_LOG.json' ]; then DAILY_COST=$(python3 -c \"import json, datetime; data=json.load(open('scripts/COST_LOG.json')); today=str(datetime.date.today()); total=sum(x.get('amount',0) for x in data.get('expenses',[]) if x.get('date','')[:10]==today); print(f'{total:.2f}')\" 2>/dev/null || echo '0'); if [ \\\"$(echo \\\"$DAILY_COST > 100\\\" | bc 2>/dev/null || echo 0)\\\" -eq 1 ]; then echo '💰 COST LIMIT EXCEEDED'; echo \\\"Daily spend: \\$$DAILY_COST (limit: \\$100)\\\"; echo 'Block API calls until reset.'; exit 1; fi; fi",
      "timeout": 5
    }
  ]
}
```

**Setup:**
- Ensure `scripts/COST_LOG.json` exists and has format:
  ```json
  {
    \"expenses\": [
      {\"date\": \"2026-03-23\", \"model\": \"opus-4.6\", \"amount\": 5.50, \"task\": \"source_engine\"},
      {\"date\": \"2026-03-23\", \"model\": \"command-r\", \"amount\": 0.80, \"task\": \"consensus\"}
    ]
  }
  ```
- Change `100` to your preferred daily cap (in dollars)

**Verification:** Create dummy expensive script, hook should trigger.

---

## Template 4: Unintended Git Changes Guard

**Add to:** `.claude/hooks/` as new file `pre-commit-artifacts.sh`

**File location:** `.claude/hooks/pre-commit-artifacts.sh`

**Contents:**
```bash
#!/bin/bash
# Prevent accidental commits of test artifacts, temp files, binary data

cd "$CLAUDE_PROJECT_DIR" 2>/dev/null || exit 0

STAGED=$(git diff --cached --name-only 2>/dev/null)
if [ -z "$STAGED" ]; then exit 0; fi

echo "=== Artifact Check ==="

# Dangerous patterns (should never be committed)
BLOCK_PATTERNS=(
    "\.pyc$"
    "__pycache__"
    "\.egg-info"
    "\.pytest_cache"
    "\.tmp$"
    "\.bak$"
    "\.swp$"
    "\.swo$"
    "results/.*\.tmp"
    "\.env$"
    "secrets\."
    "COST_LOG\.json\.bak"
    "session_state\.json\.old"
)

BLOCKED=0
for pattern in "${BLOCK_PATTERNS[@]}"; do
    MATCHES=$(echo "$STAGED" | grep -E "$pattern" || true)
    if [ -n "$MATCHES" ]; then
        echo "BLOCKED: Dangerous file pattern detected: $pattern"
        echo "$MATCHES"
        BLOCKED=1
    fi
done

# Binary files check (rough: size > 5MB or contains nulls)
for file in $STAGED; do
    if [ -f "$file" ]; then
        SIZE=$(stat -f%z "$file" 2>/dev/null || stat -c%s "$file" 2>/dev/null || echo 0)
        if [ "$SIZE" -gt 5242880 ]; then
            echo "BLOCKED: Large file detected: $file ($SIZE bytes)"
            BLOCKED=1
        fi
        if file "$file" | grep -q "binary"; then
            echo "BLOCKED: Binary file detected: $file"
            BLOCKED=1
        fi
    fi
done

if [ $BLOCKED -eq 1 ]; then
    exit 1
fi

echo "Artifact check passed."
exit 0
```

**Add to settings.json:**
```json
{
  "matcher": "Bash(git commit*)",
  "hooks": [
    {
      "type": "command",
      "command": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/pre-commit-artifacts.sh\"",
      "timeout": 10
    }
  ]
}
```

**Verification:** Try to commit a `.pyc` file or large test artifact — should be blocked.

---

## Template 5: Cross-Engine Contract Validation

**Add to:** `.claude/hooks/` as new file `cross-engine-contract.sh`

**File location:** `.claude/hooks/cross-engine-contract.sh`

**Contents:**
```bash
#!/bin/bash
# Validate cross-engine contract boundaries before push
# Windows: Requires PYTHONIOENCODING=utf-8

cd "$CLAUDE_PROJECT_DIR" 2>/dev/null || cd "$(git rev-parse --show-toplevel)" 2>/dev/null || exit 0

echo "=== Cross-Engine Contract Validation ==="

# Check if any contracts were modified
MODIFIED=$(git diff --cached --name-only | grep -E 'engines/.*/contracts\.py|shared/.*/contracts\.py' || true)

if [ -z "$MODIFIED" ]; then
    echo "No contract changes detected."
    exit 0
fi

# Windows safety: ensure UTF-8 encoding
export PYTHONIOENCODING=utf-8

# Run contract validator
python3 tools/check_cross_engine_contracts.py 2>&1
RESULT=$?

if [ $RESULT -eq 0 ]; then
    echo "Cross-engine contracts validated ✓"
    exit 0
else
    echo "BLOCKED: Cross-engine contract violation detected."
    echo "Run: PYTHONIOENCODING=utf-8 python tools/check_cross_engine_contracts.py"
    exit 1
fi
```

**Add to settings.json:**
```json
{
  "matcher": "Bash(git push*)",
  "hooks": [
    {
      "type": "command",
      "command": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/cross-engine-contract.sh\"",
      "timeout": 30,
      "statusMessage": "Validating cross-engine contracts..."
    }
  ]
}
```

**Prerequisite:** Verify `tools/check_cross_engine_contracts.py` exists or create stub:
```python
#!/usr/bin/env python3
"""Cross-engine contract validator."""
import subprocess
import sys

# Stub: Run existing pytest on cross-engine test
result = subprocess.run(
    [sys.executable, "-m", "pytest", "tests/", "-k", "cross_engine", "-v"],
    capture_output=False,
)
sys.exit(result.returncode)
```

---

## Quick Integration Checklist

### Step 1: Backup Current settings.json
```bash
cp .claude/settings.json .claude/settings.json.backup
```

### Step 2: Create New Hook Scripts
```bash
# Template 4
touch .claude/hooks/pre-commit-artifacts.sh
chmod +x .claude/hooks/pre-commit-artifacts.sh

# Template 5
touch .claude/hooks/cross-engine-contract.sh
chmod +x .claude/hooks/cross-engine-contract.sh
```

### Step 3: Update settings.json
- Add Template 1 (Metadata hook) to `PostToolUse` section
- Add Template 2 (Circuit breaker) to existing `Bash(git push*)` pre-hook
- Add Template 3 (Cost guard) to new entry in `PreToolUse`
- Add Template 4 reference to `Bash(git commit*)` pre-hook
- Add Template 5 reference to `Bash(git push*)` pre-hook

### Step 4: Verify Syntax
```bash
python3 -m json.tool .claude/settings.json > /dev/null && echo "✓ Valid JSON"
```

### Step 5: Test Each Hook
```bash
# Test 1: Edit a contracts.py file
# → Metadata flow hook should run

# Test 2: Try git push after 3 mock failures
# → Circuit breaker should block

# Test 3: Create COST_LOG.json with $150 expense
# → Cost guard should block

# Test 4: Stage a .pyc file
# → Artifact guard should block on commit

# Test 5: Push with contract changes
# → Cross-engine validator should run
```

---

## Optional: Pydantic Field Validator Enhancement

**If** `scripts/check_pydantic_fields.py` doesn't exist, create it:

**File location:** `scripts/check_pydantic_fields.py`

```python
#!/usr/bin/env python3
"""
Pre-flight Pydantic Field(None) validation.
Detects common pattern: Field(None, ...) without explicit None in constructor.
"""
import re
import sys
from pathlib import Path

def check_file(filepath: str) -> int:
    """Check for problematic Pydantic patterns."""
    issues = 0

    with open(filepath, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    for i, line in enumerate(lines, 1):
        # Pattern: Field(...) without explicit None on Optional fields
        if re.search(r'Field\s*\(\s*None\s*,', line):
            # Check if it's in an Optional type hint
            if i > 0:
                # Look backwards for type annotation
                for j in range(max(0, i - 5), i):
                    if 'Optional' in lines[j] or 'Union' in lines[j]:
                        print(f"{filepath}:{i}: Pydantic Field(None) detected.")
                        print(f"  {line.strip()}")
                        print(f"  💡 Ensure Pyright can infer the None default.")
                        issues += 1
                        break

    return issues

if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit(0)

    filepath = sys.argv[1]
    issues = check_file(filepath)
    sys.exit(0)  # Advisory only, don't block
```

---

## After Integration: Documentation

Create **`.claude/CLAUDE_CODE_SETUP.md`** with:

```markdown
# Claude Code Configuration — KR Project

## Installed Hooks (Execution Order)

### On File Write/Edit
1. Black formatter
2. Pyright type checker + Pydantic pre-flight
3. Arabic text safety check
4. **NEW:** Metadata flow validator (D-023)
5. Auto-test runner
6. Cross-engine contract validator

### On Git Commit
1. Session quality gate
2. **NEW:** Pre-commit artifact guard
3. Per-module test runner
4. Arabic text safety check (.lower()/.upper()/.strip())
5. Regex \d detection
6. SPEC quality validation

### On Git Push
1. **NEW:** Circuit breaker (3+ failures)
2. **NEW:** Cost overspend guard ($100/day cap)
3. **NEW:** Cross-engine contract validator
4. Full test suite (all engines, all shared modules)

## Guard Rails

| Guard | Trigger | Action | Override |
|-------|---------|--------|----------|
| Metadata Flow | contracts.py edit | Exit 1 if D-023 violated | N/A (non-critical) |
| Circuit Breaker | 3+ failures in log | Blocks push | Manually reset, clear log entries |
| Cost Limit | $100/day spend | Blocks API calls | Edit COST_LOG.json date or increase cap |
| Artifact Guard | Binary/temp files | Blocks commit | Unstage and re-add clean files |
| Contract Validator | contracts.py changed | Validates boundaries | Fix contract, retry push |

## Daily Workflow

1. **Start session:** git status auto-shown, NEXT.md auto-displayed
2. **Develop:** All hooks run post-save (fast feedback loop)
3. **Commit:** Artifact guard + test validation before commit lands
4. **Push:** Circuit breaker checks recent history, cost guard checks budget
5. **Overnight:** All safeguards active, stops work if 3 failures detected

## Metrics (Expected)

- Pre-commit validation time: 30-40s (was 120s before parallelization)
- Test repeat time (cache): 10-15s (was 120s)
- False positive rate: <2% (hooks are conservative)
- Overnight autonomy success: 95%+ (circuit breaker + guards)

## Troubleshooting

**Hook not running?**
- Check `.claude/settings.json` is valid JSON: `python3 -m json.tool .claude/settings.json`
- Check hook script is executable: `chmod +x .claude/hooks/*.sh`
- Check timeout isn't too short (default 30s reasonable)

**Circuit breaker blocking legitimate push?**
- Check git log: `git log --oneline | head -20 | grep -c 'BLOCKED'`
- If >3, manually review + fix root cause before re-pushing
- If false alarm, update hook to exclude specific failure patterns

**Cost guard too aggressive?**
- Increase daily cap in settings.json (Template 3, line `100` → desired cap)
- Or manually add today's date to COST_LOG.json to reset counter

**Artifact guard too sensitive?**
- Update block patterns in `.claude/hooks/pre-commit-artifacts.sh`
- Add `# safe:` comment in code if false positive is benign
```

---

## Estimated Implementation Timeline

| Task | Time | Difficulty |
|------|------|-----------|
| Backup settings.json | 1 min | Trivial |
| Create hook scripts 4 & 5 | 5 min | Easy |
| Update settings.json (Templates 1-3) | 15 min | Medium (JSON editing) |
| Test each hook | 10 min | Easy |
| Create CLAUDE_CODE_SETUP.md | 5 min | Easy |
| **Total** | **~35 minutes** | Easy-Medium |

---

**Ready to implement?** Copy template content into files above, run test checklist, commit.

Any questions on a specific template? Review the corresponding section in RESEARCH_FINDINGS.md.
