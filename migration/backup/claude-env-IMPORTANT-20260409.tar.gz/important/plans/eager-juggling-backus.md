# Post-Implementation Review: Session 3 Fix Plan

## Context

Deep adversarial review of Session 3 (Structure Discovery / Pass 4) completed. Three independent review agents analyzed SPEC compliance, edge cases, and test coverage. Cross-validated all findings against NEXT.md source text and ABD reference code. Out of ~30 findings reported, most were false positives. The implementation is fundamentally sound — fixes are cleanup and test hardening only.

## False Positives Rejected (with rationale)

| Agent Finding | Why Rejected |
|---|---|
| U+0656 missing from diacritics range | NEXT.md line 190 says "U+064B–U+0655 inclusive". `range(0x064B, 0x0656)` produces exactly that. CORRECT. |
| `or len(after_ord) < 3` in confidence | NEXT.md line 117: "follow ABD logic, lines 588–626". ABD line 598 has identical code. CORRECT per directive. |
| ROOT fallback div_id `_0_` vs heading_level=1 | NEXT.md line 171 explicitly specifies BOTH values. Explicit specification overrides the general "depth = heading_level" rule. CORRECT. |
| ROOT heading_level should be 0 | NEXT.md line 171 says `heading_level=1`. CORRECT per directive. |

## Confirmed Fixes (5 items)

### Fix 1: Remove unused import `field` from dataclasses
**File:** `structure_discovery.py` line 19
**Change:** `from dataclasses import dataclass, field` → `from dataclasses import dataclass`
**Why:** `field` is imported but never used. Dead import.

### Fix 2: Remove dead code `cand_to_node` dict
**File:** `structure_discovery.py` lines 929, 955
**Change:** Remove `cand_to_node: dict[int, DivisionNode] = {}` and `cand_to_node[i] = node`
**Why:** Dict is populated but never read. Dead code leftover from ABD's parent_id resolution.

### Fix 3: Simplify assert_tree_valid sibling check
**File:** `test_structure_discovery.py` lines 131-137
**Change:** Simplify from 3 redundant conditions to 1:
```python
# Before (conditions 1 and 3 are identical):
assert siblings[i].end_unit_index < siblings[i + 1].start_unit_index or \
    siblings[i].end_unit_index == siblings[i + 1].start_unit_index - 1 or \
    siblings[i].end_unit_index < siblings[i + 1].start_unit_index

# After (simplified — both conditions reduce to end < start):
assert siblings[i].end_unit_index < siblings[i + 1].start_unit_index
```
**Why:** Condition 2 (`end == start - 1`) is a subset of condition 1 (`end < start`). All three conditions together are logically `end < start`. The assertion was correct but poorly written.

### Fix 4: Strengthen test_sparse_structure_warning with caplog assertion
**File:** `test_structure_discovery.py` test_sparse_structure_warning
**Change:** Add assertion that NORM_SPARSE_STRUCTURE was actually logged:
```python
assert any("NORM_SPARSE_STRUCTURE" in r.message for r in caplog.records)
```
**Why:** Test captures logs but never inspects them. The test would pass even if logging was completely broken.

### Fix 5: Strengthen test_zero_heading_fallback with div_id check
**File:** `test_structure_discovery.py` test_zero_heading_fallback
**Change:** Add div_id format assertion:
```python
assert root.div_id == "div_fb_0_000"
```
**Why:** NEXT.md line 171 specifies exact div_id format for ROOT fallback.

## Verification

```bash
python -m pytest engines/normalization/tests/ -v --tb=short
# All 125 tests should still pass
```
