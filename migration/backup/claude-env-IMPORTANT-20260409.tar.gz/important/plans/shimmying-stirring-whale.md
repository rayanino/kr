# Plan: Fix L-001 — Thread chunk_id Through LLM Trace Context

## Context

**Problem:** In multi-chunk book processing, raw LLM trace files lack `chunk_id`. The runner sets `semantic_phase` on the shared `trace_context` dict before calling `run_phase2a`/`run_phase2b`, but cannot set `chunk_id` because those functions iterate over chunks internally. The Instructor `on_request` hook fires per-call but has no access to which chunk triggered it.

**Current workaround:** The analyzer infers chunk association from call sequence ordering and request content similarity — fragile if two chunks share identical text or retries reorder calls.

**Why fix now:** The 5-book campaign will process multi-chunk books. Without this fix, trace-to-chunk attribution is unreliable.

**Approach:** Thread the existing mutable `trace_context` dict into `run_phase2a` and `run_phase2b` as an optional parameter. Each function sets `trace_context["chunk_id"]` before the LLM call and resets it after. Zero new abstractions — just plumbing.

## Files to Modify

| File | Change |
|------|--------|
| `engines/excerpting/src/phase2_classify.py` | Add `trace_context` param to `run_phase2a()` |
| `engines/excerpting/src/phase2_group.py` | Add `trace_context` param to `run_phase2b()` |
| `scripts/run_integration_test.py` | Pass `trace_contexts.get("enrich")` to phase2a/2b calls |
| `scripts/excerpting_eval/models.py` | Add `chunk_id` field to `LLMTraceEntry` |
| `scripts/excerpting_eval/ingest.py` | Read `chunk_id` from request JSON; pass to `LLMTraceEntry` |
| `scripts/excerpting_eval/analysis.py` | Update limitation string (L-001 resolved) |
| `scripts/excerpting_eval/KNOWN_LIMITATIONS.md` | Mark L-001 as fixed |
| `engines/excerpting/tests/test_phase2_classify.py` | Add trace_context regression test |
| `engines/excerpting/tests/test_phase2_group.py` | Add trace_context regression test |

**Not modified (intentionally):**
- `engines/excerpting/src/pipeline.py` — calls `run_phase2a`/`run_phase2b` without trace hooks; no trace_context needed
- `engines/excerpting/src/parallel_orchestrator.py` — separate parallel path, doesn't use trace context
- Phase 3 chunk_id threading — separate concern, not part of L-001

## Step-by-Step Implementation

### Step 1: Add `trace_context` param to `run_phase2a()` in `phase2_classify.py`

Add `trace_context: Optional[dict[str, Any]] = None` after the existing `cache` parameter.

Inside the `for chunk in chunks:` loop, **before** the attempt loop:
```python
if trace_context is not None:
    trace_context["chunk_id"] = chunk.chunk_id
```

At the end of the chunk iteration (after the attempt loop, before moving to next chunk), reset:
```python
if trace_context is not None:
    trace_context["chunk_id"] = None
```

Also add `Any` to the existing `typing` import.

### Step 2: Add `trace_context` param to `run_phase2b()` in `phase2_group.py`

Same pattern as Step 1. Add `trace_context: Optional[dict[str, Any]] = None` after `cache`.

Set before attempt loop, reset after.

Also add `Any` to the existing `typing` import.

### Step 3: Pass trace context in `run_integration_test.py`

At line ~1185 (the `run_phase2a` call):
```python
classified = run_phase2a(chunks, enrich_client, config, progress=progress, cache=llm_cache, trace_context=trace_contexts.get("enrich"))
```

At line ~1275 (the `run_phase2b` call):
```python
grouped = run_phase2b(chunks, classified, enrich_client, config, progress=progress, cache=llm_cache, trace_context=trace_contexts.get("enrich"))
```

### Step 4: Add `chunk_id` to `LLMTraceEntry` in `models.py`

Add field after `error_type`:
```python
chunk_id: str | None = None
```

Add to `to_dict()`:
```python
"chunk_id": self.chunk_id,
```

### Step 5: Read `chunk_id` in `ingest.py` `load_llm_traces()`

In `load_llm_traces()`, after line ~353 where `explicit_phase` is read, also read:
```python
explicit_chunk_id = request.get("chunk_id")
```

Pass to the `LLMTraceEntry` constructor:
```python
chunk_id=explicit_chunk_id if isinstance(explicit_chunk_id, str) else None,
```

### Step 6: Update observability limitation in `analysis.py`

Update the limitation string at line ~791 from:
```
"Raw traces lack semantic phase and chunk_id: ..."
```
To:
```
"Raw traces from pre-L-001 runs lack chunk_id: the analyzer reads chunk_id "
"from request JSON when present (post-L-001) and falls back to content-based "
"inference for older run directories."
```

### Step 7: Mark L-001 as fixed in `KNOWN_LIMITATIONS.md`

Change status from `deferred` to `fixed` and add resolution note.

### Step 8: Regression tests

**In `test_phase2_classify.py`** — add test:
- Create a trace_context dict `{"semantic_phase": "classification", "chunk_id": None}`
- Call `run_phase2a([chunk1, chunk2], client, config, trace_context=trace_context)`
- After run_phase2a returns, verify `trace_context["chunk_id"]` is None (reset after loop)
- Use a side_effect on the mock client to capture what `trace_context["chunk_id"]` was during each call

**In `test_phase2_group.py`** — add test:
- Same pattern for `run_phase2b` with trace_context

These tests prove: (a) chunk_id is set correctly per-chunk during LLM calls, (b) chunk_id is reset to None after the loop.

## Verification

1. `python -m pytest engines/excerpting/tests/test_phase2_classify.py -x -v` — new + existing tests pass
2. `python -m pytest engines/excerpting/tests/test_phase2_group.py -x -v` — new + existing tests pass
3. `python -m pytest engines/excerpting/tests/ -x -q` — full suite passes (808+ tests)
4. `python -m pyright engines/excerpting/src/phase2_classify.py engines/excerpting/src/phase2_group.py` — type check
5. Verify backward compatibility: all existing callers that don't pass `trace_context` still work (the param defaults to `None`, which disables the feature)
