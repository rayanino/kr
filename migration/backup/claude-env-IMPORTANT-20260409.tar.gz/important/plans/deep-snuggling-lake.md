# KR Autonomous System — Control-Plane & Cutover Plan

## Scope

Control-plane and Codex runtime operations ONLY. Engine execution work (excerpting, taxonomy, synthesis) is handled in separate active sessions and is out of scope here.

**Claude's role in this document:** Planner and reviewer. Not implementer.

---

## Current State

| Component | Status |
|-----------|--------|
| WSL runtime installed + tools verified | ✅ DONE |
| Shadow rehearsal (queue-only) | ✅ DONE |
| val-test-regression path working | ✅ DONE |
| Protected area enforcement verified | NOT DONE |
| MORNING_REPORT.md template defined | NOT DONE |
| Post-cutover backlog defined | NOT DONE |
| First overnight run (read-only queue mode) | NOT DONE |
| Cutover gate | NOT DONE |

---

## 1. Risk Register

| # | Risk | Likelihood | Impact | Mitigation |
|---|------|-----------|--------|------------|
| R1 | Protected area write guard has gaps (Codex edits .claude/ or NEXT.md) | Medium | CRITICAL | Codex audits enforcement code before cutover |
| R2 | Auth tokens expire during overnight run | Medium | MEDIUM | Codex verifies token persistence in WSL |
| R3 | Gemini rate limits or capacity limits block 3-model review | High | LOW | Gemini is a peer primary reviewer; record any Gemini outage or capacity block explicitly and proceed transparently |
| R4 | Cutover proceeds before engine lane is ready | Medium | MEDIUM | Cutover criteria includes explicit engine-lane freeze/gate reference |
| R5 | Codex generates low-quality MORNING_REPORT | Low | LOW | Template defines mandatory sections; Claude reviews first report |
| R6 | Post-cutover backlog contains tasks exceeding Codex's authority | Medium | MEDIUM | Backlog review by Claude before cutover |

---

## 2. Remaining Work (Codex Lane Only)

| # | Task | Owner | Status |
|---|------|-------|--------|
| W1 | Verify protected area enforcement in overnight_codex scripts | Codex | TODO |
| W2 | Define MORNING_REPORT.md template (commit to docs/codex/) | Codex | TODO |
| W3 | Define post-cutover backlog (5+ bounded tasks) | Codex | TODO |
| W4 | Run first overnight session (read-only, queue-only under shadow_setup) | Codex | TODO |
| W5 | Claude reviews W1-W4 outputs | Claude (review only) | BLOCKED on W1-W4 |
| W6 | Owner verifies cutover gate | Owner | BLOCKED on W5 |

---

## 3. Collaboration Structure

### Roles in This Document

| Actor | Role | What they DO | What they NEVER do |
|-------|------|-------------|-------------------|
| Claude | Planner, reviewer | Reviews Codex outputs, plans sessions, owns engine lane elsewhere | Implement Codex runtime code |
| Codex | Runtime implementer | Audits, templates, backlog, overnight runs, quality gates | Engine feature work, scholarly domain decisions |
| Gemini | Peer primary reviewer | Reviews major Codex outputs alongside Claude whenever available | Silently skipped review role |
| Owner | Resource provider, gate authority | Reboots, starts runs, flips authority | Routine implementation |

### Review Pattern

```
Codex produces work → Claude reviews
                    → Gemini reviews
                    → Owner approves (if gate-level)

If Claude or Gemini is unavailable, the failed or blocked review attempt must be recorded explicitly.
```

### Commit Authority

| State | Claude | Codex |
|-------|--------|-------|
| active_authority: claude | Direct to master (engine work) | Branches + PRs (runtime work) |
| active_authority: codex | Branches + PRs (if needed) | Auto-apply within approved prefixes after quality gate |

---

## 4. Bounded Sessions

### Session C1: Codex Pre-Cutover Hardening (Codex, ~2h)

**Goal:** Complete W1-W4. Codex does all implementation; Claude reviews outputs.
**Executor:** Codex
**Reviewer:** Claude

**Tasks:**
1. Audit overnight_codex scripts for protected-area write guards. Verify .claude/, CLAUDE.md, NEXT.md, docs/superpowers/ are enforced. Document enforcement points.
2. Create `docs/codex/morning-report-template.md` with mandatory sections:
   - Run metadata (timestamp, duration, mode, tasks attempted)
   - Per-task results (pass / fail / skip / blocked + reason)
   - Test regression check (count before vs after)
   - Patches queued (if any, with diff summary)
   - Blockers requiring owner action
   - Suggested next backlog items
3. Draft post-cutover backlog in `overnight_codex/backlog.json`:
   - `val-contracts`: cross-engine contract check
   - `val-regression`: full test suite regression
   - `arabic-safety-sweep`: Arabic safety on all engine source
   - `hardening-unused-code`: find unused imports/functions in excerpting
   - `spec-compliance-audit`: SPEC-to-code compliance check
4. Run first overnight session (queue-only under shadow_setup)
5. Produce MORNING_REPORT.md from the run

**Stop condition:** If protected area enforcement has gaps, fix them before proceeding to the overnight run.

### Session C2: Claude Review of Pre-Cutover Outputs (Claude, ~30min)

**Goal:** Review everything Codex produced in C1.
**Executor:** Claude (review only — no implementation)

**Review:**
1. Protected area audit document — are the enforcement points real?
2. MORNING_REPORT template — is it sufficient for owner decision-making?
3. Post-cutover backlog — are all tasks within Codex's authority?
4. First overnight MORNING_REPORT.md — is it useful and accurate?
5. Recommend adjustments if needed

**Stop condition:** If CRITICAL issues found, send back to Codex for fix before cutover.

### Session C3: Cutover Gate (Owner, ~15min)

**Goal:** Verify criteria, flip authority.
**Executor:** Owner

**Criteria — all must be TRUE:**

| # | Criterion | Evidence |
|---|-----------|----------|
| G1 | WSL runtime operational + tools verified | ✅ Already done |
| G2 | Shadow rehearsal passed | ✅ Already done |
| G3 | val-test-regression working | ✅ Already done |
| G4 | Protected area enforcement verified (C1) | Codex audit document |
| G5 | MORNING_REPORT template committed (C1) | docs/codex/morning-report-template.md exists |
| G6 | Post-cutover backlog defined (C1) | overnight_codex/backlog.json exists |
| G7 | First overnight run completed without policy violations (C1) | MORNING_REPORT.md clean |
| G8 | Claude review passed (C2) | No CRITICAL findings |
| G9 | Engine lane frozen or gated | Owner confirms (separate from this plan) |

**If ALL pass:**
```
# In ACTIVE_AUTHORITY.md:
active_authority: codex
effective_date: <today>
runtime_mode: autonomous_codex
owner_interaction: resource_only
frontier_file: .kr/ACTIVE.md
rollback_authority: claude
```

**If ANY fail:** Document which criterion failed and remediation. Do not flip.

### Session C4: First Autonomous Run Review (Claude review, ~30min)

**Goal:** Verify Codex's first real autonomous run.
**Executor:** Claude (review only)

**Review:**
1. Read overnight_codex/MORNING_REPORT.md
2. Check git log for auto-applied patches — verify quality gate passed for each
3. Verify test counts stable
4. Verify zero protected-area violations
5. Check Arabic safety of any text-handling changes
6. If clean: confirm system operational, update .kr/ACTIVE.md
7. If issues: recommend policy adjustments, consider rollback

---

## 5. Cutover Criteria (Formal)

### Hard Gate (ALL required)

| # | Criterion |
|---|-----------|
| G1 | WSL runtime operational ✅ |
| G2 | Shadow rehearsal passed ✅ |
| G3 | val-test-regression working ✅ |
| G4 | Protected area enforcement verified |
| G5 | MORNING_REPORT template exists |
| G6 | Post-cutover backlog defined |
| G7 | First overnight run clean |
| G8 | Claude review of C1 outputs passed |
| G9 | Engine lane frozen or gated (owner confirms) |

### Rollback Trigger

If any of these occur post-cutover:
- Codex writes to a protected area
- Test regression introduced by auto-applied patch
- Arabic text corruption detected
- Owner determines quality is unacceptable

**Rollback:**
```
# In ACTIVE_AUTHORITY.md:
active_authority: claude
runtime_mode: shadow_setup
```
Resume from .kr/ACTIVE.md.

---

## 6. Exact Prompts

### C1 Prompt (Codex Pre-Cutover Hardening)
```
Read in this order:
1. ACTIVE_AUTHORITY.md
2. docs/codex/operating-model.md
3. docs/codex/runtime-policy.md
4. .kr/CHARTER.md

Current authority: claude. Your mode: shadow_setup.

Your job (runtime infrastructure only — do NOT touch engine code):

1. AUDIT protected area enforcement.
   Read the overnight_codex runner scripts. Find every write guard that
   prevents edits to: .claude/, CLAUDE.md, NEXT.md, docs/superpowers/.
   Document each enforcement point with file:line references.
   If gaps exist, fix them in the runner scripts.

2. CREATE docs/codex/morning-report-template.md.
   Mandatory sections: run metadata, per-task results, test regression
   counts, queued patches, blockers, suggested next backlog.

3. DEFINE post-cutover backlog in overnight_codex/backlog.json.
   Include 5 bounded tasks within your authority:
   val-contracts, val-regression, arabic-safety-sweep,
   hardening-unused-code, spec-compliance-audit.

4. RUN first overnight session (queue-only, shadow_setup mode).
   Produce MORNING_REPORT.md using your new template.

5. COMMIT all artifacts on a branch. Open a PR for Claude review.

Constraints:
- Runtime infrastructure only — zero engine code changes
- Stay within shadow_setup authority
- Quality gate before any commit: make quality-gate MODE=all
- Do not edit .claude/, CLAUDE.md, NEXT.md, docs/superpowers/
```

### C2 Prompt (Claude Review)
```
Read in this order:
1. ACTIVE_AUTHORITY.md
2. docs/codex/runtime-policy.md

Review Codex's pre-cutover PR. Check:
1. Protected area audit — are enforcement points real and complete?
2. MORNING_REPORT template — sufficient for owner decisions?
3. Post-cutover backlog — all tasks within Codex authority?
4. First overnight report — useful, accurate, no policy violations?

Use Codex CLI for any targeted follow-up investigation.
Approve, request changes, or flag CRITICAL issues.
Do not implement anything yourself.
```

### C3 Prompt (Cutover Gate — Owner checklist)
```bash
# Run each check. ALL must pass.
echo "G1-G3: WSL + shadow + val-test" && echo "Already verified ✅"
echo "G4: Protected area audit" && test -f docs/codex/morning-report-template.md && echo "✅" || echo "❌"
echo "G6: Backlog" && test -f overnight_codex/backlog.json && echo "✅" || echo "❌"
echo "G7: Overnight report" && test -f overnight_codex/MORNING_REPORT.md && echo "✅" || echo "❌"
echo "G9: Engine lane" && echo "Owner confirms: ___"

# If all pass, edit ACTIVE_AUTHORITY.md
```

### C4 Prompt (First Autonomous Run Review)
```
Read in this order:
1. ACTIVE_AUTHORITY.md (should say codex/autonomous_codex)
2. overnight_codex/MORNING_REPORT.md
3. git log --oneline -10

Review only — Codex is the active authority.
1. Assess MORNING_REPORT quality and completeness.
2. Check auto-applied patches for quality gate compliance.
3. Verify test count stable, zero protected-area violations.
4. If clean: confirm operational, update .kr/ACTIVE.md.
5. If issues: recommend policy changes or rollback.

Do not implement code changes.
```

### Codex Ongoing Overnight Template (post-cutover)
```
Read in this order:
1. ACTIVE_AUTHORITY.md
2. CLAUDE.md
3. docs/codex/operating-model.md
4. .kr/ACTIVE.md
5. .kr/HANDOFF.md

You are the active engineering authority.
Scope: hardening, regression growth, audits, bounded features.
Backlog: overnight_codex/backlog.json

For each task:
1. Run quality gate before any write: make quality-gate MODE=all
2. Skip tasks needing domain judgment — log as blocked
3. Never edit: .claude/, CLAUDE.md, NEXT.md, docs/superpowers/
4. Never auto-approve human-gated scholarly decisions

After all tasks, produce:
- overnight_codex/MORNING_REPORT.md (use docs/codex/morning-report-template.md)
- overnight_codex/state.json (updated)
- overnight_codex/progress.md (append)
```

---

## Summary

| Session | Who | Duration | Status |
|---------|-----|----------|--------|
| C1: Pre-cutover hardening | Codex | 2h + overnight | TODO |
| C2: Claude review | Claude | 30min | BLOCKED on C1 |
| C3: Cutover gate | Owner | 15min | BLOCKED on C2 + engine lane |
| C4: First-run review | Claude | 30min | BLOCKED on C3 |

3 items already done (WSL, shadow, val-test). 4 sessions remain. Total active effort: ~3.5h + 1 overnight.
