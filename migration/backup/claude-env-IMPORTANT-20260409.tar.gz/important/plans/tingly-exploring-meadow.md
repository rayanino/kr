# Adversarial Audit: Commit 1705ca5a — Division Tree Preamble Gap Fix

## Context

Commit `1705ca5a` introduced `_complete_division_tree()` in `engines/excerpting/src/phase1_assembly.py` to handle preamble content gaps — parent division nodes whose children don't cover the full `[start, end]` range. Without this fix, 2–29% of content per source was silently lost (triggering EX-V-001). The fix inserts synthetic leaf `DivisionNode`s before tree walking begins, recovering all content.

This audit is an independent adversarial review. Goal: find what the architect missed.

---

## 1. Algorithm Trace: Parent [0..29], Children [5..14] and [20..29]

**Input tree:**
```
Parent(div_id="P", start=0, end=29, children=[
    Child1(div_id="C1", start=5, end=14, children=[]),
    Child2(div_id="C2", start=20, end=29, children=[])
])
```

**Execution trace through `_complete_division_tree` (lines 212–310):**

| Step | Line | Action | Result |
|------|------|--------|--------|
| 1 | 238 | Parent has children → enter gap-filling | — |
| 2 | 244 | Recurse on `[C1, C2]` → both are leaves → returned as-is | `completed_children = [C1, C2]` |
| 3 | 247 | Sort by `start_unit_index` | `sorted = [C1(5..14), C2(20..29)]` |
| 4 | 250 | `child_level = C1.heading_level` | heading_level for synthetics |
| 5 | 255–256 | `first_child_start=5`, `0 < 5` → YES | Create preamble |
| 6 | 257–268 | Synthetic: `div_id="P_pre"`, range **[0, 4]** | `end = 5-1 = 4` |
| 7 | 271, i=0 | Append C1(5..14) | — |
| 8 | 273–277 | `gap_start = 14+1 = 15`, `gap_end = 20-1 = 19`, `15 <= 19` → YES | Create gap |
| 9 | 278–289 | Synthetic: `div_id="P_gap_0"`, range **[15, 19]** | — |
| 10 | 271, i=1 | Append C2(20..29), i < 1 → NO gap check | — |
| 11 | 292–293 | `last_child_end=29`, `29 < 29` → NO | No trailing |
| 12 | 308 | `model_copy(children=new_children)` | New parent node |

**Resulting children:** `[P_pre(0..4), C1(5..14), P_gap_0(15..19), C2(20..29)]`

**Coverage check:** `[0..4] + [5..14] + [15..19] + [20..29]` = `[0..29]`

**Verdict: NO off-by-one errors. Ranges are contiguous and complete.**

---

## 2. Wiring Consistency in run_phase1()

`completed_tree` is created once at line 1469 and used at ALL 4 subsequent points:

| Line | Usage | Correct? |
|------|-------|----------|
| 1469 | `completed_tree = _complete_division_tree(manifest.division_tree)` | Source |
| 1472 | `leaves = find_leaf_divisions(completed_tree)` | YES |
| 1544 | `validate_phase1(..., completed_tree=completed_tree)` (early return) | YES |
| 1547 | `parent_map = _build_parent_map(completed_tree)` | YES |
| 1679 | `validate_phase1(..., completed_tree=completed_tree)` (final) | YES |

**Grep for `manifest.division_tree` in run_phase1 after Step 0:** zero references. The only use is at line 1469 as input to `_complete_division_tree`.

**Verdict: CLEAN — no stale tree reference.**

---

## 3. Synthetic `_pre` vs Split `_chunk_` ID Collision

**Split naming pattern** (line 757): `{base_div_id}_chunk_{N}`
**Preamble naming pattern** (line 258): `{parent_div_id}_pre`

If a preamble synthetic gets split:
- Input: `chunk.div_id = "div_X_0_0_pre"`, `split_info = None`
- Line 730: `base_div_id = chunk.div_id = "div_X_0_0_pre"`
- Output: `chunk_id = "div_X_0_0_pre_chunk_0"`, `"div_X_0_0_pre_chunk_1"`

**Validator I-AC-5** (contracts.py:322–331): Checks `chunk_id.endswith(f"_chunk_{chunk_index}")`.
For `"div_X_0_0_pre_chunk_0"` → endswith `"_chunk_0"` → PASS.

**No regex validators on `div_id` format** in contracts.py. The `div_id` field description says `"div_{source_id}_{depth}_{index}"` but this is documentation only — no enforcing validator.

**V-P1-1 coverage** (line 1259–1273): For split preamble chunks:
- `covered_div_ids.add(chunk.div_id)` → adds `"div_X_0_0_pre"`
- `covered_div_ids.add(chunk.split_info.original_div_id)` → adds `"div_X_0_0_pre"` (same)
- `all_leaf_ids` contains `"div_X_0_0_pre"` from the completed tree
- Result: covered. No gap.

**Verdict: NO collision. Naming is safe. Validators pass.**

---

## 4. Backward Compatibility of validate_phase1 Signature

**Old signature:** `validate_phase1(chunks, manifest, skipped_divisions, config)`
**New signature:** `validate_phase1(chunks, manifest, skipped_divisions, config, completed_tree=None)`

All 4+ existing call sites (found by grep):

| Location | Call Pattern | Works? |
|----------|-------------|--------|
| `run_phase1:1544` | 5 args (keyword `completed_tree=`) | YES — updated |
| `run_phase1:1677` | 5 args (keyword `completed_tree=`) | YES — updated |
| `test_phase1_validation.py:32` | 4 positional args | YES — defaults to None |
| `test_phase1_validation.py:40` | 4 positional args | YES — defaults to None |
| `test_phase1_validation.py:66,85,107` | 4 positional args | YES — defaults to None |

When `completed_tree=None`, line 1259 recomputes: `_complete_division_tree(manifest.division_tree)`. Functionally identical.

**Verdict: FULLY backward compatible. No breakage possible.**

---

## 5. Test Results

```
588 passed in 57.67s
```

Zero failures, zero errors, zero skipped (beyond the 2 pre-existing skips that don't appear in -q output).

---

## 6. Five-Package Integration Verification

```
ext_39_masala        PASS  16 chunks  18521 words
ext_46_qa            PASS  38 chunks  23648 words
ibn_aqil_v1          PASS  14 chunks  33282 words
ibn_aqil_v3          PASS  28 chunks  24802 words
taysir               PASS 184 chunks 189423 words
```

All 5 packages produce chunks and pass validation. No exceptions.

---

## FINDINGS: What the Architect Missed

### FINDING F-1: EX-A-006 Warning Flood on Synthetic Preambles [MEDIUM]

**The problem:** Every synthetic preamble chunk triggers a spurious EX-A-006 warning. The hardcoded `heading_text="مقدمة"` (line 260) never appears in the assembled text because preamble content is introductory prose, not a heading. `check_heading_alignment` (line 1203) compares the first 30 stripped chars of heading against the first 200 chars of text — always fails for synthetics.

**Measured impact:** The integration run above shows **~30+ EX-A-006 warnings with heading "مقدمة"** across the 5 packages. These are structurally guaranteed false positives.

**Downstream consequences:**
- `heading_alignment_ok = False` on all preamble chunks (line 1531)
- The field is currently **not consumed** by Phase 2, Phase 3, gates, or writer — confirmed by grep
- SPEC says "quality flag, not a gate"
- BUT: warning noise drowns genuine misalignment warnings that DO indicate quality problems

**Recommended fix:** Skip heading alignment check for synthetic preamble nodes (detectable by `div_id.endswith("_pre")` or `division_type == DivisionType.MUQADDIMAH`), or suppress the EX-A-006 log emission for them.

**Files:** `phase1_assembly.py:1505` (caller), `phase1_assembly.py:1203` (check function)

---

### FINDING F-2: div_path Heading Duplication for Gap/Post Synthetics [LOW — LATENT]

**The problem:** Gap synthetics (line 281) and post synthetics (line 297) set `heading_text = node.heading_text` — the parent's own heading. When `find_leaf_divisions._walk` (line 200) builds the path by appending `node.heading_text` at each level, this produces:

```
path = [..., "باب الطهارة", "باب الطهارة"]  # parent heading duplicated
```

Preamble synthetics avoid this because they use `heading_text="مقدمة"` (distinct from parent).

**Current impact:** Zero. Empirically, no inter-child or trailing gaps exist across all 5 test packages (line 229 comment).

**Future risk:** If real packages produce gap/post synthetics, the duplicated `div_path` would look wrong in UI breadcrumbs and could confuse downstream Phase 3 logic that uses `div_path` for display.

**Recommended fix when needed:** Use distinct heading text for gap/post synthetics (e.g., `"فاصل"` for gap, `"تتمة"` for trailing) rather than inheriting parent heading.

---

### FINDING F-3: No Test for Preamble + Oversized Split [MEDIUM — MISSING COVERAGE]

**The gap:** No test covers the scenario where a synthetic preamble node's assembled text exceeds `OVERSIZED_DIVISION_WORDS`, triggering `split_oversized_division`. This would produce chunk_ids like `div_X_pre_chunk_0`.

**Why it matters:** This is a realistic scenario — Arabic scholarly texts often have long chapter introductions spanning many pages before sub-sections begin. The interaction between `_pre` suffix and `_chunk_N` suffix in V-P1-1 validation (matching `chunk.div_id` and `split_info.original_div_id` against leaf IDs) is untested.

**Code correctness:** Verified correct by code reading (split function is div_id-agnostic), but code review is not a substitute for a test.

**Recommended test:** Construct a synthetic preamble with word count > threshold, run through `split_oversized_division`, verify chunk_ids, split_info, and V-P1-1 passes.

---

### FINDING F-4: No Idempotency Test [LOW]

**The gap:** `_complete_division_tree()` called on an already-completed tree should return a structurally identical tree. Correct by analysis (all gap conditions evaluate to False when gaps are filled), but untested.

**Risk:** Minimal — `_complete_division_tree` is called exactly once in `run_phase1` (line 1469), never on its own output.

**Recommended test:** Trivial — call function twice, assert structural equality.

---

### FINDING F-5 (Informational): heading_alignment_ok Downstream Independence

Not a bug, but worth documenting: `heading_alignment_ok` is set on `AssembledChunk` but is **not present** on `ExcerptRecord`. It does not flow to Phase 2, Phase 3, human gates, or the output writer. This means F-1's `heading_alignment_ok=False` has zero functional impact today, but the field exists as potential future tech debt if anyone assumes it's meaningful for preamble chunks.

---

## Summary

| ID | Finding | Severity | Type |
|----|---------|----------|------|
| F-1 | EX-A-006 warning flood on synthetic preambles | **MEDIUM** | Warning noise / false positive |
| F-2 | div_path duplication for gap/post synthetics | LOW | Latent display bug |
| F-3 | Missing test: preamble + oversized split | **MEDIUM** | Test coverage gap |
| F-4 | Missing test: idempotency | LOW | Test coverage gap |
| F-5 | heading_alignment_ok not consumed downstream | INFO | Documentation note |

**The algorithm is correct.** No off-by-one errors. No ID collisions. Backward compatibility is solid. Wiring is clean. All tests pass. All 5 packages produce valid output.

**What was missed:** Warning noise from synthetic headings (F-1, ~30+ spurious warnings per run), a realistic untested code path (F-3), and a latent display issue in gap/post heading paths (F-2).

---

## Implementation Plan (if fixing)

### Fix F-1 (EX-A-006 suppression)
- **File:** `phase1_assembly.py:1505`
- **Change:** Before calling `check_heading_alignment`, detect synthetic preamble (`node.div_id.endswith("_pre")`) and skip the check (set `heading_ok = True`)
- **Alt:** Add parameter to `check_heading_alignment` to suppress warning for synthetic headings
- **Test:** Assert zero EX-A-006 warnings emitted for preamble chunks in integration test

### Fix F-3 (add preamble + split test)
- **File:** `tests/test_phase1_preamble.py`
- **Test:** Create preamble synthetic with >OVERSIZED_DIVISION_WORDS assembled text, verify split produces valid chunks with correct chunk_ids, split_info, and passes V-P1-1/V-P1-2

### Fix F-4 (add idempotency test)
- **File:** `tests/test_phase1_preamble.py`
- **Test:** Call `_complete_division_tree` on output of itself, assert identical children structure

### Fix F-2 (deferred — no real-world instances)
- **When:** First time a real package produces inter-child or trailing gaps
- **Change:** Use distinct heading_text for gap/post synthetics instead of parent heading

## Verification
```bash
python -m pytest engines/excerpting/tests/ -v --tb=short   # All tests pass
python -m pytest engines/excerpting/tests/test_phase1_preamble.py -v  # Preamble-specific
# Integration: run 5-package script, verify zero new EX-A-006 for preamble chunks
```
