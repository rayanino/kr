# Fix F-DET-9: Identity Matching for Primary Layer Exclusion

## Context

Bug F-DET-9 in `compute_quoted_scholars()` excludes ALL layers of the same type as the primary layer, instead of excluding only the specific primary author. In a multi-sharh text (e.g., two different scholars both writing sharh), the current code skips ALL sharh layers when the primary is sharh — losing secondary sharh authors from `quoted_scholars`. The fix narrows the exclusion to match on both `layer_type` AND `author_canonical_id`.

This is an **architect-defined fix** with exact code provided — no brainstorming or design exploration needed.

## Changes

### 1. Fix source (`engines/excerpting/src/phase3_deterministic.py`, line 481)

**Before:**
```python
if layer.layer_type.value == primary_layer.layer_id:
    continue
```

**After:**
```python
if (layer.layer_type.value == primary_layer.layer_id
        and (layer.author_canonical_id or "unknown") == primary_layer.author_id):
    continue
```

### 2. Add test (`engines/excerpting/tests/test_phase3_deterministic.py`, inside `TestQuotedScholars` at line 630)

Add `test_multi_author_same_type_secondary_kept` — creates two SHARH layers with different authors, verifies only the primary author is excluded while the secondary sharh author appears in results as `quoted_opinion`.

No new imports needed — all types already imported.

### 3. Verification

```bash
python -m pyright engines/excerpting/src/phase3_deterministic.py
python -m pytest engines/excerpting/tests/test_phase3_deterministic.py -v --tb=short
```

Existing test `test_primary_layer_excluded` still passes because its `_make_multi_layer_chunk` helper's SHARH layer has `author_canonical_id="sch_ibn_aqeel"` matching `primary.author_id="sch_ibn_aqeel"` — both conditions satisfied.

### 4. Commit

```
fix: F-DET-9 identity matching — exclude primary (type+author), not entire type
```
