# Sprint Manifest — Wave 1 + Wave 2 (20 tasks)

Producing the JSON array of 20 task objects based on verified codebase structure:

## Verified paths:
- Taxonomy SPEC: engines/taxonomy/SPEC.md (945 lines)
- Synthesis SPEC: engines/synthesis/SPEC.md (930 lines)
- All 5 contracts.py files exist: source, normalization, excerpting, taxonomy, synthesis
- shared/validation/src/validation.py has: validate_schema, validate_referential_integrity, validate_enrichment_passthrough
- shared/consensus/src/consensus.py exists
- shared/scholar_authority/src/name_matching.py + scholar_authority.py exist
- shared/human_gate/src/human_gate.py exists
- shared/validation/tests/ has only __init__.py (no test files yet)
- Existing test files in shared: consensus/tests/test_consensus.py, human_gate/tests/test_human_gate.py, scholar_authority/tests/test_name_matching.py + test_scholar_authority.py
- Test fixtures: tests/fixtures/shamela_real/ (10 dirs), tests/fixtures/shamela_extended/ (20 dirs)
- engines/normalization/KNOWN_LIMITATIONS.md exists with L-003 and L-005 documented

## Output: see JSON below in conversation
