# Pre-Overnight-Run Timeout Fix

## Context

The overnight run will process 308 chunks across 5 books via LLM. The current 120s per-call timeout and 3600s per-package timeout are too tight for large packages — a single complex chunk can take 2+ minutes with retry cascades. This fix raises defaults and adds CLI passthrough for runtime control.

**Baseline:** 800 tests (766 excerpting + 34 adapter), 2 skipped, 0 failures.

## Changes (5 items)

### 1. CLI adapter default timeout: 120 → 300
**File:** `shared/llm/cli_adapter.py:262`
```python
# Before:
timeout_seconds: int = kwargs.get("timeout", 120)
# After:
timeout_seconds: int = kwargs.get("timeout", 300)
```

### 2. Contracts default timeout: 120 → 300
**File:** `engines/excerpting/contracts.py:754`
```python
# Before:
TIMEOUT_SECONDS: int = 120
# After:
TIMEOUT_SECONDS: int = 300
```

### 3. Per-package subprocess timeout: 3600 → 7200
**File:** `scripts/run_full_integration.py:185` and error message at `:210`
```python
# Before:
proc = subprocess.run(cmd, timeout=3600)
# ...
"errors": ["Timeout after 3600s"],
# After: uses per_package_timeout parameter (see item 4)
```

### 4. Add --max-chunks and --per-package-timeout to run_full_integration.py
**File:** `scripts/run_full_integration.py`

**argparse (after line 311):** Add two arguments:
- `--max-chunks` (type=int, default=None) — passed through to per-package cmd
- `--per-package-timeout` (type=int, default=7200) — used in subprocess.run

**run_batch signature (line 146):** Extend to:
```python
def run_batch(output_dir: Path, backend: str = "api",
              max_chunks: int | None = None,
              per_package_timeout: int = 7200) -> dict[str, Any]:
```

**cmd construction (lines 174-181):** Conditionally append `--max-chunks`:
```python
if max_chunks is not None:
    cmd.extend(["--max-chunks", str(max_chunks)])
```

**subprocess.run (line 185):** Use parameter:
```python
proc = subprocess.run(cmd, timeout=per_package_timeout)
```

**Error message (line 210):** Use f-string with parameter:
```python
"errors": [f"Timeout after {per_package_timeout}s"],
```

**main() call (line 336):** Thread args through:
```python
summary = run_batch(args.output_dir, backend=args.backend,
                    max_chunks=args.max_chunks,
                    per_package_timeout=args.per_package_timeout)
```

### 5. Tests

**No existing tests need updating:**
- `test_cli_adapter.py:404` — `timeout=120` is a mock `TimeoutExpired` constructor value, not an assertion about the default
- `test_ri_trace_bridge.py:285` — same pattern, mock value only
- No tests assert `TIMEOUT_SECONDS == 120`

**Add one test** in `shared/llm/tests/test_cli_adapter.py`:
- Verify that `kwargs["timeout"]` is forwarded to `subprocess.run(timeout=...)` — mock subprocess.run, call with `timeout=999`, assert `subprocess.run` was called with `timeout=999`

## Scope Guard (DO NOT)

- No resume/checkpoint capability
- No retry count changes (max_retries, RETRY_COUNT)
- No chunk-size-adaptive timeout
- No phase logic modifications (phase2_classify, phase2_group, phase3_enrichment, phase3_consensus)
- Nothing beyond the 5 items above

## Verification

```bash
python -m pytest shared/llm/tests/ engines/excerpting/tests/ -q
# Expected: 801 passed (800 + 1 new), 2 skipped, 0 failed
```

## Post-Verification

Commit: `fix: increase timeouts and add --max-chunks passthrough for overnight run`
Push to remote.
