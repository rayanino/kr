# Post-Evaluation Fixes — IMPLEMENTED, REVIEWED, VERIFIED

## Status: ALL 4 FIXES COMPLETE. Committed (a8b17ff) and pushed. Full verification below.

## Final Test Suite Results

| Suite | Tests | Passed | Failed | Time |
|-------|-------|--------|--------|------|
| Source engine (`engines/source/tests/`) | 511 | 511 | 0 | 4.38s |
| Shared components (`shared/*/tests/`) | 71 | 71 | 0 | 1.43s |
| **Total** | **582** | **582** | **0** | **5.81s** |

## Quality Gate Scripts (pre-existing state, not impacted by fixes)

- **SPEC quality (check_spec_quality.py):** 37 defects (34 high) — all pre-existing vague language (unbounded "etc.", vague quantifiers). No new defects from fixes.
- **Compliance (check_compliance.py):** Source engine: 61 SPEC rules, 5762 lines, 42 test functions, 28 NYI items. All pre-existing.
- **Metadata flow (verify_metadata_flow.py):** 6 boundary warnings — expected, engines 2-7 not yet built. Static analysis false positives.

## Critical Review Results (3 parallel review agents)

### Fix 1: Genre Enum — VERIFIED CORRECT
- 20 enum values in contracts.py (was 18), prompt, synonyms JSON, SPEC all in sync
- Character-by-character cross-validation: all 20 values match across contracts.py ↔ inference_v1.py ↔ SPEC_CORE.md
- `test_all_genre_synonyms_from_config_are_valid` dynamically validates all 28 synonym entries
- Logging uses lazy `%s` formatting (not f-strings) — correct for performance
- No hardcoded genre lists in normalization engine

### Fix 2: Hashiyah Validation — VERIFIED CORRECT
- Check 5e correctly splits: hashiyah→gate, sharh→warning
- Edge case verified: hashiyah + is_multi_layer=True + text_layers=[] skips 5e but is caught by Check 6a (gate) — SAFE
- Gate handler elif in correct position with correct parameters

### Fix 3: Death Date Warning — VERIFIED CORRECT (highest risk)
- XOR logic `(death_a is None) != (death_b is None)` verified for all 4 cases:
  - (None, 911) → True ✓ (single model)
  - (911, 911) → False ✓ (both agree)
  - (None, None) → False ✓ (no date)
  - (911, 913) → False ✓ (both provided, disagreement handled elsewhere)
- needs_review_fields merge is additive only (never removes) — no regression risk
- data_for_validation injection placed correctly (after model_dump, before validate call)
- getattr defaults are safe: "absent" for death_date_source, False for death_date_single_model

### Fix 4: Documentation — VERIFIED CORRECT
- Compiler-as-muhaqiq pattern documented in SPEC_CORE.md and OPEN_PROBLEMS.md
- ERR-03 pattern documented with 3 confirmed cases and mitigation strategy

### Protected Modules — UNTOUCHED
- shared/consensus/src/consensus.py: NOT modified ✓
- _select_canonical(): NOT modified ✓

### Minor Observation (not a bug)
- No explicit test for `death_date_single_model=True, death_date_source="absent"` — implicitly safe because code requires `death_date_source == "inference"` to trigger warning. The absent case can never satisfy that condition.

---

## Fix 1: Missing Genre Values (smallest, broadest impact)

**Root cause:** Genre enum has 18 values but LLMs correctly produce `rihlah` and `usul_al_fiqh`. `validate_enum_value()` silently discards them → falls back to `"other"`.

### 1a. `engines/source/contracts.py` (lines 115–137)
Add two enum members before `OTHER`:
```python
RIHLAH = "rihlah"
USUL_AL_FIQH = "usul_al_fiqh"
```
Total becomes 20 values.

### 1b. `engines/source/prompts/inference_v1.py` (line 53)
Add `rihlah, usul_al_fiqh` to the genre enum string in `USER_MESSAGE_TEMPLATE`. Keep alphabetical style.

### 1c. `library/config/genre_synonyms.json`
Add 3 entries:
```json
"رحلة": "rihlah",
"أصول الفقه": "usul_al_fiqh",
"أصول فقه": "usul_al_fiqh"
```

### 1d. `engines/source/SPEC_CORE.md` (~line 1139)
Search for `"genre` must be one of the `Genre` enum values in contracts.py (18 values:"`. Update count 18→20, add `rihlah` and `usul_al_fiqh` to the parenthetical list. Add note: "The LLM prompt and `library/config/genre_synonyms.json` must include all Genre enum values and their Arabic synonyms."

### 1e. `engines/source/tests/test_metadata_inference.py` — TestValidateEnumValue class (after line 323)
Add 4 tests following existing patterns:
- `test_valid_genre_rihlah_passes_direct` — `validate_enum_value("rihlah", Genre, {}, "other")` → `("rihlah", False)`
- `test_valid_genre_usul_al_fiqh_passes_direct` — `validate_enum_value("usul_al_fiqh", Genre, {}, "other")` → `("usul_al_fiqh", False)`
- `test_arabic_synonym_رحلة_maps_to_rihlah` — synonym `"رحلة": "rihlah"` → `("rihlah", True)`
- `test_arabic_synonym_أصول_الفقه_maps_to_usul_al_fiqh` — synonym `"أصول الفقه": "usul_al_fiqh"` → `("usul_al_fiqh", True)`

### 1f. Additional item A: Logging in `validate_enum_value` (metadata_inference.py, line 251)
Before `return default, True`, add:
```python
logger.warning("Enum fallback: value '%s' not in %s and no synonym match — using default '%s'", value, enum_class.__name__, default)
```
Module-level `logger` already exists at line 49.

### 1g. Additional item B: Check normalization engine
Run `grep` for hardcoded genre checks in `engines/normalization/src/`. Add new genres if found.

---

## Fix 2: ERR-01 — Hashiyah Validation Escalation (small, self-contained)

**Root cause:** Check 5e treats hashiyah+ML=False+no_layers the same as sharh — both get severity="warning". But hashiyah structurally requires 3 layers (matn→sharh→hashiyah), so this is always contradictory and should be a gate.

### 2a. `engines/source/src/validation.py` (lines 247–259)
Split the `else` branch of check 5e into two paths:
- **hashiyah + no layers → severity="gate"**, check name `"consistency_hashiyah_no_layers"`, message explaining the structural contradiction
- **sharh + no layers → severity="warning"** (preserved existing behavior, keep check name `"consistency_genre_multi_layer_no_layers"`)

Add comment explaining asymmetry: hashiyah requires 3 layers; sharh could be near the sharh/risalah boundary.

### 2b. `engines/source/src/engine.py` (lines 602–608)
Add `elif` branch in gate error handler after `multi_layer_empty_layers`:
```python
elif gate_error.check == "consistency_hashiyah_no_layers":
    gate_low_confidence(
        source_id,
        "genre",
        data_for_validation.get("genre", "hashiyah"),
        0.0,
    )
```

### 2c. `engines/source/SPEC_CORE.md`
Near consistency check documentation, add: "hashiyah + is_multi_layer=False with no layers triggers human gate (not just warning) because hashiyah structurally requires 3 layers."

### 2d. `engines/source/tests/test_validation.py` — TestAutoCorrectChain class (after line 287)
- `test_hashiyah_empty_layers_gates` — genre="hashiyah", is_multi_layer=False, text_layers=[] → severity="gate", check="consistency_hashiyah_no_layers"
- Verify existing `test_sharh_empty_layers_no_auto_correct` still passes (sharh → warning preserved)

---

## Fix 3: ERR-03 — Death Date Hallucination Warning (riskiest, touches 4 code files)

**Root cause:** Opus hallucinates death dates for modern scholars (2-6 years off). Pattern: extraction has no death date, Opus infers one, CA correctly abstains (None). Pipeline accepts Opus's value with no warning.

### 3a. `engines/source/src/metadata_inference.py` — MetadataInferenceResult (line 105)
Add field after `death_date_source`:
```python
death_date_single_model: bool = False     # True when only one model provided a death date
```

### 3b. `engines/source/src/metadata_inference.py` — After step 10b (line 584)
Add step 10c:
```python
# 10c. Flag single-model death dates (ERR-03 pattern)
if len(successful) >= 2:
    death_a = successful[0].parsed.author_identification.death_date_hijri
    death_b = successful[1].parsed.author_identification.death_date_hijri
    if (death_a is None) != (death_b is None):
        result.death_date_single_model = True
else:
    result.death_date_single_model = True
```
`successful` is in scope from line 492.

### 3c. `engines/source/src/metadata_inference.py` — Step 13 (before line 606)
After the genre/format/authority/level fallback blocks, before `result.needs_review_fields = sorted(needs_review)`:
```python
# Flag single-model inferred death dates for owner review (ERR-03)
if result.death_date_single_model and result.death_date_source == "inference":
    if "death_date_hijri" not in needs_review:
        needs_review.append("death_date_hijri")
```

### 3d. `engines/source/src/engine.py` — CRITICAL: Fix needs_review_fields merge gap (after line 394)
After `needs_review_fields = _build_needs_review(confidence_scores)`, add:
```python
# Merge inference-specific review flags (genre fallback, death date, etc.)
if inference.needs_review_fields:
    for f in inference.needs_review_fields:
        if f not in needs_review_fields:
            needs_review_fields.append(f)
    needs_review_fields = sorted(needs_review_fields)
```
This is a **pre-existing bug fix** — inference.needs_review_fields was being built but silently discarded.

### 3e. `engines/source/src/engine.py` — Inject fields into data_for_validation (after line 568)
After `data_for_validation = metadata.model_dump(mode="json")`, before `validation_errors = validate_source_metadata(...)`:
```python
# Inject inference-only fields for validation (not in SourceMetadata schema)
data_for_validation["death_date_source"] = getattr(inference, "death_date_source", "absent")
data_for_validation["death_date_single_model"] = getattr(inference, "death_date_single_model", False)
```

### 3f. `engines/source/src/validation.py` — Add check 5g (before line 286 `return errors`)
```python
# 5g: Single-model death date warning
death_date_single = data.get("death_date_single_model", False)
death_date_source = data.get("death_date_source", "absent")
if death_date_single and death_date_source == "inference":
    errors.append(ValidationError(
        check="single_model_death_date",
        severity="warning",
        field="author.death_date_hijri",
        message="Death date from single-model inference only...",
        error_code="SRC_DEATH_DATE_UNVERIFIED",
        recovery="flag_needs_review",
    ))
```
Note: redundant with 3c needs_review addition — serves as documentation/logging.

### 3g. `engines/source/SPEC_CORE.md`
After "Single-LLM biographical inference cap" section, add ERR-03 documentation (death date hallucination pattern, 3 confirmed cases, mitigation).

### 3h. Tests
**test_validation.py** — 3 tests for check 5g:
- `death_date_single_model=True, death_date_source="inference"` → warning SRC_DEATH_DATE_UNVERIFIED
- `death_date_single_model=True, death_date_source="author_raw_text"` → no warning
- `death_date_single_model=False, death_date_source="inference"` → no warning

**test_engine.py or test_metadata_inference.py** — 1 merge test:
- Create inference with `needs_review_fields=["death_date_hijri"]`, verify it appears in final SourceMetadata.needs_review_fields

---

## Fix 4: ERR-02 — Compiler-as-Muhaqiq Documentation (no code)

### 4a. `engines/source/SPEC_CORE.md` — Known limitations
Add compiler-as-muhaqiq pattern documentation (السراج المنير example, muhaqiq=compiler pattern).

### 4b. `engines/source/SPEC_CORE.md` — Prompt engineering section
Add note about future inference prompt update to detect compiler pattern.

### 4c. `OPEN_PROBLEMS.md`
Add compiler detection as an open problem for future work.

---

## Execution Order

1. **Fix 1** — Genre enum (smallest, broadest impact)
2. **Fix 2** — Hashiyah validation (small, self-contained)
3. **Fix 3** — Death date warning (riskiest — needs_review merge)
4. **Fix 4** — Documentation only

---

## Verification

After all 4 fixes:
```bash
python -m pytest engines/source/tests/ -v --tb=short
```
- All ~370+ existing tests must pass (some parametrized)
- All new tests must pass (est. 10-12 new test methods)
- Specific attention to: `test_all_genre_synonyms_from_config_are_valid` (validates Fix 1 synonyms)
- Manual review of Fix 3's needs_review merge — check no existing test breaks

After tests pass:
- Update `NEXT.md` to reflect fixes complete
- Do NOT re-run pipeline books — fixes affect future runs only

---

## Key Files (complete list)

| File | Fixes |
|------|-------|
| `engines/source/contracts.py` | Fix 1 |
| `engines/source/prompts/inference_v1.py` | Fix 1 |
| `library/config/genre_synonyms.json` | Fix 1 |
| `engines/source/src/metadata_inference.py` | Fix 1 (logging), Fix 3 (field + logic) |
| `engines/source/src/validation.py` | Fix 2, Fix 3 |
| `engines/source/src/engine.py` | Fix 2, Fix 3 (merge gap + injection) |
| `engines/source/SPEC_CORE.md` | Fix 1, 2, 3, 4 |
| `OPEN_PROBLEMS.md` | Fix 4 |
| `engines/source/tests/test_metadata_inference.py` | Fix 1 |
| `engines/source/tests/test_validation.py` | Fix 2, Fix 3 |
| `engines/source/tests/test_engine.py` | Fix 3 (merge test) |
| `NEXT.md` | Post-fix update |
