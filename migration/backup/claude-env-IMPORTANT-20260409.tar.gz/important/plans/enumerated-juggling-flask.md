# Plan: Sweep Bug Fix Sprint (Weekend Task 2)

## Context

Corpus sweeps completed on 7,475 books. Normalization engine found **2 bugs**: 1 crash (diacritics canary) affecting 1 book, and a metadata misclassification causing 48 books to produce zero content despite having real Arabic text. Source engine had 0 errors — no fixes needed.

This session follows NEXT.md rules: fix crashes, write tests, commit each fix separately, create summary reports. Budget: 0 EUR (no LLM calls). No SPEC or contract modifications.

---

## Bug Inventory

### Bug 1: Zero-Content Books (48 books) — FIX NOW

**Root cause:** `_pass1_parse()` in `shamela.py:643-655` classifies pages as metadata when `page_int is None AND not seen_numbered_page`. These 48 books have NO `(ص: N)` page number markers in any PageText div, so `seen_numbered_page` never becomes True and ALL pages (including pages with dense Arabic hadith text) are classified as metadata. Pass 2 skips metadata pages → zero content output.

**Evidence:** The fixture `zero_content_hadith_dhunnun.htm` has 6 pages with rich Arabic text. Line 60 shows a full hadith isnad chain with heavy diacritization. The pipeline marks all 6 pages as `is_metadata_page=True` and produces 0 content units.

**Fix:** Pre-scan approach. Before the main loop in `_pass1_parse()`, check if ANY block has a page number: `any_numbered = any(PAGE_NUM_RE.search(b) for b in blocks)`. Then modify the metadata detection condition (line 643) to only classify pages as metadata if EITHER `any_numbered` is True (normal case — keep classifying until first numbered page) OR this is the very first page (`not pages`). For pageless books, only the first page becomes metadata; subsequent pages fall through to content processing and get proper bold_spans, title_spans, etc. extracted.

- **Files changed:** `engines/normalization/src/normalizers/shamela.py` (~8 lines added/modified)
- **Test:** New test in `engines/normalization/tests/test_shamela_passes.py` using `zero_content_hadith_dhunnun.htm` fixture
- **Risk:** Only affects books with zero page numbers. Books WITH page numbers are unaffected (`any_numbered` is True, so metadata detection works identically to current code). Full test suite validates no regressions.

### Bug 2: Diacritics Canary Crash (1 book) — FIX NOW

**Root cause:** `_ARABIC_DIACRITICS` in `shamela.py:158-162` defines 20 codepoints:
```python
set(range(0x064B, 0x0654)) | {0x0670} | set(range(0x0656, 0x0660))
```

The SPEC (§5, line 1501) defines only 10: `U+064B–U+0652, U+0670, U+0640`. The broader range includes U+0653 (maddah above) and U+0656-U+065F (extended diacritics) which regex and BS4 handle differently, causing a false positive canary failure. The set also OMITS U+0640 (tatweel) which the SPEC includes.

`validation.py:50` already has the correct SPEC-aligned set (`DIACRITICS_CHECK8`). Comment at line 49 explicitly warns: "Do NOT reuse _ARABIC_DIACRITICS from shamela.py (20 codepoints)."

`_ARABIC_DIACRITICS` is used ONLY in the canary check (lines 1460, 1463) — no other consumers.

**Fix:** Align `_ARABIC_DIACRITICS` with SPEC: `set(range(0x064B, 0x0653)) | {0x0670, 0x0640}` (10 codepoints).

- **Files changed:** `engines/normalization/src/normalizers/shamela.py` (~3 lines changed)
- **Test:** New test in `engines/normalization/tests/test_shamela_passes.py` using `crash_diacritics_entity_mismatch.htm` fixture
- **Risk:** Canary now checks fewer diacritics (standard SPEC set only). Extended diacritics (U+0653, U+0656-U+065F) are no longer validated by the canary. This is SPEC-compliant — document in SWEEP_ARCHITECT_REVIEW.md for future SPEC consideration.

### Non-Bugs (No Action)

- **15,400 warnings** (char_run, low_arabic_ratio, division_overlap, other) — all known patterns from evaluation
- **222 source engine quality flags** — not errors, just observations
- **Division overlap (15.3%)** — known limitation L-010
- **Source engine: 0 errors** — nothing to fix

---

## Execution Steps

### Step 1: Baseline Test Counts
```bash
python -m pytest engines/normalization/tests/ --co -q 2>/dev/null | tail -1
python -m pytest engines/source/tests/ --co -q 2>/dev/null | tail -1
```

### Step 2: Write SWEEP_BUG_TRIAGE.md
Create `results/SWEEP_BUG_TRIAGE.md` with the triage table per NEXT.md format.

### Step 3: Fix Bug 1 — Zero-Content Books (48 books affected)

**3.1** Write failing test FIRST:
- New test `test_pass1_books_without_page_numbers` in `test_shamela_passes.py`
- Load `tests/fixtures/shamela_edge_cases/zero_content_hadith_dhunnun.htm`
- Run through `_pass1_parse()` or full pipeline
- Assert: content_units > 0 and primary_text is non-empty for at least some units
- **Expect FAIL** before fix (currently produces 0 content units)

**3.2** Implement fix in `shamela.py` `_pass1_parse()`:

Add pre-scan before the main for loop (after line 628):
```python
# Pre-scan: check if ANY block has a page number.
# Pageless books should not have all pages classified as metadata.
any_numbered_page = any(PAGE_NUM_RE.search(b) for b in blocks)
```

Modify the metadata detection condition (line 643-655):
```python
if page_int is None and not seen_numbered_page:
    # Pages before first numbered page are normally metadata.
    # For pageless books (no page numbers anywhere), only the first
    # page is metadata (book info). Subsequent pages are content.
    if any_numbered_page or not pages:
        pages.append(RawPage(
            unit_index=-1,
            volume=volume,
            page_number_display=None,
            page_number_int=None,
            raw_html=block,
            is_metadata_page=True,
            warnings=warnings,
        ))
        continue
    # Pageless book, not first page: fall through to content processing
```

This way pages in pageless books get proper content extraction (bold_spans, font_size_spans, title_spans, pagehead_text, unit_index) during the loop, instead of being reclassified after the fact.

**3.3** Run pytest + pyright:
```bash
python -m pytest engines/normalization/tests/ -x -q
python -m pyright engines/normalization/src/normalizers/shamela.py
```

**3.4** Commit:
```
fix: [normalization] reclassify pages as content in books without page numbers (48 books affected)
```

### Step 4: Fix Bug 2 — Diacritics Canary Crash (1 book affected)

**4.1** Write failing test FIRST:
- New test `test_diacritics_canary_spec_aligned` in `test_shamela_passes.py`
- Load `tests/fixtures/shamela_edge_cases/crash_diacritics_entity_mismatch.htm`
- Run through full pipeline (or `_verify_diacritics_canary` directly)
- Assert: no crash (NormalizationError not raised)
- **Expect FAIL** before fix (currently raises NORM_DIACRITICS_ENTITY_CORRUPTION)

**4.2** Fix `_ARABIC_DIACRITICS` in `shamela.py:158-162`:
```python
# Arabic diacritics Unicode codepoints for verification.
# SPEC §5 line 1501: exactly U+064B–U+0652, U+0670, U+0640.
_ARABIC_DIACRITICS: set[int] = set(range(0x064B, 0x0653)) | {0x0670, 0x0640}
```

**4.3** Run pytest + pyright:
```bash
python -m pytest engines/normalization/tests/ -x -q
python -m pyright engines/normalization/src/normalizers/shamela.py
```

**4.4** Commit:
```
fix: [normalization] align diacritics canary with SPEC range (1 book affected)
```

### Step 5: Generate crash_books.txt and Rerun

**5.1** Extract crash books from errors.jsonl:
```python
import json
names = []
with open("results/normalization_sweep/errors.jsonl") as f:
    for line in f:
        line = line.strip()
        if not line: continue
        record = json.loads(line)
        if record["status"] == "CRASH":
            names.append(record["name"])
names = sorted(set(names))
with open("results/normalization_sweep/crash_books.txt", "w") as f:
    f.write("\n".join(names))
```
Result: 1 book name.

**5.2** Copy and rerun:
```bash
python scripts/rerun_crash_books.py results/normalization_sweep/crash_books.txt shamela-export-samples results/normalization_sweep/rerun_subset
python scripts/normalization_corpus_sweep.py --collection-dir results/normalization_sweep/rerun_subset --output-dir results/normalization_sweep/rerun_results --resume
```

**5.3** Create still_crashing.txt from rerun results (expect empty — crash should be fixed).

### Step 6: Write Documentation Files

**6.1** `results/SWEEP_ARCHITECT_REVIEW.md`:
- Bug 2 note: diacritics range narrowed from 20 to 10 codepoints. Architect should decide if SPEC should include extended diacritics (U+0653, U+0656-U+065F).
- Zero-content books: 48 books fixed by reclassification. Architect should verify the reclassification logic is appropriate for all cases.

**6.2** `results/SWEEP_FIX_SUMMARY.md`:
- Before/after crash counts
- Before/after test counts
- Fixed bugs list with commit references
- Crash book list grouped by fix status

### Step 7: Final Verification

- [ ] Full pytest passes (both engines): `python -m pytest engines/normalization/tests/ engines/source/tests/ -v --tb=short`
- [ ] Pyright clean on modified files
- [ ] Every fix has at least one new test
- [ ] SWEEP_BUG_TRIAGE.md documents every crash pattern
- [ ] SWEEP_FIX_SUMMARY.md has before/after counts
- [ ] SWEEP_ARCHITECT_REVIEW.md exists
- [ ] crash_books.txt and still_crashing.txt exist
- [ ] No SPEC or contract files modified: `git diff engines/*/SPEC*.md engines/*/contracts.py` returns empty
- [ ] All fix commits use `fix:` prefix

### Step 8: Final Commit
```
sweep: Bug fix sprint summary — 2 fixed (49 books), 0 remaining crashes
```

---

## Critical Files

| File | Action | Purpose |
|------|--------|---------|
| `engines/normalization/src/normalizers/shamela.py` | EDIT | Fix both bugs (lines 158-162 diacritics + lines 628-655 metadata detection) |
| `engines/normalization/tests/test_shamela_passes.py` | EDIT | Add 2 new tests |
| `tests/fixtures/shamela_edge_cases/zero_content_hadith_dhunnun.htm` | READ | Existing fixture for Bug 1 test |
| `tests/fixtures/shamela_edge_cases/crash_diacritics_entity_mismatch.htm` | READ | Existing fixture for Bug 2 test |
| `results/SWEEP_BUG_TRIAGE.md` | CREATE | Bug triage documentation |
| `results/SWEEP_FIX_SUMMARY.md` | CREATE | Fix summary with metrics |
| `results/SWEEP_ARCHITECT_REVIEW.md` | CREATE | Items for architect review |
| `results/normalization_sweep/crash_books.txt` | CREATE | Crash book list for rerun |
| `results/normalization_sweep/still_crashing.txt` | CREATE | Post-fix crash status |

## Verification

After all fixes, run:
```bash
# Full test suite
python -m pytest engines/normalization/tests/ engines/source/tests/ -v --tb=short

# Pyright on modified file
python -m pyright engines/normalization/src/normalizers/shamela.py

# Verify no SPEC/contract changes
git diff engines/*/SPEC*.md engines/*/contracts.py

# Rerun crash book
python scripts/rerun_crash_books.py results/normalization_sweep/crash_books.txt shamela-export-samples results/normalization_sweep/rerun_subset
python scripts/normalization_corpus_sweep.py --collection-dir results/normalization_sweep/rerun_subset --output-dir results/normalization_sweep/rerun_results --resume
```
