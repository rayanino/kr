# Plan: Implement phase1_assembly.py + 8 Test Files

## Context

The excerpting engine's Phase 1 transforms `NormalizedPackage` into `list[AssembledChunk]` — fully deterministic, no LLM calls. The stub file (`engines/excerpting/src/phase1_assembly.py`) has 17 function stubs with complete type signatures. We need to fill all stubs and write 8 test files with >=55 tests.

**Why now:** SPEC is complete (2387 lines), contracts.py is independently reviewed (1111 lines, 15/15 checks pass), conftest.py has 4 factories, and 9 stub files are ready. This is CC Session 1 of a 6-session build.

**Critical constraint:** Footnote renumbering (modifies text) MUST run BEFORE text layer rebasing (§4.1 step ordering).

---

## Phase A: Foundations — Utilities + Tree Walking + Alignment

### A1. Implement 4 utility functions

**File:** `engines/excerpting/src/phase1_assembly.py`

1. **`strip_arabic_noise(text)`** (~5 lines)
   - Apply `_ARABIC_NOISE_RE.sub("", text)` (regex already defined in stub)
   - Collapse whitespace: `re.sub(r"\s+", " ", result).strip()`
   - Reference: `extract_divisions.py:38-43`

2. **`_get_bc_separator(boundary)`** (~5 lines)
   - If None → `"\n"`
   - Else → `BC_SEPARATOR_MAP.get(boundary.type.value, "\n")`

3. **`_should_insert_space_mid_sentence(prev_text, next_text)`** (~15 lines)
   - If `prev_text` ends with whitespace → True (natural word boundary)
   - Strip trailing whitespace → `stripped`
   - If empty → False
   - If `stripped[-1]` in `_WORD_FINAL_CHARS` (ة/ى) → True
   - If `stripped[-1]` in `_TANWIN_DIACRITICS` (ً/ٌ/ٍ) → True
   - Else → False (connecting letter, mid-word)

4. **`_matches_exclude_keyword(heading_text)`** (~10 lines)
   - `stripped = strip_arabic_noise(heading_text).strip()`
   - For each keyword: `if stripped == strip_arabic_noise(kw).strip(): return True`
   - Return False
   - **Exact match, not word-boundary regex** — prevents false positives on "مصادر الأحكام" where "مصادر" would word-boundary-match but the heading is a content chapter, not bibliography
   - SPEC §4.2 test case: "مصادر الأحكام" must NOT match

### A2. Implement 2 tree-walking functions

5. **`find_leaf_divisions(division_tree)`** (~20 lines)
   - Inner `_walk(nodes, path)` recursive helper
   - For each node: `current_path = path + [node.heading_text]`
   - If `not node.children` → leaf, append `(node, current_path)`
   - Else → recurse into children
   - Reference: `extract_divisions.py:83-98`

6. **`should_skip_division(node, content_units)`** (~25 lines)
   - Empty range: `start > end` → `"EX-A-002: empty range"`
   - Filter units in `[start, end]` by unit_index
   - No units found → `"EX-A-002: no content units in range"`
   - All TOC → `"all_toc"`, all index → `"all_index"`, all blank → `"all_blank"`
   - `_matches_exclude_keyword(node.heading_text)` → `"bibliography_keyword"`
   - Else → None

### A3. Implement heading alignment

13. **`check_heading_alignment(heading_text, assembled_text)`** (~10 lines)
   - `stripped_heading = strip_arabic_noise(heading_text)[:30]`
   - `stripped_text = strip_arabic_noise(assembled_text)[:200]`
   - If `stripped_heading and stripped_heading in stripped_text` → True
   - Else → log EX-A-006, return False

### A4. Write conftest.py additions

**File:** `engines/excerpting/tests/conftest.py` (append below existing factories)

Add 4 new factories following normalization conftest.py pattern:

```python
def _make_content_unit(**overrides) -> ContentUnit:
    """ContentUnit with valid defaults. Single MATN layer covering full text."""
    # Default text: "بسم الله الرحمن الرحيم وبعد فهذا كتاب في النحو"
    # Auto-generates text_layers covering [0, len(primary_text))
    # Default: no boundary_continuity, no footnotes, no flags

def _make_division_node(**overrides) -> DivisionNode:
    """DivisionNode with valid defaults."""
    # heading="باب الاختبار", level=1, start=0, end=0, HIGH confidence

def _make_normalized_package(**overrides) -> NormalizedPackage:
    """Minimal valid NormalizedPackage: 1 division, 2 content units."""
    # Builds content_units and manifest unless overridden
    # Root division covering all units

def _make_division_tree(leaf_count: int, ...) -> list[DivisionNode]:
    """Generate a tree with one root and leaf_count child leaves."""
    # Each leaf covers a proportional range of unit_indices
```

### A5. Write test files for A1-A3

**File:** `test_phase1_tree_walk.py` — 12 tests (functions 4-6)
- test_leaf_identification, test_heading_path, test_skip_toc/index/blank, test_skip_bibliography, test_no_false_positive_masadir, test_skip_empty_range, test_volume_passthrough, test_minimal_tree_c8, test_empty_tree, test_single_root

**File:** `test_phase1_alignment.py` — 4 tests (function 13)
- test_aligned_heading, test_misaligned_heading, test_noise_stripped, test_not_gate

**Verify:** `python -m pytest engines/excerpting/tests/test_phase1_tree_walk.py tests/test_phase1_alignment.py -v --tb=short`

---

## Phase B: Core Assembly

### B1. Implement assemble_text

7. **`assemble_text(content_units, start, end)`** (~50 lines)
   - Collect units in [start, end] inclusive; ALL go into constituent_unit_indices (even skipped, per I-AC-4)
   - For each non-skipped unit (not TOC/index/blank):
     - First unit: `parts.append(text)`, cumulative_offset = len(text)
     - Subsequent: get separator from `_get_bc_separator(prev_unit.boundary_continuity)`
     - If sep is `""` (mid_sentence): check `_should_insert_space_mid_sentence(prev_text, curr_text)` → use `" "` if True
     - Append separator + text, track cumulative offset
     - Record JoinPoint: `after_unit_index=prev_idx, before_unit_index=curr_idx, boundary_type=type_or_UNKNOWN, separator_used=sep, char_offset_in_assembled=offset_before_separator`
   - When boundary is None: use `BoundaryContinuityType.UNKNOWN` for the JoinPoint's boundary_type
   - Return `("".join(parts), join_points, all_unit_indices)`

### B2. Write test file

**File:** `test_phase1_assembly.py` — 9 tests
- test_separator_mapping, test_mid_sentence_word_final, test_mid_sentence_connecting, test_skip_toc_in_range, test_diacritics_preserved, test_footnote_markers_preserved, test_join_points_recorded, test_null_boundary, test_constituent_unit_indices

**Verify:** `python -m pytest engines/excerpting/tests/test_phase1_assembly.py -v --tb=short`

---

## Phase C: Metadata Aggregation

### C1. Implement 4 metadata functions

8. **`aggregate_content_flags(content_units, unit_indices)`** (~15 lines)
   - Init `ContentFlags()`. For each unit in unit_indices: OR each boolean field
   - Reference: `extract_divisions.py:169-192` (adapted for Pydantic)

9. **`aggregate_footnotes(content_units, unit_indices)`** (~15 lines)
   - Walk units by sorted index. Track `seen: set[str]`
   - For each footnote: if ref_marker seen → log EX-A-005, skip. Else add to result + seen

10. **`renumber_footnotes(assembled_text, footnotes)`** (~40 lines)
    - Find all `⌜N⌝` markers: `re.finditer(r'⌜([^⌝]+)⌝', text)`
    - Track seen markers. If no collisions → return (text, footnotes, None)
    - Build `renumber_map: dict[str, str]` assigning sequential numbers by first-appearance order
    - Replace markers in text **from end to start** (reverse offset order) to avoid cascading offset shifts
    - Create new Footnote objects with updated ref_marker
    - Return (new_text, new_footnotes, renumber_map)
    - **Edge case:** marker length may change (e.g., "1"→"12" adds a char) — this is why reverse replacement is critical

11. **`collect_physical_pages(content_units, unit_indices)`** (~8 lines)
    - For each idx in sorted(unit_indices): find unit, collect physical_page

### C2. Write test file

**File:** `test_phase1_metadata.py` — 7 tests
- test_or_aggregate_flags, test_footnote_dedup, test_footnote_renumber, test_renumber_updates_text, test_renumber_map, test_no_renumber_needed, test_physical_pages_order

**Verify:** `python -m pytest engines/excerpting/tests/test_phase1_metadata.py -v --tb=short`

---

## Phase D: Layer Rebasing

### D1. Implement rebase_text_layers

12. **`rebase_text_layers(content_units, unit_indices, join_points, assembled_text_len)`** (~60 lines)
    - Build `offset_map: dict[int, int]` mapping unit_index → base_char_offset
      - First non-skipped unit in unit_indices → offset 0
      - From join_points: `jp.before_unit_index → jp.char_offset_in_assembled + len(jp.separator_used)`
    - For each non-skipped unit with an offset entry:
      - For each TextLayerSegment: clamp `end` to `len(primary_text)` if overflow (EX-A-004)
      - Rebase: `new_start = seg.start + base, new_end = clamped_end + base`
      - Clip to `assembled_text_len`
    - **Merge adjacent:** Sort by start. If consecutive segments have same layer_type + author_canonical_id → merge (span both ranges, confidence = min)
    - **Validate:** `validate_layer_coverage(merged, assembled_text_len)` → raises on failure (EX-A-003)

### D2. Write test file

**File:** `test_phase1_layers.py` — 6 tests
- test_rebase_single_unit, test_rebase_multi_unit, test_merge_adjacent_segments, test_coverage_invariant, test_clamping, test_gap_detection

**Verify:** `python -m pytest engines/excerpting/tests/test_phase1_layers.py -v --tb=short`

---

## Phase E: Merge + Split

### E1. Implement merge_tiny_divisions

14. **`merge_tiny_divisions(chunks, parent_div_id, config)`** (~75 lines)
    - Walk chunks list. For each chunk with `word_count < config.TINY_DIVISION_WORDS`:
      - Target: next sibling, or previous if last
      - Size guard: `combined_wc > config.OVERSIZED_DIVISION_WORDS` → skip merge
      - Only child or all siblings exceed guard → leave as-is
      - Merge: combine texts with `"\n\n"`, union constituent_unit_indices, combine join_points
      - `merge_history = [first.div_id, second.div_id]` (extend if target already merged)
      - `div_id, div_path, chunk_id` = first chunk's values
      - Recompute `word_count`, `total_tokens`
      - Placeholder text_layers (single segment covering full merged text)
      - Remove consumed sibling from working list
    - Repeat loop until no more tiny chunks (recursive stabilization)
    - I-AC-6: merge_history >= 2 entries, first = div_id
    - I-AC-7: merge creates merge_history, never split_info

### E2. Implement split_oversized_division

15. **`split_oversized_division(chunk, content_units, config)`** (~100 lines)
    - If `word_count <= config.OVERSIZED_DIVISION_WORDS` → return [chunk]
    - Find split point (priority order):
      1. **Heading markers:** find content units in chunk's range with `structural_markers.heading_detected`. Map to char offset via join_points. Split at first heading.
      2. **Section/paragraph breaks:** find all `"\n\n"` positions, pick nearest to `len(text)//2`
      3. **Sentence boundary:** find `[.؟!]\s` positions, pick nearest midpoint
      4. **Fallback:** if no split point found, use character midpoint (defensive)
    - Create two chunks: text[:split_offset], text[split_offset:]
    - Adjust join_points per chunk (filter by offset range, shift chunk_1's offsets)
    - Placeholder text_layers per chunk
    - Split footnotes: each chunk gets footnotes whose `⌜ref_marker⌝` appears in its text
    - SplitInfo: original_div_id, chunk_index, total_chunks, split_method
    - **Recursive:** if either result still oversized, split again
    - **Renumber chunk_ids:** after recursion, renumber all chunks sequentially: `{div_id}_chunk_0`, `_chunk_1`, etc. Update split_info.total_chunks and chunk_index.

### E3. Write test files

**File:** `test_phase1_merge.py` — 7 tests
- test_merge_two_tiny, test_merge_chain, test_size_guard, test_only_child, test_merge_history, test_merge_keeps_div_path, test_i_ac_7_no_merge_split

**File:** `test_phase1_split.py` — 9 tests
- test_split_at_heading, test_split_at_section_break, test_split_at_paragraph, test_split_at_sentence, test_recursive_split, test_split_info_fields, test_shared_unit_indices, test_layer_split_points, test_footnote_assignment

**Verify:** `python -m pytest engines/excerpting/tests/test_phase1_merge.py test_phase1_split.py -v --tb=short`

---

## Phase F: Validation + Orchestrator

### F1. Implement run_phase1 orchestrator

17. **`run_phase1(package, config)`** (~120 lines)

**Orchestration (7 steps with REVISED ordering):**

```
1. Walk tree → leaves              (find_leaf_divisions)
2. Assemble text + heading check   (assemble_text + check_heading_alignment)
3. Merge tiny divisions            (merge_tiny_divisions by parent group)
4. Aggregate metadata + renumber   (aggregate_* + renumber_footnotes)  ← BEFORE split
5. Split oversized divisions       (split_oversized_division)
6. Rebase text layers              (rebase_text_layers + _slice_layers_for_split)
7. Validate                        (validate_phase1)
```

**Why steps 4-5 are reordered from SPEC:** The SPEC says split (§4.5) before aggregate+renumber (§4.7). But renumbering changes text character offsets, and layers must be rebased on the FINAL text. For split chunks, we need to:
1. Rebase layers on the FULL original text (using saved join_points)
2. Slice per split chunk's text range

If we renumber AFTER split, each chunk's renumbering would change offsets differently, making full-text layer rebasing impossible. By renumbering BEFORE split, the text is stable when we split, and the full-text layer rebase produces correct offsets for slicing.

**Key implementation details:**

a. **Parent map for merge grouping:** Private helper `_build_parent_map(nodes, parent_id)` → `dict[str, str]` mapping leaf div_id to parent div_id.

b. **Proto-chunks:** Build full `AssembledChunk` objects with placeholder text_layers (single MATN segment covering full text), empty footnotes/content_flags/physical_pages. These satisfy Pydantic validators. After aggregate+renumber, replace with real values via `chunk.model_copy(update={...})`.

c. **Split chunk layer handling:**
   - Before split: save `original_join_points[div_id]` for each merged chunk
   - After split: group split chunks by `original_div_id`
   - For each group: rebase layers for FULL text using saved join_points
   - Slice per chunk using `_slice_layers_for_split(full_layers, chunk_start, chunk_end)`
   - Record layer_split_points where segments were artificially divided

d. **Helper: `_slice_layers_for_split(layers, start, end)`** (~25 lines)
   - For each layer segment: clip to [start, end), shift by -start
   - Track split_points where segments were split at chunk boundaries

e. **Split chunk footnote filtering:** After split, filter each chunk's footnotes to only those whose `⌜ref_marker⌝` appears in the chunk's assembled_text.

f. **EX-A-010:** If zero leaves after tree walk → return empty + skip validation.

### F2. Implement validate_phase1

16. **`validate_phase1(chunks, manifest, skipped_divisions, config)`** (~65 lines)
    - V-P1-1 (Division coverage, FATAL): every leaf → chunk or explicit skip
    - V-P1-2 (Content unit coverage, FATAL): all unit_indices 0..total-1 accounted for
    - V-P1-3 (No empty chunks, WARNING): word_count > 0
    - V-P1-4 (No oversized, WARNING): word_count <= OVERSIZED
    - V-P1-5 (Layer coverage, FATAL): validate_layer_coverage per chunk
    - V-P1-6 (Word count consistency, FATAL): validate_ac_invariants per chunk
    - Returns: `list[dict]` with `{"check", "status", "detail"}`
    - Raises ValueError if any FATAL check fails

### F3. Write test file

**File:** `test_phase1_validation.py` — 6 tests
- test_v_p1_1_coverage, test_v_p1_2_units, test_v_p1_3_no_empty, test_v_p1_4_no_oversized, test_v_p1_5_layers, test_v_p1_6_word_count

**Verify:** Full suite: `python -m pytest engines/excerpting/tests/ -v --tb=short`

---

## Invariants to Maintain

| Invariant | Where Enforced | How |
|-----------|---------------|-----|
| I-AC-1 | validate_phase1 (V-P1-6) | Recompute word_count/total_tokens from assembled_text |
| I-AC-2 | rebase_text_layers | validate_layer_coverage after rebasing |
| I-AC-3 | aggregate_footnotes | Each ref_marker has ⌜N⌝ in text |
| I-AC-4 | assemble_text + split | All unit_indices recorded, shared for split |
| I-AC-5 | AssembledChunk validator | chunk_id ends with _chunk_{N} |
| I-AC-6 | merge_tiny_divisions | merge_history >= 2, first = div_id |
| I-AC-7 | AssembledChunk validator + size guard | merge_history XOR split_info |
| Step 5→6 | run_phase1 | Renumber before rebase (aggregate+renumber before split+rebase) |
| Diacritics | ALL functions | Never apply Unicode normalization to stored text |
| D-023 | run_phase1 | All upstream metadata (pages, footnotes, flags, layers) preserved |

---

## Edge Cases

- Empty tree → EX-A-010, return empty
- Single root no children → one leaf = one chunk
- All divisions skipped → zero chunks, V-P1-1 passes
- TOC pages mid-division → skip text, record index
- Footnote marker collision → renumber sequentially
- Marker length change → replace from end-to-start
- Mid-sentence connecting letter → empty separator (word continues)
- Only-child tiny division → leave as-is
- Merge chain (3 tiny siblings) → recursive merge
- 12000-word division → recursive split → 3+ chunks
- Layer segment spanning split point → divided into two segments
- No split point found → character midpoint fallback
- Content unit with overflowing layer segment → clamp + EX-A-004

---

## Estimated Size

- **Implementation:** ~900-1100 lines in phase1_assembly.py
- **Tests:** 8 files, 60+ tests
- **conftest.py additions:** ~100 lines (4 factories)

## Verification (run before committing)

```bash
python -m pytest engines/excerpting/tests/ -v --tb=short
python -m pytest engines/excerpting/tests/ -v --tb=short 2>&1 | grep "passed"
python -c "from engines.excerpting.src.phase1_assembly import run_phase1; print('OK')"
python -m pyright engines/excerpting/src/phase1_assembly.py
```

## Files Modified

- `engines/excerpting/src/phase1_assembly.py` — fill 17 stubs + add ~3 private helpers
- `engines/excerpting/tests/conftest.py` — append 4 factories
- `engines/excerpting/tests/test_phase1_tree_walk.py` — NEW (12 tests)
- `engines/excerpting/tests/test_phase1_assembly.py` — NEW (9 tests)
- `engines/excerpting/tests/test_phase1_merge.py` — NEW (7 tests)
- `engines/excerpting/tests/test_phase1_split.py` — NEW (9 tests)
- `engines/excerpting/tests/test_phase1_layers.py` — NEW (6 tests)
- `engines/excerpting/tests/test_phase1_metadata.py` — NEW (7 tests)
- `engines/excerpting/tests/test_phase1_alignment.py` — NEW (4 tests)
- `engines/excerpting/tests/test_phase1_validation.py` — NEW (6 tests)

## Files Read-Only (do NOT modify)

- `engines/excerpting/contracts.py` — independently reviewed
- `engines/normalization/contracts.py` — upstream types
- `experiments/architecture_test/extract_divisions.py` — reference impl
