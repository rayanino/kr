# Plan: I-002 Curriculum Architect Bounded Session + Push

## Context

Factory hardening verified complete (independent audit passed all 10 checks). Three commits on `codex/portfolio-truth-idea-002-p1` ready to push. Before pushing, we advance the idea pipeline.

The factory has no frontier idea. I-002 "Curriculum Architect" is at dossier/challenge/visible. ADR-007 demoted it after critique verdict "weakened more substantially by unvalidated modelability and authority assumptions." The idea must earn its way back or get parked.

**Critical constraint:** Claude is not an Islamic scholar. The factory non-negotiable is "no false scholarly authority." The session must not define scholarly taxonomies or render scholarly judgments. It must ask questions that Claude CAN honestly answer.

## The Reframing

The original two questions were:
1. Can prerequisite structure be modeled honestly?
2. What authority-boundary rule prevents implying one normative study path?

After adversarial review, the honest versions are:

1. **Do published Islamic curricula already provide explicit prerequisite structures that software could consume without inventing its own?** (This is an empirical/research question, not a scholarly one.)
2. **Can we design an architecture that holds multiple contradictory prerequisite structures from real traditions without the system taking a position?** (This is a software-architecture question.)

If the answer to #1 is yes → the system consumes existing structures, no authority claim needed.
If the answer to #1 is no → the system would have to invent prerequisite structures → violates "no false scholarly authority."

## Scope and non-goals

**In scope:** Empirical research on existing curricula, authority boundary architecture, kr dependency assessment, binary judgment.
**Out of scope:** Defining prerequisite ontologies, rendering scholarly judgments, testing prerequisite graphs, writing specs, building anything.

## Two outcomes (not three)

- **A — Returns to frontier with concrete scholarly-input action.** We can specify WHAT scholarly input is needed, WHERE it would go in the architecture, and HOW to validate it. The next move is a defined action, not a hope.
- **B — Parked.** The path forward is too unclear, the structural problems are too deep, or the idea cannot work without authority claims the factory cannot make.

The difference: A means we can write a concrete next-step. B means we can't.

## Execution Steps

### Step 0: Write judgment framework

Before any analysis, write the criteria in the research note: `research/I-002-MODELABILITY-SESSION-2026-03-31.md`
- Define outcomes A and B with criteria above
- State what Claude can and cannot determine (epistemic honesty)
- Reference ADR-007's specific critique: "unvalidated modelability and authority assumptions"
- Reference I-001 lesson: what seems modelable in theory becomes tricky in practice

### Step 1: Authority boundary architecture (do this FIRST)

Design a container mechanism — can software hold multiple contradictory prerequisite structures without taking a position? This is a legitimate architecture question.

Sub-questions:
- **1a:** Can the system present multiple curricula's sequences side-by-side without choosing one?
- **1b:** Can teacher guidance override any system-presented sequence?
- **1c:** Can the system operate with NO default sequence (student must select a curriculum or enter teacher guidance)?
- **1d:** Can disagreement between traditions be visible rather than hidden?

If the mechanism is sound, it constrains what Step 2 needs to find: "Do published curricula provide structures this mechanism could consume?"

If the mechanism is NOT sound (can't handle real disagreement), the idea has a deeper structural problem — proceed to judgment with Outcome B.

**Artifact:** "Authority Boundary Architecture" section in research note
**Pass:** Mechanism is precise enough that a future spec could implement it
**Fail:** Mechanism is vague, relies on "be careful," or can't handle real cases

### Step 2: Empirical prerequisite question (research, not analysis)

The single question: **Do published Islamic educational institutions provide explicit, granular prerequisite structures in their curricula?**

Survey (based on what we know and can verify):
- **Traditional systems:** Dars-e-Nizami (Deobandi), Al-Azhar's year-by-year structure, Mauritanian mahadra progression — do these publish sequencing rules, or is sequencing transmitted through teacher discretion?
- **Online platforms:** How do Seekers Guidance, Qalam Seminary, Al-Maghrib Institute present course ordering? Is it explicit or implied?
- **Classical texts:** Does Ta'lim al-Muta'allim (al-Zarnuji) or Ibn Khaldun's Muqaddima chapter on education contain explicit prerequisite structures?

For each source, note:
- Does it provide an explicit sequence? (yes/no)
- Is the sequence granular enough for software to consume? (science-level vs. text-level)
- Does it acknowledge alternative valid sequences?

**Critical honesty rule:** Label every claim with confidence: `verified` (we've seen the source), `likely` (commonly reported), or `uncertain` (our understanding may be incomplete). Do NOT present `uncertain` claims as evidence.

**Artifact:** "Existing Curricula Survey" section in research note
**Pass:** At least one published curriculum provides explicit, consumable prerequisite structures
**Fail:** All sequencing is transmitted through teacher discretion with no published structure

### Step 3: kr dependency assessment

What does kr need to provide for Curriculum Architect to work?
- Topics, sources, excerpts, and their relationships
- The pedagogical ontology that I-002 depends on
- Status: `blocked_for_build` — is this a blocking dependency or a deferrable one?

If even Outcome A would leave I-002 blocked on kr with no timeline, that affects the frontier decision. Returning an idea to frontier when it can't progress is false promotion.

**Artifact:** "kr Dependency Assessment" section in research note

### Step 4: Binary judgment

Apply the framework from Step 0:

**For Outcome A**, all three must be true:
1. The authority boundary mechanism (Step 1) is sound
2. At least one published curriculum provides consumable prerequisite structures (Step 2)
3. There is a concrete next-step that doesn't require kr to be ready (Step 3)

The concrete next-step would be: "Find a scholar or curriculum expert who can validate whether [specific published structure] is representative, and confirm the authority boundary mechanism doesn't misrepresent their tradition."

**For Outcome B**, any one of these is sufficient:
1. The authority boundary mechanism can't handle real disagreement
2. No published curriculum provides consumable structures (everything is teacher-transmitted)
3. The idea is structurally blocked on kr with no workaround

**Artifacts to update:**
- `ideas/curriculum-architect/DOSSIER.md` — update judgment and next move
- `ideas/curriculum-architect/README.md` — update status
- `catalog/IDEA_REGISTRY.md` — update I-002 row
- `catalog/BOTTLENECK_MAP.md` — update B-002
- `catalog/ACTIVE_FOCUS.md` — update if frontier changes
- `catalog/PORTFOLIO_PRIORITY_BOARD.md` — update if priority changes
- `decisions/ADR-012-I-002-MODELABILITY-DETERMINATION.md` — new ADR

### Step 5: Epistemic honesty section

Explicit section in the research note stating:
- What Claude determined vs. what requires domain expertise
- Where the session's confidence is high vs. where it's an AI's best guess
- What a scholar reviewing this work would need to validate

## Phase 2: Commit + Push + PR

### Commit 4: I-002 session results
Stage research note, updated dossier, updated catalogs, ADR-012.

### Push and create PR
Push `codex/portfolio-truth-idea-002-p1`, create PR to main.
PR body: 4 commits (quarantine, extraction, hardening, I-002 determination).

## Key files (verified paths)

- `ideas/curriculum-architect/DOSSIER.md` — I-002 dossier
- `ideas/curriculum-architect/README.md` — I-002 workspace status
- `catalog/IDEA_REGISTRY.md` — I-002 row
- `catalog/BOTTLENECK_MAP.md` — B-002
- `catalog/ACTIVE_FOCUS.md` — current focus
- `catalog/PORTFOLIO_PRIORITY_BOARD.md` — priority board
- `decisions/ADR-007-FRONTIER-NARROWING-AFTER-INDEPENDENT-CRITIQUE.md` — demotion context
- `ideas/memorization-os/RESEARCH.md` — I-001 implementation lessons
- `templates/RESEARCH_NOTE_TEMPLATE.md` — format reference

## What this session does NOT do

- Define prerequisite ontologies (scholarly act)
- Draw prerequisite graphs (scholarly act)
- Render scholarly judgments about Islamic pedagogy (authority claim)
- Produce a specification (premature)
- Expand scope beyond the two binary questions
