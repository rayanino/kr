# Plan: Overnight System Documentation for Next-Agent Onboarding

## Context

After tonight's overnight run, a new Claude Code session will review the results and look for improvements. The current overnight system has **no dedicated documentation** — a new agent must read 1,200 lines of orchestrator code + 670 lines of task generator + scattered state files to understand how things work. This session fixed 4 critical bugs and added 5 design improvements, but those changes are only documented in the previous plan file and memory, which may not be loaded.

**Problem:** The next agent will either (a) spend 30+ minutes exploring before doing useful work, or (b) misunderstand the system and make wrong suggestions.

**Solution:** Write `overnight/README.md` — a single orientation document that gives any new agent everything they need in <2 minutes of reading.

## What to Create

### `overnight/README.md` — Overnight System Quick Reference

Contents:
1. **What this is** — 3-sentence summary
2. **Architecture** — orchestrator → manifest → tasks → quality gate → report
3. **Key files** — table with paths and one-line descriptions
4. **Philosophy** — hardening only, no implementation
5. **How to launch** — the exact PowerShell command
6. **How to review results** — where to look in the morning (MORNING_REPORT.md, decisions.log, results/)
7. **Known limitations** — Codex L5 broken on Windows, task generator pre-existing issues
8. **Recent changes** (2026-03-24) — bugs fixed, features added
9. **Manifest format** — field reference with `bookend` explained
10. **Task generator scanners** — what each of the 9 scanners does

This is NOT a code walkthrough. It's a decision-support document: what exists, why, what to check first.

## Verification

After writing, verify the README answers these questions without reading any other file:
- What does the overnight system do?
- How do I launch it?
- Where do I find tonight's results?
- What was changed recently?
- What's the `bookend` field?
- Why does cost show $0 in old state.json files?
