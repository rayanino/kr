---
title: "fix(autonomous): Harden creative evaluator against DR-identified bypass vectors"
type: fix
status: active
date: 2026-04-06
origin: ChatGPT Deep Research audit of scripts/overnight_codex_evaluator.py (2026-04-06)
---

# Harden Creative Evaluator Against DR-Identified Bypass Vectors

## Overview

ChatGPT Deep Research performed a comprehensive adversarial audit of the creative ideation evaluator. Every finding was independently confirmed against the actual codebase via 3 parallel exploration agents. The evaluator catches obvious garbage (weak payload: 2/20 REJECT) but is gameable by "dressed-up cleanups" — incremental changes framed with the right keywords, word counts, and boundary tokens to score 15+/20 and PASS.

The governing doctrine is **"stagnation over corruption"**: near-zero false positives, even at the cost of many false negatives.

## Problem Frame

The evaluator has two structural problems:

1. **It can be bypassed entirely.** Action items from creative tasks flow to the backlog via `actionable.json` → `sync_backlog_from_artifacts()` without ANY evaluator verdict check. The evaluator runs AFTER artifacts are written. A rejected idea's action items still become "proposed" backlog work.

2. **It can be gamed when not bypassed.** The 5 dimensions use proxy heuristics (word counts, engine name mentions, path existence checks, 5 shallow-pattern regexes) that a sufficiently verbose, well-structured but strategically empty idea can satisfy. Three concrete adversarial bypass examples demonstrate this.

## Requirements Trace

- R1. Close all propagation paths so evaluator verdict is a hard gate (DR finding F-C1, F-C3)
- R2. Add Evidence Fidelity dimension — verify claimed symbols exist in referenced files (DR finding F-C4)
- R3. Expand shallow detection in strategic_depth (DR finding F-H1, bypass examples A/B/C)
- R4. Tighten inflation_check — distribution-aware, reduce max delta (DR finding F-C2, F-H6)
- R5. Eliminate "provisional" verdict — binary pass/reject under doctrine (DR finding F-C5)
- R6. Raise PASS thresholds on all dimensions (DR finding F-C3)
- R7. Morning report shows evaluator-assessed class, not self-reported (DR finding F-H5)
- R8. All 3 DR adversarial bypass examples must REJECT after hardening
- R9. Golden-grade payload must still PASS (it IS the quality bar)
- R10. All existing 61 tests must not regress

## Scope Boundaries

- No API calls — all checks remain deterministic
- No engine source code changes — only evaluator/orchestrator/backlog scripts
- No changes to the excerpting-foundations-hardening lane
- Novelty/mode-collapse detection (F-H4) is DEFERRED — it requires historical comparison infrastructure that doesn't exist yet. Documented as a known limitation.
- The proposed 7th dimension "Necessity/irreversibility" is DEFERRED — it requires causal reasoning about information loss that cannot be reliably done deterministically. The Evidence Fidelity dimension partially addresses it by verifying boundary claims are factually grounded.

## Context & Research

### Confirmed Bypass Path (Exact Code Trace)

```
Line 1991: _write_result_artifacts() → writes actionable.json  ← NO GATE
Line  614: _run_creative_evaluator() → computes verdict        ← TOO LATE
Line 2805: sync_backlog() → sync_backlog_from_artifacts()      ← READS actionable.json, NO VERDICT CHECK
Line  403: _upsert_result_action_items() → status: "proposed"  ← BYPASS COMPLETE
```

### Adversarial Bypass Examples (DR-Provided)

| Example | Nature | Why It Passes Current Evaluator |
|---------|--------|-------------------------------|
| A: "Granularity Tagging Layer" | Contract field + propagation | "Introduce..." bypasses SHALLOW_PATTERNS; mentions 2+ engines; wordy |
| B: "Provenance Ledger Unification" | Observability + hashing | "study/trust" keywords; real file paths; wordy risks |
| C: "Taxonomy Placement Accelerator" | Caching + heuristics | "Transform..." bypasses patterns; mentions taxonomy + excerpting |

### Symbol Map for Evidence Fidelity

| Engine | Key Classes | Verifiable Fields |
|--------|-------------|-------------------|
| excerpting | ExcerptRecord (33 fields), TeachingUnit (10 fields) | primary_function, self_containment, source_id |
| taxonomy | TreeNode (4 fields), LeafCoverage | id, title, children, leaf |
| normalization | ContentUnit, DivisionNode | div_id, unit_index, primary_text |
| synthesis | Entry, TaxonomyPlacedExcerpt | entry_id, leaf_path, source_excerpt_ids |
| source | SourceMetadata, Genre (20 values) | source_id, genre, trust_tier |

## Key Technical Decisions

- **Sidecar verdict file approach for gating**: After the evaluator runs, write `evaluator_verdict.json` alongside `actionable.json`. All consumers check for the sidecar before ingesting. This avoids temporal reordering of the orchestrator (which would be a larger, riskier change).
  - Rationale: Simpler than reordering _write_result_artifacts vs _finalize_task_result. The sidecar approach is additive, not structural.

- **Static symbol registry, not AST parsing**: The Evidence Fidelity dimension uses a hardcoded dict of `{file_path: set_of_class_names}` extracted from contracts files, then does `grep`-style string search for those names in the referenced file. This is not perfect but kills the most common hallucination vector (claiming a class exists when it doesn't).
  - Rationale: AST parsing of Pydantic models would be more robust but adds complexity and dependencies. String search is sufficient for class/enum name verification.

- **Binary verdicts only**: Under "stagnation over corruption", provisional = reject. Any idea that fails even one dimension is rejected. This is intentionally aggressive — it's better to reject a good idea than accept a bad one.

- **Inflation delta 8 → 4**: Tighter than DR's ≤2 recommendation but still allows some legitimate variance. The delta applies to the scaled comparison, not raw. Combined with per-dimension penalty (new), this catches most gaming.

## Implementation Units

### Phase 1: Close the bypass and tighten the gate (5 units, parallelizable)

- [ ] **Unit 1: Close backlog bypass — make evaluator verdict a hard gate**

  **Goal:** No creative task's action items enter the backlog unless the evaluator verdict is "pass"

  **Requirements:** R1

  **Dependencies:** None

  **Files:**
  - Modify: `scripts/overnight_codex_orchestrator.py` (lines 546-614: `_run_creative_evaluator`, `_finalize_task_result`)
  - Modify: `scripts/overnight_codex_backlog.py` (line 194: `_upsert_result_action_items`, line 391: `sync_backlog_from_artifacts`)
  - Modify: `scripts/append_codex_findings.py` (line 83: creative findings loop)
  - Modify: `scripts/append_creative_findings.py` (line 44: `collect_actionable_items`)
  - Test: `tests/test_overnight_codex_evaluator.py`

  **Approach:**
  1. Modify `_run_creative_evaluator()` to return the `EvaluationResult` (currently returns None)
  2. In `_finalize_task_result()`, after evaluator runs, write `evaluator_verdict.json` sidecar in the result dir containing `{"verdict": "pass"|"reject", "idea_class_evaluator": "...", "evaluator_total": N}`
  3. In `_write_result_artifacts()`, for creative strategic_idea tasks, write `actionable.json` with a `"pending_evaluation": true` flag
  4. In `sync_backlog_from_artifacts()`, before calling `_upsert_result_action_items()`, check for `evaluator_verdict.json` in the same result dir. Skip ingestion if verdict != "pass" or sidecar is missing
  5. In `append_codex_findings.py` and `append_creative_findings.py`, add the same sidecar gate before reading `actionable.json`

  **Patterns to follow:**
  - Existing `_write_task_packet()` at orchestrator line 522 already writes result JSON — follow the same atomic_write pattern
  - Existing `validate_action_items()` in common.py — follow the same validation-before-ingestion pattern

  **Test scenarios:**
  - Happy path: Creative task with evaluator verdict "pass" → action items appear in backlog
  - Gate: Creative task with evaluator verdict "reject" → action items NOT in backlog
  - Gate: Creative task with missing evaluator_verdict.json → action items NOT in backlog (fail-closed)
  - Gate: Non-creative task → action items ingested normally (no sidecar required)
  - Regression: All existing test_overnight_codex_runtime tests pass

  **Verification:** Run `python -m pytest tests/test_overnight_codex_runtime.py tests/test_overnight_codex_evaluator.py -v --tb=short` — all pass

- [ ] **Unit 2: Eliminate provisional verdict**

  **Goal:** Binary pass/reject only. No middle ground under "stagnation over corruption"

  **Requirements:** R5

  **Dependencies:** None

  **Files:**
  - Modify: `scripts/overnight_codex_evaluator.py` (lines 465-478: verdict logic, line 537: route_to_findings)
  - Test: `tests/test_overnight_codex_evaluator.py`

  **Approach:**
  1. Remove the `provisional` branch from `evaluate_creative_output()` verdict logic
  2. All dimensions must pass → "pass". Any failure → "reject"
  3. Update `route_to_findings()` — only "pass" routes
  4. Remove `provisional` from `EvaluationResult.verdict` documentation/type hints
  5. Update `format_findings_entry()` — no provisional section

  **Test scenarios:**
  - Partial payload (1 dimension fails, content_total >= 10) now gets "reject" not "provisional"
  - Golden payload still gets "pass"
  - Weak payload still gets "reject"

  **Verification:** Existing partial_payload test assertion changes from `in ("provisional", "reject")` to `== "reject"`

- [ ] **Unit 3: Add Evidence Fidelity dimension**

  **Goal:** Verify that claimed symbols (class names, enum values) actually exist in the referenced files

  **Requirements:** R2

  **Dependencies:** None

  **Files:**
  - Modify: `scripts/overnight_codex_evaluator.py` (add `check_evidence_fidelity()`, update `GOLDEN_DIMENSIONS`)
  - Test: `tests/test_overnight_codex_evaluator.py`

  **Approach:**
  1. Add `SYMBOL_REGISTRY: dict[str, set[str]]` mapping repo-relative file paths to known class/enum names. Built from the symbol map above. Include the top ~30 most likely-referenced symbols per engine (not all 188 — diminishing returns)
  2. Add `check_evidence_fidelity()` dimension:
     - Extract all `engines/*/contracts.py` and `engines/*/SPEC.md` references from `current_system_limit`, `proposed_reframe`, and `primary_insertion_boundary`
     - For each referenced file, check if any symbols from that file's registry entry appear in the surrounding text
     - Score: 0 = no verifiable claims; 1 = claims reference real files but no symbols verified; 2 = 1 symbol verified; 3 = 2+ symbols verified; 4 = 3+ symbols verified across 2+ files
     - Pass threshold: >= 3 (at least 2 verified symbols — the golden example has many)
  3. Update `GOLDEN_DIMENSIONS` to include `"evidence_fidelity"` (now 6 dimensions)
  4. Update `evaluate_creative_output()` to run the new dimension
  5. Update scoring thresholds: max evaluator total now 24 (6 × 4), adjust inflation scaling

  **Patterns to follow:**
  - Existing `check_repo_grounding()` already does path extraction with regex — extend pattern
  - Existing `_references_real_files()` already extracts `engines/*/...` paths — reuse

  **Test scenarios:**
  - Golden payload: references ExcerptRecord, TeachingUnit, TreeNode in real contract files → score >= 3, PASS
  - Weak payload: references no real symbols → score 0, FAIL
  - Bypass A payload: references ExcerptRecord/TeachingUnit in real files → may score 2-3 (this alone won't catch it — strategic_depth must)
  - Fabricated symbol: claims "BranchNodeContent" exists in taxonomy contracts → not in registry → score penalty

  **Verification:** `pyright scripts/overnight_codex_evaluator.py` clean; golden payload still passes; weak payload still rejects

- [ ] **Unit 4: Harden strategic_depth and concreteness**

  **Goal:** Catch "dressed-up cleanups" that bypass the current 5 shallow patterns

  **Requirements:** R3, R8

  **Dependencies:** None

  **Files:**
  - Modify: `scripts/overnight_codex_evaluator.py` (SHALLOW_PATTERNS, vague_risk_patterns, check_strategic_depth, check_concreteness)
  - Test: `tests/test_overnight_codex_evaluator.py`

  **Approach:**

  **Expand SHALLOW_PATTERNS** (add 6 new patterns targeting DR bypass vectors):
  ```
  r"^introduce\s+(?:a\s+)?(?:new\s+)?(?:field|annotation|tag|marker|flag)\b"  # Bypass A
  r"^(?:add|introduce|create)\s+.*(?:propagat|pass.through|carry\s+alongside)"  # Field propagation
  r"^(?:build|create|implement)\s+.*(?:cache|memoiz|fingerprint|hash|ledger|log)"  # Bypass B/C
  r"^(?:optimize|accelerat|speed.up|improv.+performance)"  # Bypass C
  r"^(?:add|introduce|build)\s+.*(?:observability|monitoring|tracing|logging|audit)"  # Bypass B
  r"^transform\s+\w+\s+into\s+.*(?:router|dispatcher|filter|cache)"  # Bypass C exact phrase
  ```

  **Expand vague_risk_patterns** (add 5 new patterns):
  ```
  r"^this\s+(?:introduces|creates|adds)\s+(?:backward|compat|migration)"  # Generic compat concern
  r"^(?:storage|memory|disk)\s+(?:footprint|usage|cost)\s+(?:grows|increases|may)"  # Generic storage
  r"^(?:could|may|might)\s+complicate\s+downstream"  # Generic downstream worry
  r"^(?:requires?|needs?)\s+careful\s+(?:planning|consideration|migration|testing)"  # Generic caution
  r"^this\s+(?:could|may|might)\s+(?:affect|impact|change)\s+(?:existing|current)"  # Generic impact
  ```

  **Add single-engine penalty to strategic_depth**: If `proposed_reframe` only mentions 1 engine, cap score at 2 (cannot pass). Strategic ideas by definition span boundaries.

  **Test scenarios:**
  - "Introduce a granularity annotation carried alongside TeachingUnit" → matches new pattern → shallow detected
  - "Build a scholarly provenance ledger with content hashes" → matches cache/fingerprint/ledger pattern
  - "Transform taxonomy into an interactive study router with a two-stage placement cache" → matches transform-into-router/cache pattern
  - "This introduces backward-compat concerns for stored excerpt JSON" → matches new vague risk pattern
  - Golden payload "Build a multiresolution book digester..." → does NOT match any shallow pattern (verified)

  **Verification:** All 3 bypass examples produce strategic_depth score <= 1. Golden payload produces score >= 3.

- [ ] **Unit 5: Tighten inflation_check — distribution-aware**

  **Goal:** Prevent gaming by arithmetic tuning of self-reported scores

  **Requirements:** R4

  **Dependencies:** None

  **Files:**
  - Modify: `scripts/overnight_codex_evaluator.py` (check_inflation, MAX_INFLATION_DELTA)
  - Test: `tests/test_overnight_codex_evaluator.py`

  **Approach:**
  1. Reduce `MAX_INFLATION_DELTA` from 8 to 4
  2. Add per-dimension cross-check: for the 3 dimensions that have both evaluator and self-reported counterparts:
     - `product_reframing` ↔ `strategic_depth` evaluator score
     - `primary_boundary_accuracy` ↔ `repo_grounding` evaluator score
     - `owner_value` ↔ presence of study keywords in owner_value_statement
  3. If any self-reported dimension is 4 but the corresponding evaluator dimension scored ≤ 1, apply a penalty of +4 to the inflation delta
  4. Update scaling to account for 6 evaluator dimensions (was 5): `scaled = int(evaluator_total * (32 / 24))`

  **Test scenarios:**
  - Golden payload: self-reported 28, evaluator ~22/24 → scaled ~29 → delta ~ -1 → PASS
  - Weak payload: self-reported 32, evaluator ~4/24 → scaled ~5 → delta 27 → REJECT (INFLATED)
  - Gaming attempt: content_total=18, self-reported=24 → scaled=24 → delta 0 → but if product_reframing=4 and strategic_depth evaluator=1 → penalty +4 → delta 4 → still PASS but marginal
  - Hard gaming: content_total=18, self-reported=24, but product_reframing=4 with strategic_depth=0 → penalty → delta > 4 → REJECT

  **Verification:** Golden not flagged as inflated. Weak still flagged. Arithmetic gaming harder (penalty makes it non-linear).

### Phase 2: Raise thresholds (sequential, depends on Phase 1)

- [ ] **Unit 6: Raise PASS thresholds on all dimensions**

  **Goal:** Make PASS rare — aligned with "stagnation over corruption"

  **Requirements:** R6

  **Dependencies:** Units 2-5 (thresholds must be calibrated after dimension changes)

  **Files:**
  - Modify: `scripts/overnight_codex_evaluator.py` (pass thresholds in each check_* function)
  - Test: `tests/test_overnight_codex_evaluator.py`

  **Approach:**
  1. `repo_grounding`: pass threshold 2 → 3 (must resolve boundary + reference real files + mention engines)
  2. `structural_completeness`: pass threshold 3 → 3 (keep — already reasonable)
  3. `strategic_depth`: pass threshold 2 → 3 (must avoid shallow patterns + have depth + study keywords + multi-engine)
  4. `concreteness`: pass threshold 2 → 3 (must have specific benefits + concrete risks + specific boundary)
  5. `evidence_fidelity`: pass threshold 3 (set in Unit 3)
  6. `inflation_check`: pass threshold already set by delta (tightened in Unit 5)
  7. Update `idea_class_evaluator` thresholds: benchmark_grade requires content_total >= 20/24 (was 16/20). Major >= 15/24 (was 12/20).

  **Test scenarios:**
  - Golden payload: must still score >= 3 on every dimension → PASS
  - Partial payload: likely fails >= 2 dimensions now → REJECT
  - Verify: Run golden payload through all 6 dimensions, confirm all >= 3

  **Verification:** Golden PASS, weak REJECT, partial REJECT, bypass A/B/C REJECT

### Phase 3: Reporting and testing (sequential, depends on Phase 2)

- [ ] **Unit 7: Fix morning report to use evaluator-assessed class**

  **Goal:** Display evaluator's classification, not self-reported

  **Requirements:** R7

  **Dependencies:** Unit 1 (sidecar verdict file must exist)

  **Files:**
  - Modify: `scripts/overnight_codex_orchestrator.py` (lines 2027, 2054: idea_class assignment; line 2404: morning report display)
  - Test: `tests/test_overnight_codex_runtime.py`

  **Approach:**
  1. In `_finalize_task_result()`, after evaluator runs, override `result.idea_class` with `eval_result.idea_class_evaluator` when available
  2. In `_run_creative_evaluator()`, return the `EvaluationResult` (done in Unit 1)
  3. In morning report generation, display `[evaluator: {idea_class_evaluator}]` instead of raw `idea_class`
  4. Add `evaluator_verdict` field to the signal dict used for reporting

  **Test scenarios:**
  - Morning report for a strategic idea shows evaluator class, not self-reported
  - If evaluator didn't run (non-strategic task), show original idea_class

  **Verification:** `test_generate_morning_report_includes_strategic_ideas_section` updated and passes

- [ ] **Unit 8: Add adversarial bypass test cases from DR audit**

  **Goal:** The 3 DR bypass examples must REJECT. Golden must still PASS.

  **Requirements:** R8, R9, R10

  **Dependencies:** Units 2-6 (all hardening must be in place)

  **Files:**
  - Modify: `tests/test_overnight_codex_evaluator.py`

  **Approach:**
  1. Add `bypass_a_payload()` — "Granularity Tagging Layer" from DR report
  2. Add `bypass_b_payload()` — "Provenance Ledger Unification" from DR report
  3. Add `bypass_c_payload()` — "Taxonomy Placement Accelerator" from DR report
  4. Fix golden payload: change "TaxonomyNode" → "TreeNode" in secondary_required_changes (actual class name per contracts.py)
  5. Add test class `TestAdversarialBypass` with:
     - `test_bypass_a_rejected()` — verdict == "reject"
     - `test_bypass_b_rejected()` — verdict == "reject"
     - `test_bypass_c_rejected()` — verdict == "reject"
     - `test_golden_still_passes_after_hardening()` — verdict == "pass"
  6. Update existing test assertions for removed "provisional" verdict
  7. Update score assertions for changed thresholds

  **Test scenarios:**
  - Bypass A ("Introduce a granularity annotation..."): REJECT — strategic_depth catches field-propagation pattern
  - Bypass B ("scholarly provenance ledger..."): REJECT — strategic_depth catches observability/logging pattern
  - Bypass C ("Transform taxonomy into an interactive study router..."): REJECT — strategic_depth catches transform-into-cache pattern
  - Golden ("multiresolution book digester..."): PASS — does not match any shallow pattern, high evidence fidelity, concrete risks

  **Verification:** `python -m pytest tests/test_overnight_codex_evaluator.py -v --tb=short` — all pass including new adversarial tests

### Phase 4: Full regression

- [ ] **Unit 9: Full regression run**

  **Goal:** All tests pass, pyright clean on all modified files

  **Requirements:** R10

  **Dependencies:** All previous units

  **Files:** All modified files

  **Approach:**
  1. `python -m pyright scripts/overnight_codex_evaluator.py scripts/overnight_codex_orchestrator.py`
  2. `python -m pytest tests/test_overnight_codex_evaluator.py tests/test_overnight_codex_runtime.py -v --tb=short`
  3. `python scripts/overnight_codex_task_generator.py --dry-run` — still emits tasks
  4. `python scripts/check_codex_kr_setup.py` — still passes

  **Test expectation:** All tests pass. No pyright errors.

  **Verification:** Zero failures, zero pyright errors, task generator and setup check still clean.

## System-Wide Impact

- **Interaction graph:** `_finalize_task_result` → `_run_creative_evaluator` → writes `evaluator_verdict.json` → consulted by `sync_backlog_from_artifacts`, `append_codex_findings`, `append_creative_findings`, `generate_morning_report`
- **Error propagation:** If evaluator fails (exception), `_run_creative_evaluator` already has try/except that logs and continues. The sidecar will be missing → fail-closed (no ingestion).
- **Unchanged invariants:** Non-creative tasks are completely unaffected. The backlog gate only applies to `creative-*` result directories.

## Risks & Dependencies

| Risk | Mitigation |
|------|------------|
| Golden payload fails after hardening | Unit 8 explicitly tests this. Fix thresholds if golden fails. |
| New shallow patterns are too aggressive (catch legitimate ideas) | Patterns target specific construction verbs, not content. "Build a multiresolution..." does not match "build...cache/hash/ledger". |
| Evidence fidelity registry becomes stale if contracts change | Registry is ~30 symbols from stable contracts. Changes to contracts would also need evaluator update. Acceptable for the autonomous period. |
| Existing 39 runtime tests break | Unit 1 changes are additive (sidecar), not structural. Existing test paths don't produce evaluator verdicts. |

## Known Limitations (Deferred)

- **Novelty/mode-collapse detection** (DR finding F-H4): Requires comparing against previously accepted ideas. Needs historical storage infrastructure. Deferred to next session.
- **Necessity/irreversibility dimension** (DR proposed 7th dimension): Requires causal reasoning about information loss. Cannot be done deterministically with current infrastructure. Partially addressed by Evidence Fidelity verifying factual claims.
- **Latent-ingredient leverage check** (DR finding F-H2): Would require understanding which upstream structures are preserved. Too complex for deterministic checking. Relies on coworker review for now.
- **Full AST-based symbol verification**: Current approach uses string search, not AST parsing. Sufficient for class/enum names but won't catch field-level claims. Acceptable tradeoff.

## Sources & References

- **Origin:** ChatGPT Deep Research audit (2026-04-06, relayed by owner)
- Evaluator code: `scripts/overnight_codex_evaluator.py` (commit `e94ae8979`)
- Orchestrator: `scripts/overnight_codex_orchestrator.py`
- Backlog: `scripts/overnight_codex_backlog.py`
- Golden example: `docs/codex/2026-04-03-golden-example-multiresolution-digester.md`
- Autonomous doctrine: `docs/codex/autonomous-doctrine-2026-04-09-to-2026-07-01.md`
- Symbol map: All 5 `engines/*/contracts.py` files
