# Plan: Nahw Tree Research — Corpus-Based Heading Analysis

## Context

We need to empirically analyze how real Arabic grammar (nahw) books organize their topics, by mining heading structures from ~30K Shamela HTML exports. The output will be compared with independently-produced taxonomy trees. The analysis must come ONLY from the book files — no existing taxonomy files in the repo.

**Data source:** `shamela-export-samples/` (hyphens, not underscores) — 30,421 .htm files, ~8,400 distinct books.

## Verified HTML Format

- **Title**: line 58, `<title>BOOK - جـ N</title>`
- **Category**: line 59, `<span class='title'>القسم:</span> VALUE` (single quotes = metadata)
- **Content headings**: `<span class="title">&#8204;TEXT</span>` (double quotes = content)
- **Multi-volume**: directories with numbered .htm files (001.htm, 002.htm...)
- **Hierarchy**: inferred from prefix keywords and position, not HTML nesting

## Implementation: 6 Scripts + 1 Common Module

Scripts: `scripts/nahw_research/`
Outputs: `reference/research/`

### Module: `_common.py` — Shared utilities

- `SHAMELA_DIR = Path("shamela-export-samples")`
- `discover_all_books()` → list of `BookEntry(name, first_file, is_multivolume, all_files)`
- `extract_title_fast(path)` → reads first 60 lines, regex `<title>(.*?)</title>`, strips `- جـ N`
- `extract_category_fast(path)` → regex on line 59 for `القسم:` value
- `extract_headings_from_file(path)` → full read, regex `<span class="title">(.*?)</span>` (double quotes only, skip metadata card)
- `normalize_heading(text)` → strip diacritics, normalize alef/ya, collapse whitespace
- `classify_heading_type(text)` → enum: BAB, FASL, MASALA, KITAB, etc.
- Pure stdlib — no BeautifulSoup, no Pydantic, no engine imports

### Step 1: `step1_identify_nahw.py` → `nahw_books_identified.json`

Three-tier classification:
1. **Tier A** (category match): `القسم: النحو والصرف` — highest confidence
2. **Tier B** (title keywords): النحو, الإعراب, الألفية, الأجرومية, قطر الندى, شذور الذهب, أوضح المسالك, المقتضب, الخصائص, المفصل...
   - Smart matching: generic words (شرح, الكتاب, الأصول) only count when combined with nahw-specific evidence
3. **Tier C** (known books): hardcoded list of ~30 famous nahw book fragments as safety net

Multi-volume dedup: group by directory name, strip `- جـ N` from titles.

**Performance**: ~8,400 books × 60 lines each ≈ 15-30s.

### Step 2: `step2_extract_headings.py` → `nahw_headings_by_book.json`

For each identified nahw book:
1. Read all .htm files, extract `<span class="title">` (double quotes only)
2. Clean `&#8204;` (ZWNJ), strip whitespace
3. Handle clarifying text: brackets `[في كذا]`, text after colon, following paragraph context
4. Merge consecutive title spans (Sibawayh pattern: two `<span class="title">` with <50 chars between = one heading)
5. Record: raw text, full heading, heading type, position, volume

**Performance**: ~200-400 books × 1-100 volumes ≈ 30-90s.

### Step 3: `step3_topic_frequency.py` → `nahw_topic_frequency.json`

1. Normalize all headings (strip diacritics, normalize alef/ya)
2. Strip prefix keywords (باب, هذا باب, فصل, مسألة) to get core topic
3. Cluster similar headings by Jaccard word-set similarity > 0.7
4. Count per-book (not per-volume) frequency
5. Separate generic headings (فصل alone, مسألة alone) from descriptive ones
6. Rank by book count

### Step 4: `step4_hierarchy.py` → `nahw_hierarchy_patterns.json`

1. For each book, reconstruct heading sequence in document order
2. Assign depth levels by prefix keyword:
   - L0: المجلد/الجزء, L1: كتاب, L2: باب, L3: فصل, L4: مبحث/مدخل, L5: مسألة/مطلب, L6: تنبيه/فائدة
3. Infer parent-child: heading at level N is child of most recent level N-1
4. Cross-book analysis: which topics are ALWAYS sub-topics vs. sometimes top-level
5. Record common hierarchy patterns (e.g., "باب > فصل > مسألة" in N books)

### Step 5: `step5_build_tree.py` → `nahw_corpus_tree.yaml`

1. Load frequency + hierarchy data
2. Core topics = appearing in ≥10% of books
3. Group by most common parent relationship
4. Build tree: root nodes = top-level باب topics, children = sub-topics, etc.
5. Each node: id (transliterated), title (Arabic), book_count, example_books, children

### Step 6: `step6_gap_analysis.py` → `nahw_corpus_gaps.md`

Markdown report covering:
1. Topics that don't fit the tree
2. Topics in only 1-2 books (specialized)
3. Typical heading depth (1/2/3 levels)
4. Unique topics vs. tree leaves
5. Surprising findings

## Critical Files (read, not import)

| File | What to reference |
|------|-------------------|
| `engines/normalization/src/normalizers/shamela.py` | `TITLE_SPAN_DOUBLE_RE`, page parsing patterns |
| `engines/normalization/src/structure_discovery.py` | `normalize_arabic_for_match()` algorithm |
| `engines/normalization/reference/structural_patterns.yaml` | Keyword-to-level mapping |
| `engines/normalization/reference/SHAMELA_HTML_REFERENCE.md` | HTML format ground truth |
| `scripts/normalization_corpus_sweep.py` | `discover_books()` pattern, Windows encoding fix |

## Verification

1. Run each step sequentially, inspect output between steps
2. Spot-check Step 1: verify أوضح المسالك, الأصول في النحو, ألفية ابن مالك are identified
3. Spot-check Step 2: verify أوضح المسالك headings match what we saw (المبتدأ والخبر, كان وأخواتها, etc.)
4. Step 3: verify المبتدأ والخبر, الفاعل, الحال appear as high-frequency topics
5. Final: commit all `reference/research/` outputs + `scripts/nahw_research/` scripts
