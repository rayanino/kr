# Plan: Fresh Session Handoff — Environment Audit & Remaining Fixes

## Decision: Fresh session

This session (best-practices digestion) is at high context usage after research + implementation + Codex review. The remaining work benefits from clean context and a full audit perspective. Below is the handoff prompt for the new session.

---

## Handoff Prompt (copy this entire block into a new session)

```
/ultra-think You are auditing the KR project's Claude Code environment after a major best-practices digestion session. Your job is twofold: (1) independently audit the entire .claude/ configuration for quality, correctness, and gaps, and (2) fix the specific issues listed below.

## What Was Done (Previous Session)

A comprehensive analysis of https://github.com/shanraisshan/claude-code-best-practice was performed, extracting patterns from Boris Cherny (Claude Code creator) and Thariq (Anthropic engineer). Changes were implemented and then reviewed by Codex CLI (GPT-5.4), which caught several cargo-cult patterns that were reverted. Here's what shipped:

### Settings.json
- `defaultMode` changed from `bypassPermissions` to `acceptEdits` (critical safety fix)
- 10 `ask` rules for destructive commands (rm -rf, force-push, git reset, kill, etc.)
- `effortLevel: "high"` persisted
- `respectGitignore: true`
- Custom `statusLine` via `scripts/kr_statusline.py`
- `attribution.commit` standardized
- `spinnerTipsOverride` with 7 KR domain rules
- `env`: `CLAUDE_AUTOCOMPACT_PCT_OVERRIDE=60`, `CLAUDE_CODE_SUBPROCESS_ENV_SCRUB=1`
- `once: true` on SessionStart hooks
- `statusMessage` added to 9 hooks (was 5)

### Agents (22 agents enriched)
- `effort`, `color`, `maxTurns` added to ALL 22 active agents
- `memory: project` piloted on code-reviewer only
- `skills:` preloading on code-reviewer (knowledge-safety + arabic-text) and arabic-reviewer (5 domain skills)
- arabic-reviewer body updated to note skills are preloaded

### Skills (4 skills improved)
- Gotchas sections added to arabic-text, domain-glossary, scholarly-attribution
- `disable-model-invocation: true` on evaluation-methodology only (knowledge-safety and consensus-pattern remain auto-triggerable)

### New Files
- `scripts/kr_statusline.py` — status line script
- `.claude/hooks/config/hooks-config.json` — shared hook control
- `.claude/hooks/config/hooks-config.local.json` — personal hook overrides (git-ignored)
- `.claude/agent-memory/code-reviewer/MEMORY.md` — seed memory

### Dropped (per Codex review)
- /careful and /freeze skills (cargo-cult — always-on guards beat opt-in safety)
- stop_nudge.py (risks stop-loops KR already defends against)
- Memory on arabic-reviewer and spec-writer (contamination risk across worktrees)

## What Codex Flagged But Wasn't Fixed

### HIGH PRIORITY

1. **Stale validation scripts** — `scripts/verify_metadata_flow.py` and `tools/check_cross_engine_contracts.py` assume old 7-engine pipeline layout and SPEC section numbering. The stop-quality-gate hook fires D-023 false positives because of this. A quality gate that fires false positives is WORSE than no quality gate — it trains the user to dismiss warnings.
   - Read both scripts, compare against current engine structure
   - Fix or disable the stale checks
   - Verify the stop-quality-gate.sh uses the corrected checks

2. **HOOK_WIRING.md is stale** — Says circuit-breaker, cost-guard, and no-ask-human hooks are "pending wire-up" but they're already wired in settings.json lines 106-126. Remove the stale documentation or update it to reflect current state.

3. **Agent/skill description rewrites** — Thariq (Anthropic engineer) says: "The description field is not a summary — it's a description of WHEN TO TRIGGER this skill. Write it for the model." Only arabic-reviewer was updated. The other 21 agents and 14 skills still have generic descriptions. Audit each one and rewrite as trigger conditions.
   - Bad: "Reviews code for quality"
   - Good: "Use PROACTIVELY after writing or modifying engine source code to review for SPEC compliance, Arabic text safety, and D-023 metadata preservation"

### MEDIUM PRIORITY

4. **MCP cleanup** — 6 dead-weight MCP servers still configured per `.claude/MCP_ACTION_PLAN.md`. This requires manual Claude Desktop restart but the plan should be documented.

5. **Per-agent `permissionMode`** — Codex said this is more meaningful than `color` for KR. Consider:
   - Reviewers (code-reviewer, arabic-reviewer, spec-auditor-a/b): `permissionMode: plan` (read-only, can't modify code they review)
   - Builders (spec-writer, test-engineer): `permissionMode: acceptEdits`
   - Researchers (deep-researcher): `permissionMode: default` (needs web access approval)

6. **Per-agent `isolation: worktree`** — Some agents should work in isolated copies:
   - spec-adversary (adversarial testing shouldn't touch main working tree)
   - deep-researcher (web searches shouldn't block main session)

7. **Agent skill preloading expansion** — code-reviewer and arabic-reviewer have `skills:` preloading. Consider adding to:
   - spec-writer: preload spec-examples, domain-glossary
   - test-engineer: preload arabic-text (tests must use real Arabic fixtures)
   - spec-auditor-a/b: preload knowledge-safety

8. **Verify the `acceptEdits` + `ask` rules actually work** — The previous session changed defaultMode from bypassPermissions to acceptEdits and added ask rules. Verify that destructive commands now prompt for confirmation and that normal operations (Read, Write, Edit, pytest, git commit) still work without prompting.

## Your Audit Should Also Check

Beyond the listed issues, independently audit:

- **Frontmatter validity**: Parse every agent .md and skill SKILL.md for valid YAML frontmatter. Flag any missing required fields.
- **Hook consistency**: Verify every hook command path exists on disk. Flag orphaned hooks pointing to non-existent scripts.
- **Cross-references**: Check that agent descriptions reference valid skill names in `skills:` field.
- **Settings.json schema compliance**: Validate against the JSON schema at https://json.schemastore.org/claude-code-settings.json
- **Redundant hooks**: The Codex review noted circuit-breaker and cost-guard each have 2 identical Bash matchers in PreToolUse. Should be 1 each.
- **Test suite health**: Run `python -m pytest engines/*/tests/ shared/*/tests/ -q` to verify nothing is broken.

## Key Files to Read First
1. `.claude/settings.json` — the full settings after changes
2. `.claude/HOOK_WIRING.md` — stale documentation to fix
3. `.claude/MCP_ACTION_PLAN.md` — MCP cleanup plan
4. `scripts/verify_metadata_flow.py` — stale validation script
5. `tools/check_cross_engine_contracts.py` — stale validation script
6. `.claude/hooks/stop-quality-gate.sh` — references the stale scripts
7. A sample of 5+ agent .md files to assess description quality

## Codex Review (for reference)
The full Codex (GPT-5.4) review is at `/tmp/codex_review.txt`. Key verdict: "Roughly half is useful after rewrite, the rest is either low-ROI polish or cargo-culting." The review correctly caught: bypassPermissions incompatibility, stop-loop risks, cargo-cult /careful and /freeze skills, memory contamination across worktrees, stale validation scripts as higher-value than cosmetic changes.

Use Codex CLI (`codex exec`) as a fresh pair of eyes at every major checkpoint during this session too.
```
