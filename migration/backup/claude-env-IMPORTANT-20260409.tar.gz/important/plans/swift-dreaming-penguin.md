# Plan: Install Office-Word-MCP-Server for Word Document Creation

## Context

The user has an upcoming project requiring encyclopedic entries written in Word (.docx) format. We need an MCP server that provides rich document creation capabilities (headings, formatting, tables, footnotes, styles, page breaks).

**Chosen server:** [Office-Word-MCP-Server](https://github.com/GongRzhe/Office-Word-MCP-Server) by GongRzhe — the most feature-complete Word MCP server available.

## Step 1: Install dependencies

```bash
pip install python-docx python-pptx docx2pdf
```

## Step 2: Clone and set up the MCP server

```bash
cd ~/.claude
git clone https://github.com/GongRzhe/Office-Word-MCP-Server.git
cd Office-Word-MCP-Server
pip install -r requirements.txt
```

## Step 3: Add MCP server configuration

Add to `~/.claude/settings.json` under `mcpServers`:

```json
{
  "mcpServers": {
    "office-word": {
      "type": "stdio",
      "command": "python",
      "args": ["C:/Users/Rayane/.claude/Office-Word-MCP-Server/word_mcp_server.py"]
    }
  }
}
```

## Step 4: Verify

- Restart Claude Code (or run `/mcp` to check server status)
- Test by creating a simple Word document

## Verification

- [ ] MCP server shows as connected in `/mcp`
- [ ] Can create a test .docx file
- [ ] Basic formatting works (headings, bold, tables)
