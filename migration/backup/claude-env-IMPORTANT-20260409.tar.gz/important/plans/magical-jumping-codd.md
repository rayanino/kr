# Critical Self-Analysis: Source Engine Pre-Step-3 Audit

## Context

I executed the Pre-Step-3 Exhaustive Audit plan: ran all tests, applied 5 code fixes (B1-B5), re-verified tests, confirmed Phase A metrics, and updated documentation. The user asked for a critical self-analysis to ensure the source engine is truly ready for Step 3.

Three parallel deep-dive agents verified: (1) B2 enum validity, (2) test count discrepancy, (3) all fix correctness.

---

## Verified Correct (No Issues)

| Item | Status | Evidence |
|------|--------|----------|
| B1: Lock acquisition tracking | CORRECT | `sources_acquired` flag properly gates release; LIFO release order in finally block |
| B3: Genre chain warning | CORRECT | `_log` is module-level, `gc.relation_type` is in scope, ValueError is the right exception |
| B4: Staging cleanup logging | CORRECT | `exc` captured, `source_id` in scope, `_log` accessible |
| B5: Exception types | CORRECT | `(OSError, RuntimeError)` covers FileLock.release() failures; `filelock.Timeout` only on acquire |
| "mixed" enum validity | CONFIRMED | `StructuralFormat.MIXED = "mixed"` exists at `contracts.py:112` |
| SPEC alignment | CONFIRMED | `SPEC_CORE.md:1094` mandates "mixed" as conservative default |
| Phase A metrics | MATCH | title_full=2519 (100%), author_name_raw=2423 (96.2%), muhaqiq=1350 (53.6%), errors=0 |

---

## Issue Found: B2 ValueError Fallback Inconsistency

**File:** `engines/source/src/engine.py:405-409`

**Current code (after my B2 fix):**
```python
structural_format_val = inference.structural_format or "mixed"  # ← Fixed (was "prose")
try:
    structural_format = StructuralFormat(structural_format_val)
except ValueError:
    structural_format = StructuralFormat.PROSE  # ← INCONSISTENT! Should be MIXED
```

**The problem:** I fixed the None/falsy path (line 405: `or "mixed"`) but left the ValueError path (line 409) falling back to `PROSE`. This is inconsistent with:

1. **The SPEC:** "set the field to the most conservative value... 'mixed' for structural_format" — applies to ALL unknown cases, not just None.
2. **The genre/authority_level pattern** right next to it:
   - `genre`: `or "other"` + `Genre.OTHER` — CONSISTENT
   - `authority_level`: `or "modern_compilation"` + `AuthorityLevel.MODERN_COMPILATION` — CONSISTENT
   - `structural_format`: `or "mixed"` + `StructuralFormat.PROSE` — **INCONSISTENT**
3. **The inference layer itself** at `metadata_inference.py:279`: `validate_enum_value("novel_format", StructuralFormat, {}, "mixed")` — falls back to "mixed".

**Risk assessment:** LOW. The inference layer catches invalid values before they reach engine.py. The ValueError path at line 409 is defense-in-depth that should rarely trigger. But it's still wrong and trivial to fix.

**Fix:** Change line 409 from `StructuralFormat.PROSE` to `StructuralFormat.MIXED`.

---

## Issue Found: Test Count Documentation Was Already Wrong

**Old NEXT.md claimed:** "768 tests passing, 22 skipped"
**Actual verified count:** 548 passing (source + shared tests), or 549+22 if including normalization

**Root cause:** The "768" was an inflated count, likely from AST-level function counting that double-counted parametrized tests. **No tests have been lost** — this was a pre-existing documentation error, not a regression.

**My fix:** I wrote "548 tests passing" in the engine CLAUDE.md update, which is the correct count for `python -m pytest engines/source/tests/ shared/*/tests/`. This is accurate.

---

## Non-Issues Investigated and Cleared

| Concern | Status | Reasoning |
|---------|--------|-----------|
| Phase A ran cached (--resume) | OK | B1-B5 don't touch extraction. Cached results ARE the post-fix baseline. |
| Quality gate Unicode crashes | OK | Windows cp1252 display issue, not functional failure. Underlying checks pass with PYTHONIOENCODING=utf-8. |
| `_safe_remove_lock` bare except | OK | By design ("Never raises" docstring). Cleanup wrapper, not data path. |
| 22 skipped tests | OK | All in normalization engine (deferred, not source engine). |
| metadata_flow 6 boundary warnings | OK | Static analysis false positives for engines not yet built. |

---

## Final Verdict: Source Engine Readiness for Step 3

**Status: READY, with one trivial fix needed.**

The source engine is solid for Step 3. The one remaining fix (ValueError fallback → MIXED) is:
- 1 line change
- Defense-in-depth only (inference layer already handles this)
- Consistent with the SPEC and adjacent code patterns
- Zero risk of regression

---

## Execution Plan

1. Fix the ValueError fallback: `engine.py:409` → `StructuralFormat.MIXED`
2. Re-run tests to confirm (expected: 548 pass, 0 fail)
3. Commit all changes (B1-B5 fixes + B2 completion + documentation)

---

## Critical Files

| File | Changes |
|------|---------|
| `engines/source/src/engine.py` | B2 (mixed default), B2b (ValueError→MIXED), B3 (genre warning), B4 (cleanup log), logging import |
| `engines/source/src/registries/__init__.py` | B1 (lock tracking), B5 (exception types) |
| `NEXT.md` | Step 3 directive |
| `engines/source/CLAUDE.md` | State update |

## Verification

1. `python -m pytest engines/source/tests/ shared/*/tests/ -v --tb=short` → 548 pass, 0 fail
2. Confirm `engine.py:409` reads `StructuralFormat.MIXED`
3. `git diff --stat` shows exactly 4 files changed
