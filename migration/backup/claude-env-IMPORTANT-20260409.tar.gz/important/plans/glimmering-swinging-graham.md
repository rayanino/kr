# Plan: Source Engine Session 6 — engine.py + logger.py + Integration

## Context

All source engine modules are built and tested (723 tests, 22 skipped) EXCEPT the two final pieces: the pipeline orchestrator (`engine.py`) and its structured logger (`logger.py`). These are the capstone that wires everything together. Session 6 also resolves the two remaining Step 4 blocking conditions (confidence calibration CG-1, author complementarity CG-5) via a full integration run with real LLM calls on all 14 fixtures.

---

## Phase 1: Build `logger.py` + Tests

### File: `engines/source/src/logger.py`

**Class `SourceEngineLogger`** — append-only JSONL writer with batch alert state.

```
__init__(log_path: Path | None = None)
  - Default: Path("library/logs/source_engine.jsonl")
  - mkdir parents, init batch state: _batch_error_codes (Counter), _batch_source_count (int), _fatal_seen (bool), _batch_severity_counts (Counter)

log_error(error: SourceError) -> None
  - Build record: error.model_dump(mode="json") + {"type": "error"} prepended
  - Append as JSON line (ensure_ascii=False)
  - Update: _batch_error_codes[error.error_code.value] += 1, _batch_severity_counts[error.severity.value] += 1
  - If error.severity == FATAL: _fatal_seen = True

log_event(event_type: str, source_id: str | None, message: str, context: dict | None = None) -> None
  - Build: {"type": "event", "timestamp": now_utc_iso, "source_id": source_id, "event": event_type, "message": message}
  - Append context if provided
  - If event_type == "intake_start": _batch_source_count += 1

check_alerts() -> list[str]
  - Alert 1: _fatal_seen → "ALERT: Fatal error during batch processing"
  - Alert 2: For each code in _batch_error_codes, if count > 0.10 * _batch_source_count (and _batch_source_count > 0): "ALERT: >10% of sources hit {code}"
  - Alert 3: get_pending_count() > 20 → "ALERT: Human gate queue exceeds 20"

get_batch_stats() -> dict
  - {"total_sources", "fatal_seen", "by_error_code": dict(_batch_error_codes), "by_severity": dict(_batch_severity_counts)}

reset_batch() -> None
  - Reset all counters
```

**Imports**: `json`, `datetime`, `Counter`, `SourceError`, `ErrorSeverity` from contracts, `get_pending_count` from `shared.human_gate.src.human_gate`

### Tests: `engines/source/tests/test_logger.py` (7 tests)

1. `test_log_error_jsonl_format` — Log SourceError, read back, verify JSON structure
2. `test_log_event_jsonl_format` — Log event, verify format
3. `test_append_only` — 3 writes, verify 3 lines
4. `test_alert_fatal_during_batch` — Fatal error → alert
5. `test_alert_same_warning_threshold` — >10% same code → alert
6. `test_alert_gate_queue_threshold` — Mock `get_pending_count` → 25, verify alert
7. `test_no_alerts_normal_operation` — Normal batch → empty alerts

### Verification
```bash
python -m pytest engines/source/tests/test_logger.py -v --tb=short
```

---

## Phase 2: Build `engine.py` + Orchestration Tests

### File: `engines/source/src/engine.py`

**4 public functions:**
- `async def acquire_source(source_path, config=None) -> SourceMetadata`
- `def acquire_source_sync(source_path, config=None) -> SourceMetadata`
- `def startup_cleanup(config=None) -> list[str]`
- `async def acquire_batch(source_paths, config=None) -> list[tuple[Path, SourceMetadata | SourceError]]`

### 13-Step Data Flow in `acquire_source`

All imports verified against actual codebase signatures:

**Step 1 — Config + Logger init**
- `load_config()` from `engines.source.src.config`
- `SourceEngineLogger(config.library_root / "logs" / "source_engine.jsonl")`

**Step 2 — stage_source**
- `stage_source(source_path, config, existing_source_ids)` → `StagingResult`
- existing_source_ids loaded from `source_registry.load(registry_path=...)`.keys()
- On error: log, raise (no lock to clean yet if staging fails before lock creation)

**Step 3 — extract_metadata**
- `extract_metadata(staging_result.source_path, staging_result.source_format)` → dict
- On error: set source_id on error, log, clean lock, raise

**Step 4 — infer_metadata** (async)
- `await infer_metadata(extracted, staging_result.source_format)` → `MetadataInferenceResult`
- On error: log, clean lock, raise

**Step 5 — check_exact_duplicate**
- `source_reg = source_registry.load(registry_path=...)`
- `check_exact_duplicate(staging_result.composite_hash, source_reg)` → Optional[str]
- If match: make_error(DUPLICATE_EXACT, severity=WARNING), log, clean lock, raise

**Step 6 — Register author** (BEFORE freeze, BEFORE register_source)
- `inference.author_reference` is a dict with keys: `name_arabic`, `death_date_hijri`
- School: from `inference.canonical_output.author_identification.school_affiliations` — extract first value or None
  - `school_affiliations` is `Optional[dict[str, Optional[str]]]` — keys are school names, values are optional descriptions
  - Pass first key as the school string
- `lookup_or_register_author(name, death_date_hijri, school, source_id, registry_path=...)` → `(ScholarReference, Optional[str])`
- If gate_id returned → add to human_gates list

**Step 7 — Register muhaqiq** (if extracted has muhaqiq_name_clean or muhaqiq_name_raw)
- `lookup_or_register_muhaqiq(muhaqiq_name, source_id, registry_path=...)` → ScholarReference

**Step 8 — freeze_source**
- `freeze_source(staging_result.source_path, source_id, config.library_root, staging_result.file_hashes, staging_result.file_timestamps)` → `FreezeResult`
- FreezeResult fields: `source_id`, `frozen_path` (Path), `frozen_hash`, `frozen_file_hashes`, `file_count`

**Step 9 — Assemble SourceMetadata**

Field mapping (all verified against contracts.py SourceMetadata):

```
title_arabic = extracted.get("display_title") or extracted.get("title_full") or extracted.get("title_arabic") or ""
work_id = generate_work_id(author_ref.name_arabic, title_arabic, config.transliteration)
human_label = generate_human_label(title_arabic, config.transliteration)
text_fidelity, text_fidelity_reason = _compute_fidelity(source_format, extracted)
confidence_scores = InferredFieldConfidence from inference.confidence_scores dict
text_layers = [TextLayer(layer_type=..., author=ScholarReference via lookup_or_register_author) for each layer]
scholarly_context = ScholarlyContext(**inference.canonical_output.scholarly_context.model_dump()) if present
genre_chain = GenreChain(relation_type, base_work_title, base_work_author, confidence) if present
volumes = [VolumeInfo(**v) for v in extracted.get("volumes", [])]
```

Check work-level duplicate BEFORE register_source:
- `work_reg = work_registry_store.load(registry_path=...)`
- If `work_id in work_reg`: log_event("work_duplicate", ...) — Info only, don't abort

**Step 10 — evaluate_trust** (BEFORE registration)
- Load scholar record: `get_all(registry_path=...)` → get `author_record` by `author_ref.canonical_id`
- `evaluate_trust(author_ref, author_record, muhaqiq_name, publisher, authority_level, text_fidelity, source_id, recognized_muhaqiqs=config.recognized_muhaqiqs, known_publishers=config.known_publishers)` → `(TrustTier, float, list[TrustworthinessFactor], str)`
- Update metadata trust fields
- Create human gates: inference.needs_human_gate triggers, low confidence fields, trust flagged

**Step 11 — validate_source_metadata**
- `validate_source_metadata(metadata.model_dump(mode="json"), registries=...)` → list[ValidationError]
- Fatal validation errors → make_error(SCHEMA_VIOLATION), log, clean lock, raise

**Step 12 — register_source**
- `register_source(metadata, library_root=config.library_root, config=config)` → None

**Step 13 — Move staging to .processed/, remove lock**
- `shutil.move(staging_result.source_path, config.staging_path / ".processed" / source_id)`
- `remove_staging_lock(lock_path)`
- `logger.log_event("intake_success", source_id, ...)`

### Helper Functions
- `_safe_remove_lock(lock_path)` — remove lock if exists, never raises
- `_compute_fidelity(source_format, extracted)` → (TextFidelity str, reason str) — format-based + quality issues
- `_build_text_layers(inference, source_id, config)` → list[TextLayer] — registers each layer author
- `_build_scholarly_context(inference)` → Optional[ScholarlyContext]
- `_build_genre_chain(inference)` → Optional[GenreChain]
- `_build_confidence_scores(inference)` → InferredFieldConfidence

### Error Handling Pattern
- Each step in try/except SourceEngineError
- Caught → log_error, clean lock (if acquired), re-raise
- Lock cleanup in finally block wrapping steps 3-13 (step 2 creates the lock)
- `acquire_batch`: sequential processing, each source independent, error → SourceError in result tuple

### Tests: `engines/source/tests/test_engine.py` (15 tests)

All mock `infer_metadata` to avoid LLM calls. Use `tmp_path` for isolated library.

| # | Test | What it verifies |
|---|------|-----------------|
| 1 | test_acquire_shamela_simple | Happy path on 03_fiqh fixture |
| 2 | test_acquire_plain_text | Plain text path on alfiyyah |
| 3 | test_acquire_exact_duplicate | Pre-populated hash → SRC_DUPLICATE_EXACT |
| 4 | test_acquire_work_duplicate | Pre-populated work_id → Info logged, source still acquired |
| 5 | test_acquire_consensus_disagreement | needs_human_gate=True → gate created |
| 6 | test_acquire_low_confidence | confidence < 0.50 → gate created |
| 7 | test_acquire_staging_modified | File modified after staging → SRC_STAGING_MODIFIED |
| 8 | test_acquire_empty_input | Empty dir → SRC_EMPTY_INPUT |
| 9 | test_acquire_unsupported_format | .pdf → SRC_UNSUPPORTED_FORMAT |
| 10 | test_acquire_batch_isolation | Batch of 3, #2 fails, #1 and #3 succeed |
| 11 | test_startup_cleanup_orphaned_lock | Old lock → cleaned |
| 12 | test_startup_cleanup_orphaned_reg | Orphaned pending_registration → recovered |
| 13 | test_metadata_assembly_completeness | All required fields populated |
| 14 | test_staging_moved_to_processed | Source dir moved to .processed/ |
| 15 | test_status_transition | status == ACQUIRED |

**Mock fixture pattern:**
```python
@pytest.fixture
def mock_inference(monkeypatch):
    def _factory(result):
        async def _mock(extracted, source_format, staging_context=None):
            return result
        monkeypatch.setattr("engines.source.src.engine.infer_metadata", _mock)
    return _factory
```

### Verification
```bash
python -m pytest engines/source/tests/test_engine.py -v --tb=short
python -m pytest --ignore=reference/ -q  # Full regression
```

---

## Phase 3: Error Path Tests

### File: `engines/source/tests/test_error_paths.py` (~19 tests)

Each test verifies a specific error code fires correctly through the engine:

| Error Code | Trigger Strategy |
|-----------|-----------------|
| SRC_EMPTY_INPUT | Empty dir to acquire_source |
| SRC_UNSUPPORTED_FORMAT | .pdf file |
| SRC_FORMAT_STRUCTURE_MISSING | .htm without PageText div |
| SRC_ENCODING_SUSPECT | File with U+FFFD chars |
| SRC_PAGE_COUNT_MISMATCH | Crafted fixture or mock extraction |
| SRC_CONTENT_MINIMAL | Source with <3 pages |
| SRC_HIGH_EMPTY_RATIO | Source with >25% empty pages |
| SRC_CONSENSUS_DISAGREEMENT | Mock inference disagreement |
| SRC_LOW_CONFIDENCE | Mock confidence < 0.50 |
| SRC_AUTHOR_AMBIGUOUS | Mock ambiguous scholar match |
| SRC_ATTRIBUTION_DISPUTED | Mock disputed attribution |
| SRC_METADATA_INCONSISTENCY | Mock inconsistent genre/format |
| SRC_DUPLICATE_EXACT | Pre-populated hash in registry |
| SRC_DUPLICATE_WORK | Pre-populated work_id (Info, not error) |
| SRC_STAGING_MODIFIED | Modify file after staging |
| SRC_FREEZE_COPY_CORRUPT | Mock freeze hash mismatch |
| SRC_SCHEMA_VIOLATION | Malformed metadata dict |
| SRC_MULTI_LAYER_VIOLATION | is_multi_layer=True, empty layers |
| SRC_REGISTRATION_INTERRUPTED | Orphaned pending_registration file |

**Strategy**: Errors in steps 1-3 (SRC_EMPTY_INPUT through SRC_HIGH_EMPTY_RATIO) use crafted minimal fixture files. Errors in step 4 (inference) use mocked `infer_metadata`. Errors in steps 5+ use pre-populated registries or mocked functions.

### Verification
```bash
python -m pytest engines/source/tests/test_error_paths.py -v --tb=short
```

---

## Phase 4: Integration Script + Run

### File: `scripts/run_session6_integration.py`

**Design:**
1. Verify ANTHROPIC_API_KEY and OPENROUTER_API_KEY env vars set
2. Load GROUND_TRUTH.json
3. For each of 14 fixtures (13 shamela_real + alfiyyah_versified):
   - Create isolated temp library (registries, logs, config, sources, gates)
   - Copy fixture to temp staging dir
   - `await acquire_source(staging_path, config)`
   - Compare result against ground truth: genre, author, trust_tier matches
   - Save per-fixture JSON to `tests/results/source_engine/session6/{fixture}.json`
   - Extract confidence_scores and per-model responses for 6e analysis
4. Generate `SESSION6_SUMMARY.json` with aggregate stats
5. Run on 03_fiqh FIRST to verify format, then all 14
6. Hard cost ceiling: $5

**Output per fixture:**
```json
{
  "source_id": "src_...", "fixture": "03_fiqh",
  "extraction": {...}, "inference": {...}, "trust": {...},
  "registration": {...}, "validation": {...},
  "ground_truth": {"genre_match": true, "trust_match": true, "author_match": true}
}
```

### Verification
```bash
python scripts/run_session6_integration.py  # ~$1-2 API cost
```

---

## Phase 5: Analysis Documents + Boundary Verification

### 6e: `tests/results/source_engine/session6/CONFIDENCE_ANALYSIS.md`
- Table: fixture × field × confidence score
- Flag overconfident wrong answers (>0.90 on wrong fields)
- Evaluate 0.50/0.70 threshold gate rates
- CG-1 conclusion

### 6e: `tests/results/source_engine/session6/AUTHOR_COMPLEMENTARITY.md`
- Table: fixture × model_a_author × model_b_author × ground_truth
- Agreement rate, per-disagreement correctness
- CG-5 conclusion

### 6f: Boundary verification (in integration script or separate)
```python
NORMALIZATION_REQUIRED_FIELDS = [
    "source_id", "source_format", "work_id", "text_fidelity",
    "structural_format", "is_multi_layer", "genre", "volume_count"
]
```
Verify: all fields present/non-null, frozen/ exists, source_format in {"shamela_html", "plain_text"}

---

## Critical Files to Modify/Create

| File | Action | Lines (est.) |
|------|--------|-------------|
| `engines/source/src/logger.py` | Replace stub | ~90 |
| `engines/source/src/engine.py` | Replace stub | ~350 |
| `engines/source/tests/test_logger.py` | Create | ~150 |
| `engines/source/tests/test_engine.py` | Create | ~500 |
| `engines/source/tests/test_error_paths.py` | Create | ~450 |
| `scripts/run_session6_integration.py` | Create | ~250 |
| `tests/results/source_engine/session6/CONFIDENCE_ANALYSIS.md` | Create | ~80 |
| `tests/results/source_engine/session6/AUTHOR_COMPLEMENTARITY.md` | Create | ~80 |

## Existing Code to Reuse (DO NOT rebuild)

- `engines/source/src/config.py` — `load_config()`, `SourceEngineConfig` (102 lines, complete)
- `engines/source/src/staging.py` — `stage_source()`, `remove_staging_lock()`, `cleanup_orphaned_locks()`
- `engines/source/src/extractors/__init__.py` — `extract_metadata()`
- `engines/source/src/metadata_inference.py` — `infer_metadata()`
- `engines/source/src/deduplication.py` — `check_exact_duplicate()`
- `engines/source/src/registries/scholar_registry.py` — `lookup_or_register_author()`, `lookup_or_register_muhaqiq()`
- `engines/source/src/registries/__init__.py` — `register_source()`, `check_orphaned_registrations()`
- `engines/source/src/registries/source_registry.py` — `load()` function
- `engines/source/src/registries/work_registry_store.py` — `load()` function
- `engines/source/src/freezer.py` — `freeze_source()`
- `engines/source/src/trust_evaluator.py` — `evaluate_trust()`
- `engines/source/src/validation.py` — `validate_source_metadata()`
- `engines/source/src/text_utils.py` — `generate_work_id()`, `generate_human_label()`
- `engines/source/src/human_gate.py` — 5 gate convenience functions
- `engines/source/src/exceptions.py` — `make_error()`, `SourceEngineError`
- `shared/scholar_authority/src/scholar_authority.py` — `get_all()`
- `shared/human_gate/src/human_gate.py` — `get_pending_count()`

## Verification Plan

After each phase:
```bash
# Phase 1: Logger
python -m pytest engines/source/tests/test_logger.py -v --tb=short

# Phase 2: Engine
python -m pytest engines/source/tests/test_engine.py -v --tb=short
python -m pytest --ignore=reference/ -q  # Full regression (expect 723+ pass)

# Phase 3: Error paths
python -m pytest engines/source/tests/test_error_paths.py -v --tb=short

# Phase 4: Integration (real LLM calls, ~$1-2)
python scripts/run_session6_integration.py

# Phase 5: Boundary check
python -c "import json; [print(f) for f in ['source_id','source_format','work_id','text_fidelity','structural_format','is_multi_layer','genre','volume_count'] if ...]"
```

Final regression:
```bash
python -m pytest --ignore=reference/ -q  # All tests still pass
```
