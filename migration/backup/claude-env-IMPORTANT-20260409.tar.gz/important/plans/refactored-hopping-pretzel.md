# Plan: Session 7 Architect Review — 3-Round Protocol

## Context

Session 7 was the final normalization engine build session (testing only, zero implementation changes). CC produced commit `26a5ed2` against handoff `c69af30`. The review follows `reference/protocols/REVIEW_PROTOCOL.md` — the governing document. Two verdicts only: ACCEPT or BLOCKED.

**Scope:** 4 files changed, 605 insertions, 0 deletions in `src/`.

**Files modified:**
- `engines/normalization/tests/test_integration.py` — NEW (579 lines)
- `engines/normalization/tests/test_kr_output.py` — skip reason updates only
- `engines/normalization/CLAUDE.md` — metrics update
- `engines/normalization/KNOWN_LIMITATIONS.md` — L-012 addition

**Skills used:** kr-reviewing-cc-output (v3 from repo), REVIEW_PROTOCOL.md (governing authority). `critical-review` skill not found in repo — F1-F4 fixes are embedded in the NEXT.md handoff.

---

## Round 1 — Structural (separate response)

### 1.1 Verify no src/ changes
```bash
git diff --name-only c69af30..26a5ed2 -- engines/normalization/src/
```
Must return empty.

### 1.2 Read every modified file in full
Already read during planning:
- [x] test_integration.py (579 lines) — need function/class count verified by grep
- [x] test_kr_output.py diff — 12 skip message changes
- [x] CLAUDE.md diff — 2 lines changed
- [x] KNOWN_LIMITATIONS.md diff — 12 lines added

**RULE 7 verification:** After reading each file, state function/class count and verify with grep:
```bash
grep -c "def " engines/normalization/tests/test_integration.py
grep -c "class " engines/normalization/tests/test_integration.py
```

### 1.3 Run full test suite
```bash
python -m pytest engines/normalization/tests/ -v --tb=short
```
Expected: ~420 passed, ~14 skipped, 0 failed.
Verify 63 individual PASSED lines in TestFixtureIntegration.

### 1.4 Cross-engine contract check (RULE 3)
Session 7 is testing-only — should NOT modify any contract types. Verify:
```bash
git diff c69af30..26a5ed2 -- engines/normalization/contracts.py
```
Must return empty.

Also run cross-engine checker:
```bash
PYTHONIOENCODING=utf-8 python tools/check_cross_engine_contracts.py
```

### 1.5 Inventory: NEXT.md requested vs delivered

| NEXT.md Item | Delivered? | Verify |
|---|---|---|
| A1: 9 Shamela integration tests | ? | Count test methods in TestShamelaNormalizer |
| A2: 3 content flagger tests | ? | Count test methods in TestContentFlagger |
| A3: 1 deferred census skip | ? | Verify test_census_deferred exists and skips |
| B: 63 parametrized fixture tests with F1 page-loss | ? | Count FIXTURES, verify F1 assertion |
| C: 3 normalize_and_write tests (F3 plain text) | ? | Count test methods in TestNormalizeAndWrite |
| D: 8 ADV tests | ? | Count test methods in TestAdversarialGap |
| E: test_kr_output.py skip updates (11 + 1 census) | ? | Verify all 12 skips updated |
| F: CLAUDE.md metrics update (ADV 30→29 correction) | ? | Check the diff for correction |
| F: KNOWN_LIMITATIONS.md L-012 | ? | Verify L-012 added |
| Do NOT Do #1-7 compliance | ? | Verify no violations |

### 1.6 Key concerns to investigate in Round 1
- **CLAUDE.md ADV count:** Was 30/51 corrected to 29/51 before adding Session 7 numbers? The diff shows old="30/51" → new="37/51". The NEXT.md said the correct pre-Session-7 count was 29/51. Investigate if this means 29+8=37 or 30+7=37.
- **Test count claim:** "420 tests passing" — verify with pytest output
- **14 skips claim:** Verify — should be 12 in test_kr_output.py + 1 census + 1 ADV-038
- **"Do NOT Do #5":** NEXT.md said "Do NOT add parametrized pytest tests for individual files from shamela-export-samples/". Verify compliance.

---

## Round 2 — Adversarial (separate response, after "continue")

### 2.1 F1 — Page-loss check depth
Read the actual assertion code in `test_normalize_source_all_fixtures`. Verify:
- It imports BeautifulSoup
- It reads raw HTML
- It counts `<div class='PageText'>` tags
- It compares to `len(content_units)` with tolerance 5

### 2.2 F2 — Boundary continuity real signals
Read `test_boundary_continuity_signals`. Verify:
- It checks `>=2 distinct types` (not just "is not None")
- It verifies `confidence > 0`
- It runs on `01_nahw_simple` fixture

### 2.3 F3 — Plain text normalize_and_write
Read `test_plain_text_normalize_and_write`. Verify:
- It calls `normalize_and_write()` (not just `normalize_source()`)
- It passes `source_format='plain_text'`
- It verifies output files exist

### 2.4 F4 — "Do NOT Do #5"
Verify no parametrized tests reference `shamela-export-samples/`. Only `shamela_real/` and `shamela_extended/` should be in the fixture discovery.

### 2.5 ADV test tautology check
For each of 8 ADV tests:
1. Read ADV description from `reference/SPEC_ADVERSARY_NORMALIZATION.md`
2. Read the test
3. Verify the test actually distinguishes correct from naive-wrong behavior

### 2.6 Probing scripts (3+ required)
Run constructed inputs through the pipeline:
- Probe 1: Duplicate page numbers (ADV-020) — verify output
- Probe 2: Trailing diacritics (ADV-022) — verify preservation
- Probe 3: Page number overflow (ADV-049) — verify no crash

### 2.7 Fixture spot-checks (2+ required)
Run normalize_source on 2 fixtures, print actual output values, compare to test assertions:
- Spot-check 1: 04_hadith — verify hadith flag count matches test assertion (>=30)
- Spot-check 2: 02_nahw_muhaqiq — verify multi-layer count matches test assertion (>=3)

### 2.8 SPEC concrete example trace (RULE 5)
Trace at least 1 SPEC worked example through the implementation.

### 2.9 Cross-engine data flow
Verify NormalizedPackage can deserialize into passaging contracts. Read passaging contracts and check field compatibility.

---

## Round 3 — Self-Verification + Verdict (separate response, after "continue")

### 3.1 Verify all factual claims from Rounds 1-2
Every "N functions", "N tests pass", "not implemented" claim gets a tool call verification.

### 3.2 Rationalization check
Re-read every "not a finding" conclusion. Ask: am I explaining it away?

### 3.3 Fill checklist
Copy REVIEW_CHECKLIST_TEMPLATE.md to `reference/archive/sessions/reviews/review_session_7.md`. Fill every checkbox.

### 3.4 Deliver verdict
- ACCEPT if zero unfixed findings, repo clean
- BLOCKED if findings exist

### 3.5 Build metrics
```
Implementation: ~7,797 lines (+0 this session — testing only)
Tests: [N] passing (+[M] this session)
ADV covered: [N]/51
Known limitations: L-001 through L-012
```

---

## Verification

Each round ends with its own verification. The checklist artifact is the final verification — committed before verdict.
