# Session 5b Plan: Registries + Registration Orchestrator

## Context

Session 5a delivered config, scholar authority, human gate, trust evaluator, and validation (447 tests). Session 5b builds the **registration layer** — the modules that persist source/work/scholar data into the library registries and handle crash recovery. All 6 modules are currently stubs with defined signatures. This session is fully deterministic (no API keys needed).

---

## Prerequisites (verify before building)

1. `engines/source/contracts.py` ErrorCode enum must contain:
   - `SCHEMA_VIOLATION`, `MULTI_LAYER_VIOLATION`, `SCHOLAR_NAME_BLOCKED`, `SCHOLAR_SELF_REFERENCE`
2. `engines/source/src/validation.py` ~line 130: error code must be `SRC_DUPLICATE_WORK` (not `SRC_DUPLICATE_DETECTED`)
3. Run `pytest engines/source/tests/ shared/*/tests/ -q` → 447 tests pass

---

## Build Order (6 modules, strict dependency chain)

### Module 1: `engines/source/src/text_utils.py` — Slug Generation (~60 lines added)

**What:** Add slug generation utilities to existing file (already has `strip_tags`, `parse_arabic_ordinal`).

**Implement:**
- `ARABIC_DIACRITICS` — set of 9 Unicode tashkeel marks (U+064B–U+0652, U+0670)
- `TRANSLIT_MAP` — dict of 28 Arabic → Latin char mappings (ب→b, ت→t, etc.)
- `strip_diacritics(text: str) -> str` — remove chars in ARABIC_DIACRITICS
- `transliterate_chars(text: str) -> str` — char-by-char via TRANSLIT_MAP, strip "ال"→"al_", spaces→"_", remove non-alphanumeric, collapse underscores, strip edges
- `generate_slug(arabic_text: str, table: dict) -> str` — (1) longest substring match in table, (2) fallback: strip diacritics + transliterate, (3) truncate 20 chars, (4) if empty: first 8 hex of MD5
- `generate_work_id(author_name, title, transliteration_table) -> str` — `wrk_{author_slug}_{title_slug}`, max 50 chars. Uses table["scholars"] and table["titles"]
- `generate_human_label(title, transliteration_table) -> str` — transliterated, lowercased, underscored, max 30 chars

**Test file:** `engines/source/tests/test_text_utils.py` (add new test class/functions alongside any existing tests)
- Arabic text with diacritics → stripped correctly
- Table lookup: exact match, substring match (longest first), no match → fallback
- Empty input → MD5 hash
- Max length truncation (20 per component, 50 total for work_id, 30 for human_label)
- Known fixtures: السيوطي → suyuti (table hit), unknown scholar → transliteration fallback

**Dependencies:** None (uses only stdlib hashlib, re)

---

### Module 2: `engines/source/src/registries/source_registry.py` (~80 lines)

**What:** Replace stub. Source registry CRUD.

**Implement:**
- `build_entry(metadata: SourceMetadata) -> SourceRegistryEntry` — maps fields: source_id, work_id, human_label, title_arabic, author_canonical_id (from metadata.author.canonical_id), trust_tier, processing_status, frozen_hash, intake_timestamp, acquisition_path
- `load(registry_path: Path) -> dict[str, dict]` — JSON load, empty dict if file missing
- `save(registry_path: Path, data: dict) -> None` — atomic write with .bak (reuse pattern from session5-architecture.md: shutil.copy2 → tempfile → fsync → os.replace)
- `find_by_hash(frozen_hash: str, registry: dict) -> Optional[str]` — linear scan for matching hash, return source_id

**Test:** In `engines/source/tests/test_registries.py`
- build_entry maps all fields correctly from a constructed SourceMetadata
- load from missing file → empty dict
- save creates .bak, file is valid JSON after write
- find_by_hash returns correct source_id or None

**Dependencies:** contracts.py (SourceRegistryEntry, SourceMetadata), pathlib, json, shutil, tempfile

---

### Module 3: `engines/source/src/registries/scholar_registry.py` (~80 lines)

**What:** Replace stub. Thin wrapper around `shared.scholar_authority`.

**Implement:**
- `lookup_or_register_author(name, death_date_hijri, school, source_id, *, registry_path) -> tuple[ScholarReference, Optional[str]]`
  - Call `scholar_authority.lookup()` → get `ScholarMatchResult`
  - If `action == "auto_link"`: return (ScholarReference from existing record, None)
  - If `action == "human_gate"`: create checkpoint via `shared.human_gate.create_checkpoint(trigger=AUTHOR_DISAMBIGUATION)`, return (ScholarReference from best match, checkpoint_id)
  - If `action == "new_record"`: call `scholar_authority.register()` with minimal record, return (ScholarReference from new record, None)
- `lookup_or_register_muhaqiq(muhaqiq_name, source_id, *, registry_path) -> ScholarReference`
  - Same pattern, simpler: muhaqiqs have name only, higher auto-link tolerance

**Key types to use:**
- `ScholarMatchResult` (dataclass from shared/scholar_authority): `.found`, `.record`, `.match_score`, `.action`
- `ScholarReference` (Pydantic from contracts): `.canonical_id`, `.name_arabic`, `.confidence`, `.source_of_identification`

**Test:** In `test_registries.py`
- Auto-link path (score ≥ 0.85) → no checkpoint created
- Human gate path (0.50–0.85) → checkpoint created, checkpoint_id returned
- New record path (< 0.50) → scholar registered, new canonical_id returned
- Muhaqiq registration with name-only

**Dependencies:** shared/scholar_authority (lookup, register), shared/human_gate (create_checkpoint), contracts.py

---

### Module 4: `engines/source/src/registries/work_registry_store.py` (~150 lines)

**What:** Replace stub. Work registry CRUD + relationship edge processing.

**Implement:**
- `build_entry(metadata: SourceMetadata, transliteration_table: dict) -> WorkRegistryEntry` — generates work_id via `text_utils.generate_work_id()`, maps canonical_title, author_canonical_id, genre, science_scope, source_ids=[source_id], preferred_source_id, status="active"
- `build_placeholder(title, author_canonical_id, work_id) -> WorkRegistryEntry` — status="referenced_not_acquired", source_ids=[], preferred_source_id=None
- `create_relationship_edge(from_work_id, to_work_id, relation_type, confidence, discovered_by="source_engine") -> WorkRelationshipEdge`
- `process_genre_chain(metadata: SourceMetadata, work_registry: dict, scholar_registry_path: Path, transliteration_table: dict) -> list[WorkRelationshipEdge]`
  - Extract base work title + author from metadata.genre_chain (list[GenreChain])
  - For each chain entry: search work_registry via `find_by_title_author()`
  - Found → create edge to existing work
  - Not found → create sparse scholar record for referenced author (via scholar_registry), create placeholder work, create edge to placeholder
- `load(registry_path: Path) -> dict[str, dict]` — JSON load
- `save(registry_path: Path, data: dict) -> None` — atomic write with .bak
- `find_by_title_author(title, author_canonical_id, registry) -> Optional[str]` — uses `normalized_name_similarity` ≥ 0.80 for title comparison

**Test:** In `test_registries.py`
- build_entry generates correct work_id format
- build_placeholder has status="referenced_not_acquired", empty source_ids
- process_genre_chain with fixture 11 (همع الهوامع — sharh of جمع الجوامع)
- find_by_title_author with similar titles above/below threshold
- Placeholder creation triggers sparse scholar record

**Dependencies:** text_utils (generate_work_id), scholar_registry (for placeholder authors), name_matching (normalized_name_similarity), contracts.py

---

### Module 5: `engines/source/src/human_gate.py` (~60 lines)

**What:** Replace stub. 5 convenience wrappers for source-engine gate creation.

**Implement** (each constructs appropriate fields_to_review, current_values, alternatives, then calls `shared.human_gate.create_checkpoint()`):
- `gate_author_disambiguation(source_id, candidates, match_score, inferred_name)` — trigger: AUTHOR_DISAMBIGUATION
- `gate_consensus_disagreement(source_id, field, model_a_value, model_b_value, model_a_name, model_b_name)` — trigger: CONSENSUS_DISAGREEMENT
- `gate_low_confidence(source_id, field, value, confidence)` — trigger: LOW_CONFIDENCE_FIELD
- `gate_trust_flagged(source_id, trust_score, trust_factors)` — trigger: TRUST_FLAGGED
- `gate_scholar_conflict(source_id, canonical_id, conflict_type, existing_value, proposed_value)` — trigger: SCHOLAR_CONFLICT

**Test:** In `test_registries.py` or separate `test_human_gate_wrapper.py`
- Each function creates a checkpoint with correct trigger type
- fields_to_review and current_values populated correctly
- Checkpoint persisted (status = pending or auto_approved depending on mode)

**Dependencies:** shared/human_gate (create_checkpoint), contracts.py (HumanGateTrigger enum)

---

### Module 6: `engines/source/src/registries/__init__.py` (~200 lines)

**What:** Replace stub. Registration orchestrator with atomic WAL pattern.

**Implement:**
- `register_source(metadata: SourceMetadata, *, library_root: Path, config: SourceEngineConfig) -> None`
  1. Build SourceRegistryEntry via source_registry.build_entry()
  2. Build/update WorkRegistryEntry via work_registry.build_entry()
  3. Process genre chain → relationship edges + placeholder works
  4. Write `library/logs/pending_registration_{source_id}.json` (RegistryPendingWrite)
  5. Acquire FileLock on sources.json, works.json (30s timeout)
  6. For each registry: create .bak → apply changes → update completed_files in pending
  7. Write `library/sources/{source_id}/metadata.json` (full SourceMetadata as JSON)
  8. Delete pending registration file
  - Lock timeout → raise with REGISTRATION_INTERRUPTED error code
- `check_orphaned_registrations(*, library_root: Path) -> list[str]`
  - Scan for `pending_registration_*.json` in library/logs/
  - Three cases:
    - All registries updated (source_id exists) → delete pending (completed ok)
    - No registries updated → delete pending (never started)
    - Partial → restore from .bak files, delete pending (rollback)
  - JSON parse failure in registry → restore from .bak

**Test:** In `test_registries.py`
- Full registration: pending created → registries updated → metadata.json written → pending deleted
- .bak files created before each write
- metadata.json at correct path, valid SourceMetadata JSON
- Orphan recovery: all-complete case, none-started case, partial-rollback case
- Lock timeout raises correct error

**Dependencies:** All previous modules, filelock, contracts.py (RegistryPendingWrite)

---

## Key Patterns to Reuse

| Pattern | Source | Used By |
|---------|--------|---------|
| Atomic JSON write (temp+fsync+replace) | `session5-architecture.md` | source_registry.save, work_registry.save, orchestrator |
| FileLock with 30s timeout | `shared/scholar_authority/src/scholar_authority.py` | orchestrator lock acquisition |
| ScholarMatchResult action routing | `shared/scholar_authority/src/scholar_authority.py` | scholar_registry routing logic |
| create_checkpoint() call pattern | `shared/human_gate/src/human_gate.py` | human_gate wrappers, scholar_registry |
| normalized_name_similarity | `shared/scholar_authority/src/name_matching.py` | work_registry find_by_title_author |
| load_config() for transliteration | `engines/source/src/config.py` | text_utils, work_registry |

---

## Concerns & Risks

1. **GenreChain model structure**: Need to verify the exact fields on `GenreChain` in contracts.py — process_genre_chain parses this. The exploration showed `work_relationships: list[GenreChain]` on SourceMetadata but I need to confirm GenreChain fields (base_work_title, base_work_author, relation_type).

2. **Lock ordering**: SPEC says scholars are registered in Step 4 (not Step 7). The orchestrator only locks sources.json and works.json. But if process_genre_chain creates sparse scholar records for placeholder authors, that requires scholar_authority.register() which locks scholars.json. This creates a potential lock ordering issue: works.json lock → scholars.json lock (inside process_genre_chain) vs. the Step 4 order (scholars.json first). **Mitigation**: Process genre chain (including scholar registration for referenced authors) BEFORE acquiring registry locks. Only the final source/work JSON writes happen under lock.

3. **save() not in some stubs**: NEXT.md mentions `save()` for source_registry but the stub only has `build_entry`, `load`, `find_by_hash`. Need to add `save()` — trivial since the pattern is defined.

4. **Windows path handling**: All file ops use pathlib.Path. `os.replace()` is atomic on Windows for same-filesystem. `shutil.copy2` for .bak is safe. No concerns here.

5. **Test fixture for genre chain**: NEXT.md says fixture 11 has genre_chain (همع الهوامع — sharh of جمع الجوامع). Need to construct a SourceMetadata dict with this chain for testing, not rely on live extraction output.

---

## Verification

After all 6 modules:
```bash
# Run all tests (expect ~480-490 total)
python -m pytest engines/source/tests/ shared/*/tests/ -v --tb=short

# Specific new test file
python -m pytest engines/source/tests/test_registries.py -v --tb=short
python -m pytest engines/source/tests/test_text_utils.py -v --tb=short

# Verify no regressions in Session 5a modules
python -m pytest engines/source/tests/test_config.py engines/source/tests/test_trust_evaluator.py -v

# Integration check: construct a full SourceMetadata and run register_source()
# in a test with tmp_path to verify end-to-end file creation
```

---

## Target: ~30-40 new tests, 480-490 total, 0 failures
