# Adversarial Critique: KR Factory Roadmap (FACTORY_ROADMAP.md)

## Context

The FACTORY_ROADMAP.md proposes a 10-session, 14-session-effort plan to build a deterministic control plane that autonomously builds KR engines using three coding CLIs (Claude Code, Codex CLI, Gemini CLI) dispatched by a Python orchestrator. The roadmap was written 2026-03-27 using inputs from Claude Chat, GPT-5.4 review, and a CC capabilities report (which the roadmap itself acknowledges was partially fabricated).

**This critique was produced by Claude Code Opus 4.6 running inside the KR repo**, with access to:
- Actual CLI `--help` output for `claude` and `codex exec` (verified on this system)
- The existing `scripts/overnight_orchestrator.py` (1195+ lines of working orchestration code)
- The `.claude/settings.json` hook configuration (19 hook entries)
- A live test of `--json-schema` flag behavior

**Methodology:** Every claim below is backed by a specific file, CLI output, or test result from this repo. No assumptions from training data.

---

## Structured Output

```json
{
  "assumption_audit": [
    {
      "id": 1,
      "assumption": "claude -p can run headlessly and produce structured JSON via --output-format json",
      "verdict": "TRUE",
      "actual_behavior": "Verified in three ways: (1) `claude --help` shows both `-p/--print` and `--output-format json` flags; (2) `scripts/overnight_orchestrator.py` lines 503-505 use exactly this pattern in production; (3) live test returned valid JSON envelope with fields: type, subtype, duration_ms, total_cost_usd, usage, modelUsage, session_id. The JSON envelope wraps CC's response, including a `result` field with the model's output and a `subtype` field for error classification (e.g., 'error_max_turns', 'error_max_budget_usd').",
      "orchestrator_implication": "The orchestrator can rely on this. Parse `result` for model output, `subtype` for error classification, `total_cost_usd` for cost tracking. The overnight_orchestrator.py already demonstrates the correct parsing pattern."
    },
    {
      "id": 2,
      "assumption": "CC reads and acts on CLAUDE.md and .claude/ context automatically in headless mode",
      "verdict": "TRUE — BUT WITH A CRITICAL CAVEAT",
      "actual_behavior": "By default, `claude -p` reads CLAUDE.md and .claude/ from the working directory. HOWEVER: the `--bare` flag (verified in `claude --help`) explicitly says: 'Minimal mode: skip hooks, LSP, plugin sync, attribution, auto-memory, background prefetches, keychain reads, and CLAUDE.md auto-discovery.' If the orchestrator ever uses --bare, ALL project context (13 skills, 15 rules, CLAUDE.md) is silently dropped. The overnight_orchestrator.py does NOT use --bare — it uses --dangerously-skip-permissions which bypasses permission checks but preserves hooks and context.",
      "orchestrator_implication": "The orchestrator MUST NEVER use --bare for build work units. This should be a policy enforcement check. The roadmap never mentions --bare, but it's a single-flag footgun that disables the entire 'deterministic layer' the architecture depends on."
    },
    {
      "id": 3,
      "assumption": "CC can reliably process work units requiring 5+ large files within context window",
      "verdict": "TRUE — capacity is sufficient, quality degradation is the real risk",
      "actual_behavior": "This CC instance has a 1M-token context window (confirmed in system info: 'claude-opus-4-6[1m]'). A typical work unit might need: SPEC.md (~20-40K tokens), contracts.py (~5-10K), engine src/ (~20-30K), test output (~10-20K), CLAUDE.md + rules (~15K) = ~70-115K tokens total. This fits easily. HOWEVER: (1) Arabic text tokenizes at 1.5-2x the rate of English (per .claude/rules/llm-call-optimization.md), so Arabic-heavy SPECs consume more than expected. (2) The 'lost in the middle' phenomenon means details in the middle of very long prompts receive less attention. (3) The live test showed just the INITIAL cache creation for a trivial prompt consumed 57,849 tokens — the system prompt + project context overhead is ~58K tokens before the orchestrator's prompt even starts.",
      "orchestrator_implication": "Budget ~60K tokens for CC's project context overhead. This leaves ~940K for the work unit, which is generous. But the orchestrator should monitor actual token usage from the JSON output (modelUsage.inputTokens) and flag work units that exceed 500K input tokens — quality degrades at extreme lengths."
    },
    {
      "id": 4,
      "assumption": "13 hooks fire correctly in headless mode (not just interactive mode)",
      "verdict": "TRUE — hooks fire, BUT the count is wrong AND overhead is severe",
      "actual_behavior": "Hooks are shell commands executed by the CC harness, not by the model. They fire in headless mode when using `--dangerously-skip-permissions` (verified: overnight_orchestrator.py uses this flag and hooks run). The ACTUAL hook count from settings.json is: 7 PreToolUse + 9 PostToolUse + 2 SessionStart + 1 Stop = 19 hook entries, not 13. The roadmap's count (line 156: '13 hooks (7 PreToolUse, 7 PostToolUse, 2 SessionStart, 1 Stop)') is wrong — PostToolUse has 9 entries, not 7. The 9 PostToolUse hooks fire on EVERY Write/Edit/MultiEdit operation with cumulative worst-case timeout of 225 seconds per edit (ruff 15s + spec-check 5s + arabic-safety 10s + auto-stage 5s + pyright 30s + auto-test 120s + boundary-check 30s + diacritic-preservation 10s + spec-coverage 5s). In a build session with 50 file edits, that's potentially 50 * 225s = 3.1 hours of hook overhead alone.",
      "orchestrator_implication": "The orchestrator's per-work-unit timeout must account for hook overhead. A '15-minute' work unit with 20 file edits could consume 15 min of CC thinking + 75 min of hook execution = 90 minutes total. Either: (a) the orchestrator sets generous timeouts (2-3x the expected CC work time), or (b) certain hooks are disabled for build work units via --allowedTools restrictions or a custom settings overlay. The roadmap addresses none of this."
    },
    {
      "id": 5,
      "assumption": "Agents (e.g., code-reviewer, spec-adversary) can be dispatched as subagents in headless mode",
      "verdict": "TRUE",
      "actual_behavior": "Verified two mechanisms: (1) `claude --help` shows `--agent <agent>` flag: 'Agent for the current session. Overrides the agent setting.' This dispatches the named agent from .claude/agents/ for the entire session. (2) Inside a headless CC session, the Agent tool is available for dispatching subagents mid-work. The overnight_orchestrator.py uses `--agent` at line 514-515 to dispatch named agents. Both mechanisms work in headless mode.",
      "orchestrator_implication": "The orchestrator can dispatch agent-specific sessions (e.g., claude -p --agent code-reviewer). But be aware: agents inherit the same hook overhead. A code-reviewer agent reading files still triggers PostToolUse hooks on any edits. For read-only agents, consider using --allowedTools to restrict to read-only tools, avoiding PostToolUse hooks entirely."
    },
    {
      "id": 6,
      "assumption": "CC can produce artifact bundles (prompt hash, inputs, outputs, git SHA) as part of output",
      "verdict": "PARTIALLY TRUE — stdout JSON is an envelope, not custom-structured; file artifacts work",
      "actual_behavior": "CC's --output-format json produces a FIXED envelope structure: {type, subtype, duration_ms, total_cost_usd, usage, modelUsage, result, session_id, ...}. The 'result' field contains the model's text output. CC CANNOT customize this JSON structure — you get the envelope or nothing. For artifact bundles, CC would need to (a) WRITE files to disk containing the artifact data, then (b) reference them in the result text. The --json-schema flag (verified to exist in CLI help) CAN constrain the model's output to match a schema, but the envelope structure is still wrapped around it. So the model's 'result' field would be schema-conformant JSON, but the outer envelope remains fixed.",
      "orchestrator_implication": "The orchestrator needs TWO parsing strategies: (1) parse the outer JSON envelope for operational data (cost, duration, errors, subtype); (2) parse the inner 'result' field for the model's structured output. If using --json-schema, the 'result' field contains schema-conformant JSON. Without it, 'result' is free text. The roadmap's artifact bundle design should specify whether artifacts go in the result field or on disk. On-disk artifacts are more reliable but require the orchestrator to know where CC wrote them."
    },
    {
      "id": 7,
      "assumption": "CC can run pytest and capture results in headless mode",
      "verdict": "TRUE",
      "actual_behavior": "CC uses the Bash tool to run pytest. This works identically in headless and interactive mode. The overnight_orchestrator.py relies on this (it dispatches tasks that run pytest). Results appear in the Bash tool output within CC's conversation context, and the overall success/failure is reflected in the JSON envelope's exit code. HOWEVER: pytest output for 1600+ tests can be very long. If CC runs 'pytest -v --tb=long', the output may consume significant context window space. Use '-x -q --tb=short' for space-efficient results.",
      "orchestrator_implication": "Works as expected. Recommend the orchestrator's prompts include explicit pytest flags to control output verbosity."
    },
    {
      "id": 8,
      "assumption": "CC can commit and push to git in headless mode",
      "verdict": "TRUE",
      "actual_behavior": "With --dangerously-skip-permissions, CC can run any git command including commit and push. The overnight_orchestrator.py's safety prompt (line 56) explicitly says 'NEVER run git push' — showing that push IS possible but intentionally restricted. The pre-push hook (settings.json line 82-89) runs the full test suite before allowing push, adding ~120s overhead. The pre-commit hook (settings.json line 92-99) also fires. Both hooks run even in headless mode.",
      "orchestrator_implication": "The orchestrator can rely on CC for commits. For pushes, the pre-push hook's 120s pytest run is a safeguard. The overnight system deliberately avoids pushing (the human pushes after reviewing the morning report). The factory roadmap should make the same choice: CC commits locally, orchestrator pushes only after all gates pass."
    },
    {
      "id": 9,
      "assumption": "CC can be called repeatedly by the orchestrator without session state leaking between calls",
      "verdict": "TRUE",
      "actual_behavior": "With --no-session-persistence (verified in CLI help), each CC invocation starts with zero conversation history. Session state is not persisted to disk. HOWEVER: (1) FILESYSTEM state persists between calls — any temp files, modified configs, dirty git state carry over. (2) The auto-staging hook (settings.json line 168) runs 'git add' on every file CC writes, so git's staging area accumulates across work units if the orchestrator doesn't clean it. (3) The .claude/session_state.json file is modified by CC and persists between calls, but this is informational (budget tracking) not operational.",
      "orchestrator_implication": "The orchestrator MUST run 'git status' between work units to detect dirty filesystem state. It should 'git reset --hard && git clean -fd' before each work unit if clean state is required. The existing overnight_orchestrator.py does exactly this (git_is_clean check + git_rollback on failure). This is NOT mentioned in the factory roadmap's orchestrator specification."
    },
    {
      "id": 10,
      "assumption": "--json-schema works reliably for structured output in headless mode",
      "verdict": "UNVERIFIED — flag exists and is accepted, but output not observed",
      "actual_behavior": "The `--json-schema` flag IS listed in `claude --help` with description: 'JSON Schema for structured output validation. Example: {\"type\":\"object\",\"properties\":{\"name\":{\"type\":\"string\"}},\"required\":[\"name\"]}'. A live test confirmed the flag is accepted (no 'unknown flag' error). However, the test was budget-killed before producing output ($0.36 of cache creation cost on Opus 4.6 just for the system prompt, vs the $0.01 budget limit). The result JSON showed stop_reason='tool_use', suggesting --json-schema may work through the tool_use mechanism under the hood. The existing overnight_orchestrator.py does NOT use --json-schema — it parses free-text result fields. No code in this repo demonstrates --json-schema producing conformant output. RELIABILITY IS UNVERIFIED.",
      "orchestrator_implication": "Do not depend on --json-schema in the initial factory build. Instead, use the proven pattern from overnight_orchestrator.py: structured prompts asking for JSON output, then parse the 'result' field with json.loads() and a try/except fallback. If --json-schema proves reliable in testing, migrate to it in a later session. The Codex equivalent is --output-schema <FILE> (takes a file path, not inline JSON) — another divergence the roadmap doesn't address."
    }
  ],

  "missing_requirements": [
    {
      "id": 1,
      "requirement": "CLI flag abstraction layer that handles per-CLI differences",
      "why_needed": "The roadmap's architecture diagram (lines 43-45) shows uniform flags across all three CLIs: '--output-format json' for all. This is FABRICATED for Codex and UNVERIFIED for Gemini. Actual verified flags: Claude Code uses '--output-format json' (single JSON envelope). Codex CLI uses '--json' (JSONL events to stdout) OR '--output-last-message <FILE>' (writes last message to file). Codex has NO '--output-format' flag at all. Gemini CLI is not installed on this system. The existing overnight_orchestrator.py already handles this correctly (lines 501-599): separate _execute_cli() and _execute_codex() functions with different flag sets. Additionally, Codex has a purpose-built 'codex exec review' subcommand (verified via --help) that the roadmap doesn't leverage.",
      "what_happens_without": "Session 3's verification commands (lines 265, 272-273: 'codex exec \"What is 2+2?\" --output-format json') will FAIL immediately, blocking Phase 1 completion. The owner will think Codex is broken when the actual problem is wrong flags."
    },
    {
      "id": 2,
      "requirement": "Structured work-unit response contract between CC and orchestrator",
      "why_needed": "The orchestrator dispatches a work unit and receives JSON back. But the roadmap never defines the response schema. Claude Code's --output-format json produces a fixed envelope with 'result' (model text), 'subtype' (error class), 'total_cost_usd', etc. But the MODEL's output within 'result' is free text. The orchestrator needs to know: Did CC complete the work? Did it get stuck? Did it find a SPEC bug? Did it need a design decision? Without a defined response contract, the orchestrator can only check exit code (0 = probably ok, non-0 = failed). The existing overnight_orchestrator.py parses 'result' as free text and checks 'subtype' for known error types, which works but provides no structured status information.",
      "what_happens_without": "The orchestrator cannot distinguish between 'work unit complete, all tests pass' and 'work unit attempted, but I found a SPEC ambiguity and implemented my best guess' and 'work unit partially complete, 3 tests broken, I couldn't fix them.' All three appear as exit code 0 with different text in 'result'. The orchestrator will advance work units that should be blocked."
    },
    {
      "id": 3,
      "requirement": "SPEC-level escalation path for design decisions in the autonomous loop",
      "why_needed": "D-F010 says 'Claude Chat has no role in the autonomous loop.' But the roadmap provides no alternative for design decisions. Scholarly content decisions go through human gates (D-F009 + Session 8). Deterministic checks are automated. But TECHNICAL design decisions — SPEC ambiguities, architectural trade-offs, conflicting requirements between engines — have no escalation path. The existing ENGINE_FACTORY_PLAN.md had an 'Oracle' agent for this; the FACTORY_ROADMAP replaces it with... nothing. The cross-provider review (Codex + Gemini) can catch implementation errors but cannot resolve design ambiguities — they don't have authority to make design decisions either.",
      "what_happens_without": "CC encounters a SPEC ambiguity, makes its best guess, implements it, tests pass (because the tests reflect CC's interpretation), Codex reviews and approves (because the implementation is internally consistent), and the design decision gets baked into the engine without anyone realizing an ambiguity was silently resolved. This is exactly the 'confident-wrong' failure mode the KR project's QUALITY_AXIOM.md warns about."
    },
    {
      "id": 4,
      "requirement": "Hook overhead budget and management strategy",
      "why_needed": "The 9 PostToolUse hooks fire on every file write/edit with cumulative worst-case timeout of 225 seconds. The roadmap's orchestrator runs every 30 minutes (Session 7). If a work unit involves 20 file edits (typical for implementing a SPEC section), hook overhead alone could be 20 * 225s = 75 minutes — exceeding the 30-minute cycle. The roadmap mentions no strategy for: (a) which hooks to disable for which work unit types, (b) how to calculate effective timeouts including hook overhead, (c) whether to use --allowedTools to restrict tools and thus skip certain hooks. The auto-test hook alone (120s timeout) is the biggest offender — it runs the FULL pytest suite after every single edit.",
      "what_happens_without": "Work units consistently time out. The orchestrator retries, times out again, marks as failed. The factory grinds to a halt because the hook overhead was never budgeted. The irony: the hooks exist for quality, but their overhead prevents work from completing."
    },
    {
      "id": 5,
      "requirement": "Git state hygiene between orchestrator work units",
      "why_needed": "The auto-staging hook (settings.json line 168) runs 'git add $FILE' on every file CC writes. This means after a work unit, git's staging area contains all modified files — even ones from a failed or aborted work unit. Additionally, if CC creates temp files, writes partial implementations, or leaves debug output, these persist on the filesystem for the next work unit. The existing overnight_orchestrator.py handles this with git_is_clean() checks and git_rollback() cleanup (git reset --hard + git clean -fd). The factory roadmap's Session 6 orchestrator specification (lines 361-393) mentions 'commits to git' (step 11) but never mentions cleanup between work units.",
      "what_happens_without": "Work unit N fails, leaving modified files staged in git. Work unit N+1 starts with dirty git state. CC sees uncommitted changes from the previous work unit and either (a) tries to continue from the wrong state, or (b) commits the previous unit's failed work alongside its own. The factory produces corrupt commits."
    },
    {
      "id": 6,
      "requirement": "The existing overnight_orchestrator.py must be referenced and either extended or explicitly replaced",
      "why_needed": "The repo already contains scripts/overnight_orchestrator.py (1195+ lines) and scripts/overnight_task_generator.py (763 lines) — nearly 2000 lines of battle-tested orchestration code with: CLI dispatch (claude + codex), quality gates (5 levels), crash recovery (lock files + heartbeat), morning report generation, SIGINT/SIGBREAK graceful shutdown, correct per-CLI flag handling, PYTHONIOENCODING=utf-8 for Windows, and more. The roadmap's Session 6 proposes building kr_orchestrator.py from scratch with similar but less mature functionality. This either: (a) wastes 2 sessions rebuilding what exists, or (b) creates a parallel system that conflicts with the existing one.",
      "what_happens_without": "Two orchestrators exist in the same repo. Confusion about which one to use. The new one lacks the Windows-specific fixes, the heartbeat monitoring, the graceful shutdown, and the correct Codex flag handling that the existing one already has."
    },
    {
      "id": 7,
      "requirement": "Rate limit handling for all three CLI subscriptions",
      "why_needed": "The '$0 incremental' claim (line 499) is true per-token but ignores subscription rate limits. Claude Code Max has usage quotas (requests/minute, tokens/minute). Codex CLI uses ChatGPT subscription quota. Gemini CLI free tier has aggressive daily limits. At 48 orchestrator cycles/day, each potentially dispatching CC (build) + Codex (review) + Gemini (challenge), that's up to 144 CLI invocations/day. The existing .claude/rules/llm-call-optimization.md mandates exponential backoff with jitter for API rate limits, but the roadmap's Session 3 cli_dispatch.py is specified to 'retry once' only.",
      "what_happens_without": "The factory hits rate limits after 4-6 hours of continuous operation. All three CLIs start returning 429/throttle errors. The 'retry once' logic fails because the limit is time-based, not transient. The factory stalls until the rate limit window resets (typically 1 hour for per-hour limits, 24 hours for daily limits)."
    },
    {
      "id": 8,
      "requirement": "MCP server configuration for headless CC invocations",
      "why_needed": "The benchmark harness (Session 4, line 313) says 'All ground truth must be hand-verified (use web search to verify author attributions, death dates, genre classifications).' Web search in CC is provided by MCP servers (tavily, context7 listed in system prompt). The --mcp-config flag exists (verified in claude --help) and can load MCP servers from JSON config files. But the roadmap never specifies whether headless CC invocations should include MCP config. The settings.json shows enabledPlugins: {'oberskills@rtd': true} but no explicit MCP server configuration for headless mode.",
      "what_happens_without": "CC invocations that need web search (benchmark ground truth verification, scholarly cross-referencing via Usul.ai) silently lack the capability. CC either hallucinates ground truth answers or reports it cannot access web search, failing the work unit."
    }
  ],

  "failure_modes": [
    {
      "scenario": 1,
      "description": "SPEC has an ambiguity; CC cannot ask the architect",
      "actual_behavior": "CC will: (1) attempt to infer the intended behavior from surrounding SPEC context, (2) check if DECISION_PLAYBOOK.md has a relevant precedent, (3) implement its best interpretation, (4) write a note in the result text like 'NOTE: SPEC section 4.3 is ambiguous about X, I interpreted it as Y.' The implementation will be internally consistent, tests will pass (because CC wrote both), and the Codex reviewer will likely approve (because the code matches the tests). The ambiguity becomes silently resolved by CC's interpretation. This is the MOST DANGEROUS failure mode because it produces correct-looking output that embeds an unreviewed design decision.",
      "orchestrator_impact": "The orchestrator has no mechanism to detect 'ambiguity resolved by inference.' The JSON envelope shows exit code 0, tests pass, review passes. The design decision is invisible. To mitigate: (1) the structured response contract should include an 'assumptions_made' field that CC must populate, (2) the orchestrator should flag any work unit with non-empty assumptions for human review, (3) Gemini's adversarial challenge should specifically prompt: 'Were there any ambiguities the builder might have silently resolved?'"
    },
    {
      "scenario": 2,
      "description": "Bug fix breaks 3 other tests; CC runs past the timeout",
      "actual_behavior": "CC will attempt to fix the cascading failures. With hooks active, each edit attempt triggers pyright (30s) + auto-test (120s) + other hooks. After 2-3 edit-test cycles, 10+ minutes have passed. If the orchestrator's timeout is 15 minutes, the subprocess is killed via SIGTERM. On Windows, the behavior depends on whether `Popen.terminate()` or `Popen.kill()` is used. The existing overnight_orchestrator.py uses `process.terminate()` (Python's default), which sends SIGTERM. If CC is mid-git-commit when killed, the git state is corrupted (partially written objects). If mid-file-write, the file may be truncated. The JSON envelope is NOT produced because stdout was never flushed before kill. The orchestrator gets empty stdout or partial JSON.",
      "orchestrator_impact": "The orchestrator must: (1) set timeouts generously (3x expected, to account for hook overhead), (2) always check git state after a timeout (git fsck + git status), (3) have a cleanup function that resets to last known good commit, (4) detect partial/empty JSON as a timeout signal distinct from a crash. The existing overnight_orchestrator.py handles timeouts via _run_subprocess_safe() with explicit process.kill() on timeout and stdout capture. The factory roadmap mentions 'retry once' for failures but does not distinguish timeout from error."
    },
    {
      "scenario": 3,
      "description": "Work unit references a file that doesn't exist (orchestrator config typo)",
      "actual_behavior": "CC will attempt to read the file using the Read tool, get a 'file not found' error, and then either: (a) search for similarly-named files and use those instead (CC is resourceful), (b) report the error in its output and continue with what it can find, or (c) abort the work unit entirely. The most likely outcome is (a) — CC will Glob for the file pattern and find something close, potentially implementing against the WRONG file. This is insidious because CC's output will look correct and tests may pass, but the work unit is targeting the wrong code. The JSON envelope shows exit code 0.",
      "orchestrator_impact": "The orchestrator should: (1) validate all input[] file paths exist BEFORE dispatching the work unit (a 1-line Python check per path), (2) include a checksum or git blob SHA for each input file so CC can verify it's reading the right version. This is a trivial pre-flight check that prevents a class of silent errors. The roadmap's work unit schema (Session 6, line 387) includes 'inputs[]' but specifies no validation."
    },
    {
      "scenario": 4,
      "description": "CC discovers a SPEC bug during implementation",
      "actual_behavior": "CC will: (1) note the SPEC bug in its output text, (2) implement what seems correct despite the SPEC (following the KR principle 'never implement errors'), (3) add a comment in the code like '# SPEC BUG: section 4.3 says X but this should be Y'. The implementation deviates from SPEC. Codex reviews the code and flags the deviation as a 'SPEC compliance failure.' Gemini challenges and agrees with Codex. The orchestrator sees review + challenge both flagging the same issue. But the orchestrator's policy engine expects pass/fail, not 'SPEC needs updating.' The work unit is marked failed, and the same (buggy) SPEC is re-dispatched for the next attempt, creating an infinite loop.",
      "orchestrator_impact": "The orchestrator needs a 'spec_issue' work unit type that can be created mid-execution. When CC encounters a SPEC bug: (1) CC writes a spec_issue artifact describing the bug, the proposed fix, and the evidence, (2) the orchestrator detects this artifact type, (3) pauses the implementation work unit, (4) creates a spec_review work unit for Codex + Gemini, (5) if both agree the SPEC is wrong, queues a spec_fix work unit (which CC implements), (6) then re-dispatches the original implementation work unit. Without this, every SPEC bug creates an infinite retry loop."
    },
    {
      "scenario": 5,
      "description": "Max subscription usage limits hit at call 40 of 48",
      "actual_behavior": "Claude Code CLI returns immediately with a JSON envelope: {type: 'result', subtype: 'error_*', is_error: false/true, ...}. The specific subtype depends on the rate limit type — it could be 'error_max_budget_usd' (if --max-budget-usd is set), or a non-zero exit code with stderr containing the rate limit error. The actual behavior for subscription-level throttling is UNDOCUMENTED — this is a gap in Claude Code's own documentation. The live test showed that even cache creation costs ($0.36 for Opus 4.6 system prompt) count against --max-budget-usd, suggesting the SDK tracks costs even for subscription users. If the subscription limit is hit, the CLI likely returns a non-zero exit code with an error message, but the exact JSON structure for this case is unknown.",
      "orchestrator_impact": "The orchestrator must: (1) track cumulative invocations per day per CLI, (2) implement exponential backoff when any CLI returns a rate-limit error, (3) have a 'throttled' state that pauses all work units for that CLI for a configurable cooldown period (default: 60 minutes), (4) log rate-limit events prominently for the owner's morning report. The roadmap's 'every 30 minutes' schedule may need to become adaptive: slower when approaching rate limits, faster when limits reset."
    }
  ],

  "top_additions": [
    {
      "addition": "Build on the existing overnight_orchestrator.py instead of starting from scratch",
      "rationale": "The repo already contains 2000+ lines of battle-tested orchestration code (scripts/overnight_orchestrator.py + scripts/overnight_task_generator.py) that correctly handles: (a) per-CLI flag differences (Claude Code vs Codex), (b) Windows-specific PYTHONIOENCODING issues, (c) crash recovery with lock files and heartbeat, (d) git state cleanup between work units, (e) graceful SIGINT/SIGBREAK shutdown, (f) 5-level quality gates, (g) morning report generation, (h) cost tracking via total_cost_usd parsing. The factory roadmap's Session 6 proposes building kr_orchestrator.py from scratch with less mature versions of these same features. This wastes 2 sessions of effort and loses hard-won Windows compatibility fixes. Instead: Session 6 should EXTEND the existing orchestrator with the new capabilities (cross-provider dispatch, benchmark routing, artifact provenance), not replace it.",
      "risk_if_missing": "Two competing orchestrators in the same repo. The new one lacks Windows fixes, hook overhead management, and the correct Codex CLI flag handling. The factory is LESS reliable than the existing overnight system it replaces. Sessions 6-7 are wasted on reimplementation instead of net-new features."
    },
    {
      "addition": "A per-CLI abstraction with verified flag mappings and output parsing",
      "rationale": "The three CLIs have fundamentally different interfaces that the roadmap's architecture diagram treats as identical. Verified differences: (1) Output: Claude uses --output-format json (single JSON envelope), Codex uses --json (JSONL events) OR --output-last-message <FILE>, Gemini is unknown. (2) Permissions: Claude uses --dangerously-skip-permissions, Codex uses --dangerously-bypass-approvals-and-sandbox (verified in codex exec --help), Gemini unknown. (3) Schema: Claude uses --json-schema <inline>, Codex uses --output-schema <FILE>, Gemini unknown. (4) Context: Claude reads CLAUDE.md, Codex reads AGENTS.md, Gemini reads GEMINI.md. (5) Code review: Codex has a dedicated 'codex exec review' subcommand with --base, --commit, --uncommitted flags that are purpose-built for review — far more powerful than generic prompt-based review. The cli_dispatch.py abstraction (Session 3) must be a genuine adapter layer with per-CLI implementations, not a thin wrapper assuming flag uniformity.",
      "risk_if_missing": "Session 3's verification commands fail immediately (wrong Codex flags). The orchestrator produces wrong CLI commands that either fail silently or produce unparseable output. The entire cross-provider review architecture is broken before it starts."
    },
    {
      "addition": "An escalation protocol for non-scholarly decisions (SPEC ambiguities, technical design, architectural trade-offs)",
      "rationale": "The roadmap provides a human gate for scholarly content decisions (Session 8) but no escalation path for technical decisions. The most dangerous failure mode in autonomous engine building is not a crash — it's a silent design decision made by CC that goes unreviewed because the code is internally consistent. When CC encounters a SPEC ambiguity, it will implement its best guess, write tests that pass, and the reviewer will approve because the implementation matches the tests. The design decision is invisible. This is exactly how the source engine's post-build bugs (FIX-C04 through FIX-C08) happened — self-review passes because the same mental model that produced the work reviews it. The fix: (1) define a 'technical_decision' artifact type, (2) CC MUST create one whenever it resolves an ambiguity or makes a judgment call, (3) the orchestrator routes technical decisions to a decision queue (analogous to human_gate/pending/ but for technical decisions), (4) Codex and Gemini independently evaluate the decision, (5) if they disagree, the decision goes to the owner. This is D-F002 (cross-provider review) applied to design decisions, not just code.",
      "risk_if_missing": "Silent design decisions accumulate across 48 daily work units. Each is individually reasonable but collectively they form an unreviewed architectural direction. By the time the owner notices (probably during the next engine's integration testing), dozens of decisions have been baked into the codebase. Rolling them back requires understanding each one, which requires the original context — which was discarded because no artifact was created. This is the 'confident-wrong' failure mode scaled by automation."
    }
  ],

  "bonus_findings": [
    {
      "id": "B1",
      "severity": "HIGH",
      "finding": "The auto-staging hook (settings.json line 168) runs 'git add $FILE' on every file CC writes. In a multi-CLI orchestration flow, this means files are staged BEFORE quality gates run. If a work unit fails, the staging area contains the failed work's files. The orchestrator must explicitly unstage between work units."
    },
    {
      "id": "B2",
      "severity": "HIGH",
      "finding": "The cost-guard hook checks tests/results/source_engine/COST_LOG.json — a path specific to the source engine's evaluation phase. It provides ZERO budget protection for factory operations (CLI dispatch costs, benchmark runs, artifact storage). The factory needs its own cost tracking."
    },
    {
      "id": "B3",
      "severity": "MEDIUM",
      "finding": "The knowledge-diversity exclusion of the Decision Playbook from Gemini is INSTRUCTIONAL, not STRUCTURAL. Gemini CLI has file access tools and can read reference/DECISION_PLAYBOOK.md directly. The GEMINI.md instruction 'reason from first principles only' is a suggestion that a capable model may override if it decides the Playbook is relevant. True structural exclusion would require --disallowedTools or file-level permissions."
    },
    {
      "id": "B4",
      "severity": "MEDIUM",
      "finding": "No disk space management for the artifacts/ directory. At 48 work units/day with full provenance bundles (prompt, inputs, outputs, git SHA), storage grows unboundedly. The existing overnight system uses overnight/results/{task_id}/ but has no pruning. A 6-month factory run at 48 units/day = 8,640 artifact bundles. With 100KB average, that is 864MB. With 1MB average (including model outputs), that is 8.6GB."
    },
    {
      "id": "B5",
      "severity": "MEDIUM",
      "finding": "The Codex CLI 'review' subcommand (codex exec review --base master --uncommitted) is purpose-built for exactly the review role the roadmap assigns to Codex. It produces structured review output with findings. The roadmap's design uses generic 'codex exec' with a review prompt, which is a strictly worse approach. The existing overnight_orchestrator.py also misses this — it uses 'codex exec --full-auto' for all tasks."
    },
    {
      "id": "B6",
      "severity": "LOW",
      "finding": "The live test of --json-schema showed Opus 4.6 consumes $0.36 in cache creation cost just for the system prompt (57,849 tokens). This means the 'total_cost_usd' field in JSON output reflects real calculated cost even for Max subscription users. The orchestrator can track this for budget monitoring, but the $0.36 per-call system prompt cost means 48 calls/day = $17.28/day in 'virtual cost' — useful for monitoring model efficiency but NOT actual billing."
    }
  ]
}
```

---

## Summary of Findings by Severity

### Will Cause Outright Failure (3)
1. **Fabricated CLI flags** for Codex (`--output-format json` doesn't exist) — Session 3 verification will fail
2. **Existing 2000-line orchestrator ignored** — Session 6 rebuilds what exists, losing battle-tested fixes
3. **Hook overhead unbudgeted** — 225s worst-case per edit makes 30-minute cycles impossible for build work

### Will Cause Significant Operational Issues (5)
4. Auto-staging hook creates dirty git state between work units
5. Hook count in roadmap is wrong (says 13, actual is 19 entries)
6. "$0 incremental" ignores subscription rate limits
7. No structured response contract between CC and orchestrator
8. No escalation path for technical design decisions

### Will Cause Friction (4)
9. Knowledge-diversity Playbook exclusion is instructional, not structural
10. Cost guard monitors wrong budget scope
11. No disk space management for artifact accumulation
12. Codex's purpose-built `review` subcommand not leveraged

### Counts
- **TRUE assumptions:** 6 of 10 (assumptions 1, 5, 7, 8, 9 are cleanly true; 2 is true with --bare caveat)
- **PARTIALLY TRUE:** 2 of 10 (assumptions 3, 6)
- **TRUE BUT WRONG COUNT/OVERHEAD:** 1 of 10 (assumption 4)
- **UNVERIFIED:** 1 of 10 (assumption 10, --json-schema reliability)
- **Missing requirements found:** 8
- **Failure modes analyzed:** 5
- **Bonus findings:** 6
- **Total problems identified:** 21
