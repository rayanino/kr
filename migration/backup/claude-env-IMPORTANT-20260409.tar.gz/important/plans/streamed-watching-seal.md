# Plan: Harden Environment for Zero-Human-Review Workflow

## Context

The owner doesn't review outputs — Claude Chat directs work, owner relays instructions to Claude Code. This means the environment must be **self-enforcing**. Currently, 83% of quality rules exist only as documentation. The pre-commit hook always exits 0 (advisory only). Nothing actually blocks bad work.

## Priority fixes (highest impact, lowest risk)

### Fix 1: Make pre-commit hook BLOCKING

**File:** `.claude/hooks/pre-commit-check.sh`

Currently the hook runs quality checks but always `exit 0`. Change it to `exit 1` when critical checks fail:
- Tests fail for modified engine → BLOCK
- Arabic `.lower()/.upper()` found → BLOCK (already blocks via separate hook, but inconsistent)
- Modified `contracts.py` without running `verify_metadata_flow.py` → WARN (don't block, too fragile)

Keep advisory warnings for non-critical items (SPEC quality, session log).

### Fix 2: Add post-edit auto-test enforcement

**File:** `.claude/settings.json` — PostToolUse hooks

Currently tests run "in background" after edits. Strengthen to:
- After editing `engines/*/src/*.py` or `shared/*/src/*.py`: run `pytest` on that engine's tests with `-x -q` and **show the result** (not background). If tests fail, the output is visible and Claude Code should fix before continuing.

### Fix 3: Add pre-push verification hook

**File:** `.claude/settings.json` — add PreToolUse hook for `git push`

Before any push: run the 3 most critical checks:
1. `python -m pytest engines/*/tests/ shared/*/tests/ -x -q` — all tests pass
2. Import check on all modified Python files
3. If any `contracts.py` modified: `verify_metadata_flow.py`

Block push if tests fail.

### Fix 4: Strengthen post-compaction recovery

**File:** `.claude/hooks/post-compaction.sh` (or existing SessionStart hook)

After compaction, add to the displayed reminders:
- Result preservation & COST_LOG.json requirement
- Temperature=0 for consensus models
- Ripple verification for shared concepts
- Real Arabic fixture mandate for tests

### Fix 5: Add independent review dispatch rule

**File:** `.claude/rules/quality-workflow.md`

Add rule: "After completing any task that modifies `engines/*/src/` or `contracts.py`, dispatch the `code-reviewer` agent before committing. Self-review is insufficient per Principle 34."

This makes it a documented rule that Claude Code should follow (not just a nice-to-have).

## Files to modify

1. `.claude/hooks/pre-commit-check.sh` — make blocking on test failures
2. `.claude/settings.json` — strengthen hooks (pre-push, post-edit)
3. `.claude/rules/quality-workflow.md` — add mandatory review dispatch
4. `.claude/hooks/post-compaction.sh` — expand reminders (if exists, else modify SessionStart hook)

## What this does NOT cover (future work)

- CI/CD (GitHub Actions) — would give server-side enforcement, but requires repo admin setup
- Runtime contract validation between engines — requires tracer bullet infrastructure
- Automated ripple-effect grep — could be a hook but high false-positive risk
- Arabic encoding linter — custom tool needed, defer

## Verification

After implementation:
1. Make a deliberate bad commit (failing test) → confirm it's blocked
2. Try `git push` with a failing test → confirm it's blocked
3. Trigger compaction → confirm expanded reminders display
4. Edit `engines/*/src/*.py` → confirm tests auto-run visibly
