# Plan: Source Engine Step 1 Fixes — 6 Blocking Bugs

## Context

Code audit (Session 6 validation, Step 1) found **6 blocking bugs** that must be fixed before Step 2 integration testing. The audit document (`engines/source/review/CODE_AUDIT_SESSION6.md`) has THREE layers with corrections — only the "Definitive Fix List" section (line 730+) is authoritative, with one correction for Fix 6 noted below.

**Critical rule:** Line numbers are from commit `70fb797`. They WILL SHIFT during edits. **Navigate by code patterns, not line numbers.**

---

## Fix Order: 3 → 2 → 5 → 4 → 6 → 1

Rationale: Start with isolated modules (name_matching, registries), then engine.py simple edits (5, 4, 6), then the complex gate fix (1) last to minimize line-shift interference.

---

## Fix 3: Punctuation Stripping in Name Matching

**File:** `shared/scholar_authority/src/name_matching.py`
**Function:** `normalize_arabic_name` (line 15)

**What:** Add punctuation stripping regex AFTER the definite article strip (line 30: `result = re.sub(r'\bال[ـ]?', '', result)`) and BEFORE whitespace collapse (line 32: `result = re.sub(r'\s+', ' ', result).strip()`).

**Insert this line between lines 30 and 32:**
```python
# Strip Arabic and Latin punctuation (prevents token mismatches from LLM commas)
result = re.sub(r'[،؛,;:.!؟?\u00BB\u00AB\-\u2013\u2014/]', ' ', result)
```

**Why:** LLM-inferred names may include punctuation (Arabic commas, semicolons) that breaks name similarity matching. Replacing with spaces lets the subsequent whitespace collapse handle it.

**Test:** Add test to `shared/scholar_authority/tests/test_name_matching.py` — verify that names with Arabic commas (`،`), semicolons, hyphens normalize identically to clean names.

**Run:** `python -m pytest shared/scholar_authority/tests/test_name_matching.py -x -v --tb=short`

---

## Fix 2: Rollback Validation and Fail-Loud

**File:** `engines/source/src/registries/__init__.py`

### 2a: `_rollback_registries` (line 270)

**Current code (lines 282-286):**
```python
except (json.JSONDecodeError, OSError):
    try:
        os.replace(str(bak_file), str(registry_path))
    except OSError:
        pass
```

**Change to:**
```python
except (json.JSONDecodeError, OSError):
    try:
        os.replace(str(bak_file), str(registry_path))
    except OSError as exc:
        raise RuntimeError(
            f"Cannot restore registry {registry_path} from backup: {exc}. "
            f"Manual recovery required."
        ) from exc
    # Validate restored content is valid JSON
    try:
        restored_raw = registry_path.read_text(encoding="utf-8")
        json.loads(restored_raw)
    except (json.JSONDecodeError, OSError) as exc:
        raise RuntimeError(
            f"Registry {registry_path} restored from backup but backup is also corrupt. "
            f"Manual recovery required."
        ) from exc
```

### 2b: `check_orphaned_registrations` partial rollback (lines 260-263)

**Current code:**
```python
try:
    os.replace(str(bak_path), str(registry_path))
except OSError:
    pass
```

**Change to:**
```python
try:
    os.replace(str(bak_path), str(registry_path))
except OSError as exc:
    raise RuntimeError(
        f"Cannot restore registry {registry_path} from backup during "
        f"orphan recovery for {source_id}: {exc}. Manual recovery required."
    ) from exc
```

**Test:** Add/update tests in `engines/source/tests/test_registries.py` — test that corrupt .bak raises RuntimeError instead of silently passing.

**Run:** `python -m pytest engines/source/tests/test_registries.py -x -v --tb=short`

---

## Fix 5: Title Priority — title_full Before display_title

**File:** `engines/source/src/engine.py`
**Find pattern:** `extracted.get("display_title")` followed by `extracted.get("title_full")`

**Current code (lines 376-381):**
```python
title_arabic = (
    extracted.get("display_title")
    or extracted.get("title_full")
    or extracted.get("title_arabic")
    or ""
)
```

**Change to:**
```python
title_arabic = (
    extracted.get("title_full")
    or extracted.get("display_title")
    or extracted.get("title_arabic")
    or ""
)
```

**Why:** `display_title` is Shamela card header (short UI name). `title_full` is الكتاب field (authoritative). Python `or` short-circuits — wrong priority means wrong title → wrong `work_id` → deduplication breaks.

**Test:** Add test in `engines/source/tests/test_engine.py` verifying that when both `display_title` and `title_full` are present, `title_full` wins.

---

## Fix 4: Publication Year Field Mapping

**File:** `engines/source/src/engine.py`
**Find pattern:** `extracted.get("publication_year_hijri")`

**Current code (lines 461-462):**
```python
publication_year_hijri=extracted.get("publication_year_hijri"),
publication_year_miladi=extracted.get("publication_year_miladi"),
```

**Change to:**
```python
publication_year_hijri=extracted.get("edition_year_hijri"),
publication_year_miladi=extracted.get("edition_year_miladi"),
```

**Why:** `shamela_html.py` extraction writes `edition_year_hijri`/`edition_year_miladi`, but engine.py reads `publication_year_*`. Keys don't match → years always null.

**Test:** Add test verifying that extracted edition year data flows through to SourceMetadata publication year fields.

---

## Fix 6: Layer Author Dummy ID → Real Registration

**File:** `engines/source/src/engine.py`
**Find pattern:** `canonical_id="sch_00000"`

**Current code (lines 208-213):**
```python
else:
    ref = ScholarReference(
        canonical_id="sch_00000",
        name_arabic="مجهول",
        confidence=0.0,
        source_of_identification="inferred",
    )
```

**Change to:**
```python
else:
    ref = lookup_or_register_muhaqiq(
        "مجهول",
        source_id,
        registry_path=registry_path,
    )
```

**Why:** `sch_00000` is a hardcoded dummy ID that doesn't exist in the scholar registry. Validation Check 6c (`_check_layer_authors_in_registry`) will ALWAYS fail with `SRC_REGISTRY_CONFLICT` (fatal) when this ID is looked up. `lookup_or_register_muhaqiq` is already imported (line 66) and `registry_path` is already defined (line 195). First call creates a "مجهول" record; subsequent calls auto-link (name similarity = 1.0).

**Test:** Update test in `engines/source/tests/test_engine.py` — verify `_build_text_layers` with missing author calls `lookup_or_register_muhaqiq` instead of producing dummy ID.

---

## Fix 1: Gate Errors — Create Checkpoints AND Abort (Most Complex)

**Files:** `engines/source/src/human_gate.py` + `engines/source/src/engine.py`

### 1a: New wrapper in `human_gate.py`

Add `gate_author_science_mismatch` following existing 5-wrapper pattern (after `gate_scholar_conflict`, line ~147):

```python
def gate_author_science_mismatch(
    source_id: str,
    author_sciences: list[str],
    source_sciences: list[str],
    detail: str,
) -> HumanGateCheckpoint:
    """Create AUTHOR_SCIENCE_MISMATCH gate."""
    return create_checkpoint(
        source_id=source_id,
        trigger=HumanGateTrigger.AUTHOR_SCIENCE_MISMATCH,
        trigger_detail=detail,
        fields_to_review=["science_scope", "author"],
        current_values={
            "author_sciences": author_sciences,
            "source_sciences": source_sciences,
        },
    )
```

### 1b: Import the new wrapper in engine.py

**Find pattern:** `from engines.source.src.human_gate import (`

**Add** `gate_author_science_mismatch` to the import list.

### 1c: Gate error processing in engine.py

**Find pattern:** The line `logger.log_event("validation_complete"` (currently line 583) — insert gate processing BETWEEN the fatal_errors block (line 581) and this log line.

**Insert:**
```python
# Process gate-severity errors — create checkpoints then abort
gate_errors = [e for e in validation_errors if e.severity == "gate"]
if gate_errors:
    for gate_error in gate_errors:
        if gate_error.check == "confidence_threshold":
            gate_low_confidence(
                source_id,
                gate_error.field,
                data_for_validation.get(gate_error.field, ""),
                0.0,  # Confidence already below threshold
            )
        elif gate_error.check == "consistency_author_science":
            gate_author_science_mismatch(
                source_id,
                author_sciences=[],
                source_sciences=[],
                detail=gate_error.message,
            )
        elif gate_error.check == "multi_layer_empty_layers":
            gate_low_confidence(
                source_id,
                "text_layers",
                "[]",
                0.0,
            )
    raise make_error(
        ErrorCode.LOW_CONFIDENCE,
        f"Validation gate: {len(gate_errors)} issue(s) require human review",
        source_id=source_id,
        context={"gate_errors": [e.message for e in gate_errors]},
    )
```

**CRITICAL:** The `raise` is essential. Without it, sources register despite needing human review — defeating the entire gate mechanism. SPEC §5 line 1445: "Any failure aborts the write."

**Test:** Add tests in `engines/source/tests/test_engine.py`:
- Gate error with `severity="gate"` creates checkpoint AND raises `SourceEngineError`
- Multiple gate errors create multiple checkpoints before single raise
- Non-gate errors (warnings) do NOT trigger abort

---

## Non-Blocking (if time permits)

1. `engine.py` ~line 401: Change `"prose"` to `"mixed"` as default structural_format (SPEC says most conservative = "mixed")
2. `engine.py` ~line 175: Add `logger.warning` before `return None` in early-exit path
3. `engine.py` ~line 598: Replace `pass` with `logger.log_event("cleanup_warning", ...)` for staging move failure

---

## Files Modified (Summary)

| File | Fix # | Type |
|------|-------|------|
| `shared/scholar_authority/src/name_matching.py` | 3 | Add 2 lines |
| `shared/scholar_authority/tests/test_name_matching.py` | 3 | Add test |
| `engines/source/src/registries/__init__.py` | 2 | Edit 2 functions |
| `engines/source/tests/test_registries.py` | 2 | Add test |
| `engines/source/src/engine.py` | 5, 4, 6, 1 | Multiple edits |
| `engines/source/src/human_gate.py` | 1 | Add 1 wrapper |
| `engines/source/tests/test_engine.py` | 5, 4, 6, 1 | Add tests |

**Do NOT modify:** `SPEC_CORE.md`, `contracts.py`, test fixtures.

---

## Verification

After all 6 fixes:
```bash
python -m pytest engines/source/tests/ shared/scholar_authority/tests/ -x -v --tb=short
```

Expected: All existing tests pass + new tests for each fix pass. Zero regressions.
