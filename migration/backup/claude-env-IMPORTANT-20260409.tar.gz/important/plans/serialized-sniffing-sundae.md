# Plan: Fix Overnight Auth — API Key Overriding Subscription

## Root Cause

`ANTHROPIC_API_KEY` is set in the user's environment (length 108). When the orchestrator spawns `claude -p`, the subprocess inherits it and uses API key billing (low balance) instead of the Max 20x subscription (OAuth). Interactive sessions use subscription auth — that's why Claude Chat works fine on opus.

## Fix

**File:** `scripts/overnight_orchestrator.py` — `_execute_cli()` env dict (line ~505)

Remove `ANTHROPIC_API_KEY` from the spawned environment:

```python
env = {
    **os.environ,
    "KR_OVERNIGHT": "1",
    "PYTHONIOENCODING": "utf-8",
    "KR_BUDGET_LIMIT": os.environ.get("KR_BUDGET_LIMIT", "20"),
}
# Remove API key so CLI uses Max subscription auth (OAuth), not API billing
env.pop("ANTHROPIC_API_KEY", None)
```

Also add `--fallback-model sonnet` as a safety net for any future rate limiting.

## Verification
1. Dry-run
2. Quick smoke test: `claude -p "say hello" --model opus --output-format json` (without ANTHROPIC_API_KEY) — should succeed on subscription
3. Clean stale state, relaunch
