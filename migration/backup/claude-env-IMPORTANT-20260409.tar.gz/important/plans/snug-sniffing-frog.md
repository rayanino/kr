# Migration Plan: Claude Code Environment Preservation

## Context

The owner is migrating from the current Windows PC to a new Windows PC. The current machine will be destroyed. The KR project codebase has been migrated to branch `canonical/excerpting-clean-start-20260409`. Codex settings are bundled in `kr-codex-setup-bundle-20260408_235052.zip`.

**The critical risk:** The project-level `.claude/` directory (132 files) is fully tracked in git and will survive. But the **user-level** `C:\Users\Rayane\.claude\` directory (2.3GB, 15,030 files) is NOT in any git repo and will be destroyed with the PC. This contains 8 months of memory, all plugin installations, global settings, hooks, session history, and project memory files.

---

## What's Safe (No Action Needed)

These are already preserved in the git branch:
- `.claude/agents/` (26 agent definitions)
- `.claude/commands/` (24 slash commands)
- `.claude/hooks/` (32 hook scripts)
- `.claude/rules/` (21 behavioral rules)
- `.claude/skills/` (15 custom skills)
- `.claude/settings.json` (project-level — 38 hooks, permissions, plugins)
- `.claude/settings.local.json` (project-level overrides)
- `CLAUDE.md`, `AGENTS.md`, `mcp.json`
- `requirements.txt`, `pyproject.toml`, `Makefile`

---

## Step 1: Create Full Backup Archive of `~/.claude/`

**Script:** `scripts/migrate_claude_env.sh`

Creates a compressed archive of the entire user-level Claude Code directory, categorized by priority.

### 1A. CRITICAL files (must preserve — irreplaceable)

| Path | Size | Why |
|------|------|-----|
| `~/.claude/settings.json` | 4K | Global permissions, 17 plugins, hooks, env vars |
| `~/.claude/settings.local.json` | 335B | Model config (opus-4-6), max output tokens (60K), cost warnings |
| `~/.claude/settings.json.bak` | 2.2K | Settings backup |
| `~/.claude/settings.json.bak.20260330` | 2.3K | Dated settings backup |
| `~/.claude/settings.json.orig` | 2.2K | Original settings |
| `~/.claude/settings.local.json.bak.20260330` | 3.9K | Local settings backup |
| `~/.claude/hooks/` (5 files, 32K) | 32K | Global hooks: GSD check-update, context-monitor, statusline |
| `~/.claude/statusline-command.sh` | 9.4K | Custom statusline |
| `~/.claude/projects/C--Users-Rayane-Desktop-kr/memory/` (122 files) | 562K | **ALL 93+ KR project memories — irreplaceable** |
| `~/.claude/agents/` + `~/.claude/.agents/` | 784K | Agent definitions + Feynman skills |
| `~/.claude/plugins/installed_plugins.json` | 9.7K | Plugin installation manifest |
| `~/.claude/plugins/known_marketplaces.json` | 1.9K | Custom marketplace definitions |

### 1B. IMPORTANT files (should preserve — saves rebuild time)

| Path | Size | Why |
|------|------|-----|
| `~/.claude/history.jsonl` | 888K | Full session command history |
| `~/.claude/tasks/` (220 files) | 556K | Task tracking state |
| `~/.claude/plans/` | 1.9M | Session plans |
| `~/.claude/teams/` | 4K | Team coordination |
| `~/.claude/sessions/` (4 files) | 8K | Session metadata |
| `~/.claude/commands/` | 290K | Custom commands |
| `~/.claude/skills/` | 60K | Custom skills |
| `~/.claude/get-shit-done/` | 1.2M | GSD integration |
| `~/.claude/todos/` | 161K | Todo tracking |
| `~/.claude/scripts/` | 20K | Automation scripts |
| `~/.claude/gsd-file-manifest.json` | 18K | GSD tracking |

### 1C. SESSION DATA (large but valuable — preserve if space allows)

| Path | Size | Why |
|------|------|-----|
| `~/.claude/projects/C--Users-Rayane-Desktop-kr/` (minus memory/) | ~736M | Session transcripts, JSONL logs |
| `~/.claude/projects/` (other 21 project dirs) | ~1.1GB | Other project sessions |

### 1D. WILL REGENERATE (skip to save space, or include for convenience)

| Path | Size | Why |
|------|------|-----|
| `~/.claude/plugins/cache/` | ~388M | Plugin cache — reinstalls rebuild this |
| `~/.claude/file-history/` | 79M | File tracking — rebuilds on use |
| `~/.claude/shell-snapshots/` | 19M | Shell state — rebuilds on use |
| `~/.claude/paste-cache/` | 2.3M | Clipboard history |
| `~/.claude/telemetry/` | 2.2M | Usage metrics |
| `~/.claude/debug/` | 2.5M | Debug logs |
| `~/.claude/session-env/` | 640K | Env snapshots |
| `~/.claude/.credentials.json` | 471B | OAuth tokens — will expire, need re-login |

---

## Step 2: Create Dependency Reinstall Script

**Script:** `scripts/reinstall_deps.sh` (or `.ps1` for PowerShell)

### 2A. Runtime Versions to Install

```
Python 3.13.12
Node.js v24.14.0
npm 11.11.0
Git (latest)
```

### 2B. Global npm Packages (11 packages)

```bash
npm install -g @google/gemini-cli@0.36.0 \
  @modelcontextprotocol/server-sequential-thinking@2025.12.18 \
  @openai/codex@0.118.0 \
  firecrawl-cli@1.11.2 \
  openclaw@2026.3.24 \
  pnpm@10.33.0 \
  promptfoo@0.121.3 \
  repomix@1.13.1 \
  tsx@4.21.0 \
  yarn@1.22.22
```

### 2C. Python Environment

```bash
cd <project-dir>
make install  # Creates .venv, installs from requirements.txt
```

Key packages (206 total):
- LLM: anthropic, litellm, instructor, openai, mcp, fastmcp
- Arabic NLP: camel-tools, PyArabic
- ML: torch, transformers, sentence-transformers
- Quality: pytest, pyright, black, ruff, mypy
- Web: fastapi, uvicorn, beautifulsoup4
- OCR: docling, easyocr, opencv-python

### 2D. Claude Code CLI

```bash
# Reinstall Claude Code CLI (check latest install method)
# Binary was at: ~/.local/bin/claude
```

### 2E. Environment Variables to Recreate

```
TAVILY_API_KEY=<from .env or password manager>
MEMORY_FILE_PATH=${HOME}/.claude-memory/kr-engine.jsonl
CLAUDE_AUTOCOMPACT_PCT_OVERRIDE=60
CLAUDE_CODE_SUBPROCESS_ENV_SCRUB=1
CLAUDE_CODE_DISABLE_ADAPTIVE_THINKING=1
MAX_THINKING_TOKENS=128000
```

---

## Step 3: Create Restoration Script for New PC

**Script:** `scripts/restore_claude_env.sh`

Steps the script performs on the new PC:

1. Extract the backup archive to `C:\Users\<NewUser>\.claude\`
2. Fix any path references in settings files (old username → new username)
3. Fix project directory references in `projects/` folder names
   - `C--Users-Rayane-Desktop-kr` → `C--Users-<NewUser>-<NewPath>-kr`
   - All 22 project directories need path remapping
4. Reinstall Claude Code plugins from the manifest:
   ```
   pyright-lsp, commit-commands, pr-review-toolkit, coderabbit,
   feature-dev, serena, skill-creator, claude-md-management,
   firecrawl, oberskills, superpowers, explanatory-output-style,
   context7, claude-lens, frontend-design, prompt-architect,
   compound-engineering
   ```
5. Re-authenticate Claude Code (`.credentials.json` will have expired)
6. Verify hooks execute correctly (bash compatibility)

---

## Step 4: Path Remapping Considerations

The user-level `~/.claude/projects/` directory names encode the full project path:
- `C--Users-Rayane-Desktop-kr` = `C:\Users\Rayane\Desktop\kr`

If the new PC has a different username or project location, ALL project directory names under `~/.claude/projects/` must be renamed to match. There are 22 project directories to remap.

Memory files inside these directories may also contain hardcoded paths that need updating.

---

## Step 5: Verification Checklist (Post-Migration)

Run these on the new PC to confirm everything works:

```bash
# 1. Claude Code starts and loads project config
claude   # Should show KR statusline, load hooks

# 2. Memory is accessible
# In Claude Code: "recall what you know about the KR project"
# Should find all 93+ memory files

# 3. Settings loaded correctly
# Check: hooks fire, plugins load, permissions match

# 4. Python environment works
cd <project-dir>
make install
make test

# 5. Coworker CLIs work
codex --version
gemini --version

# 6. MCP servers connect
# In Claude Code: try using context7, tavily, memory MCP tools

# 7. Project hooks fire
# Make a test edit → PostToolUse hooks should trigger
# Try to commit → PreToolUse hooks should fire

# 8. Global hooks fire
# SessionStart hook should show git status + budget
```

---

## Step 6: Path Remapping Details (CRITICAL)

The global `~/.claude/settings.json` contains **hardcoded absolute paths** that will break on the new PC:

```json
// Hooks:
"command": "node \"C:/Users/Rayane/.claude/hooks/gsd-check-update.js\""
"command": "node \"C:/Users/Rayane/.claude/hooks/gsd-context-monitor.js\""
// Statusline:
"command": "bash \"C:/Users/Rayane/.claude/statusline-command.sh\""
```

The `known_marketplaces.json` has 7 entries with hardcoded `installLocation` paths:
```json
"installLocation": "C:\\Users\\Rayane\\.claude\\plugins\\marketplaces\\..."
```

The `installed_plugins.json` has 21 entries with hardcoded `installPath` values:
```json
"installPath": "C:\\Users\\Rayane\\.claude\\plugins\\cache\\..."
```

**Remapping strategy:** Simple find-and-replace of `C:/Users/Rayane/` and `C:\\Users\\Rayane\\` with the new user's home path in all JSON files under `~/.claude/`.

The `~/.claude/projects/` directory names also encode the old path:
- `C--Users-Rayane-Desktop-kr` → needs renaming if username or project path changes

---

## Step 7: Plugin Reinstallation

Plugins will be re-downloaded from their GitHub repos. The restore script needs to:

1. Copy `settings.json` with `enabledPlugins` and `extraKnownMarketplaces` blocks
2. On first Claude Code launch, plugins auto-install from the marketplace definitions
3. If auto-install doesn't work, manually install each:

**7 marketplace sources:**
| Marketplace ID | GitHub Repo |
|---|---|
| claude-plugins-official | anthropics/claude-plugins-official |
| rtd | ryanthedev/rtd-claude-inn |
| claude-lens-marketplace | Astro-Han/claude-lens |
| prompt-architect-marketplace | ckelsoe/prompt-architect |
| openai-codex | openai/codex-plugin-cc |
| compound-engineering-plugin | EveryInc/compound-engineering-plugin |
| thedotmack | thedotmack/claude-mem |

**17 enabled plugins** (will auto-install from marketplaces above):
pyright-lsp, commit-commands, pr-review-toolkit, coderabbit, feature-dev, serena, skill-creator, claude-md-management, firecrawl, oberskills, superpowers, explanatory-output-style, context7, claude-lens, frontend-design, prompt-architect, compound-engineering

**4 installed-but-disabled plugins** (available if needed):
gopls-lsp, qodo-skills, playground, code-simplifier, ralph-loop, claude-mem

---

## Implementation: What I Will Create

1. **`scripts/backup_claude_env.sh`** — Backup script that:
   - Creates timestamped archive of `~/.claude/` 
   - Separates CRITICAL (settings, memory, hooks) from OPTIONAL (cache, telemetry)
   - Produces a `backup_manifest.txt` listing every file with checksums
   - Estimates archive size before compressing

2. **`scripts/restore_claude_env.sh`** — Restoration script that:
   - Extracts the archive to the new `~/.claude/`
   - Accepts old and new username as parameters
   - Performs path remapping in all JSON files (`settings.json`, `installed_plugins.json`, `known_marketplaces.json`)
   - Renames project directories under `projects/`
   - Verifies restored files against the manifest checksums

3. **`scripts/reinstall_deps.sh`** — Dependency installation:
   - Installs exact npm global package versions
   - Runs `make install` for Python env
   - Verifies CLI tools (codex, gemini, claude) are available

4. **`migration/MIGRATION_CHECKLIST.md`** — Non-technical step-by-step the owner can follow

### Files Already Read (no re-read needed)

- `~/.claude/settings.json` — global config with 17 plugins, 5 marketplaces, hooks, env vars ✅
- `~/.claude/settings.local.json` — model=opus-4-6, max output 60K, cleanup 90 days ✅
- `~/.claude/plugins/installed_plugins.json` — 21 plugins with paths and versions ✅
- `~/.claude/plugins/known_marketplaces.json` — 7 marketplace repos ✅
- Project `.claude/settings.json` — already in git ✅

### Existing Utilities to Reuse

- `Makefile` `install` target for Python env setup
- `requirements.txt` for pip dependencies (206 packages)
- `mcp.json` for MCP server configuration (context7, tavily, memory)

---

## Verification Plan

After creating the scripts:
1. Run backup script on current PC → verify archive contains all 15K+ files
2. Verify manifest checksums match
3. Dry-run restore script (print what it would do without writing)
4. Owner copies archive + git repo to new PC
5. Owner runs restore script with new username
6. Owner opens Claude Code in KR project → verify:
   - Statusline loads
   - Hooks fire on SessionStart
   - Memory is accessible ("recall the KR project")
   - Plugins load (check skill list)
   - `make install && make test` passes
   - Coworker CLIs work (`codex --version`, `gemini --version`)
