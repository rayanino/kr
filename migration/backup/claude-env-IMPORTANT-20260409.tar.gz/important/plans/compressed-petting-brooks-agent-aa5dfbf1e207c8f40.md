# Wave 5-6 Tasks (41-55)

Writing the 15-task JSON array for the sprint manifest. All Wave 5 tasks are readonly sprint_analysis. Wave 6 tasks 51-53 are readonly sprint_analysis with bookend=true. Tasks 54-55 are sprint_script/additive with bookend=true since they write outside overnight/results/.

Key findings from context:
- Taxonomy SPEC: 945 lines, contracts: 491 lines
- Synthesis SPEC: 930 lines, contracts: 565 lines
- Science trees are dirs (aqidah, balagha, imlaa, nahw, sarf) with tree.yaml files
- No decisions/ dir -- decisions are in reference/kr_decisions.md
- Consensus code at shared/consensus/src/consensus.py
- Error codes: source in contracts.py (SRC_*), normalization in src/errors.py (NORM_*), excerpting in contracts.py (EX-A/C/M-*)
- Taxonomy/synthesis contracts.py have NO error codes yet (unbuilt)
- TESTING_FRAMEWORK.md is 979 lines (not 41K as stated)
- KNOWN_LIMITATIONS.md exists for normalization
- verify_metadata_flow.py and check_compliance.py both exist

JSON output below.
