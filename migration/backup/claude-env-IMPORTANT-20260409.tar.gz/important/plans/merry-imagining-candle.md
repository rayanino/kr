# Plan: Phase D Post-Processing + Review GUI

**Context:** Pipeline ran 204 books (all success, 0 gate_abort, 0 errors). Need to fix output naming, tag reruns, generate screening report, and build a review GUI.

## Key data from exploration

- 204 books, ALL status=success
- RERUN_BOOKS.json lists 80 rerun books (not 73)
- Phase C had 22 success + 51 gate_abort → all 80 reruns now success
- Cost: 20.4 EUR for 204 books (currently logged under "C" key)
- 12 books have ground truth, all match
- 30 sanity flags total (0 errors, 2 warnings, 28 info)
- Consensus: all books show `agreed: true` with both models successful
- Genre enums: 18 values in contracts.py

## Files to create/modify

### Task 1-3: `scripts/phase_d_postprocess.py` (NEW)

Single script handling Tasks 1-3:

**Task 1 — Rename and fix:**
- Rename PHASE_C_MANIFEST.json → PHASE_D_MANIFEST.json
- Rename PHASE_C_SUMMARY.json → PHASE_D_SUMMARY.json
- Inside manifest: `"phase": "C"` → `"D"`, `"phase_c/"` → `"phase_d/"` in result_path
- COST_LOG.json: move the "C" entry's current 204-book data to a new "D" entry, restore "C" to its historical values (22 success + 51 gate_abort, 7.0 EUR from Phase C memory)

**Task 2 — Tag reruns:**
- Read RERUN_BOOKS.json for the 80 rerun book names
- For each of 204 books: add `"is_rerun": true/false` and `"original_phase": "C"/null` to result.json

**Task 3 — Auto-screening report:**
Generate `PHASE_D_AUTO_SCREENING.md` with 8 sections:
- 3a: Regression comparison (80 reruns vs Phase C results)
- 3b: Statistical summary
- 3c: Confidence outliers (<0.75)
- 3d: Consensus disagreements (agreed=false)
- 3e: Trust anomalies
- 3f: Multi-layer books
- 3g: Remaining gate_aborts
- 3h: Category coverage

### Task 4: `scripts/generate_review_gui.py` (NEW)

Walks phase_d/ reading all book data, embeds as JSON in self-contained HTML.

**Data collection:** For each book, read result.json, extraction.json, consensus.json, llm_responses/*.json. Build the schema from the prompt.

**HTML generation:** Single file with embedded data + CSS + JS. Three views:
1. Dashboard — stats, distributions, navigation
2. Review Queue — one book at a time, 3-column layout, feedback panel
3. List View — filterable/sortable card list

**Key design decisions:**
- Dark theme (#0c0a09 bg)
- Google Fonts: IBM Plex Mono, IBM Plex Sans, Amiri
- localStorage persistence for verdicts
- All UI text in English, Arabic only in data content with `dir="rtl"`
- Genre dropdown uses actual 18 enum values from contracts.py
- Keyboard shortcuts: 1/2/3 for verdicts, arrows for navigation

### Other files modified:
- `tests/results/source_engine/phase_d/PHASE_D_MANIFEST.json` (renamed + contents fixed)
- `tests/results/source_engine/phase_d/PHASE_D_SUMMARY.json` (renamed)
- `tests/results/source_engine/COST_LOG.json` (D entry added)
- `tests/results/source_engine/phase_d/*/result.json` (204 files, is_rerun tag added)
- `tests/results/source_engine/phase_d/PHASE_D_AUTO_SCREENING.md` (new)
- `tests/results/source_engine/phase_d/review_gui.html` (new, generated)
- `NEXT.md` (updated status)

## Execution order

1. Run `python scripts/phase_d_postprocess.py` — Tasks 1-3
2. Run `python scripts/generate_review_gui.py` — Task 4
3. Update NEXT.md
4. Commit and push

## Verification

```
python scripts/generate_review_gui.py && echo "GUI generated" && ls -la tests/results/source_engine/phase_d/review_gui.html
```
