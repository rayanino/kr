# Wave 3-4 Task Generation Plan

## Context gathered:
- Normalization ADV spec at `reference/SPEC_ADVERSARY_NORMALIZATION.md` (51 cases)
- Already covered ADVs: 001-018, 019-022, 024-026, 028-029, 033-034, 038, 040, 045, 047-051
- Uncovered ADVs for Wave 3: 023, 027, 030, 031, 032, 035, 036, 037, 039, 041, 042, 043, 044, 046
- Source error codes: 36 SRC_* codes in contracts.py
- Source engine tests: test_error_paths.py, test_trust_evaluator.py, test_deduplication.py exist
- Normalization modules: layer_detector.py, boundary_continuity.py confirmed
- Contracts: source/contracts.py, normalization/contracts.py, excerpting/contracts.py all exist
- Taxonomy/synthesis contracts exist but engines are stubs (only __init__.py + tracer.py)
- Scripts dir has check_compliance.py
- Tools dir has check_cross_engine_contracts.py (already exists!)
- Library: sciences/ has YAML trees, registries/ has JSON, config/ has JSON, gates/ has pending+resolved, logs/ has JSONL
- tests/adversarial/ does NOT exist yet
- Normalization SPEC is 2044 lines

## Key decisions:
- Task 31 (script-contract-checker): tools/check_cross_engine_contracts.py EXISTS. Must name differently or enhance. Use tools/check_cross_engine_contracts_v2.py to avoid modifying existing.
- Task 29/30: Cross-boundary tests go to tests/ root
- Wave 3 tests: new files only in engine test dirs
- Wave 4 scripts: new files only in scripts/ or tools/

Ready to output JSON.
