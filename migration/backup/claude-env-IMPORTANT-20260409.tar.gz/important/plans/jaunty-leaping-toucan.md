# Plan: Complete Preamble Review Fixes (F-1 + F-3 Tests)

## Context

Commit `1705ca5a` added `_complete_division_tree()` which inserts synthetic preamble leaf nodes (div_id ending in `_pre`) to fill gaps in the division tree. The architect review found 2 findings:

- **F-1**: Synthetic preamble nodes trigger false EX-A-006 warnings because `check_heading_alignment()` tries to match `"مقدمة"` (assigned heading) against assembled text where it doesn't appear. Fix: skip the heading alignment check for `_pre` nodes, set `heading_alignment_ok=True`.
- **F-3**: No test coverage for oversized preamble chunk splitting (preamble `_pre` chunks going through `split_oversized_division`).

**Critical finding:** The F-1 code fix is **NOT applied** in the working tree. `grep` confirms zero matches for `endswith.*_pre` in `phase1_assembly.py`, and `git diff --name-only` shows only `.claude/session_state.json` modified. The fix must be applied.

## Steps

### Step 1: Apply F-1 Code Fix
**File:** `engines/excerpting/src/phase1_assembly.py` (line 1505)

Change:
```python
heading_ok = check_heading_alignment(node.heading_text, text)
```
To:
```python
# F-1: Synthetic preamble nodes have assigned heading "مقدمة" that
# won't appear in assembled text — skip alignment check (not a real mismatch)
if node.div_id.endswith("_pre"):
    heading_ok = True
else:
    heading_ok = check_heading_alignment(node.heading_text, text)
```

### Step 2: Add Imports to Test File
**File:** `engines/excerpting/tests/test_phase1_preamble.py`

Add to existing imports:
```python
from engines.excerpting.contracts import (
    AssembledChunk,
    ExcerptingConfig,
    _count_arabic_words,
)
from engines.excerpting.src.phase1_assembly import (
    _complete_division_tree,
    run_phase1,
    split_oversized_division,
)
from engines.excerpting.tests.conftest import (
    _make_assembled_chunk,
    _make_division_node,
)
from engines.normalization.contracts import (
    ...existing...,
    LayerType,
    TextLayerSegment,
)
```

### Step 3: Add Test A — `test_preamble_heading_alignment_ok_true`
**Location:** End of `TestCompleteDivisionTree` class (after line 302)

Integration test that verifies the F-1 fix end-to-end:
1. Load `ibn_aqil_v1` package via `_load_package(PACKAGES_DIR / "ibn_aqil_v1")`
2. Run `run_phase1(pkg, ExcerptingConfig())`
3. Filter chunks where `"_pre" in chunk.div_id`
4. Assert at least 1 preamble chunk exists
5. Assert `heading_alignment_ok is True` for every preamble chunk

**Note:** This test references `PACKAGES_DIR` and `_load_package` which are defined later in the module (line 310+). This works in Python since global names are resolved at call time, not definition time. Follows the user's explicit instruction to place in `TestCompleteDivisionTree`.

### Step 4: Add Test B — `test_preamble_oversized_split`
**Location:** End of `TestCompleteDivisionTree` class (after Test A)

Unit test verifying preamble chunks split correctly:
1. Generate ~6000 Arabic words using the `base_words` cycling pattern from `test_phase1_hardening.py`
2. Insert `\n\n` at midpoint for a reliable split point
3. Construct chunk via `_make_assembled_chunk(chunk_id="div_test_0_0_pre", div_id="div_test_0_0_pre", assembled_text=text, word_count=wc, total_tokens=len(text.split()), text_layers=[...])` — must override `text_layers` to cover full text length
4. Call `split_oversized_division(chunk, [], ExcerptingConfig(OVERSIZED_DIVISION_WORDS=5000))`
5. Assert `len(result) >= 2`
6. Assert `result[0].chunk_id == "div_test_0_0_pre_chunk_0"`
7. Assert `result[0].split_info is not None`
8. Re-validate each chunk: `AssembledChunk.model_validate(chunk.model_dump())`

### Step 5: Verification
1. `python -m pyright engines/excerpting/src/phase1_assembly.py` — type check the fix
2. `python -m pytest engines/excerpting/tests/ -q --tb=short` — expect 590+ passed (588 baseline + 2 new), 0 failed

### Step 6: Commit & Push
```bash
git add engines/excerpting/src/phase1_assembly.py engines/excerpting/tests/test_phase1_preamble.py
git commit -m "review-fix: F-1 suppress EX-A-006 on synthetics + F-3 oversized split test"
git push
```

## Critical Files

| File | Action | Purpose |
|------|--------|---------|
| `engines/excerpting/src/phase1_assembly.py:1505` | Edit | F-1 fix: skip heading alignment for `_pre` nodes |
| `engines/excerpting/tests/test_phase1_preamble.py` | Edit | Add 2 tests + new imports |
| `engines/excerpting/tests/test_phase1_hardening.py` | Read-only | Reference for `_generate_arabic_text` pattern |
| `engines/excerpting/tests/conftest.py:63` | Read-only | `_make_assembled_chunk` factory signature |

## Reuse

- `_make_assembled_chunk` from `conftest.py` — factory with valid defaults, override `chunk_id`, `div_id`, `assembled_text`, `word_count`, `total_tokens`, `text_layers`
- `_load_package` / `PACKAGES_DIR` from `test_phase1_preamble.py` module level — already defined for integration tests
- Arabic word generation pattern from `test_phase1_hardening.py:70-83` — 20-word cycling list
- `split_oversized_division` call pattern from `test_phase1_hardening.py:244,273` — `(chunk, [], config)`
