# Plan: Self-Review Fixes for Agent Definitions + Push

## Context

All 7 agents and the adversarial catalog were committed in `981be7e`. This plan covers the self-review findings: comparing each agent against AGENT_ARCHITECTURE.md and checking the adversarial catalog quality.

## Self-Review Findings

### Finding 1: Consolidator quality gate lacks specificity (FIXABLE)

**Architecture §4.1 says:**
```
| Format | All verdicts have 14 required fields | Halt, fix verifier prompt |
| Sources | Verifier B: web_fetch count ≥ 1 per item | Halt, escalate to Architect |
```

**My consolidator.md says:**
```
| Format | All verdicts have required fields | Halt, fix |
| Sources | Verifier B cited web evidence for applicable items | Halt, B didn't do web research |
```

**Fix:** Update consolidator.md quality gate table to match architecture's exact wording:
- "required fields" → "14 required fields"
- "Halt, fix" → "Halt, fix verifier prompt"
- "cited web evidence for applicable items" → "web_fetch count ≥ 1 per item"
- "Halt, B didn't do web research" → "Halt, escalate to Architect"

### Finding 2: 14 verdict fields not enumerated (ARCHITECTURE GAP — cannot fix)

Neither the architecture nor any agent defines what the "14 required fields" are. This is intentional — the verdict schema will be defined during Probe 3 calibration when the Verification Team runs on real normalization output.

**Action:** Note in commit message for Architect awareness. No code change.

### Finding 3: ADV-003 reveals SPEC ambiguity (NOTE — no fix needed)

`width="95%"` (percentage) matches the SPEC regex and captures `95`. The SPEC doesn't distinguish pixel values from percentages. The adversarial test correctly exposes this. The current "correct behavior" (treat as separator) is acceptable because real Shamela `<hr>` tags rarely use percentage widths, and matching is safer than missing footnotes.

**Action:** Add a SPEC-ambiguity note to ADV-003 in the catalog. No behavioral change.

### Finding 4: All other checks PASS

| Check | Agent | Result |
|-------|-------|--------|
| Role match | build-prober | ✅ Reviews diffs vs SPEC, flags deviations/improvisations/omissions |
| Role match | spec-adversary | ✅ Writes adversarial test cases from SPEC |
| Role match | verdict-adversary | ✅ Re-probes VERIFIED items, 20-30% sample |
| Role match | triage-analyst | ✅ Automated €0 checks, risk tiers |
| Role match | verifier-a | ✅ Playbook-guided, records usage |
| Role match | verifier-b | ✅ NO Playbook, 4 prohibition statements |
| Role match | consolidator | ✅ A vs B comparison, 5-round self-review |
| Model | Red Team (3) | ✅ All opus |
| Model | triage-analyst | ✅ sonnet |
| Model | Verification (3) | ✅ All opus |
| P1 enforcement | verifier-b | ✅ Explicit prohibition, reason explained |
| P1 tracking | verifier-a | ✅ Records Playbook influence per verdict |
| P1 tracking | consolidator | ✅ PLAYBOOK_FLAG when A-B disagree on Playbook rule |
| Quality gates | consolidator | ⚠️ Fix specificity (Finding 1) |
| Engine adaptation | verifier-a/b | ✅ Structural/knowledge/hybrid approaches described |
| CANDIDATE_PATTERN | consolidator | ✅ Captures from B's novel patterns + disagreements |
| Adversarial quality | catalog | ✅ 42 concrete cases, real Arabic text, exact thresholds |
| Missing agents | — | ✅ All 16 architecture agents have files |

### Finding 5: Adversarial catalog strength check

For each test case I asked: "Would a wrong implementation actually PASS this test?"

- **ADV-001/002** (boundary values): A wrong impl using `width >= 50` would FAIL these tests. Strong.
- **ADV-005** (orphan footnote): A wrong impl replacing ALL markers would FAIL. Strong.
- **ADV-011** (bold + transition marker): A wrong impl checking only char count would FAIL. Strong.
- **ADV-025** (Arabic ratio 70%): A wrong impl using `>=` instead of `>` would FAIL. Strong.
- **ADV-014** (layer coverage gap): A wrong impl producing gap segments would FAIL §5 check 4. Strong.

**No weak test cases found.** Each adversarial input is designed so that the wrong behavior is a plausible implementation mistake, not a strawman.

## Execution

1. Edit `consolidator.md` quality gate table (3 cell changes)
2. Add SPEC-ambiguity note to ADV-003 in the adversarial catalog
3. Commit with review findings documented
4. Push

## Files Modified

- `.claude/agents/consolidator.md` — quality gate specificity (lines 91-98)
- `reference/SPEC_ADVERSARY_NORMALIZATION.md` — ADV-003 ambiguity note
