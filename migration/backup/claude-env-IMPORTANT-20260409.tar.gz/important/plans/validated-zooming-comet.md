# QuranApp: Advanced Hifz Module — Implementation Plan

## Context

Rayane is an Islamic Studies student building personal learning applications. He loves the existing quran.com web app (reading UI, audio, tafseer, translations) but it lacks a dedicated, intelligent memorization system. The goal is to **fork quran.com-frontend-next** and extend it with a world-class Hifz (Quran memorization) module — featuring FSRS spaced repetition, traditional Sabaq/SabaqPara/Manzil scheduling, progress tracking, colorized bookmarks, self-testing, and an integrated memorization mode within the existing QuranReader.

The repo at `C:\Users\Rayane\desktop\QuranApp` is currently empty. We'll bootstrap it from the quran.com source.

---

## Architecture Overview

### Tech Stack (Inherited + Added)
- **Framework**: Next.js (Pages Router) — inherited from quran.com
- **Language**: TypeScript
- **State**: Redux Toolkit + XState (audio) + SWR (data fetching) — inherited
- **Styling**: SCSS modules with CSS custom properties — inherited
- **New deps**: `ts-fsrs` (spaced repetition), `idb` (IndexedDB wrapper)
- **Storage**: IndexedDB (persistent, structured) + Redux (UI cache)
- **Fonts**: QCF V2 (Uthmanic Hafs) — inherited
- **Data**: Quran.com API — inherited

### Key Architectural Decisions
1. **IndexedDB over localStorage** — 6,236 ayat with FSRS cards + review logs exceed localStorage's 5MB limit
2. **Redux as UI cache only** — IndexedDB is source of truth; Redux holds the working subset for current view
3. **Hifz data separate from bookmarks** — Different data models; keeps existing bookmarks untouched
4. **Memorization mode as overlay** — Not a separate page; activates within QuranReader (like StudyMode)
5. **FSRS mapped to traditional Hifz** — Sabaq/SabaqPara/Manzil categories derived from FSRS card states

---

## Phase 0: Environment & Project Setup
> Install tools, bootstrap the fork, get it running

### 0A. Development Environment Setup
1. Install `claude-code-templates` CLI for agent/hook marketplace
   ```bash
   npm install -g claude-code-templates
   ```
2. Install **React Performance Optimizer** agent (specialized for React perf + Core Web Vitals)
   ```bash
   npx claude-code-templates@latest --agent web-tools/react-performance-optimizer
   ```
3. Install **Next.js Code Quality Enforcer** hook (auto-enforces Next.js patterns)
   ```bash
   npx claude-code-templates@latest --hook automation/next-js-code-quality-enforcer
   ```
4. Verify Node.js 18+ and yarn are available

### 0B. Bootstrap the Fork
1. Clone quran.com-frontend-next into QuranApp directory
   ```bash
   git clone https://github.com/quran/quran.com-frontend-next.git .
   ```
2. Install dependencies with `yarn install`
3. Create `.env.local` with required env vars (API endpoints)
4. Verify the app runs with `yarn dev`
5. Add `ts-fsrs` and `idb` dependencies
   ```bash
   yarn add ts-fsrs idb
   ```
6. Create initial commit on `main` branch

### Files
- `package.json` — add ts-fsrs, idb
- `.env.local` — API configuration
- `.gitignore` — verify it covers our additions

---

## Phase 1: Data Layer Foundation
> Types, IndexedDB schema, Redux slices, bridge hooks

### 1.1 Type Definitions — `types/Hifz.ts`

Core types to create:
- `HifzStatus` enum — `NotStarted | Learning | Memorized | NeedsReview | Bookmarked`
- `AyahHifzRecord` — per-verse state with FSRS card, status, schedule category, timestamps
- `ScheduleCategory` enum — `Sabaq | SabaqPara | Manzil`
- `DailySchedule` / `ScheduleBlock` — daily memorization plan structure
- `HifzSession` / `SessionRating` — session tracking with self-assessment
- `HifzReviewEntry` — FSRS review log linked to sessions
- `TestMode` enum — `CompleteTheAyah | ReciteFromMemory | FirstLetterHint | FillInBlank`
- `TestSession` / `TestResult` — test state and results
- `HifzPlan` — user's memorization settings (daily pace, active days, etc.)
- `SurahProgress` / `JuzProgress` — computed aggregates

### 1.2 IndexedDB Schema — `src/utils/hifz/db.ts`

Database: `quran-hifz`, Version 1

| Store | Key | Indexes |
|-------|-----|---------|
| `ayah-records` | verseKey | by-status, by-chapter, by-juz, by-due-date, by-schedule-category |
| `sessions` | id (UUID) | by-date |
| `review-logs` | id (UUID) | by-verse, by-session, by-date |
| `daily-schedules` | date string | — |
| `plan` | 'current' | — |

### 1.3 FSRS Service — `src/utils/hifz/fsrs.ts`

- Initialize FSRS with 90% target retention, 365-day max interval, fuzz enabled
- `createNewCard()` — factory for new memorization cards
- `reviewCard(card, rating)` — compute next review state
- `getScheduledCards(db)` — query IndexedDB for due reviews
- `sessionRatingToFSRS()` — map self-assessment to FSRS ratings

### 1.4 Redux Slices

**`src/redux/slices/hifz.ts`** — Main slice:
- `ayahStatuses: Record<string, HifzStatus>` — visible verse statuses
- `todaySchedule: DailySchedule | null`
- `stats` — dashboard aggregates (memorized count, streak, due count)
- `plan: HifzPlan | null`
- `memorizationMode` — isActive, hiddenVerseKeys, revealedVerseKeys, testMode

**`src/redux/slices/hifzSession.ts`** — Active session:
- `activeSession: HifzSession | null`
- `isSessionActive: boolean`

Register in `src/redux/store.ts` and `src/redux/types/SliceName.ts`. NOT added to redux-persist whitelist (IndexedDB handles persistence).

### 1.5 Service Layer — `src/utils/hifz/`

- `ayahService.ts` — CRUD for AyahHifzRecord
- `sessionService.ts` — session lifecycle
- `reviewService.ts` — review log management
- `scheduleService.ts` — daily schedule generation (Sabaq/SabaqPara/Manzil algorithm)
- `progressService.ts` — compute surah/juz/overall progress
- `exportImport.ts` — JSON export/import for backup

### 1.6 Bridge Hooks — `src/hooks/hifz/`

- `useHifzDB.ts` — singleton IndexedDB connection
- `useAyahHifzStatus.ts` — single verse status from Redux cache
- `useAyahHifzStatuses.ts` — batch status lookup
- `useHifzDashboardData.ts` — load stats from IndexedDB into Redux
- `useTodaySchedule.ts` — load/generate today's schedule
- `useHifzSession.ts` — session lifecycle
- `useHifzReview.ts` — FSRS review queue management
- `useMemorizationMode.ts` — hide/reveal state
- `useSelfTest.ts` — test progression
- `useSurahProgress.ts` / `useJuzProgress.ts` — progress aggregates
- `useHifzStreak.ts` — consecutive-day streak

---

## Phase 2: QuranReader Integration
> Add memorization features into the existing reading experience

### 2.1 Verse-Level Status Indicators

**Modify `src/components/QuranReader/TranslationView/TranslationViewCell.tsx`**:
- Add `AyahStatusBadge` component showing colored dot for memorization status
- Colors: green=memorized, yellow=learning, red=needs review, blue=bookmarked

**Modify `src/components/Verse/OverflowVerseActionsMenuBody.tsx`**:
- Add "Hifz Status" action to the verse context menu (3-dot menu)
- Opens a popover to set status: Learning / Memorized / Needs Review / Bookmarked

### 2.2 Memorization Mode (Hide/Reveal)

**New components: `src/components/Hifz/MemorizationMode/`**:
- `MemorizationControls.tsx` — toolbar with: Hide All, Reveal All, Next Verse, Test Mode toggle, Exit
- `HiddenVerse.tsx` — renders a blurred/covered verse placeholder with a "Tap to Reveal" button

**Modify `src/components/QuranReader/index.tsx`**:
- Render `MemorizationControls` toolbar when `memorizationMode.isActive`

**Modify `TranslationViewCell.tsx`**:
- When memorization mode is active and verse is hidden, wrap `VerseText` in `HiddenVerse`

**Modify `src/components/QuranReader/ReadingView/Page.tsx`**:
- Add CSS blur overlay for hidden verses in reading mode

### 2.3 Context Menu Toggle

**Modify `src/components/QuranReader/ContextMenu/index.tsx`**:
- Add memorization mode toggle button (icon: brain/book)

### 2.4 Shared Components — `src/components/Hifz/shared/`

- `AyahStatusBadge.tsx` — colored dot indicating HifzStatus
- `ColorTag.tsx` — color tag selector popover for setting status
- `HifzProgressBar.tsx` — segmented progress bar (green/yellow/red/gray)

---

## Phase 3: Dashboard & Schedule
> The command center for memorization

### 3.1 Dashboard Page — `src/pages/hifz/index.tsx`

Uses `getStaticProps` to fetch `chaptersData` (same pattern as other pages).

**Dashboard Components — `src/components/Hifz/HifzDashboard/`**:
- `ProgressOverview.tsx` — total memorization stats (memorized/learning/review/total), visual chart
- `DailyScheduleCard.tsx` — today's Sabaq/SabaqPara/Manzil blocks with "Start" buttons
- `StreakCard.tsx` — consecutive-day memorization streak
- `RecentSessions.tsx` — list of recent sessions with ratings
- `SurahProgressGrid.tsx` — 114 surahs with color-coded progress bars
- `JuzProgressGrid.tsx` — 30 juz progress visualization

### 3.2 Schedule Generation — `src/utils/hifz/scheduleService.ts`

Algorithm:
1. **Sabaq**: Next N verses from `HifzPlan.currentVerse` (where N = dailyNewVerses)
2. **SabaqPara**: All verses with `scheduleCategory === SabaqPara` (learned in last `sabaqParaDays` days)
3. **Manzil**: FSRS-scheduled verses due today from older material
4. Auto-advance `currentVerse` when Sabaq block is completed

### 3.3 Settings Page — `src/pages/hifz/settings.tsx`

- Daily new verses count (default: 5 ayat)
- SabaqPara window (default: 7 days)
- Manzil juz rotation count
- Active days selection (checkboxes for each day)
- Current surah/verse position
- Data export/import buttons

### 3.4 Navigation

**Modify `src/components/Navbar/NavigationDrawer/NavigationDrawerList.tsx`**:
- Add "Hifz" item with book/brain icon, linking to `/hifz`

**Add to `src/utils/navigation.ts`**:
- `HIFZ_URL`, `getHifzReviewUrl()`, `getHifzTestUrl()`, `getHifzSettingsUrl()`, `getHifzProgressUrl()`

---

## Phase 4: Review System & Self-Testing
> FSRS-driven intelligent review + testing modes

### 4.1 Review Queue — `src/pages/hifz/review.tsx`

**Components — `src/components/Hifz/ReviewQueue/`**:
- `ReviewQueue.tsx` — fetches due cards from IndexedDB, presents them one at a time
- `ReviewCard.tsx` — shows verse text, rating buttons (Again/Hard/Good/Easy)
- After rating: FSRS computes next interval, updates IndexedDB, advances to next card
- Shows remaining count and estimated time

### 4.2 Self-Testing — `src/pages/hifz/test.tsx`

**Components — `src/components/Hifz/SelfTest/`**:
- `SelfTestView.tsx` — container with mode selection and verse range picker
- `CompleteTheAyah.tsx` — shows first N words, hides rest; user reveals and self-assesses
- `ReciteFromMemory.tsx` — fully hidden verse; user recites from memory, then reveals to check
- `TestResultsSummary.tsx` — score, time, and per-verse breakdown after test completion

Test modes:
- **Complete the Ayah**: First 2-3 words shown, rest hidden
- **Recite from Memory**: Entire verse hidden, tap to reveal
- **First Letter Hint**: Only first letter of each word shown
- **Fill in Blank**: Random words hidden within verse

### 4.3 Session Tracking

Each memorization/review/test session logged to IndexedDB:
- Duration, verses studied, category (Sabaq/SabaqPara/Manzil/Review/Test)
- Self-assessment rating
- Optional notes

---

## Phase 5: Progress Visualization & Polish
> Visual progress tracking and finishing touches

### 5.1 Progress Page — `src/pages/hifz/progress.tsx`

- Detailed surah-by-surah breakdown with expandable rows
- Juz-level progress with color-coded segments
- Historical chart showing memorization over time
- Heatmap of activity (similar to GitHub contribution graph)

### 5.2 Streak System

- Track consecutive days with at least one session
- Display on dashboard
- Celebrate milestones (7-day, 30-day, 100-day streaks)

### 5.3 Data Backup

- Export all Hifz data as JSON file
- Import from JSON file (with merge strategy)
- Accessible from Settings page

### 5.4 RTL & Accessibility

- Verify all new components work in RTL layout
- Keyboard navigation for memorization mode
- Screen reader labels for status badges
- Proper focus management in hide/reveal flow

---

## Files Summary

### New Files (~45 files)

```
types/Hifz.ts

src/utils/hifz/db.ts
src/utils/hifz/fsrs.ts
src/utils/hifz/ayahService.ts
src/utils/hifz/sessionService.ts
src/utils/hifz/reviewService.ts
src/utils/hifz/scheduleService.ts
src/utils/hifz/progressService.ts
src/utils/hifz/exportImport.ts

src/redux/slices/hifz.ts
src/redux/slices/hifzSession.ts

src/hooks/hifz/useHifzDB.ts
src/hooks/hifz/useAyahHifzStatus.ts
src/hooks/hifz/useAyahHifzStatuses.ts
src/hooks/hifz/useHifzDashboardData.ts
src/hooks/hifz/useTodaySchedule.ts
src/hooks/hifz/useHifzSession.ts
src/hooks/hifz/useHifzReview.ts
src/hooks/hifz/useMemorizationMode.ts
src/hooks/hifz/useSelfTest.ts
src/hooks/hifz/useSurahProgress.ts
src/hooks/hifz/useJuzProgress.ts
src/hooks/hifz/useHifzStreak.ts

src/components/Hifz/HifzDashboard/HifzDashboard.tsx + .module.scss
src/components/Hifz/HifzDashboard/ProgressOverview/ProgressOverview.tsx + .module.scss
src/components/Hifz/HifzDashboard/DailyScheduleCard/DailyScheduleCard.tsx + .module.scss
src/components/Hifz/HifzDashboard/StreakCard/StreakCard.tsx + .module.scss
src/components/Hifz/HifzDashboard/RecentSessions/RecentSessions.tsx + .module.scss
src/components/Hifz/HifzDashboard/SurahProgressGrid/SurahProgressGrid.tsx + .module.scss
src/components/Hifz/HifzDashboard/JuzProgressGrid/JuzProgressGrid.tsx + .module.scss
src/components/Hifz/MemorizationMode/MemorizationMode.tsx + .module.scss
src/components/Hifz/MemorizationMode/MemorizationControls/MemorizationControls.tsx + .module.scss
src/components/Hifz/MemorizationMode/HiddenVerse/HiddenVerse.tsx + .module.scss
src/components/Hifz/SelfTest/SelfTestView.tsx + .module.scss
src/components/Hifz/SelfTest/CompleteTheAyah/CompleteTheAyah.tsx + .module.scss
src/components/Hifz/SelfTest/ReciteFromMemory/ReciteFromMemory.tsx + .module.scss
src/components/Hifz/SelfTest/TestResultsSummary/TestResultsSummary.tsx + .module.scss
src/components/Hifz/HifzSettings/HifzSettings.tsx + .module.scss
src/components/Hifz/ReviewQueue/ReviewQueue.tsx + .module.scss
src/components/Hifz/ReviewQueue/ReviewCard/ReviewCard.tsx + .module.scss
src/components/Hifz/shared/AyahStatusBadge/AyahStatusBadge.tsx + .module.scss
src/components/Hifz/shared/ColorTag/ColorTag.tsx + .module.scss
src/components/Hifz/shared/HifzProgressBar/HifzProgressBar.tsx + .module.scss

src/pages/hifz/index.tsx
src/pages/hifz/review.tsx
src/pages/hifz/test.tsx
src/pages/hifz/settings.tsx
src/pages/hifz/progress.tsx
```

### Existing Files to Modify (~8 files)

```
package.json                                              — add ts-fsrs, idb
src/redux/store.ts                                        — register hifz + hifzSession reducers
src/redux/types/SliceName.ts                              — add HIFZ, HIFZ_SESSION
src/utils/navigation.ts                                   — add hifz routes
src/components/Navbar/NavigationDrawer/NavigationDrawerList.tsx — add Hifz nav item
src/components/QuranReader/index.tsx                       — render MemorizationControls
src/components/QuranReader/TranslationView/TranslationViewCell.tsx — AyahStatusBadge + HiddenVerse
src/components/Verse/OverflowVerseActionsMenuBody.tsx      — add Hifz Status action
src/components/QuranReader/ContextMenu/index.tsx           — memorization mode toggle
```

---

## Verification Plan

### After Phase 0
- [ ] `yarn dev` starts without errors
- [ ] Quran reading, audio, translations all work as upstream

### After Phase 1
- [ ] IndexedDB database creates successfully in browser DevTools > Application > Storage
- [ ] Redux DevTools shows hifz and hifzSession slices
- [ ] Can create/read AyahHifzRecord via browser console

### After Phase 2
- [ ] AyahStatusBadge appears next to verses in translation view
- [ ] Clicking "Hifz Status" in verse menu opens color tag selector
- [ ] Setting status persists in IndexedDB across page refreshes
- [ ] Memorization mode activates from context menu
- [ ] Verses hide/reveal correctly in both translation and reading views
- [ ] Existing features (bookmarks, audio, search) still work

### After Phase 3
- [ ] `/hifz` dashboard loads with progress stats
- [ ] Daily schedule generates correctly based on plan settings
- [ ] Navigation drawer includes Hifz link
- [ ] Settings save and persist

### After Phase 4
- [ ] `/hifz/review` shows due cards with correct FSRS intervals
- [ ] Rating a card updates its next due date correctly
- [ ] All test modes work (CompleteTheAyah, ReciteFromMemory, etc.)
- [ ] Sessions log to IndexedDB with ratings

### After Phase 5
- [ ] Progress page shows accurate surah/juz breakdowns
- [ ] Streak counter works correctly
- [ ] Export produces valid JSON; import restores state
- [ ] All views render correctly in RTL
- [ ] Keyboard navigation works in memorization mode

---

## Execution Strategy

Since the user wants autonomous execution, I will:
1. Execute phases sequentially (0 → 1 → 2 → 3 → 4 → 5)
2. Run verification checks after each phase
3. Commit after each phase completion
4. Use parallel subagents within phases where tasks are independent
5. Follow existing quran.com patterns for all new code (SCSS modules, component structure, Redux patterns)
