# Session 7 Plan: Integration Testing & ADV Gap Closure

## Context

This is the **final normalization engine build session** (Session 7 of 7). The previous 6 sessions built the complete normalization pipeline: Shamela 6-pass normalizer, plain text normalizer, structure discovery, layer detection, boundary continuity, content flagging, validation, writer, and dispatcher. The pipeline processes 63 fixtures successfully (13 real + 50 extended) with 335 tests passing.

Session 7 is **testing-only** — no `src/` modifications. The goal is to add integration tests on real fixtures, close remaining core ADV gaps (8 of 9 remaining), update skip reasons in test_kr_output.py, add L-012 to KNOWN_LIMITATIONS.md, and update build metrics.

All design decisions are pre-resolved in NEXT.md (D7-1 through D7-5). This plan follows the architect's directive literally.

## Critical Files

| File | Action |
|------|--------|
| `engines/normalization/tests/test_integration.py` | **CREATE** — all new tests |
| `engines/normalization/tests/test_kr_output.py` | EDIT — update skip reason strings only |
| `engines/normalization/KNOWN_LIMITATIONS.md` | EDIT — add L-012 |
| `engines/normalization/CLAUDE.md` | EDIT — fix ADV count 30→29, add Session 7 metrics |
| `engines/normalization/tests/conftest.py` | READ-ONLY (factories: `_make_source_metadata`, `_make_cleaned_page`, `_wrap_page`, `_make_html`) |
| `engines/normalization/src/dispatcher.py` | READ-ONLY (`normalize_source()`, `normalize_and_write()`) |
| `engines/normalization/src/content_flagger.py` | READ-ONLY (`compute_content_flags()`) |
| `engines/normalization/contracts.py` | READ-ONLY (schemas) |

## Constraints

1. **Do NOT modify** any file in `engines/normalization/src/`
2. **Do NOT modify** existing test files except `test_kr_output.py` skip strings
3. **Do NOT change** conftest.py
4. **Do NOT implement** deferred ADV cases (027, 030-032, 035-037, 039, 041-044, 046)
5. **Do NOT touch** SPEC.md

## Implementation Steps

### Step 1: Create `test_integration.py` — Imports and Helpers

Create `engines/normalization/tests/test_integration.py` with:

**Imports:**
```python
from __future__ import annotations
import json
import re
from pathlib import Path
import pytest
from engines.normalization.contracts import (
    ContentFlags, ContentUnit, LayerType, NormalizedManifest, NormalizedPackage,
)
from engines.normalization.src.dispatcher import normalize_source, normalize_and_write
from engines.normalization.src.content_flagger import compute_content_flags
from engines.normalization.tests.conftest import (
    _make_source_metadata, _make_cleaned_page, _wrap_page, _make_html,
)
```

**Fixture discovery helper** (module-level, from NEXT.md):
```python
def _discover_fixtures():
    project_root = Path(__file__).parent.parent.parent.parent  # kr/
    fixtures = []
    for base in [project_root / "tests" / "fixtures" / "shamela_real",
                 project_root / "tests" / "fixtures" / "shamela_extended"]:
        if not base.exists():
            continue
        for d in sorted(base.iterdir()):
            if not d.is_dir() or d.name.startswith("."):
                continue
            htms = list(d.glob("*.htm"))
            if htms:
                fixtures.append((d.name, htms[0]))
    return fixtures

FIXTURES = _discover_fixtures()
MULTI_LAYER_FIXTURES = {"02_nahw_muhaqiq"}
```

**Fixture path constants** for named tests:
```python
FIXTURES_REAL = Path("tests/fixtures/shamela_real")
```

### Step 2: TestShamelaNormalizer (9 tests)

All tests call `normalize_source()` on real fixtures using `_make_source_metadata()`.

1. `test_output_schema_compliance` — `02_nahw_muhaqiq`, `is_multi_layer=True`. Assert NormalizedPackage, valid manifest, source_id, total_content_units match, non-empty division_tree, layer_map has 2 entries.
2. `test_content_preservation_arabic_text` — `02_nahw_muhaqiq`. Assert every CU has non-empty primary_text. Assert >50% Arabic chars. Assert no `<` or `>` in any primary_text.
3. `test_footnote_separation` — `03_fiqh` (32 pages with footnotes). Assert >=20 CUs with footnotes. Assert non-empty `.text`.
4. `test_multi_layer_detection` — `02_nahw_muhaqiq`, `is_multi_layer=True`. Assert MATN + SHARH in layer_map. Assert >=3 CUs with 2+ text_layers.
5. `test_diacritics_preservation` — `04_hadith`. Assert diacritics codepoints exist. Assert total count >5000 (confirmed: 11,120).
6. `test_page_boundaries` — `02_nahw_muhaqiq`. Assert unit_index contiguous 0..N-1. Assert volume >=1. Assert len == total_content_units.
7. `test_structure_discovery` — `06_usul` (9 divisions). Assert >=5 division_tree entries. Assert non-empty heading_text. Assert start<=end for all nodes.
8. `test_content_flags` — `04_hadith`: >=30 CUs with has_hadith_citation. `01_nahw_simple`: 0 or very few hadith flags.
9. `test_boundary_continuity_signals` — `01_nahw_simple`. Assert >=50% CUs have boundary_continuity. Assert >=2 distinct boundary types. Assert all non-None confidence >0.

### Step 3: TestContentFlagger (3 tests)

Unit-level tests using `_make_cleaned_page()` and `compute_content_flags()`.

10. `test_quran_verse_detection` — Construct page with `قال تعالى {وَأَقِيمُوا الصَّلَاةَ}`. Assert `has_quran_citation == True`. Test without pattern → False.
11. `test_hadith_marker_detection` — Page with `رواه البخاري`. Assert True. Page with `ﷺ`. Assert True. Clean text → False.
12. `test_poetry_verse_detection` — Page with `has_verse=True` → True. `has_verse=False` → False.

### Step 4: TestContentCensus (1 skip)

13. `test_census_deferred` — `pytest.skip("§4.B.5 DEFERRED — content census not in core build")`.

### Step 5: TestFixtureIntegration (63 parametrized tests)

Parametrize over all `.htm` files in `shamela_real/` (13) and `shamela_extended/` (50).

For each fixture:
1. Build metadata with `_make_source_metadata(is_multi_layer=...)`.
2. Call `normalize_source()`.
3. Assert NormalizedPackage type.
4. Assert `len(content_units) == manifest.total_content_units`.
5. Assert contiguous unit_index 0..N-1.
6. Assert every non-blank CU primary_text contains Arabic chars.
7. Assert non-empty layer_map.
8. **F1 Silent page loss check:** Parse raw HTML with BeautifulSoup (local import), count `<div class='PageText'>` tags, assert `abs(raw_count - len(content_units)) <= 5`.

### Step 6: TestNormalizeAndWrite (3 tests)

1. `test_end_to_end_write_and_read` — `01_nahw_simple` via `normalize_and_write()` to `tmp_path`. Verify files exist, manifest source_id, JSONL line count, first line parseable with `primary_text` key.
2. `test_roundtrip_content_integrity` — Write+read first CU's primary_text. Assert identical.
3. `test_plain_text_normalize_and_write` — Create temp `.txt` with 3 Arabic paragraphs. Call `normalize_and_write()` with `source_format='plain_text'`. Verify files, content, `normalizer_id` contains `plain_text`.

### Step 7: TestAdversarialGap (8 tests)

1. **ADV-019** `test_adv019_unit_index_contiguity` — Run on `02_nahw_muhaqiq` (295 units) and `03_fiqh` (102 units). Assert indices = `range(N)`.
2. **ADV-020** `test_adv020_duplicate_page_numbers` — Construct 2-page HTML both with `(ص: 12)`. Assert 2 CUs with unique unit_index (0,1) and both `page_number_int == 12`.
3. **ADV-022** `test_adv022_trailing_diacritics_preserved` — HTML with text ending in kasra (U+0650). Assert kasra present in output.
4. **ADV-034** `test_adv034_universal_footnote_marker` — HTML with `(1)` ref and `<hr width='95'>` footnote section. Assert `⌜1⌝` in primary_text. Assert no literal `(1)`.
5. **ADV-038** `test_adv038_interrupted_write_missing_content` — Document as "covered by test_writer.py::TestRecoverInterruptedWrite::test_adv047_invalid_temp_restores_from_latest_prev" (confirmed: test_writer.py:145 creates temp with manifest.json but no content.jsonl = "missing content"). Skip with reference.
6. **ADV-040** `test_adv040_arabic_filename_multi_volume` — Create temp dir with `المجلد_الأول.htm` and `المجلد_الثاني.htm`, each valid single-page HTML. Run `normalize_source()` on directory. Assert 2 CUs with sequential volumes.
7. **ADV-048** `test_adv048_windows_1256_encoding` — Create temp file with Arabic text encoded in Windows-1256. Run `normalize_source()`. Assert Arabic preserved. Assert `NORM_ENCODING_ERROR` in `caplog`.
8. **ADV-049** `test_adv049_page_number_overflow` — HTML with `(ص: 999999999999999)`. Assert no crash. Assert CU exists.

### Step 8: Update `test_kr_output.py` Skip Reasons

Update each of the 11 skipped tests (not TestContentCensus) with specific superseding references:

- `TestShamelaNormalizer::test_output_schema_compliance` → `"Superseded by test_integration.py::TestShamelaNormalizer::test_output_schema_compliance — Session 7"`
- `TestShamelaNormalizer::test_content_preservation_arabic_text` → same pattern
- `TestShamelaNormalizer::test_footnote_separation` → same
- `TestShamelaNormalizer::test_multi_layer_detection` → same
- `TestShamelaNormalizer::test_diacritics_preservation` → same
- `TestShamelaNormalizer::test_page_boundaries` → same
- `TestShamelaNormalizer::test_structure_discovery` → same
- `TestShamelaNormalizer::test_content_flags` → same
- `TestContentFlagger::test_quran_verse_detection` → `"Superseded by test_integration.py::TestContentFlagger::test_quran_verse_detection — Session 7"`
- `TestContentFlagger::test_hadith_marker_detection` → same pattern
- `TestContentFlagger::test_poetry_verse_detection` → same

Update `TestContentCensus::test_census_on_synthetic_content`:
```python
pytest.skip("§4.B.5 DEFERRED — content census not in core build (CORE_EXTRACTION.md)")
```

### Step 9: Add L-012 to KNOWN_LIMITATIONS.md

Append L-012 entry (Arabic-Indic digit footnote markers) per the exact text in NEXT.md.

### Step 10: Update CLAUDE.md Build Metrics

1. Fix line 90: change `30/51 ADV` → `29/51 ADV` (the actual pre-Session-7 count)
2. Add Session 7 row to the build table: `| 7 | Integration testing on fixtures | Full pipeline, adversarial cases | ✅ Done |`
3. Update build metrics line with new counts: tests, ADV coverage (29+8=37/51 with ADV-038 documented as covered)

## Existing Utilities to Reuse

- `conftest._make_source_metadata(**overrides)` — builds SourceMetadata (lines 59-107)
- `conftest._make_cleaned_page(primary_text, ...)` — builds CleanedPage (lines 134-152)
- `conftest._wrap_page(content, page_num)` — wraps in PageText div (lines 269-280)
- `conftest._make_html(*page_contents)` — builds minimal Shamela HTML (lines 283-289)
- `dispatcher.normalize_source(frozen_path, metadata)` — full normalization pipeline
- `dispatcher.normalize_and_write(frozen_path, metadata, library_root)` — normalize + validate + write
- `content_flagger.compute_content_flags(page, is_toc_page)` — content flag computation
- `FIXTURES_REAL` path constant from conftest (line 49)

## Key Technical Notes

1. **ADV-040 (Arabic filenames):** `_resolve_input_files()` handles non-numeric stems by assigning sequential volume numbers starting from max(numeric)+1. Both Arabic filenames will be non-numeric, getting volumes 1 and 2.

2. **ADV-048 (Windows-1256):** `_read_html()` catches `UnicodeDecodeError` on UTF-8 and falls back to `windows-1256`. Log message uses `NormErrorCode.ENCODING_ERROR.value` = `"NORM_ENCODING_ERROR"`. Use `caplog` to capture it.

3. **ADV-034 (footnote marker):** Pass 2 replaces `(1)` with `⌜1⌝` (U+231C + U+231D). Test needs a footnote section after `<hr width='95'>` with matching `(1)` marker to trigger replacement.

4. **ADV-038:** Already covered by `test_writer.py::test_adv047_invalid_temp_restores_from_latest_prev` (line 145) which creates temp with manifest but no content.jsonl. Document with skip, per D7-4.

5. **BeautifulSoup import:** Used only in `TestFixtureIntegration.test_normalize_source_all_fixtures` for the F1 page loss check. Import locally inside the method, not at module level. Already a project dependency (`beautifulsoup4>=4.12`).

6. **Test count expectations:** 335 existing + ~86 new = ~421 total. Skips: 12 existing (in test_kr_output.py) + 1 new (census) + 1 ADV-038 = 14 skips.

## Verification

All 5 checks must pass before committing:

```bash
# 1. Full test suite — zero failures
python -m pytest engines/normalization/tests/ -v --tb=short
# Expected: ~421 passed, 14 skipped

# 2. Integration tests specifically
python -m pytest engines/normalization/tests/test_integration.py -v --tb=short
# Expected: all pass except 2 skips (census + ADV-038)

# 3. Smoke test regression
python tools/smoke_test_validation.py
# Expected: 63/63 PASS

# 4. No src/ changes
git diff --name-only engines/normalization/src/
# Expected: empty

# 5. ADV coverage in new file
grep -oi "adv.0[0-9][0-9]" engines/normalization/tests/test_integration.py | sort -u | wc -l
# Expected: >= 8
```

## Commit

Single commit: `feat: Session 7 — integration tests, ADV gap closure, L-012`
