# Plan: Unify the Autonomous System — One Launcher, Clear Map

## Context

Three independently-built systems exist in the repo, built by different tools at different times:

| System | Entry Point | Tool | Lines | Purpose |
|--------|-------------|------|-------|---------|
| **System 0** "Overnight v2" | `scripts/overnight_orchestrator.py` | Claude Code CLI | 2,904 | Quality work (tests, SPEC audit, Arabic edge cases, creative) |
| **System 1** "Overnight Codex" | `scripts/overnight_codex_orchestrator.py` | Codex CLI in worktrees | 4,459 | Same as above but newer, with backlog + creative templates |
| **System 2** "KB Digestion" | `scripts/digest_dr.py` + dashboard | Python pipeline | ~2,500 | DR response → findings → cross-ref → follow-up prompts → dashboard |

**Problems:**
- No unified entry point (3 separate commands)
- System 1 results don't flow into System 2's KB (dashboard never sees Codex findings)
- System 2's data lives inside System 1's directory (`overnight_codex/autonomous/`)
- No follow-up prompt generation from Codex findings
- Branch mess (24 branches, some with 175+ unique commits)
- No clarity document explaining what's what

**Goal:** ONE command starts everything. Codex runs tasks → results become KB findings → cross-references find contradictions → follow-up prompts appear on dashboard → owner relays to DR → cycle continues.

---

## Implementation Steps (6 steps, ~400 new lines)

### Step 1: SYSTEM_MAP.md — Clarity Document

**NEW:** `docs/autonomous-system/SYSTEM_MAP.md` (~80 lines)

Plain-language explanation of all three systems: what each does, how to run it, how they relate, and the unified launcher. This is the "I'm confused, what is all this?" document.

### Step 2: Add CODEX enum to DRTarget

**MODIFY:** `scripts/autonomous_schemas.py` (+1 line)

Add `CODEX = "codex"` to `DRTarget` at line 43. Lets `DRResponse` and `DigestionRecord` reference Codex as a source.

### Step 3: Bridge Module — Codex Results → KB Findings

**NEW:** `scripts/codex_kb_bridge.py` (~180 lines)

Core function: `ingest_codex_results(run_id) → dict[str, int]`

Logic:
1. Scan `overnight_codex/results/*/final_response.json`
2. Skip already-ingested tasks (read `digestion_log.jsonl`)
3. For each un-ingested task:
   - Convert `action_items` → `Finding` records (one per item)
   - Convert `findings` strings → `Finding` records (severity=INFORMATIONAL)
   - Create `DRResponse` record (source=DRTarget.CODEX)
   - Create `DigestionRecord` (provider=DRTarget.CODEX)
   - Append all via `append_jsonl()`
4. Run `cross_reference_all()` on ALL findings (existing + new)
5. **Run `generate_followups()`** — creates DR prompts from new contradictions/gaps
6. Return stats

**Field mapping:**
- `finding_id` = `F-codex-{task_id}-{item_id}`
- `source_type` = `"codex_task"`
- `severity` = item.priority mapped (HIGH→high, MEDIUM→medium, LOW→low)
- `category` = task category mapped (review/test→ENGINE_SPECIFIC, creative→CREATIVE_VISIONARY, spec→ARCHITECTURE)
- `affected_files` = from evidence[].path + files_changed
- `confidence` = 0.7 (structured output, not heuristic)
- `raw_text_hash` = SHA-256 of `{task_id}:{item.id}` for idempotent dedup

**Key reuse:** `autonomous_schemas.py` (models, append_jsonl), `cross_reference_findings.py`, `generate_followup_prompts.py`, `overnight_codex_common.py` (RESULTS_DIR)

### Step 4: Hook Bridge into Orchestrator

**MODIFY:** `scripts/overnight_codex_orchestrator.py` (+10 lines)

Add `ingest_to_kb(state.run_id)` at line 2582, after `maybe_append_findings()` and before `generate_morning_report()`. Non-fatal on failure (try/except + log_decision, same pattern as existing sync_backlog and maybe_append_findings).

### Step 5: Unified Launcher

**NEW:** `scripts/launch_autonomous.py` (~120 lines)

```bash
python scripts/launch_autonomous.py                    # 4h, dashboard on :8000
python scripts/launch_autonomous.py --hours 8          # 8h overnight
python scripts/launch_autonomous.py --no-dashboard     # headless
python scripts/launch_autonomous.py --ingest-only      # bridge existing results only
python scripts/launch_autonomous.py --dashboard-only   # just view dashboard
```

Logic:
1. Parse args: `--hours` (4), `--port` (8000), `--no-dashboard`, `--no-browser`, `--ingest-only`, `--dashboard-only`, `--dry-run`
2. Start dashboard in daemon thread (unless `--no-dashboard`) — same pattern as `dashboard.py` line 41
3. Run `run_overnight()` from orchestrator (direct import, not subprocess)
4. Bridge runs automatically (hooked into orchestrator finalization at step 4)
5. Print summary: tasks run, findings created, prompts generated, dashboard URL

### Step 6: Safe Branch Cleanup

**Branches with 0 unique commits — safe to delete:**
- `autonomous-system` (local + remote)

**Branches to KEEP (have unique unmerged work):**
- `excerpting-foundations-hardening-20260404` (175 commits)
- `migration/wsl-to-windows-main-20260405` (92 commits)
- `taxonomy-k2-synthesis-20260406` (49 commits)
- `wsl-master-preserved-20260406` (22 commits)
- `taxonomy-sarf-review-packet-publish-20260406` (15 commits)

**Branches to investigate before deciding (1-3 commits):**
- `codex/doctrine-reconcile-20260401_1015` (1 commit)
- `codex/mainline-proof-20260401_1818` (3 commits)

**Remote-only branches — check if merged before deleting.**

**NOTE:** The ultrathink plan said "11 stale branches with 0 unique work" — that was wrong. Most have significant unmerged work. We will NOT blindly delete.

---

## Critical Files Reference

| File | Action | Purpose |
|------|--------|---------|
| `scripts/autonomous_schemas.py:38-43` | Add CODEX enum | Prerequisite for bridge |
| `scripts/overnight_codex_common.py:90-155` | Read only | FINAL_RESPONSE_SCHEMA — defines Codex result format |
| `scripts/overnight_codex_backlog.py:194-234` | Pattern to follow | `_upsert_result_action_items` — existing result→backlog conversion |
| `scripts/overnight_codex_orchestrator.py:2579-2584` | Hook insertion point | Finalization sequence where bridge call goes |
| `scripts/cross_reference_findings.py` | Called by bridge | Post-ingestion cross-referencing |
| `scripts/generate_followup_prompts.py:271` | Called by bridge | `generate_followups()` — creates DR prompts |
| `scripts/dashboard.py` | Pattern for launcher | uvicorn + browser thread pattern |
| `scripts/autonomous_dashboard/store.py` | No changes needed | Already handles any Finding source_type generically |

## Verification

1. `python -c "from scripts.autonomous_schemas import DRTarget; print(DRTarget.CODEX)"` — enum accepted
2. Create mock `final_response.json` in temp dir → run bridge → verify findings.jsonl updated
3. `python scripts/launch_autonomous.py --dashboard-only --no-browser` — dashboard starts on :8000
4. `python scripts/launch_autonomous.py --ingest-only` — bridge runs, findings appear on dashboard
5. Run bridge twice → second run skips already-ingested (idempotent)
6. Each piece still works standalone (orchestrator, digest_dr, dashboard)
7. `python -m pytest engines/excerpting/tests/ -x -q` — existing tests unbroken

## Sequence

1. SYSTEM_MAP.md (clarity first)
2. `autonomous_schemas.py` — add CODEX enum
3. `codex_kb_bridge.py` — the bridge
4. `overnight_codex_orchestrator.py` — hook bridge
5. `launch_autonomous.py` — unified launcher
6. Branch cleanup (safe deletions only)
7. Smoke test
