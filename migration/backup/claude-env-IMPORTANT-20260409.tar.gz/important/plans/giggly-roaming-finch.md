# Post-E2E Validation Audit — Fix Plan

## Context

Deep audit of the E2E validation work found 1 critical issue and 1 medium issue. The fix verification logic itself is correct (all 5 PASS verdicts confirmed against actual data), but supporting artifacts need cleanup.

## Audit Summary

### Verified Correct (no action needed)
- All 5 book results verified against actual result.json data
- Fix 1 (rihlah): genre=rihlah, Ibn Rushayd's travel narrative correctly classified
- Fix 2 (hashiyah gate): gate_abort fired, gate_errors confirms "hashiyah requires 3 layers"
- Fix 3 (death_date): needs_review_fields contains death_date_hijri, ERR-03 pattern confirmed (Opus=1437, CommandA=null)
- Fix 4 (control): hadith_collection unchanged
- Fix 1b (usul_al_fiqh): genre=usul_al_fiqh, Ibn Qayyim's foundational work correctly classified
- Engine code properly reverted (consensus.py + run_phase_c.py)
- Git state clean, commit pushed

### Fix 1 (Critical): COST_LOG.json Phase C data corrupted

`run_phase_c.py` always writes to `cost_log["phases"]["C"]` regardless of `--output-dir`. The E2E run overwrote the original Phase C entry.

**Git history of corruption:**
- `b18c850`: Phase C = 73 books, €7.00 (CORRECT)
- `f3250b4`: Phase C = 5 books, €0.50 (first corruption — earlier unrelated commit)
- `7ddbab4`: Phase C = 204 books, €20.40 (Phase D run doubled it)
- `d9ed505`: Phase C = 5 books, €0.50 (E2E run overwrote again)

**Fix:** Restore `tests/results/source_engine/COST_LOG.json`:
```json
{
  "phases": {
    "0": {"books": 13, "cost_eur": 1.8, "status": "complete"},
    "A": {"books": 2519, "cost_eur": 0.0, "status": "complete"},
    "C": {"books": 73, "cost_eur": 7.0, "status": "complete"},
    "D": {"books": 204, "cost_eur": 20.4, "status": "complete"},
    "E2E": {"books": 5, "cost_eur": 0.5, "status": "complete"},
    "E": {"books": 0, "cost_eur": 0.0, "status": "pending"}
  },
  "total_eur": 30.6,
  "budget_ceiling_eur": 100.0
}
```

Note: Phase sum = 29.7 < total_eur 30.6 because ~€0.9 went to testing/exploration not assigned to a named phase. The total_eur is the correct running total.

### Fix 2 (Medium): verify_e2e_fixes.py unused variable + cost cleanup

- Line 193: `phase_c_cost` read from COST_LOG but never used — remove
- Lines 211-216: Cost calculation reads per-book cost with 0.10 fallback. Simplify to just use the known total (5 books × €0.10 = €0.50 as reported by pipeline).

## Verification

After fixes:
1. `python scripts/verify_e2e_fixes.py` still prints all 5 PASS with €0.50 total
2. COST_LOG.json Phase C shows 73 books/€7.00 (not 5/€0.50)
3. Git diff shows only COST_LOG.json and verify_e2e_fixes.py changed
