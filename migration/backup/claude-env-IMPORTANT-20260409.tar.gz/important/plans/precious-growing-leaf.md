# Plan: Session 6 Integration Run

## Context
Session 6 integration script (`scripts/run_session6_integration.py`) runs all 13 fixtures through `acquire_source` with live LLM calls and compares results against `tests/fixtures/GROUND_TRUTH.json`. There's a bug where the author comparison never runs because the ground truth field is `"author_identified"` but the code checks for `"author_name"`.

## Steps

### Step 1: Install dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Fix bug in `scripts/run_session6_integration.py`
**File:** `scripts/run_session6_integration.py`
**Lines 84-85** (user said line 93 but the actual bug is at 84-85):

Change:
```python
if "author_name" in truth:
    results["author_match"] = truth["author_name"] in metadata.author.name_arabic
```
To:
```python
if "author_identified" in truth:
    results["author_match"] = truth["author_identified"] in metadata.author.name_arabic
```

### Step 3: Set environment variables
```bash
export ANTHROPIC_API_KEY="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"
export OPENROUTER_API_KEY="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"
```

### Step 4: Run integration script
```bash
python scripts/run_session6_integration.py
```
This runs all 13 fixtures (12 Shamela + 1 plaintext) with live LLM calls. Hard cost ceiling: $5. Expected runtime: several minutes.

**Do NOT fix any failures.** Let the full run complete.

### Step 5: Commit and push results
```bash
git add tests/results/source_engine/session6/
git commit -m "Step 0: Session 6 integration results"
git push
```

## Verification
- Results directory `tests/results/source_engine/session6/` should contain:
  - One JSON per fixture (13 files)
  - `SESSION6_SUMMARY.json` with pass/fail counts
- Author match checks should now appear in ground truth comparisons (previously silently skipped)
