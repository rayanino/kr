# Plan: Fix 5 Phase A Findings in Shamela HTML Extractor

## Context

Phase A (deterministic sweep) ran successfully: 2,519/2,519 books, zero crashes, 28.5 seconds. But data review in `PHASE_A_FIXES.md` found 2 critical bugs, 1 moderate bug, and 2 minor fixes in `shamela_html.py` that must be fixed before Step 3 (LLM probes). Every wrong value here feeds into LLM prompts, producing wrong inferences that cost money and time to debug.

**Task spec:** `PHASE_A_FIXES.md`
**Single file to modify:** `engines/source/src/extractors/shamela_html.py` (lines 25-88 for FIELD_MAP, lines 327-360 for `_parse_bibliographic_fields`, line ~201 for fallback)

---

## Fix 1+5 (combined): القسم guard — skip header line in field loop

**Root cause:** `_RE_FIELD.finditer()` matches the card header line (`TITLE&nbsp;(AUTHOR)القسم: CATEGORY`). After `strip_tags()`, the label ends with `القسم`. This causes:
- Bug 1 (32 books): MUHAQIQ_KEYWORDS triggers on titles containing تحقيق/تعليق/تخريج, assigns the Shamela category (e.g., "كتب السنة") as `muhaqiq_name_raw`
- Fix 5 (2,193 books): Header line redundantly captured in `_extra_card_fields`

**Change in `_parse_bibliographic_fields()` (line ~333):** Add as the FIRST check in the loop, before any other processing:
```python
# Skip header line captured as field — القسم is never a real field label.
# The category is already extracted by _parse_category().
if "القسم" in label:
    continue
```

**Risk:** Zero. No legitimate field label contains `القسم`. Category already extracted by `_parse_category()`.

---

## Fix 2: Format B colon-in-label recovery (64 books)

**Root cause:** Two HTML card formats exist:
- Format A (standard, 2,455 books): `<span class='title'>LABEL<font>:</font></span> VALUE`
- Format B (variant, 64 books): `<span class='title'>LABEL <font>:</font> VALUE ... <font>:</font></span> CONTINUATION`

In Format B, the value is INSIDE the `<span>` tag. The regex's non-greedy `(.*?)` expands to the LAST colon before `</span>`, so group 1 captures `LABEL : VALUE (المتوفى` and group 2 gets just a fragment like `1425هـ)`.

After `strip_tags()`, the label contains `:` — this is the reliable detection signal.

**Change in `_parse_bibliographic_fields()`, after القسم guard, before FIELD_MAP lookup:**
```python
# Format B: when the field value is inside <span class='title'>,
# strip_tags(label) contains ":" from the embedded <font>:</font>.
# Split on first ":" to recover the real label and value.
if ":" in label:
    colon_pos = label.index(":")
    real_label = label[:colon_pos].strip()
    value_prefix = label[colon_pos + 1:].strip()
    label = real_label
    if value_prefix and value:
        value = f"{value_prefix} {value}"
    elif value_prefix:
        value = value_prefix
```

**Why space-join (not colon-join):** Plan agent analysis found 123 colon-in-label instances across the collection. Colon-join (`f"{prefix}: {value}"`) is correct for titles (subtitle separator) and المتوفى cases, but adds spurious colons in 49 other fields (الطبعة, الناشر, أ.د. cases). Space-join works universally:
- Titles: `أجنحة المكر الثلاثة وخوافيها التبشير...` — loses subtitle colon but display_title provides the short title
- Authors with death: `عبد الرحمن ... (المتوفى 1425هـ)` — `_RE_AUTHOR_DEATH` uses `المتوفى\s*:?\s*` (optional colon), still works
- Editions: `الأولى 1398 هـ` — correct
- Publishers: `عطاءات العلم ...` — correct

**Risk:** Zero false positives — no FIELD_MAP label or MUHAQIQ_KEYWORDS entry contains `:`.

---

## Fix 3: title_full fallback to display_title (32 books)

**Root cause:** 32 books lack a parseable `الكتاب:` field, but all have `display_title` from the header. Some overlap with Bug 2 (Format B الكتاب fields) — those will be fixed by Fix 2. The fallback handles the remaining cases.

**Change in `extract_shamela_metadata()`, after `_parse_bibliographic_fields(card, result)` (line ~201), before `_parse_death_dates(result)`:**
```python
# Fallback: if title_full not extracted but display_title exists
if "title_full" not in result and "display_title" in result:
    result["title_full"] = result["display_title"]
    result["_field_source_title_full"] = "display_title_fallback"
```

**Risk:** Zero. Pure fallback, no overwrite.

---

## Fix 4: Add unmapped labels to FIELD_MAP

Add to the appropriate sections of `FIELD_MAP` (lines 25-88):

| Label | Maps to | Section | Rationale |
|-------|---------|---------|-----------|
| `تأليف` | `author_name_raw` | After `المؤلف` (line 29) | Synonym for المؤلف (3 books) |
| `بعناية` | `muhaqiq_name_raw` | After last muhaqiq entry (line 48) | Editorial care variant (3 books) |
| `جمعها` | `compiler_name_raw` | After `جمع وترتيب` (line 68) | Collection/compilation (3 books) |
| `انتقاء` | `compiler_name_raw` | After `جمعها` | Selection/curation (8 books) |
| `تاريخ النشر` | `publication_year_raw` | After `سنة النشر` (line 59) | Publication date variant (4 books) |

**Not adding:** `رواية` (26 books) — hadith-specific narration label, needs owner input on correct mapping. Stays in `extra_card_fields`.

**Risk:** Very low. Standard FIELD_MAP additions following existing patterns.

---

## Implementation sequence

1. **FIELD_MAP additions** (Fix 4) — add 5 new entries to the dict
2. **`_parse_bibliographic_fields()` modifications** (Fix 1+5 + Fix 2) — add القسم guard + colon-split, both before existing FIELD_MAP logic
3. **`extract_shamela_metadata()` fallback** (Fix 3) — add title_full fallback after field parsing
4. **Run existing tests** — `python -m pytest engines/source/tests/ -v --tb=short` — all 477+ must pass
5. **Run ALL tests** — `python -m pytest engines/*/tests/ shared/*/tests/ -q` — all 549+ must pass
6. **Re-run Phase A on full collection** — `python scripts/run_phase_a.py "C:\Users\Rayane\Desktop\kr\shamela export samples" --output-dir tests/results/source_engine/phase_a`
7. **Compare metrics against baseline:**

| Metric | Before | Expected After |
|--------|--------|----------------|
| successful | 2,519 | 2,519 (no regressions) |
| errors | 0 | 0 |
| title_full count | 2,472 (98.1%) | ≥2,504 (≥99.4%) |
| author_name_raw count | 2,375 (94.3%) | ≥2,439 (≥96.9%) |
| muhaqiq_name_raw count | 1,372 (54.5%) | ~1,340 (32 false positives removed, some real added) |
| Books with category-as-muhaqiq | 32 | 0 |

8. **Spot-check 5 books** from each bug category per PHASE_A_FIXES.md §Step 5
9. **Write `PHASE_A_LESSONS.md`** per PHASE_A_FIXES.md §Step 6

---

## Critical files

| File | Role |
|------|------|
| `engines/source/src/extractors/shamela_html.py` | ALL code fixes (FIELD_MAP + _parse_bibliographic_fields + extract_shamela_metadata) |
| `engines/source/tests/test_deterministic.py` | Existing Shamela tests — must not regress |
| `PHASE_A_FIXES.md` | Task specification with verification criteria |
| `scripts/run_phase_a.py` | Phase A runner (DO NOT modify) |
| `shamela export samples/أجنحة المكر الثلاثة.htm` | Primary Format B test case |

## What NOT to do

- Do NOT modify `run_phase_a.py` — it works correctly
- Do NOT modify any module outside `shamela_html.py`
- Do NOT change the quality inspection logic
- Do NOT attempt to fix page count mismatches or truncations — those are real Shamela data quality issues
