# Implementation Plan: KR Memory System Upgrade

## Context

6-source investigation (DR25, DR26, DR27, Gemini CLI, Codex CLI, CC direct measurement) converged on a 4-layer architecture. This plan implements Layers 1-3. Layer 4 is deferred post-pipeline.

## Architecture Summary

```
Layer 1: AGENTS.md (universal cross-tool surface)
Layer 2: Schema-governed doctrine (typed markdown + auto-index)
Layer 3: Append-only event log (JSONL via session_stop.py)
Layer 4: Derived indexes (DEFERRED — SQLite FTS5 when needed)
```

## Implementation Units

### Unit 1: Fix 5-vs-7 engine contradiction
- **File:** `.claude/projects/C--Users-Rayane-Desktop-kr/memory/principles.md`
- **Change:** Line 9: "5-engine pipeline" → "7-engine pipeline"
- **Verification:** grep for "5-engine" across all memory files
- **Priority:** IMMEDIATE (invariant inconsistency)

### Unit 2: Expand AGENTS.md
- **File:** `AGENTS.md` (repo root, already exists at 1,724 bytes)
- **Change:** Expand to ~10KB with curated critical conventions:
  - Pipeline-first doctrine (from CLAUDE.md)
  - Arabic text handling critical rules (from .claude/rules/arabic-scholarly-conventions.md — condensed)
  - Python code critical rules (from .claude/rules/python-code.md — condensed)
  - Testing rules (from .claude/rules/testing.md — condensed)
  - No-single-model-conclusion rule (condensed)
  - Autonomous operation constraints
  - Keep under 32KiB budget (target ~10KB)
- **Verification:** `wc -c AGENTS.md` < 32768
- **Priority:** IMMEDIATE (enables overnight Codex)

### Unit 3: Add @AGENTS.md import to CLAUDE.md
- **File:** `CLAUDE.md` (repo root)
- **Change:** Add `@AGENTS.md` at top so Claude Code also reads AGENTS.md
- **Verification:** Start new CC session, verify AGENTS.md content is loaded
- **Priority:** IMMEDIATE (cross-tool bridge)

### Unit 4: Add frontmatter schema to memory system
- **File:** Auto-memory system instructions (in system prompt, not a file)
- **Change:** Document required frontmatter fields:
  - Existing: name, description, type
  - New: created_at, scope, status (active/superseded/archived), supersedes, source_agent, confirmed_by
  - New type: kunnash (pedagogical observations for student)
- **Verification:** Check that new memories include required fields
- **Priority:** HIGH (enables Layer 2 automation)

### Unit 5: Build auto-generated MEMORY.md index
- **File:** New script `scripts/generate_memory_index.py`
- **Change:** Scans all memory files, validates frontmatter, generates MEMORY.md
- **Verification:** Generated index matches manual index content
- **Priority:** HIGH (solves 200-line ceiling)
- **DEFERRED to follow-up session** (moderate complexity)

### Unit 6: Build invariant consistency checker
- **File:** New script `scripts/check_invariant_consistency.py`
- **Change:** Asserts key invariants (engine count, pipeline stages, D-rules) match across governance docs
- **Verification:** Catches the 5-vs-7 contradiction (test case)
- **Priority:** HIGH (prevents doctrine drift)
- **DEFERRED to follow-up session**

### Unit 7: Extend session_stop.py for event log
- **File:** `scripts/session_stop.py`
- **Change:** Append structured events to `memory/events/YYYY/MM/sessions.jsonl`
- **Verification:** Session stop produces JSONL entry with provenance
- **Priority:** MEDIUM (enables Layer 3)
- **DEFERRED to follow-up session**

## This Session: Units 1-3

Units 1-3 are immediate, low-risk, and high-impact. Units 4-7 are follow-up session work.
