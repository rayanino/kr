# Plan: Audit Fix — One Missed Broken Reference

## Context

Deep self-audit of the 11 defect fixes + repo cleanup found **one defect**: a broken reference in `.claude/commands/design-review.md` that was missed during the broken reference sweep. The original sweep searched `.claude/rules/` but not `.claude/commands/`.

Everything else passed: all 11 fixes correct, MASTER_MANIFEST valid, all 21 file moves complete, protected files untouched, git state clean.

## Fix

**File:** `.claude/commands/design-review.md` line 18
**Current:** `→ Read STEERING.md and skills/shared/ENGINE_PROTOCOL.md.`
**Change to:** `→ Read reference/archive/STEERING.md and skills/shared/ENGINE_PROTOCOL.md.`

## Commit

Amend commit 2 (`80ed46b`) since this is a missed item from that same cleanup scope. Or create a new commit:
```
fix: missed broken STEERING.md reference in design-review command
```

## Verification

```bash
# Confirm no bare STEERING.md references remain outside archive/
grep -r "STEERING\.md" --include="*.md" . | grep -v "archive/"
# Should return NOTHING
```
