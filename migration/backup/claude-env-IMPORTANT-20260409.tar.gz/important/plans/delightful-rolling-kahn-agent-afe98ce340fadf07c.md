# IsIdeas Artifact Sweep -- Complete Findings Report

## Summary

The repo still contains a full Next.js control-tower dashboard application (source, config, dependencies, tests, runtime scripts) alongside the markdown factory content. Below is every implementation artifact found, organized by category, with a recommended action for each.

---

## 1. Hidden Config Files at Repo Root

| File | Found? | Action |
|------|--------|--------|
| `.eslintrc*` | No | -- |
| `.prettierrc*` | No | -- |
| `.editorconfig` | No | -- |
| `postcss.config.*` | No | -- |
| `tailwind.config.*` | No | -- |
| `.npmrc` / `.nvmrc` / `.node-version` | No | -- |
| `jest.config.*` | No | -- |
| `.babelrc*` / `babel.config.*` | No | -- |
| `turbo.json` / `nx.json` / `lerna.json` | No | -- |
| **`vitest.config.ts`** | **YES** | **DELETE** -- test runner config for the dashboard |
| **`next.config.ts`** | **YES** | **DELETE** -- Next.js app config |
| **`tsconfig.json`** | **YES** | **DELETE** -- TypeScript project config for the dashboard |
| **`next-env.d.ts`** | **YES** | **DELETE** -- auto-generated Next.js type shim |
| **`package.json`** | **YES** | **DELETE** -- defines `isideas-control-tower` with next/react/pg/pg-boss deps |
| **`package-lock.json`** | **YES** | **DELETE** -- npm lockfile |
| **`.env.example`** | **YES** | **DELETE** -- references `DATABASE_URL`, `ISIDEAS_STORAGE_MODE`, API keys |
| **`.env.local`** | **YES** | **DELETE** -- gitignored but still on disk; contains live secrets potentially |

---

## 2. Source Code Files (non-node_modules)

### `src/` -- Full Next.js dashboard app (20 files)

| Path | Description | Action |
|------|-------------|--------|
| `src/app/page.tsx` | Dashboard homepage (React/JSX) | DELETE |
| `src/app/layout.tsx` | Root layout with fonts/metadata | DELETE |
| `src/app/globals.css` | Full CSS for the dashboard | DELETE |
| `src/app/api/runtime/tick/route.ts` | Next.js API route for runtime tick | DELETE |
| `src/app/api/runtime/red-team/route.ts` | Next.js API route for red-team | DELETE |
| `src/app/api/submissions/route.ts` | Next.js API route for submissions | DELETE |
| `src/components/frontier-surface.tsx` | React component | DELETE |
| `src/components/runtime-actions.tsx` | React component | DELETE |
| `src/components/submission-form.tsx` | React component | DELETE |
| `src/lib/dashboard.ts` | Dashboard data fetching | DELETE |
| `src/lib/database-url.ts` | Postgres connection URL logic | DELETE |
| `src/lib/postgres-repository.ts` | Postgres-backed state repository | DELETE |
| `src/lib/redteam.ts` | Red-team critique logic | DELETE |
| `src/lib/repository-core.ts` | Core repository interface | DELETE |
| `src/lib/repository.ts` | File-store repository implementation | DELETE |
| `src/lib/runtime-paths.ts` | Path resolution helpers | DELETE |
| `src/lib/state.ts` | State management | DELETE |
| `src/lib/tick.ts` | Runtime tick logic | DELETE |
| `src/lib/types.ts` | TypeScript type definitions | DELETE |
| `src/lib/utils.ts` | Utility functions (slugify, date) | DELETE |

**Action: Delete entire `src/` directory.**

### `scripts/` -- Runtime helper scripts (9 files)

| Path | Description | Action |
|------|-------------|--------|
| `scripts/morning-report.ts` | TS script | DELETE |
| `scripts/reset-runtime.ts` | TS script | DELETE |
| `scripts/runtime-tick.ts` | TS script | DELETE |
| `scripts/runtime-doctor.ts` | TS script | DELETE |
| `scripts/runtime-baseline.ts` | TS script | DELETE |
| `scripts/supervised-proving-run.ts` | TS script | DELETE |
| `scripts/runtime-redteam.ts` | TS script | DELETE |
| `scripts/bootstrap_wsl.sh` | Shell bootstrap script | DELETE |
| `scripts/bootstrap_wsl.ps1` | PowerShell bootstrap script | DELETE |

**Action: Delete entire `scripts/` directory.**

### `tests/` -- Vitest test files (3 files)

| Path | Action |
|------|--------|
| `tests/repository.test.ts` | DELETE |
| `tests/state.test.ts` | DELETE |
| `tests/redteam.test.ts` | DELETE |

**Action: Delete entire `tests/` directory.**

### `apps/fixed-text-preservation/` -- Already deleted from working tree

The git status shows these files as ` D` (deleted from working tree but still tracked). They are already gone from disk. The deletion needs to be staged and committed.

**Action: Stage the deletions (`git rm` the tracked files).**

---

## 3. Package/Dependency Artifacts

| Path | Action |
|------|--------|
| `package.json` | DELETE |
| `package-lock.json` | DELETE |
| `node_modules/` (397 MB) | DELETE (already gitignored, but should be removed from disk) |

---

## 4. GitHub-Related Files

| File | Found? |
|------|--------|
| `.github/workflows/` | No |
| `.github/CODEOWNERS` | No |
| `.github/pull_request_template.md` | No |

**No GitHub CI/CD or config files exist. Clean.**

---

## 5. Docker Files

None found. Clean.

---

## 6. Database Files

| Type | Found? |
|------|--------|
| `.sql` files | No |
| `prisma/` | No |
| `migrations/` | No |

However, `src/lib/postgres-repository.ts` creates tables dynamically at connect time (no migration files). The Postgres schema exists only in code. This will be removed with `src/`.

---

## 7. `runtime/seed/state.json` Analysis

This file contains **factory state that has real value**, not just dashboard wiring. Specifically:

**Worth preserving (factory/portfolio content):**
- `profile` -- thesis, horizon, operator role, canonical end state
- `decisions` (D-0001 through D-0010) -- governance decisions including the factory-only scope decision
- `bottlenecks` (B-001 through B-005) -- deep bottleneck map
- `ideas` (I-001 through I-004) -- portfolio ideas with stages, priorities, critique links
- `submissions` -- owner intake records
- `evidenceLinks` -- reference URLs with notes
- `critiqueArtifacts` -- adversarial review references
- `integrityFlags` -- active integrity concerns
- `researchArtifacts` -- active research threads

**Dashboard/runtime-specific (can be dropped or simplified):**
- `profile.runtimeMode: "bootstrap_file_store"` -- only meaningful for the dashboard runtime
- `profile.schemaVersion: 2` -- schema version for the JSON state format
- `tools` -- references pg-boss, WSL runtime, Codex CLI, etc. as tooling candidates
- `loops` (L-001 through L-005) -- autonomous loop definitions with cadences, staleness thresholds
- `runs` -- runtime execution records

**Recommendation:** The content in this file is real portfolio intelligence. Consider:
- Extracting the decisions, ideas, bottlenecks, etc. into their canonical markdown equivalents (catalog/, decisions/, ideas/) if not already mirrored
- Or keeping the file as a historical snapshot with a note that it is no longer the live source
- The loop/run/tool sections can be dropped since they only served the dashboard runtime

---

## 8. Markdown Files Referencing Implementation

These markdown files contain `npm`, `Next.js`, `Postgres`, or dashboard-specific references that need editing:

| File | References | Action |
|------|-----------|--------|
| **`README.md`** | `npm install/dev/test`, "Next.js dashboard", "local Postgres runtime mode", `src/` in repo map, "Start the dashboard" | **EDIT** -- rewrite as pure markdown factory README |
| **`runtime/README.md`** | `npm run runtime:*` commands, Postgres mode reference | **EDIT or DELETE** -- either rewrite for seed-only context or remove |
| **`codex/IMMEDIATE_NEXT_ACTIONS.md`** | `npm run dev/doctor/tick` | **EDIT** -- remove dashboard-specific actions |
| **`control_tower/ARCHITECTURE.md`** | "Next.js dashboard", TypeScript, PostgreSQL upgrade path | **EDIT** -- rewrite without implementation stack references |
| **`control_tower/SUPERVISED_PROVING_RUN.md`** | `npm run runtime:baseline/pilot` | **EDIT or DELETE** -- proving run protocol was for the dashboard runtime |
| **`workflows/CONSISTENCY_AND_SOURCE_OF_TRUTH.md`** | "local Postgres runtime documents" | **EDIT** -- remove Postgres runtime surface |
| **`ADVERSARIAL_REVIEW_2026-03-30.md`** | Multiple references to `src/lib/postgres-repository.ts`, Postgres mode findings | **KEEP as-is** -- this is a historical critique artifact; its references to removed code are part of the record |
| **`decisions/ADR-006-POSTGRES-RUNTIME-UPGRADE.md`** | Postgres upgrade decision | **KEEP as-is** -- historical ADR |
| **`decisions/ADR-008-...-QURAN-REFERENCE.md`** | References the fixed-text-preservation app | **KEEP as-is** -- historical ADR |
| **`decisions/ADR-009-...-HANDOFF-READY.md`** | References the handoff decision | **KEEP as-is** -- historical ADR |
| **`codex/FIXED_TEXT_PRESERVATION_MVP_TASK_PACKET.md`** | "Next.js 16 App Router" | **KEEP as-is** -- this is a handoff build packet documenting what was built |

---

## 9. `.gitignore` Analysis

Current contents:
```
node_modules/
.next/
coverage/
dist/

runtime/local/
.env.local

.DS_Store
*.log
```

| Entry | App-specific? | Action |
|-------|--------------|--------|
| `node_modules/` | YES | DELETE after cleanup |
| `.next/` | YES (Next.js build cache) | DELETE after cleanup |
| `coverage/` | YES (test coverage) | DELETE after cleanup |
| `dist/` | YES (build output) | DELETE after cleanup |
| `runtime/local/` | MIXED -- still useful if seed/local split is kept | KEEP or adjust |
| `.env.local` | YES (app env) | DELETE after cleanup |
| `.DS_Store` | GENERAL -- useful for any repo | KEEP |
| `*.log` | GENERAL -- useful for any repo | KEEP |

**Post-cleanup `.gitignore` should be minimal:**
```
.DS_Store
*.log
```

Optionally keep `runtime/local/` if the runtime seed directory structure is preserved.

---

## 10. `runtime/local/` (Gitignored Runtime State)

This directory exists on disk (gitignored) and contains mutable runtime state:
- `runtime/local/state.json`
- `runtime/local/MORNING_REPORT.md`
- `runtime/local/baselines/`
- `runtime/local/proving-runs/`
- `runtime/local/critique-runs/` (contain prompt.md, artifact.md, metadata.json, response.json)

**Action:** Delete the entire `runtime/local/` directory from disk. It is operational state for the now-removed dashboard. The critique-run artifacts (prompts and responses) could be interesting historical records, but they are gitignored and were never committed.

---

## Complete Deletion List

### Directories to remove entirely:
1. `src/` (20 files -- full Next.js app)
2. `scripts/` (9 files -- runtime helper scripts)
3. `tests/` (3 files -- vitest tests)
4. `node_modules/` (397 MB -- npm dependencies, on disk only)
5. `runtime/local/` (gitignored mutable state, on disk only)

### Root files to remove:
6. `package.json`
7. `package-lock.json`
8. `tsconfig.json`
9. `next.config.ts`
10. `next-env.d.ts`
11. `vitest.config.ts`
12. `.env.example`
13. `.env.local` (on disk, gitignored)

### Already-deleted files to stage:
14. All `apps/fixed-text-preservation/*` files (already deleted from working tree, need `git rm`)

### Markdown files to edit (remove/rewrite implementation references):
15. `README.md` -- full rewrite needed
16. `runtime/README.md` -- rewrite or delete
17. `codex/IMMEDIATE_NEXT_ACTIONS.md` -- remove npm commands
18. `control_tower/ARCHITECTURE.md` -- remove stack references
19. `control_tower/SUPERVISED_PROVING_RUN.md` -- remove or rewrite
20. `workflows/CONSISTENCY_AND_SOURCE_OF_TRUTH.md` -- remove Postgres references
21. `.gitignore` -- strip to generic entries only

### Files to keep as-is (historical records):
- `ADVERSARIAL_REVIEW_2026-03-30.md`
- `decisions/ADR-006-POSTGRES-RUNTIME-UPGRADE.md`
- `decisions/ADR-008-...-QURAN-REFERENCE.md`
- `decisions/ADR-009-...-HANDOFF-READY.md`
- `codex/FIXED_TEXT_PRESERVATION_MVP_TASK_PACKET.md`

### `runtime/seed/state.json` -- decision needed:
- Option A: Extract portfolio content into markdown, delete the file
- Option B: Keep as a historical snapshot with a deprecation note
- Option C: Slim it down to only the factory-relevant sections (remove loops, runs, tools, runtimeMode)
