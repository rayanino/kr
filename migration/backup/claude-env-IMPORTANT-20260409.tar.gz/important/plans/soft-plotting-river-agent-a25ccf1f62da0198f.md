# CLI Speed Plan -- Operational Review

## Source Material
- Plan: `C:\Users\Rayane\.claude\plans\soft-plotting-river.md`
- Batch runner: `scripts/run_full_integration.py`
- Per-package runner: `scripts/run_integration_test.py`
- Config: `engines/excerpting/contracts.py` (ExcerptingConfig, lines 764-798)
- CLI adapter: `shared/llm/cli_adapter.py`

---

## Part 1: Findings From Operational Code Review

### 1A. Hook Logger is NOT Thread-Safe (CONFIRMED, HIGH)

The plan correctly identifies this but underestimates severity. In `run_integration_test.py` lines 104-105:

```python
call_counter: dict[str, int] = {"n": 0}
call_start_time: dict[str, float] = {"t": 0.0}
```

These are **closure-captured mutable dicts shared across ALL calls on a single client**. With 40 threads using the same `enrich_client`, two threads can both read `call_counter["n"]` as 42, both increment to 43, and overwrite each other's request/response files. The `call_start_time` race is worse -- thread A sets it, thread B overwrites it, thread A logs B's latency.

The plan says "Per-thread adapter instance OR thread-prefixed call IDs" but does not commit to one. **Decision needed**: the plan's proposal for per-chunk processing (lines 170-201) calls `classify_chunk(ctx.chunk, clients.enrich, config)` where `clients.enrich` appears to be a shared client. If shared, every hook is racing. If per-thread, startup cost multiplies.

**Recommendation**: Per-thread CLIInstructorAdapter instances. The adapter is lightweight (no connection pool, no auth state beyond shutil.which lookup). Creating 40 instances costs nothing.

### 1B. trace_context is a Shared Mutable Dict (CONFIRMED, HIGH)

In `run_integration_test.py` lines 106-109 and 700-707, the `trace_context` dict is captured by hook closures AND mutated by the caller to set `semantic_phase` and `chunk_id`. With parallel chunks, thread A sets `trace_context["chunk_id"] = "chunk_007"`, thread B immediately overwrites with `"chunk_042"`, and thread A's request log records chunk_042 as its chunk_id.

This silently corrupts the trace audit trail. Over 37K chunks, the contamination would make post-run debugging nearly impossible.

### 1C. progress.json Atomic Write Under Concurrent Access (MEDIUM)

The plan proposes atomic write via tmp+replace for `progress.json`, and suggests "Write only after ThreadPoolExecutor join, OR use threading.Lock." Neither is adequate at scale:

- Writing only after join: loses all progress if the process is killed. Defeats the purpose of chunk-level resume.
- Lock around every write: 40 threads contending on a single file lock. At ~1 write per 500s per thread, this is low contention -- acceptable.

But the **real problem** is `os.replace()` on Windows. If another thread (or the monitoring script) has the file open for reading at the exact moment of replace, Windows may return `PermissionError: [WinError 32] The process cannot access the file`. This is a known Windows pitfall that does not exist on Unix.

**Recommendation**: Use a write-ahead log (one line per completion in a `.jsonl` file), rebuild the full state on startup by replaying the log. This eliminates concurrent file access entirely.

### 1D. No Graceful Shutdown on Ctrl+C (MEDIUM)

`run_full_integration.py` catches KeyboardInterrupt (line 723) and writes incremental SUMMARY.json. But the plan's ThreadPoolExecutor model (Layer 4) does not address what happens to 40 in-flight `subprocess.run()` calls when Ctrl+C arrives.

On Windows, Ctrl+C is delivered to ALL processes in the console group. The CLI subprocesses (claude, codex, gemini) receive SIGINT independently. Some may write partial output. The Python threads will raise KeyboardInterrupt at unpredictable points within their `semaphore.acquire()` / `classify_chunk()` calls. ThreadPoolExecutor does NOT guarantee clean shutdown on interrupt.

**Recommendation**: Install a signal handler that sets an `Event` flag. Each worker checks the flag before starting a new phase. In-flight calls complete naturally (they're subprocess.run with timeout). This drains gracefully.

### 1E. Per-Package Timeout Does Not Compose With Chunk Parallelism (MEDIUM)

`run_full_integration.py` line 585-589 applies a flat `per_package_timeout` (default 28800s = 8h) via `_run_package_subprocess()`. But with chunk-level parallelism, a package with 50 chunks at concurrency 20 takes ~1.5h, while the same package at concurrency 1 takes ~30h. The 8h timeout was calibrated for serial execution.

The plan does not address recalibrating this timeout. At concurrency 40, the timeout should be much shorter. At concurrency 1 (fallback), 8h may be insufficient for large packages.

### 1F. No Disk Space Check (LOW)

The plan's risk matrix says "Each ChunkPipelineContext ~10KB. 1000 concurrent = 10MB. Negligible." This addresses memory only. Disk artifacts are unaddressed:
- 37K chunks x 4 phases x (1 request JSON + 1 response JSON) = 296K files
- Each response JSON: ~2-10KB (classification) to ~20-50KB (enrichment with full Arabic text)
- Plus cache files (Layer 3): another 148K files
- Estimate: 444K files, 5-15 GB total

Not a storage risk on modern drives, but a significant risk if the output directory is on OneDrive-synced Desktop (which it appears to be given the path `C:\Users\Rayane\Desktop\kr`).

---

## Part 2: Gemini's Findings (Independent Review)

Gemini identified these TOP 5 risks:

| Rank | Risk | Assessment |
|------|------|------------|
| 1 | **Backend Rate/Concurrency Limiting** | AGREE. CLI subscriptions have undocumented concurrency ceilings. The plan acknowledges this ("Real-world testing needed to find the ceiling") but has no adaptive mechanism. |
| 2 | **NTFS Directory Exhaustion** | PARTIALLY AGREE. NTFS handles 100K+ files per directory without performance degradation if file names are short and direct-access (not `os.listdir()`). But 2-level hash directories are cheap insurance. |
| 3 | **Retry/Outage Death Spiral** | STRONG AGREE. This is the plan's biggest gap. 40 threads hitting a dead backend = 40 simultaneous retries = 40 failures marked in progress.json in seconds. No circuit breaker. |
| 4 | **Silent Output Corruption (Cache Poisoning)** | STRONG AGREE. If an LLM returns a refusal or error text, Layer 3 will cache that as a valid response. The plan caches "raw LLM output" without any sanity gate. |
| 5 | **CLI Initialization Tax** | PARTIALLY AGREE. Claude CLI startup is slow (~3-5s). But at 500s per call, 5s overhead is 1%. At concurrency 40, all startups overlap. This is LOW impact in practice. |

Additional Gemini observations worth noting:
- **"Final Chunk" tail**: valid concern. Large chunks at end of queue cause thread starvation.
- **OneDrive sync**: correctly identified as a risk given the file path.
- **Progress I/O contention**: valid -- batching progress writes is important.

---

## Part 3: Merged TOP 5 Operational Risks

Ranked by (probability x impact during a real 21-day run):

### RISK 1: Retry Death Spiral on Backend Outage (PROBABILITY: HIGH, IMPACT: CRITICAL)

**Source**: Both reviews identified this independently.

**Scenario**: Anthropic has a 2-hour outage on day 10. All 40 threads fail their current classify/group/enrich calls within the timeout window (900s). Each thread retries per Layer 1 logic (2 retries with 1.5x timeout). Within ~45 minutes, all threads exhaust retries and mark ~120 chunks as "failed" in progress.json. The orchestrator moves on to the next chunks, which also fail. In 2 hours, ~1,000+ chunks are marked "failed."

On resume, all those chunks need re-running. But there is no mechanism to distinguish "failed because the backend was down" from "failed because the input is malformed." The operator must either re-run everything or manually inspect error logs.

**Mitigation**:
- Add a **circuit breaker**: if N consecutive failures (e.g., 5) occur within T seconds (e.g., 300s), pause all threads for a backoff period (e.g., 5 minutes). Exponentially increase the pause up to 30 minutes. Resume automatically.
- Mark failed chunks with the error category (`backend_timeout`, `rate_limit`, `validation_error`). On resume, re-run only `backend_timeout`/`rate_limit` failures automatically; skip `validation_error` failures (those need investigation).

### RISK 2: Hook Logger / Trace Context Thread Races (PROBABILITY: CERTAIN, IMPACT: HIGH)

**Source**: Code review (findings 1A, 1B).

**Scenario**: This is not probabilistic -- it WILL happen with any concurrency > 1. The shared `call_counter`, `call_start_time`, and `trace_context` dicts will produce: (a) overwritten request/response files (data loss), (b) wrong latency measurements, (c) corrupted chunk-ID-to-call-ID mappings in traces.

The plan identifies this risk but does not resolve it. The impact is high because these traces are the primary debugging tool for a 21-day run. Corrupted traces mean flying blind.

**Mitigation**:
- One CLIInstructorAdapter instance per worker thread. Each gets its own hook logger closure.
- Pass a per-thread trace_context to each worker. Never share trace_context across threads.
- Use `threading.local()` or explicit per-worker state for call_counter.

### RISK 3: Silent Cache Poisoning (PROBABILITY: MEDIUM, IMPACT: CRITICAL)

**Source**: Gemini review.

**Scenario**: The CLI adapter encounters a transient issue (safety filter, malformed prompt after some encoding drift, backend internal error). The LLM returns text like "I apologize, I cannot process this request" or an empty JSON `{}`. Layer 3 caches this as the raw LLM response. On all future runs, the cache serves this garbage result. The chunk is permanently corrupted unless someone manually deletes the cache entry.

At 37K chunks, even a 0.1% poisoning rate = 37 corrupted excerpts embedded in the owner's knowledge library.

**Mitigation**:
- Add a **response validation gate** before caching: (1) non-empty, (2) parses as the expected Pydantic model, (3) has at least 1 meaningful field populated (e.g., segments list non-empty for classify, topic list non-empty for enrich).
- If validation fails, do NOT cache. Mark the chunk as "failed" with error details.
- The plan already caches "raw" pre-normalization output. The validation gate should run on the raw output before caching, not after.

### RISK 4: Windows Restart / Power Loss Loses In-Flight Work (PROBABILITY: MEDIUM, IMPACT: HIGH)

**Source**: Both reviews.

**Scenario**: Windows Update forces a restart at 3 AM on day 8. Forty threads are mid-call. Their subprocess.run() calls are terminated. progress.json may be mid-write (if using the tmp+replace pattern, the .tmp file exists but hasn't been renamed). On restart:
- If the .tmp file was written but not renamed: progress.json has stale state. Some completed chunks must be re-run.
- If progress.json was being read by the monitoring script during the replace: PermissionError on Windows.
- Raw LLM responses from in-flight calls: lost (subprocess killed before writing stdout).

The plan's Layer 2 handles crash recovery but does not address Windows-specific file locking behavior or the scenario where both .tmp and .json exist on restart.

**Mitigation**:
- Use write-ahead log (.jsonl append) instead of atomic replace for progress tracking. Append is crash-safe on NTFS (writes are flushed per-line with explicit flush).
- On startup, replay the log to reconstruct state. Detect partial last line (incomplete write) and discard it.
- Add startup recovery logic: if `progress.json.tmp` exists and `progress.json` exists, delete the .tmp (it was a failed atomic write).

### RISK 5: Effective Concurrency Ceiling Unknown (PROBABILITY: HIGH, IMPACT: HIGH)

**Source**: Both reviews.

**Scenario**: The plan assumes concurrency 40 is needed for the 21-day target. But CLI backend rate limits are undocumented and may vary by subscription tier, time of day, and backend provider. If the real ceiling is 10 concurrent calls, the run takes 84 days instead of 21. If it is 5, it takes 168 days.

The plan says "Real-world testing needed to find the ceiling" but provides no fallback architecture for a low ceiling.

**Mitigation**:
- **Empirical ceiling test** (MUST run before production): ramp concurrency 1, 2, 5, 10, 15, 20 on a 10-chunk test. Measure error rate and throughput at each level. Plot the curve. Find the knee.
- **Adaptive concurrency**: if error rate exceeds 10% over a 5-minute window, automatically reduce concurrency by 25%. If error rate drops below 2%, increase by 1. This auto-adjusts to the real ceiling.
- **Fallback plan**: if ceiling is 10, the run takes 84 days. Document whether this is acceptable. If not, investigate: (a) running on 2 machines with separate subscriptions, (b) using API for high-concurrency phases and CLI for low-concurrency ones, (c) accepting a partial run with priority ordering (highest-value books first).

---

## Summary

The plan is architecturally sound. The 6-layer decomposition is well-reasoned, the ThreadPoolExecutor choice is correct for I/O-bound subprocess work, and the cache-key design (including prompt hash) is solid.

The critical gaps are all operational, not architectural:

1. **No circuit breaker** -- the single biggest risk for a multi-week run.
2. **Thread-safety of existing hook/trace infrastructure** -- not hypothetical, will certainly corrupt data.
3. **No response validation before caching** -- permanent silent corruption vector.
4. **Windows-specific file locking edge cases** -- the tmp+replace pattern is not crash-safe on Windows+NTFS under concurrent readers.
5. **No empirical concurrency ceiling data** -- the 21-day timeline depends on an untested assumption.

None of these require rethinking the architecture. They are all additive: a circuit breaker module (~100 lines), per-thread adapter instances (configuration change), a cache validation gate (~30 lines), a WAL-based progress tracker (~50 lines more than the proposed design), and a pre-production concurrency benchmark (~2 hours of testing).
