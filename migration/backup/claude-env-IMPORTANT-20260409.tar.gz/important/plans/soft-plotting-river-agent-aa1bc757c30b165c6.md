# Review: CLI Speed Architecture Plan (soft-plotting-river.md)

## Reviewer: Claude Opus 4.6 (1M context)
## Codex (GPT-5.4): Unable to complete analytical review -- sandbox errors on Windows Constrained Language Mode prevented it from producing analysis. It spent all time reading files via PowerShell `Select-String` commands that kept failing. Two separate invocations attempted; both hit the same issue.

---

## Section 1: Findings from Code Review

### FINDING-1 (HIGH): Hook Logger Has 3 Concurrent Thread-Safety Race Conditions

**File:** `scripts/run_integration_test.py` lines 104-195

The `make_hook_logger()` closure captures three shared mutable objects that will corrupt data under the plan's proposed concurrency:

1. **`call_counter["n"] += 1`** (line 112): Read-modify-write race. Two threads reading the same `n`, both incrementing to the same value, producing duplicate `call_id` strings like `enrich_0005`. Both threads then write to `raw_llm_requests/enrich_0005.json` -- one overwrites the other. Result: lost artifact files, violating the "every API call persists its full output" rule.

2. **`call_start_time["t"] = time.monotonic()`** (line 113): Thread A writes start time, thread B overwrites it, thread A's `on_response` computes latency using B's start time. All latency measurements in trace files become wrong.

3. **`trace_context["semantic_phase"]`** (lines 106-109, set at line 860): Currently set globally before each phase loop. With per-chunk workers where chunk A is in classify while chunk B is in enrich, the shared trace_context is meaningless.

**Required fix:** Per-thread adapter instances, each with its own hook logger. The plan mentions this option (line 210) but does not commit. This is the only correct solution -- it also fixes FINDING-2.

### FINDING-2 (MEDIUM): `_tool_checked` TOCTOU Race

**File:** `shared/llm/cli_adapter.py` lines 370-372

```python
if backend not in adapter._tool_checked:    # read
    _check_tool_available(backend)           # side effect
    adapter._tool_checked.add(backend)       # write
```

Classic check-then-act race. Two threads can both pass the check and both call `shutil.which()`. Consequence is harmless (redundant work), but with per-thread adapter instances (FINDING-1 fix), this goes away entirely.

### FINDING-3 (HIGH): Cache Key Is Missing 4 Critical Inputs

**File:** Plan lines 109-117 (cache key algorithm)

The plan hashes `assembled_text + phase + prompt_hash + model + temperature + max_tokens + context_hash`. After reading the actual code, these inputs are missing:

| Missing Input | Where It Affects Output | Code Location |
|---|---|---|
| `source_metadata` dict | Embedded in enrich + verify user prompts (author, title, science, school) | phase3_enrichment.py:193-197, phase3_consensus.py:146-149 |
| `structural_format` | Substituted into classify + group system prompts via `.format()` | phase2_classify.py:337, phase2_group.py:166 |
| `response_model` schema | Injected into system prompt by CLI adapter as JSON schema directive | cli_adapter.py:375-400 |
| `error_feedback` | Appended to user message on retries, changes the prompt | phase2_classify.py:340-341, phase2_group.py:175-176 |

**Impact:** Cache could serve stale results when source metadata changes (e.g., corrected author name after human gate review), when schema evolves, or when retries with error feedback accidentally match a clean first attempt.

**Fix:** The cache key should hash the FULL system prompt and FULL user prompt as sent to the CLI, rather than individual components. This is simpler and automatically captures all inputs including adapter-injected schema directives.

### FINDING-4 (MEDIUM): Plan's process_chunk Pseudocode Does Not Match Actual Code Architecture

**File:** Plan lines 170-200 vs. actual code in `phase3_consensus.py`

The plan shows:
```python
ctx.final, ctx.gates = verify_chunk(ctx.chunk, ctx.enriched, clients.verify, config)
```

But the actual verification path is `run_consensus()` (line 698), which:
- Groups ALL excerpts across ALL chunks by chunk_id (line 717)
- Calls `verify_chunk()` per chunk (line 763) -- correct for per-chunk model
- Then calls `resolve_consensus()` per excerpt (line 849) which may invoke `_call_escalation()` (line 374) -- an additional LLM call per disagreement

The plan's `process_chunk` worker would need to replicate the `run_consensus` logic for its subset of excerpts. This is feasible since verify_chunk already works per-chunk, but the plan omits:
- The excerpt-to-verification-item mapping (lines 810-828)
- The `check_gate_triggers()` call (line 865)
- The gate entry building (lines 858-874)

**Fix:** The per-chunk worker should call a new `run_consensus_for_chunk()` function that extracts the single-chunk logic from `run_consensus()`. Do not try to wrap the existing `run_consensus()` which expects all chunks.

### FINDING-5 (MEDIUM): `os.replace()` on Windows Is Not Always Atomic

**File:** Plan lines 78-79

The plan says "write .tmp + os.replace" for atomic progress.json updates. On Windows:
- `os.replace()` can raise `PermissionError` if the target file is open by another process (antivirus, monitoring script, another thread reading it)
- Unlike Unix, Windows file replacement requires exclusive access to the destination
- The plan's monitoring script (`scripts/kr_pipeline_monitor.py`) reading progress.json every 5s via `watch` could collide with a write

**Fix:** Use a retry loop around `os.replace()` (3 attempts, 100ms backoff), or use `ctypes`/`win32api` for `MoveFileExW` with `MOVEFILE_REPLACE_EXISTING`. Alternatively, have the monitoring script read via copy-on-read (copy to temp, read temp).

### FINDING-6 (MEDIUM): ri_trace_bridge Has Thread-Unsafe State

**File:** `shared/llm/ri_trace_bridge.py` lines 42, 67

The `TraceBridge` class has `self._seen_system_hashes: set[int]` (line 42) and calls `self._seen_system_hashes.add(h)` (line 67). If an ri session is attached to a shared adapter, multiple threads will concurrently read/write this set. CPython's GIL makes `set.add` atomic, but the check-then-add at lines 65-67 is the same TOCTOU pattern as FINDING-2.

Also, `session.add_message()` (line 69) is called from multiple threads -- unless the ri Session class is thread-safe (not verified), messages from different chunks could interleave.

**Fix:** If using per-thread adapter instances, attach a separate TraceBridge per thread. If sharing adapters, guard `_seen_system_hashes` and `add_message` with a Lock.

### FINDING-7 (LOW): Speedup Table Assumes Perfect Linear Scaling

**File:** Plan lines 224-228

The table shows `856 days / 10 = 86 days`, `856 / 20 = 43 days`, etc. Real scaling factors:

- **CLI startup overhead:** ~2-5s per call (Node.js for claude, Python for codex). At 500s per call, this is <1% -- negligible.
- **Rate limiting (HIGH risk):** claude.ai subscription has undocumented per-minute/per-hour rate limits. At concurrency 20, expect throttling. OpenAI's subscription tier also has limits. The plan should include automatic backoff with concurrency reduction (e.g., if >10% of calls fail with rate limit, halve concurrency).
- **Disk I/O:** At concurrency 20, each chunk writes ~8 files (cache, progress, request artifact, response artifact per phase). That is ~160 concurrent file operations. On SSD this is fine; on HDD it serializes.

**The plan should include** an adaptive concurrency controller that starts at `--concurrency N` and automatically reduces if error rate exceeds a threshold.

### FINDING-8 (LOW): Batch Escalation Partial Failure Not Specified

**File:** Plan lines 241-264

The plan proposes `_call_batch_escalation()` but only specifies the happy path. If the batched response returns items for indices 0-2 but is missing index 3:
- Should the missing item fall back to enrichment-kept (current `_call_escalation` return None behavior)?
- Should the entire batch be retried?
- Should the batch be split and retried as individual calls?

**Fix:** Specify: missing items in batch response fall back to individual `_call_escalation()` per missing item. Total failure of the batch falls back to the original per-item path.

---

## Section 2: Codex (GPT-5.4) Review Status

Two attempts were made to get an independent Codex review:

1. **First attempt:** Full plan text piped via stdin. Codex spent all its turns reading repository files (9,204 lines of output, all file contents) rather than analyzing. Hit Windows Constrained Language Mode `InvalidOperation` errors.

2. **Second attempt:** Concise plan summary with pre-analyzed concerns embedded in prompt. Codex again spent turns reading files via `Select-String` and hit the same sandbox policy errors. 4,354 lines of output, no analytical text.

**Root cause:** Codex in read-only sandbox mode on Windows uses PowerShell `Select-String` for file reads, which keeps hitting `InvalidOperation` due to Constrained Language Mode. This prevents Codex from completing file reads, and it never reaches the analytical phase.

**Recommendation:** For future Codex reviews of KR plans, either: (a) use the `codex` provider via the CLI adapter (which handles subprocess wrapping), or (b) pipe the plan + relevant code snippets directly in the prompt without relying on Codex's file-reading ability.

---

## Section 3: Merged Blind Spots and Required Changes

### Must-Fix Before Implementation (HIGH)

| # | Finding | Plan Section Affected | Required Change |
|---|---------|----------------------|-----------------|
| F-1 | Hook logger race conditions (call_counter, start_time, trace_context) | Layer 4, Thread Safety table | Mandate per-thread adapter instances. Add explicit requirement in Layer 4 spec. |
| F-3 | Cache key missing source_metadata, structural_format, response_model schema, error_feedback | Layer 3, Cache key algorithm | Replace component hashing with full-prompt hashing. Cache key = sha256(full_system_prompt + full_user_prompt + model + temperature + max_tokens). |
| F-4 | process_chunk pseudocode skips resolve_consensus, gate checks, escalation mapping | Layer 4, Per-Chunk Worker | Create `run_consensus_for_chunk()` that extracts single-chunk logic from `run_consensus()`. Update pseudocode to call it. |

### Should-Fix Before Production (MEDIUM)

| # | Finding | Plan Section Affected | Required Change |
|---|---------|----------------------|-----------------|
| F-2 | _tool_checked TOCTOU (harmless if per-thread adapters used) | Layer 4 | Resolved by F-1 fix (per-thread adapters). |
| F-5 | os.replace() not atomic on Windows when target is locked | Layer 2, Protocol step 3 | Add retry loop (3 attempts, 100ms backoff) around os.replace(). |
| F-6 | ri_trace_bridge _seen_system_hashes is thread-unsafe | Layer 4 | Per-thread TraceBridge instances (follows from F-1 fix). |

### Improvements to Add

| # | Description | Layer | Effort |
|---|-------------|-------|--------|
| I-1 | Adaptive concurrency controller: start at N, auto-reduce on high error rate | Layer 4 | +2h |
| I-2 | Batch escalation partial failure fallback: missing items -> individual calls | Layer 5 | +30min |
| I-3 | Empirical concurrency ramp test protocol in Verification Plan | Layer 4 | +1h |
| I-4 | Full-prompt cache key instead of component key (simpler AND more correct) | Layer 3 | Simplifies impl |
| I-5 | Timeout escalation cap: 1.5x retry multiplier should cap at 2x original (avoid infinite growth on 3+ retries) | Layer 1 | +15min |

### Plan Strengths (confirmed by code review)

- ThreadPoolExecutor over asyncio is the correct choice. subprocess.run() is blocking and threads handle this well.
- Global semaphore is simpler and more correct than per-phase pools.
- Per-chunk full-chain workers is architecturally sound -- classify_chunk, group_chunk, enrich_chunk are genuinely stateless pure functions that take all inputs as arguments and return new values without mutation.
- Caching raw LLM output rather than post-processed output is the right call for knowledge integrity.
- The 6-layer ordering (timeouts first, parallelism last) is correct -- each layer provides standalone value.
