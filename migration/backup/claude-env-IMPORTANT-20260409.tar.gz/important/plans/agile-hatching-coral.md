# Investigation: Where Are All the KR Skills?

## Finding: Nothing is lost. Everything is here.

Claude Code uses a **two-level** directory structure. The user was looking at the **global** level and only seeing 2 skills, but all KR-specific tooling lives at the **project** level.

---

## Global (`~/.claude/`) — shared across ALL projects
| Type | Count | Examples |
|------|-------|---------|
| Skills | 2 | `frontend-design`, `senior-backend` |
| Commands | 19 | `ultra-think`, `todo`, GSD commands |
| Agents | 55+ | `python-pro`, `debugger`, GSD agents |

## Project (`kr/.claude/`) — KR-specific
| Type | Count | Items |
|------|-------|-------|
| **Skills** | **8** | `arabic-text`, `consensus-pattern`, `domain-glossary`, `evaluation-methodology`, `knowledge-safety`, `scholarly-design`, `spec-examples`, `technology-survey` |
| **Commands** | **11** | `catchup`, `challenge`, `check-spec`, `commit`, `design-review`, `phase-status`, `read-vision`, `research`, `smart-compact`, `trace-pipeline`, `verify-boundaries` |
| **Agents** | **8** | `boundary-validator`, `code-reviewer`, `integrity-checker`, `researcher`, `result-analyst`, `scholarly-verifier`, `spec-writer`, `test-engineer` |
| **Rules** | **5** | `python-code`, `result-preservation`, `session-discipline`, `spec-writing`, `testing` |

## Repo-level (`kr/skills/`) — Claude.ai uploadable skills
6 packaged skills: `kr-build-prep`, `kr-core-extract`, `kr-evaluate`, `kr-integrity`, `kr-research`, `kr-spec-review`

---

## Why it's set up this way
- **Global**: General-purpose tools usable on any project
- **Project**: Domain-specific tools that only make sense inside KR
- Claude Code **automatically merges both levels** — all 8 KR skills + 2 global skills + GSD skills all show up together

## No action needed
The environment is intact and comprehensive. The GSD update only touches `commands/gsd/`, `get-shit-done/`, and `agents/gsd-*` — it never touches project-level skills, commands, agents, or rules.
