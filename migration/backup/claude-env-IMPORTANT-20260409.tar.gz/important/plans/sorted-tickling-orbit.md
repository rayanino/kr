---
title: "fix(taxonomy): nahw cold-read audit remediation + coworker validation"
type: fix
status: active
date: 2026-04-07
origin: taxonomy-k2-synthesis-20260406:NEXT.md (branch-local directive)
---

# Nahw Cold-Read Audit Remediation + Coworker Validation

## Overview

Apply 11 prescribed edits to the nahw knowledge tree (`library/sciences/nahw/tree.yaml`) based on a 16-check cold-read audit by a fresh Claude instance, triaged by the architect. The remediation adds 10 leaves, creates 1 new L1 branch (أحكام الجمل), and relocates 1 misplaced leaf — bringing the tree from 183 to 193 leaves and 9 to 10 L1 branches.

**Critical knowledge integrity concern:** The entire audit-triage chain is single-provider (Claude). Per `no-single-model-conclusion.md`, all remediation decisions are PRELIMINARY until cross-provider confirmation. This plan includes mandatory coworker dispatch to achieve multi-model validation before the changes can be treated as confirmed.

## Problem Frame

The nahw tree (v2.0, 183 leaves) was built via 4-researcher synthesis with dual-provider merge and adversarial review, but predated the K2 cold-read audit protocol. A fresh Claude Opus instance (outside the project, zero context) ran a 16-check adversarial audit. The architect triaged all 16 checks:

- **5 ACCEPTED** (Checks 7, 8-partial, 9-partial, 11, 15) — genuine gaps or misplacements
- **9 REJECTED** — false positives where the auditor guessed missing topics that already exist in the YAML
- **2 DEFERRED** — synthesis-layer concerns (cross-cutting views), not tree edits

The 5 accepted findings map to 10 new leaves + 1 moved leaf across 4 areas of the tree. The triage document (`reference/research/nahw_cold_read_triage.md`) provides detailed scholarly reasoning for each decision, referencing Mughni al-Labib, Rasf al-Mabani, and the Alfiyya.

## Requirements Trace

- R1. Apply exactly the 11 edits from branch NEXT.md — no more, no less
- R2. Maintain YAML structural integrity (no duplicates, valid hierarchy)
- R3. Update all hardcoded test assertions referencing the old leaf count (183)
- R4. Update taxonomy registry to reflect new leaf/branch counts
- R5. Cross-provider validation of all content quality decisions (per `no-single-model-conclusion.md`)
- R6. DR dispatch for Islamic sciences classification validation (per user directive)
- R7. All taxonomy tests pass after changes

## Scope Boundaries

- This plan covers ONLY the nahw tree remediation and its validation
- NOT installing K2 drafts for balagha (197 leaves) or imlaa (51 leaves)
- NOT continuing sarf/aqidah DR work
- NOT modifying any other tree files
- Post-remediation assessment of broader branch state is included as a final step

## Context & Research

### Relevant Code and Patterns

- `library/sciences/nahw/tree.yaml` (954 lines) — the file being edited. V1 YAML format with `taxonomy.nodes` hierarchy
- `library/sciences/taxonomy_registry.yaml` — canonical registry; nahw entry needs notes update
- `engines/taxonomy/tests/test_tree_loader.py:61` — hardcodes `assert nahw_tree.leaf_count == 183`
- `engines/taxonomy/tests/conftest.py:190` — docstring references "183 leaves"
- `engines/taxonomy/tests/test_routing.py:233` — comment references "183 <= 200"
- `reference/research/nahw_cold_read_triage.md` — full triage reasoning (already on branch)

### Key Line Numbers in nahw tree.yaml (current state on branch)

| Target | Line | Purpose |
|--------|------|---------|
| `law_wa_lawla_wa_lawma_wa_amma` | ~422 | Leaf to REMOVE (Edit 1) |
| `al_mawsulat` / `al_aid` | ~156/167 | Insert point for Edit 3 |
| `irab_al_fil_al_mudari_wa_ahkamuhu` | ~399 | Insert point for Edit 5 (after this node's children) |
| `al_idafa` / `al_mudaf_ila_ya_al_mutakallim` | ~587/594 | Insert point for Edit 4 |
| `al_tawabi_wa_al_bayan` | ~668 | Insert point for Edit 2 (new L1 branch goes AFTER) |
| `al_asalib_al_nahwiyya_wa_al_abwab_al_khassa` | ~735 | Edit 2 new branch goes BEFORE this |
| `al_ikhbar_bi_al_ladhi_wa_al_alif_wa_al_lam` | ~925 | Insert point for Edits 6-8 |
| `leaf_count` | ~949 | Edit 9: 183 → 193 |
| `methodology` | ~3 | Edit 10: append cold-read note |
| `date` | ~6 | Edit 11: 2026-04-07 |

### Audit-Triage Decision Summary (for coworker validation)

| Check | Finding | Verdict | New Leaves |
|-------|---------|---------|------------|
| 7 | Missing الجمل التي لها/لا محل (sentence classification) | AGREE — FIXABLE | 3 (ahkam_al_jumal branch) |
| 8 | Missing حروف العرض/التحضيض + المصدر المؤوّل | PARTIAL AGREE | 2 (huruf_al_ard + masdar_muawwal) |
| 9 | Missing أدوات الاستفهام + الشرط غير الجازمة + الموصول الحرفي | PARTIAL AGREE | 3 + idafa expansion (+3) |
| 11 | لو/لولا misplaced under إعراب المضارع | AGREE — FIXABLE | 0 (move, not add) |
| 15 | الإضافة too thin (only 2 leaves) | AGREE — FIXABLE | 3 (idafa expansion) |

### Single-Provider Risk

The entire decision chain is Claude-only:
- **Auditor:** Fresh Claude Opus (outside project)
- **Triager:** Claude Chat Architect (this project)
- **Executor:** Claude Code (this session)

Per `no-single-model-conclusion.md`, all content quality conclusions from this chain are PRELIMINARY. Cross-provider confirmation is MANDATORY before treating the remediation as scholarly validated.

## Key Technical Decisions

- **Edit order:** Follow NEXT.md order exactly. Edits are designed to be applied sequentially (Edit 1 removes a leaf that Edit 7 re-adds in its correct location)
- **Registry update:** NEXT.md omits updating `taxonomy_registry.yaml` notes field. This plan adds it as a necessary consistency fix (notes currently say "183 leaves, 9 branches")
- **Test updates:** 3 files need assertion/comment updates. The routing test assertion (`193 <= 200`) remains True, so the logic is unchanged — only the comment needs updating
- **Coworker strategy:** Gemini CLI for Arabic scholarly validation (strongest Arabic capability), Codex CLI for structural validation, Gemini DR for independent Islamic study methodology confirmation (strongest DR source per owner assessment 2026-04-01)

## Open Questions

### Resolved During Planning

- **Q: Will test_routing.py break?** No. `_should_skip_stage1(nahw_tree)` checks `leaf_count <= 200`. 193 <= 200 is True. Only the comment needs updating.
- **Q: Does the gold baseline need updating?** No. `gold_baseline_nahw.yaml` references leaf paths in existing branches (almajrurat, huruf_aljar). None of the new/moved leaves affect those paths.
- **Q: Should we update the registry?** Yes. The notes field says "183 leaves, 9 branches" which will be stale.

### Deferred to Implementation

- **Q: Exact YAML indentation at each insertion point?** Must read the surrounding lines at edit time to match existing indentation (2-space vs 4-space at each depth level).
- **Q: Will Gemini CLI coworker find additional corrections?** If so, those would be a separate remediation cycle, not part of this commit.

## Implementation Units

- [ ] **Unit 1: Branch Switch and Baseline Verification**

  **Goal:** Switch to taxonomy branch and confirm all tests pass before making changes.

  **Requirements:** Precondition for all other units.

  **Dependencies:** None.

  **Files:**
  - Read: `library/sciences/nahw/tree.yaml`
  - Read: `engines/taxonomy/tests/test_tree_loader.py`

  **Approach:**
  - `git checkout taxonomy-k2-synthesis-20260406` (creates local branch tracking origin)
  - Run `pytest engines/taxonomy/tests/ -v --tb=short` to establish green baseline
  - Verify branch NEXT.md matches what we planned against (no surprise updates)

  **Verification:**
  - All taxonomy tests pass
  - Nahw tree has 183 leaves (pre-edit baseline confirmed)

- [ ] **Unit 2: Apply 11 Nahw Tree Edits + Test/Registry Updates**

  **Goal:** Execute all prescribed edits from NEXT.md, update test assertions, and update taxonomy registry — as a single atomic change.

  **Requirements:** R1, R2, R3, R4

  **Dependencies:** Unit 1

  **Files:**
  - Modify: `library/sciences/nahw/tree.yaml` (11 edits)
  - Modify: `engines/taxonomy/tests/test_tree_loader.py` (leaf count assertion)
  - Modify: `engines/taxonomy/tests/conftest.py` (docstring)
  - Modify: `engines/taxonomy/tests/test_routing.py` (comment)
  - Modify: `library/sciences/taxonomy_registry.yaml` (nahw notes)

  **Approach:**
  - Apply edits in NEXT.md order (1 through 11). Edit 1 removes a leaf; Edit 7 re-adds it in its correct home. These must be sequential.
  - Read surrounding YAML at each insertion point to match indentation precisely
  - After all tree edits: update `leaf_count` metadata (183→193), `methodology`, and `date`
  - Update test assertion: `test_tree_loader.py:61` — `183` → `193`
  - Update docstring: `conftest.py:190` — "183 leaves" → "193 leaves"
  - Update comment: `test_routing.py:233` — "183 ≤ 200" → "193 ≤ 200"
  - Update registry: `taxonomy_registry.yaml` nahw notes — "183 leaves, 9 branches" → "193 leaves, 10 branches" + append "cold-read audit remediation (2026-04-07)"

  **Patterns to follow:**
  - Existing YAML node structure in `tree.yaml` (2-space indent per level, `id`/`title`/`leaf`/`confidence` fields)
  - L2 nodes with single leaf children exist elsewhere in the tree (e.g., `al_ikhtisas`)

  **Test scenarios:**
  - Happy path: Leaf count is exactly 193 after all edits
  - Happy path: No duplicate IDs across entire tree
  - Happy path: L1 branch count is exactly 10
  - Happy path: `law_wa_lawla_wa_lawma_wa_amma` exists under `adawat_al_shart_ghayr_al_jazima` (new home), NOT under `irab_al_fil_al_mudari` (old home)
  - Happy path: `irab_al_fil_al_mudari_wa_ahkamuhu` has exactly 5 children after Edit 1
  - Happy path: `al_idafa` has exactly 5 children after Edit 4
  - Happy path: All new leaf IDs are findable via tree traversal
  - Edge case: YAML parses without errors (no broken indentation)
  - Integration: `pytest engines/taxonomy/tests/ -v --tb=short` passes all tests

  **Verification:**
  - Run NEXT.md verification commands (leaf count Python one-liner, duplicate check, L1 branch count)
  - Run `pytest engines/taxonomy/tests/ -v --tb=short` — all pass
  - `yaml.safe_load()` succeeds on the modified file

- [ ] **Unit 3: Coworker Dispatch — Gemini CLI + Codex CLI**

  **Goal:** Cross-provider validation of the nahw tree remediation to move decisions from PRELIMINARY to confirmed.

  **Requirements:** R5

  **Dependencies:** Unit 2 (tree must be edited and committed first, so coworkers review the actual final state)

  **Files:**
  - Read: `library/sciences/nahw/tree.yaml` (post-edit)
  - Read: `reference/research/nahw_cold_read_triage.md`

  **Approach:**
  - **Gemini CLI dispatch:** Arabic scholarly validation. Specific questions:
    1. Are the 10 new leaves correctly categorized as nahw (not sarf/balagha)?
    2. Are the Arabic titles standard terminology (matching canonical textbooks)?
    3. Is the relocation of لو/لولا/لوما/أمّا from إعراب المضارع to أدوات الشرط غير الجازمة correct?
    4. Did the cold-read audit miss any standard nahw topics not already in the 193-leaf tree?
    5. Are the 3 new إضافة subtypes (صفة مشبهة, ملازمة, إلى الجمل) standard Alfiyya categories?
  - **Codex CLI dispatch:** Structural validation. Questions:
    1. Verify zero duplicate IDs across the full tree
    2. Verify all `id` fields follow the transliteration naming convention
    3. Verify no Arabic text appears in `id` fields
    4. Count leaves per L1 branch for balance check
    5. Verify `confidence` field is present on all new leaves
  - Both dispatches go through `/prompt-architect` per Rule 14
  - Log dispatches to `.kr/runtime/dispatch_log.jsonl`

  **Test scenarios:**
  - Happy path: Gemini CLI confirms all 10 leaves are correctly placed
  - Happy path: Codex CLI confirms zero structural issues
  - Error path: If Gemini identifies a misplacement, document as finding and create follow-up remediation
  - Error path: If Codex finds duplicate IDs or naming violations, fix before committing

  **Verification:**
  - Both coworker reports received and documented
  - No CRITICAL or HIGH findings unresolved
  - Dispatch logged to `.kr/runtime/dispatch_log.jsonl`

- [ ] **Unit 4: DR Dispatch — Gemini DR (Islamic Study Methodology)**

  **Goal:** Independent Islamic sciences validation by the strongest DR source for scholarly methodology.

  **Requirements:** R6

  **Dependencies:** Unit 2 (need the final tree state for the prompt)

  **Approach:**
  - Gemini DR CANNOT access the repo — prepare a file bundle for owner relay:
    1. The post-edit `library/sciences/nahw/tree.yaml` (full file)
    2. The triage document `reference/research/nahw_cold_read_triage.md`
    3. A focused prompt asking Gemini DR to independently evaluate:
       - Whether the 10 new topics are standard nahw curriculum topics (referencing canonical texts: الألفية، شرح ابن عقيل، مغني اللبيب، أوضح المسالك)
       - Whether the new L1 branch أحكام الجمل is correctly scoped (not overlapping with existing branches)
       - Whether the 193-leaf nahw tree now covers the standard nahw curriculum as taught in Arabic-language Islamic studies programs
       - Any topics still missing that would leave a gap in the owner's understanding of nahw
  - Prompt goes through `/prompt-architect` before relay
  - Present relay prompt + file bundle to owner with clear instructions
  - This is NON-BLOCKING: the commit can proceed while DR is in flight, with findings applied as follow-up

  **Verification:**
  - DR prompt prepared and presented to owner
  - File bundle prepared for upload
  - Dispatch logged

- [ ] **Unit 5: Commit, Push, and Post-Remediation Assessment**

  **Goal:** Land the changes and assess what's next on the taxonomy branch.

  **Requirements:** R1, R7

  **Dependencies:** Units 2-3 (Unit 4 is non-blocking)

  **Files:**
  - All modified files from Unit 2
  - Create/update: branch NEXT.md (post-remediation state)

  **Approach:**
  - Use the exact commit message from NEXT.md (with `Co-Authored-By` appended)
  - Push to `origin/taxonomy-k2-synthesis-20260406`
  - After push, assess and document remaining branch work:
    - **Balagha K2:** 197-leaf architect draft ready, cold-read audited — ready for CC installation as `balagha_v2_0`
    - **Imlaa K2:** 51-leaf architect draft ready, cold-read integrated — ready for CC installation as `imlaa_v2_0`
    - **Sarf K2:** 152-leaf draft paused — needs Claude DR K2 + ChatGPT DR K2 before convergence
    - **Aqidah K2:** Gemini DR v2 processed — needs ChatGPT DR K2 before convergence
  - Update branch NEXT.md with the post-remediation state and next session directive

  **Verification:**
  - Push succeeds
  - All tests pass on pushed commit
  - Branch NEXT.md accurately reflects what's done and what's next

## System-Wide Impact

- **Taxonomy engine:** Nahw tree changes affect taxonomy placement routing. New leaves become valid placement targets. Stage 1 branch pre-selection must include the new `ahkam_al_jumal` branch.
- **Gold baseline:** Current `gold_baseline_nahw.yaml` uses paths in existing branches (almajrurat, huruf_aljar). No gold baseline entries need updating. However, new leaves mean new excerpts could be placed in locations the gold baseline doesn't cover — the baseline should eventually be extended (not this plan).
- **Excerpting engine:** No impact. Excerpting operates upstream of taxonomy.
- **Synthesis engine:** The architect triage deferred Checks 5 and 6 (cross-cutting المرفوعات/المنصوبات views) as synthesis-layer concerns. These are documented requirements for the synthesis engine, not tree edits.
- **Unchanged invariants:** All other science trees (sarf, balagha, imlaa, aqidah) remain at their current versions. The taxonomy registry structure is unchanged — only the nahw notes field is updated.

## Risks & Dependencies

| Risk | Mitigation |
|------|------------|
| YAML indentation error breaks tree parsing | Verify with `yaml.safe_load()` immediately after each edit batch. Run tree loader test before committing. |
| New leaf IDs don't match transliteration convention | Codex CLI structural review validates naming. IDs in NEXT.md follow the existing convention. |
| Scholarly disagreement on topic placement | Gemini CLI + Gemini DR provide cross-provider validation. If they disagree with the triage, document and create follow-up. |
| Merge conflicts with excerpting branch | Taxonomy branch modifies only `library/sciences/` and `reference/research/`. Excerpting branch modifies `engines/excerpting/`. Zero overlap expected. |

## Sources & References

- **Origin:** `taxonomy-k2-synthesis-20260406:NEXT.md` (branch-local directive for nahw remediation)
- **Triage document:** `reference/research/nahw_cold_read_triage.md` (16-check audit results + architect verdicts)
- **Taxonomy protocol:** `reference/protocols/TAXONOMY_TREE_PROTOCOL.md` (tree validation governance)
- **No-single-model rule:** `.claude/rules/no-single-model-conclusion.md`
- **Coworker dispatch rules:** `.claude/rules/mandatory-coworker-dispatch.md`, `.claude/rules/coworker-dispatch.md`
