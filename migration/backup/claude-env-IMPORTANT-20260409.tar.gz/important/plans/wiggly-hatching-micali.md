# Raw Trace Data: 5-Book Overnight Run (~308 Chunks)

Traced from source code on 2026-03-28. All line numbers verified against current master.

---

## 1. RETRY CASCADE — Exact Call Sequence for One Permanently-Failing Chunk

### Two nested loops

**Inner loop — CLI Adapter** (`shared/llm/cli_adapter.py:306`):
```python
# Line 254: max_retries default=0, but ALL callers pass 2
# Line 306:
for attempt in range(max_retries + 1):   # range(3) → attempts 0, 1, 2
    try:
        raw_output = self._invoke_backend(...)  # Line 322 — SUBPROCESS CALL
        json_data = extract_json(raw_output)     # Line 334
        result = response_model.model_validate(json_data)  # Line 337
        return result                            # Line 355
    except json.JSONDecodeError:                 # Line 357 — retry with feedback, NO sleep
    except ValidationError:                      # Line 384 — retry with feedback, NO sleep
    except subprocess.TimeoutExpired:            # Line 413 — sleep(2**attempt), then retry
    except subprocess.CalledProcessError:        # Line 430 — sleep(2**attempt), then retry
# After loop: raise CLIBackendError (lines 378, 424, 448)
```

Timeout per subprocess: `120s` (line 262: `kwargs.get("timeout", 120)`)
Backoff between timeout retries: `2**attempt` → 1s, 2s (line 421, 445)
Exception raised on exhaustion: `CLIBackendError` (lines 35-49)

**Outer loop — Phase 2a** (`engines/excerpting/src/phase2_classify.py:371-478`):
```python
# Line 371:
max_attempts = 1 + config.RETRY_COUNT  # 1 + 2 = 3 (RETRY_COUNT at contracts.py:753)
# Line 378:
for attempt in range(max_attempts):     # range(3) → attempts 0, 1, 2
    try:
        cr = classify_chunk(chunk, client, config, error_feedback)  # Line 383
        # classify_chunk calls client.chat.completions.create(max_retries=2) at line 347
        # ^^^ THIS ENTERS THE INNER ADAPTER LOOP (3 subprocess calls)
    except ValidationError:              # Line 420 — retry, NO sleep
    except ValueError:                   # Line 434 — retry, NO sleep
    except Exception:                    # Line 454 — sleep(2**attempt), then retry
# After loop: log error, chunk EXCLUDED (lines 469-476)
```

**Outer loop — Phase 2b** (`engines/excerpting/src/phase2_group.py:289-392`):
```python
# Line 289: max_attempts = 1 + config.RETRY_COUNT = 3
# Line 300: for attempt in range(max_attempts):
#   calls group_chunk → client.chat.completions.create(max_retries=2) at line 182
#   except Exception: sleep(2**attempt) — same pattern as Phase 2a
# After loop: chunk EXCLUDED (lines 383-392)
```

**Outer loop — Phase 3a enrichment** (`engines/excerpting/src/phase3_enrichment.py:454-522`):
```python
# Line 454: max_attempts = 1 + config.RETRY_COUNT = 3
# Line 467: for attempt in range(max_attempts):
#   calls enrich_chunk → client.chat.completions.create(max_retries=2) at line 274
#   except ValidationError: retry, NO sleep (line 489)
#   except Exception: sleep(2**attempt) (line 498-505)
# After loop: chunk PROCEEDS with "llm_enrichment_failed" flag (lines 507-520)
```

**Outer loop — Phase 3b consensus** (`engines/excerpting/src/phase3_consensus.py:739-798`):
```python
# Line 739: max_attempts = 1 + config.RETRY_COUNT = 3
# Line 758: for attempt in range(max_attempts):
#   calls verify_chunk → verify_client.chat.completions.create(max_retries=2) at line 215
#   if verify disagrees → escalation_client.chat.completions.create(max_retries=2) at line 466
#   except Exception: retry, NO sleep (line 783-790)
# After loop: all excerpts get "verification_skipped" flag (lines 792-798)
```

### Precise call counts for permanently-failing chunk (all timeouts)

**Phase 2a only (chunk excluded after):**
```
Phase attempt 0:
  Adapter attempt 0: subprocess (120s) → TimeoutExpired → sleep(1s)
  Adapter attempt 1: subprocess (120s) → TimeoutExpired → sleep(2s)
  Adapter attempt 2: subprocess (120s) → TimeoutExpired → raise CLIBackendError
  = 363s
  Phase catches CLIBackendError → sleep(2^0 = 1s)

Phase attempt 1:
  Adapter attempt 0: subprocess (120s) → TimeoutExpired → sleep(1s)
  Adapter attempt 1: subprocess (120s) → TimeoutExpired → sleep(2s)
  Adapter attempt 2: subprocess (120s) → TimeoutExpired → raise CLIBackendError
  = 363s
  Phase catches CLIBackendError → sleep(2^1 = 2s)

Phase attempt 2:
  Adapter attempt 0: subprocess (120s) → TimeoutExpired → sleep(1s)
  Adapter attempt 1: subprocess (120s) → TimeoutExpired → sleep(2s)
  Adapter attempt 2: subprocess (120s) → TimeoutExpired → raise CLIBackendError
  = 363s
  Phase logs error. Chunk excluded.

TOTAL: 9 subprocess calls, 1,092 seconds (18m 12s)
```

**Phase 3a + 3b (chunk passed 2a/2b, fails all Phase 3):**
```
Phase 2a: 1 successful call (~15s)
Phase 2b: 1 successful call (~15s)
Phase 3a: 9 subprocess calls, 1,092s (same nesting as above, chunk proceeds with degradation)
Phase 3b: 9 subprocess calls, 1,089s (no phase-level sleep, but adapter has backoff)

TOTAL: 20 subprocess calls, ~2,211 seconds (36m 51s)
```

**Phase 3b with escalation (verify succeeds but disagrees, escalation times out):**
```
Phase attempt 0: verify succeeds (1 call, ~15s) → disagrees → escalation:
  Adapter attempt 0: subprocess (120s) → timeout → sleep(1s)
  Adapter attempt 1: subprocess (120s) → timeout → sleep(2s)
  Adapter attempt 2: subprocess (120s) → timeout → raise CLIBackendError
  verify_chunk raises → phase catches

Phase attempt 1: same as above
Phase attempt 2: same as above

TOTAL: 3 verify + 9 escalation = 12 subprocess calls, 1,134 seconds (18m 54s)
```

### Constants table

| Constant | Value | File:Line |
|----------|-------|-----------|
| `RETRY_COUNT` | 2 | `contracts.py:753` |
| `TIMEOUT_SECONDS` | 120 | `cli_adapter.py:262` |
| Phase 2a `max_retries` | 2 (hardcoded) | `phase2_classify.py:347` |
| Phase 2b `max_retries` | 2 (hardcoded) | `phase2_group.py:182` |
| Phase 3a `max_retries` | 2 (hardcoded) | `phase3_enrichment.py:274` |
| Phase 3b verify `max_retries` | 2 (hardcoded) | `phase3_consensus.py:215` |
| Phase 3b escalation `max_retries` | 2 (hardcoded) | `phase3_consensus.py:466` |
| Per-package timeout | 3600s | `run_full_integration.py:185` |

### Failure outcomes by phase

| Phase | On all-retries-exhausted | Code path |
|-------|--------------------------|-----------|
| 2a classify | Chunk **absent** from result dict → excluded from 2b/3 | `phase2_classify.py:469-476` |
| 2b group | Chunk **absent** from result dict → excluded from 3 | `phase2_group.py:383-392` |
| 3a enrich | Excerpts **kept** with `"llm_enrichment_failed"` flag, proceeds to 3b | `phase3_enrichment.py:507-520` |
| 3b consensus | Excerpts **kept** with `"verification_skipped"` flag | `phase3_consensus.py:792-798` |
| Orchestrator (3a crash) | Catches exception, degrades to deterministic-only | `phase3_orchestrator.py:119-127` |
| Orchestrator (3b crash) | Catches exception, flags all `"verification_skipped"` | `phase3_orchestrator.py:150-164` |
| Integration script (any phase) | `return 1` (abort package) | `run_integration_test.py:661-732` |
| Full integration (per-package) | Log + continue to next package | `run_full_integration.py:203-224` |

Programming bugs (`TypeError`, `AttributeError`, `NameError`, `KeyError`, `IndexError`, `ZeroDivisionError`, `StopIteration`) are re-raised at `phase3_orchestrator.py:120-121` and `phase3_orchestrator.py:151-152`. They crash the process.

---

## 2. UNTESTED CODE PATHS — Grep Results

### Test files referencing CLI backends

**`shared/llm/tests/test_cli_adapter.py`** — 34 tests total, ALL use `@patch("shared.llm.cli_adapter.subprocess.run")`:
- Lines 131-145: `test_provider_routing_openai()` — asserts `codex` routing, subprocess MOCKED
- Lines 148-161: `test_provider_routing_google()` — asserts `gemini` routing, subprocess MOCKED
- Lines 273-294: `test_codex_schema_file_created()` — asserts `--output-schema` in cmd, subprocess MOCKED, file read MOCKED via `patch.object(Path, "read_text")`
- Lines 212-228: gemini flag tests — asserts `-p` flag, subprocess MOCKED

**`engines/excerpting/tests/test_phase3_consensus.py`** — ~70 tests:
- Line 3: "All tests use mocked LLM clients — no real API calls."
- Uses `_make_mock_instructor_client()` for verify and escalation clients
- Lines 249-1050: escalation_value references in mock objects only

**`shared/llm/tests/test_ri_trace_bridge.py`** — 16 tests:
- Lines 223-225: mock response with `backend="cli:gemini"` — tests trace struct, not subprocess

### Real backend invocation capability

`scripts/run_integration_test.py:510-514`:
```python
if backend == "cli":
    enrich_client = create_cli_client()  # Real CLIInstructorAdapter
```
This path EXISTS but is invoked by the standalone script, NOT by any pytest test.

### Exact answers

- `codex exec --output-schema`: **0 real invocations** across all tests
- `gemini -p`: **0 real invocations** across all tests
- `claude -p`: **0 real invocations** across all tests (only via mocked subprocess)

### Untested code paths in the adapter

| Code Path | File:Lines | What It Does | Tested? |
|-----------|-----------|--------------|---------|
| Codex schema file write + read | `cli_adapter.py:461+` (in `_invoke_backend`) | Writes JSON schema to temp file, passes `--output-schema <path>`, reads response from file | MOCKED (file write/read patched) |
| Gemini `-p` flag construction | `cli_adapter.py:461+` | Builds `gemini -p "..."` command | MOCKED (subprocess patched) |
| Claude OAuth refresh | `cli_adapter.py:439-444` | On auth error, calls `_get_oauth_token()` | NEVER TESTED |
| Timeout kill behavior | `cli_adapter.py:413` | `subprocess.run(timeout=120)` kills process on timeout | MOCKED (TimeoutExpired raised manually) |

---

## 3. RESUME CAPABILITY — Code Path Trace

### Search results

```
grep -rn "checkpoint\|resume\|skip.*chunk\|already.*processed" engines/excerpting/src/
→ 0 matches
```

### File write modes (all overwrite)

| File | Writer | Mode | Location |
|------|--------|------|----------|
| `excerpts.jsonl` | `writer.py` | `"w"` | Line 52 |
| `gate_queue.jsonl` | `writer.py` | `"w"` | Line 91 |
| `processing_log.jsonl` | `writer.py` | `"w"` | Line 245 |
| `phase1_chunks.json` | `run_integration_test.py` | fresh write | Line 625 |
| `timing.json` | `run_integration_test.py` | fresh write | Line 396 |

### Processing order (all sequential, no parallel)

```
phase2_classify.py:373    →  for chunk in chunks:              # Sequential
phase2_group.py:298       →  for chunk_id, ... in ...:         # Sequential
phase3_enrichment.py:456  →  for chunk_id, chunk_excerpts ...: # Sequential
phase3_consensus.py:741   →  for chunk_id, chunk_excerpts ...: # Sequential
```

### When output is flushed to disk

Output is written ONLY after ALL phases complete:
```
run_integration_test.py:741-756  →  write_results() called after phase3 returns
```
Crash mid-phase = zero disk output. All in-memory results lost.

### `--max-chunks` behavior

```python
# run_integration_test.py:629-635
chunks = chunks[:max_chunks]  # Slices from index 0. Not resume. Not offset.
```

### Crash-at-chunk-150 trace

```
1. Process starts → loads all 308 chunks into memory
2. Phase 2a: processes chunks 0..149 (each with LLM call) → crash at chunk 150
3. Chunks 0-149 results: IN MEMORY ONLY (classify_chunk returns dict, never flushed)
4. Chunks 150-307: never reached
5. write_results(): NEVER CALLED (crash happened before it)
6. Disk state: EMPTY (or stale from previous run)
7. Re-run: loads all 308 chunks, starts from chunk 0, overwrites everything
```

---

## 4. ERROR ACCUMULATION — What Gets Written Where

### processing_log.jsonl structure (`writer.py:218-250`)

```json
{
  "source_id": "string",
  "timestamp": "ISO8601",
  "excerpt_count": 0,
  "gate_count": 0,
  "error_count": 1,
  "errors": ["EX-C-001", "phase2a_fatal: CLIBackendError(...)"],
  "timings": {
    "load_package": 0.005,
    "phase1": 0.029,
    "phase2a": 43.875,
    "phase2a_per_chunk": {"chunk_001": 43.875, "chunk_002": 12.3},
    "phase2b": 45.467,
    "phase3": 34.679
  }
}
```

Per-chunk timing: YES (in `timings.phase2a_per_chunk`).
Per-chunk pass/fail status: NO. Failed chunks are absent from results, not explicitly marked.

### LLM call logging (`run_integration_test.py:78-168`)

Three hooks registered:

| Hook | Fires when | Output file | Fields |
|------|-----------|-------------|--------|
| `on_request` (lines 96-117) | Before each LLM call | `raw_llm_requests/{call_id}.json` | model, temperature, max_tokens, messages |
| `on_response` (lines 119-149) | After successful call | `raw_llm_responses/{call_id}.json` | latency, usage (prompt/completion/total tokens), finish_reason |
| `on_error` (lines 155-166) | After failed call | `raw_llm_responses/{call_id}_error.json` | error_type, error message (truncated to 500 chars) |

Failed attempts: each gets a `{call_id}_error.json`. Token usage: NOT available (no response body on timeout).

Call ID format: `{client_name}_{counter:04d}` — counter increments per hook registration, so the sequence shows every attempt including retries.

### Finding failed chunks after a run

```bash
# Failed at Phase 2a (chunks completely absent from output):
python3 -c "
import json
chunks = json.load(open('output/phase1_chunks.json'))
excerpts = [json.loads(l) for l in open('output/excerpts.jsonl')]
chunk_ids = {c['chunk_id'] for c in chunks}
excerpt_chunks = {e['source_chunk_id'] for e in excerpts}
missing = chunk_ids - excerpt_chunks
print(f'Dropped chunks: {len(missing)}')
for c in sorted(missing): print(f'  {c}')
"

# Failed at Phase 3a (present but flagged):
grep -c "llm_enrichment_failed" output/excerpts.jsonl

# Failed at Phase 3b (present but flagged):
grep -c "verification_skipped" output/excerpts.jsonl

# Count all error files from LLM hooks:
ls raw_llm_responses/*_error.json 2>/dev/null | wc -l
```

### Error propagation chain (exact exception flow)

```
subprocess.TimeoutExpired (OS level)
  → caught by cli_adapter.py:413
  → retried 2 more times (adapter loop)
  → raised as CLIBackendError (cli_adapter.py:424-428)
  → caught by phase2_classify.py:454 (except Exception)
  → retried 2 more times (phase loop)
  → chunk excluded from result dict (phase2_classify.py:469)
  → Phase 2b receives smaller dict (missing chunk)
  → Phase 3 never sees this chunk
  → writer.py never writes excerpts for this chunk
  → chunk is SILENTLY ABSENT from excerpts.jsonl
```

---

## 5. AGGREGATE NUMBERS

### Per-chunk call counts (happy path)

| Phase | Calls | Backend |
|-------|:-----:|---------|
| 2a classify | 1 | claude (primary) |
| 2b group | 1 | claude (primary) |
| 3a enrich | 1 | claude (primary) |
| 3b verify | 1 | codex (verify) |
| 3b escalate | 0 or 1 | gemini (escalation, only on disagreement) |
| **Total** | **4-5** | — |

### Per-chunk call counts (all-timeout worst case)

| Phase | Calls | Calculation | Wall-clock |
|-------|:-----:|-------------|:----------:|
| 2a classify | 9 | 3 phase × 3 adapter | 1,092s |
| 2b group | 9 | 3 phase × 3 adapter | 1,092s |
| 3a enrich | 9 | 3 phase × 3 adapter | 1,092s |
| 3b verify | 9 | 3 phase × 3 adapter | 1,089s |
| 3b escalate | 9 | 3 phase × 3 adapter | 1,089s |
| **Max total** | **45** | (never all hit — 2a failure excludes from 2b+) | — |

### Realistic worst-case paths

| Path | Calls | Wall-clock |
|------|:-----:|:----------:|
| Fail at 2a, excluded | 9 | 18m 12s |
| Pass 2a, fail 2b, excluded | 3+9=12 | 18m 27s |
| Pass 2a/2b, fail 3a+3b | 2+9+9=20 | 36m 51s |
| Pass 2a/2b/3a, fail 3b (verify+escalation) | 3+9+9=21 | 37m 6s |

### 308-chunk totals

| Scenario | Failing chunks | Total calls | Total time |
|----------|:--------------:|:-----------:|:----------:|
| 0% failure | 0 | 1,232 | 5.1h |
| 5% fail at 2a | 15 | 1,367 | 9.5h |
| 10% fail at 2a | 31 | 1,511 | 13.6h |
| 20% fail at 2a | 62 | 1,790 | 22.9h |
| 100% fail at 2a | 308 | 2,772 | 92.4h |

### Per-package numbers (5 packages)

`run_full_integration.py:27-73` defines: ibn_aqil_v1, ibn_aqil_v3, taysir, ext_39_masala, ext_46_qa

Per-package timeout: `3600s` (line 185).

308 chunks / 5 packages ≈ 62 chunks average per package.
Happy-path per package: 62 × 60s = 3,720s → **already exceeds 3600s timeout**.

Failing chunk budget per package (before timeout):
- 0 failing chunks: 3,720s happy path → timeout at 3,600s (already over by 120s)
- Wait — if happy path is 62 × 60s = 3,720s, the per-package timeout is ALREADY INSUFFICIENT even with 0 failures, assuming 60s per chunk average.
- Actual per-chunk time depends on LLM latency. First smoke test showed ~88s total for 5 excerpts from 2 chunks. ~44s per chunk for 2a only. Full pipeline likely ~60-90s per chunk.
