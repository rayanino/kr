# Autonomous System Hardening — 5 Critical Fixes for 3-Month Run

## Context

The autonomous overnight system is deployed (Gate 0 passed Apr 7) and starts Apr 9. Three exploration agents and one planning agent analyzed the system's task generator, governance, and actual output quality. They found **3 pipeline breaks that will waste the 3-month window** and 2 supporting issues that reduce effectiveness. The owner has 2 full days (Apr 7-8) to fix everything before the autonomous period.

**Stakes:** Without fixes: 3 months of compute produces an empty backlog, a useless morning report, and no summer work queue. With fixes: 100+ evaluated findings, 30+ ranked improvements, summer starts day 1.

## The 5 Fixes (Priority Order)

### Fix 1: Creative Task Crash Diagnostics + Readonly Guard False Positive
**Why first:** 4/5 creative tasks crash in ~20 seconds. Nothing else matters if tasks don't run.

**Root cause:** 
- 3 tasks crash instantly — no diagnostic info is written. Likely prompt/schema issues with Codex CLI.
- 1 task policy-blocked because `_readonly_guard_failures()` detects pre-existing dirty files as "new drift"

**Changes:**
- `scripts/overnight_codex_orchestrator.py`: Write `diagnostic.json` on task failure (returncode, stderr, prompt length, schema size). Currently errors vanish.
- `scripts/overnight_codex_orchestrator.py`: Fix readonly guard to compare ONLY changes that appeared DURING the task, not pre-existing dirt. The snapshot→diff logic at line ~1852 needs to take a proper baseline.
- `scripts/overnight_codex_orchestrator.py`: Add prompt length guard (warn if >12K chars, log the excess)

**Tests:** `test_execute_task_writes_diagnostic_on_failure()`, `test_readonly_guard_ignores_preexisting_drift()`

---

### Fix 2: Findings-to-Backlog Pipeline
**Why second:** Once tasks run, their findings must flow into the backlog.

**Root cause:**
- `sync_backlog_from_artifacts()` in `scripts/overnight_codex_backlog.py` only reads `final_response.json`
- Creative tasks produce `creative.json` — the sync never finds them
- Manual runs (which produced the 1 good finding) bypass the orchestrator entirely
- JSON parse failures silently swallowed: `except (OSError, json.JSONDecodeError): continue`

**Changes:**
- `scripts/overnight_codex_backlog.py`: Add `_find_result_files()` helper — scans `final_response.json` first, falls back to `creative.json` for `creative-*` directories
- `scripts/overnight_codex_backlog.py`: Replace silent `continue` with logged error + continue
- `scripts/overnight_codex_orchestrator.py`: Ensure `evaluator_verdict.json` is written for all creative results, not just orchestrator-managed ones

**Tests:** `test_sync_reads_creative_json_fallback()`, `test_sync_logs_json_parse_failure()`

---

### Fix 3: Backlog Approval CLI
**Why third:** The pipeline needs a consumer. Owner must be able to approve items.

**Root cause:**
- `update_backlog_status()` exists but has no CLI entry point
- Owner cannot approve without editing JSON
- No auto-approve mechanism for items the owner doesn't review

**Changes:**
- `scripts/overnight_codex_backlog.py`: Add `main()` with argparse subcommands:
  - `approve <item_id>` — mark proposed item as approved
  - `reject <item_id>` — mark as superseded  
  - `list [--status proposed]` — show items as formatted table
  - `auto-approve --days 7` — approve all proposed items older than N days
- `scripts/overnight_codex_orchestrator.py`: In `run_overnight()`, call `auto_approve_aged_items(days=7)` after backlog sync

**Tests:** `test_cli_approve_updates_status()`, `test_auto_approve_aged_items()`, `test_auto_approve_skips_non_proposed()`

---

### Fix 4: Morning Report — "Needs Owner" Section
**Why fourth:** Owner must see findings and have approval prompts, or they disengage by week 2.

**Root cause:**
- Morning report reads `findings_registry.json` (doesn't exist) instead of `CUMULATIVE_FINDINGS.md` (has data)
- No "Needs Owner Attention" section despite doctrine prescribing it
- No backlog approval prompts in the report

**Changes:**
- `scripts/overnight_codex_orchestrator.py`: Add `_load_cumulative_findings_summary()` — parse CUMULATIVE_FINDINGS.md for finding count, recent entries, scores
- `scripts/overnight_codex_orchestrator.py`: In `generate_morning_report()`:
  - Add "Cumulative findings: N (M passing)" stat line
  - Add "## Needs Owner Attention" section with top 3 proposed items older than 3 days
  - Each item shows: summary, priority, occurrences, and the exact `python -m scripts.overnight_codex_backlog approve ITEM-ID` command
- `scripts/overnight_codex_backlog.py`: Add `proposed_items_needing_review(max_age_days=3)` query function

**Tests:** `test_morning_report_shows_needs_owner()`, `test_morning_report_shows_cumulative_findings()`

---

### Fix 5: SUMMER_WORK_QUEUE.md Generation
**Why last:** Phase 3 starts Jun 2. Must be ready by then but not urgent for Apr 9 launch.

**Root cause:** No code exists. Phase 3's key deliverable has zero implementation.

**Changes:**
- `scripts/overnight_codex_backlog.py`: Add `generate_summer_work_queue()`:
  - Load backlog.json + parse CUMULATIVE_FINDINGS.md
  - Rank by: priority, occurrence count, evaluator score, source_task_ids count
  - Output `overnight_codex/SUMMER_WORK_QUEUE.md` with 3 tiers:
    - Tier 1: High Impact (approved + multi-validated)
    - Tier 2: Promising (proposed, high recurrence)
    - Tier 3: Creative Findings (evaluator-validated)
  - Include statistics: total items, multi-validated count, avg score
- `scripts/overnight_codex_orchestrator.py`: In `run_overnight()`, call `generate_summer_work_queue()` when active phase is "synthesis"
- `scripts/overnight_codex_task_generator.py`: Add `val-synthesis-queue` task to Phase 3 manifest

**Tests:** `test_generate_summer_work_queue_ranked()`, `test_synthesis_phase_triggers_queue()`

## Session Strategy (2 Days)

**Session 1 (current or next CC session):** Fix 1 + Fix 2 — unblock task execution and findings pipeline
**Session 2:** Fix 3 + Fix 4 — approval workflow and owner visibility  
**Session 3:** Fix 5 — SUMMER_WORK_QUEUE.md generation
**Session 4:** Integration test — run 2 full shadow cycles with all fixes, verify end-to-end
**DR Dispatch:** Prepare relay prompts for ChatGPT DR (what should the system find about excerpting?), Claude DR (governance gap analysis), Gemini DR (creative template quality for Islamic scholarly analysis)

## DR Relay Prompts to Prepare

1. **ChatGPT DR**: "Analyze the KR excerpting engine's known limitations and architectural gaps. What are the 10 highest-value improvements an autonomous analysis system should discover over 3 months? Read `engines/excerpting/SPEC.md`, `engines/excerpting/KNOWN_LIMITATIONS.md`, and `overnight_codex/creative_templates/`."

2. **Claude DR**: "Audit the KR overnight autonomous system's governance model for silent failure modes. Read `docs/codex/autonomous-doctrine-2026-04-09-to-2026-07-01.md`, `scripts/overnight_codex_orchestrator.py` (morning report section), and `scripts/overnight_codex_backlog.py`. Where can findings be silently lost?"

3. **Gemini DR**: "Evaluate the creative templates in `overnight_codex/creative_templates/` for effectiveness in discovering improvements to an Arabic Islamic scholarly text processing pipeline. Are the prompts grounded in real Islamic scholarly conventions? What templates are missing?"

## Verification

After all 5 fixes:
1. Run `python -m pytest tests/test_overnight_codex_evaluator.py tests/test_overnight_codex_runtime.py -v` — 110+ tests pass (original 110 + new tests)
2. Run `python -m pyright` on all modified files — 0 errors
3. Run 2 full shadow cycles via WSL — both complete with 0 failures
4. Verify morning report has "Needs Owner" section
5. Verify backlog has >0 items after a creative task succeeds
6. Run `python -m scripts.overnight_codex_backlog list` — shows items
7. Run `python -m scripts.overnight_codex_backlog approve <id>` — works

## Critical Files

| File | Fixes |
|------|-------|
| `scripts/overnight_codex_orchestrator.py` | 1, 2, 4 |
| `scripts/overnight_codex_backlog.py` | 2, 3, 4, 5 |
| `scripts/overnight_codex_task_generator.py` | 5 |
| `tests/test_overnight_codex_runtime.py` | 1, 2, 3, 4, 5 |
| `scripts/overnight_codex_common.py` | (already fixed: schema, CRLF ignore) |
