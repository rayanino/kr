# Taxonomy Engine — Session 1 Build Plan (Deterministic Infrastructure)

## Context

The taxonomy engine is the last piece before v1 E2E pipeline. It takes excerpts from the excerpting engine and places each one at the correct leaf in existing science trees (5 sciences, 922 total leaves). The SPEC rewrite, contracts, and architecture doc are already complete — this session implements the actual code.

**Session 1 scope:** All deterministic infrastructure (tree loading, routing, validation, writing, diagnostics, orchestration). NO LLM prompt construction or LLM calls — that's Session 2.

**Key files already done:**
- `engines/taxonomy/SPEC.md` (551 lines, core-only v1)
- `engines/taxonomy/contracts_core.py` (all Pydantic models)
- `engines/taxonomy/docs/architecture.md` (module structure)
- `engines/taxonomy/CLAUDE.md` (build guide)
- `library/sciences/*/tree.yaml` (5 science trees)
- `library/sciences/taxonomy_registry.yaml` (active tree versions)
- `engines/taxonomy/tests/fixtures/gold_baseline_nahw.yaml` (12 gold baseline excerpts)
- `integration_tests/smoke_fix_20260329/ibn_aqil_v3/excerpts.jsonl` (real excerpts)

## Build Order (7 Steps)

Dependencies flow: `contracts_core.py` → `tree_loader.py` → `placer.py` / `validator.py` / `writer.py` / `diagnostics.py` → `engine.py`

### Step 0: `conftest.py` — Test Infrastructure
**File:** `engines/taxonomy/tests/conftest.py`

Factory functions returning valid instances with sensible defaults (pattern from excerpting engine):
- `make_excerpt(**overrides) -> dict` — Real Arabic default primary_text from ibn_aqil excerpt 0
- `make_run_config(**overrides) -> RunConfig`
- `make_placement_additions(**overrides) -> PlacementAdditions`
- `MockPlacementAdapter` — Returns configurable deterministic PlacementRanking (for testing routing/engine without LLM)

Pytest fixtures:
- `nahw_tree`, `aqidah_tree`, `all_trees` — Load real trees
- `real_excerpts` — First 5 from integration test JSONL
- `tmp_output_dir` — pytest tmp_path for writer tests

### Step 1: `tree_loader.py` + `test_tree_loader.py`
**File:** `engines/taxonomy/src/tree_loader.py`

Functions:
- `load_tree(science_id, registry_path, override_path?) -> LoadedTree`
- `detect_yaml_format(data) -> "v0" | "v1"` — Check for `taxonomy.nodes` key
- `normalize_v1(data) -> (list[TreeNode], str, str)` — Recursive node walking, build paths with `/` separator
- `normalize_v0(data, science_id) -> (list[TreeNode], str)` — Envelope key excluded from paths; `__overview` double-underscore ARE children; single `_`-prefix (except `_label`/`_leaf`) are metadata
- `collect_leaves(nodes) -> list[TreeNode]` — Recursive leaf collection
- `build_branch_view(nodes) -> str` — Format branch structure as text (for Stage 1 prompt context)
- `build_leaf_view(leaves) -> str` — Format leaf list as text (for Stage 2 prompt context)

Error: `TAX_TREE_LOAD_ERROR` for YAML parse failure, zero leaves, duplicate leaf paths.

**Tests (~16):** Load all 5 real trees with correct leaf counts (nahw:226, sarf:226, balagha:335, imlaa:105, aqidah:28-30), verify `__overview` nodes are leaves, leaf path uniqueness, v0 envelope exclusion, format detection, branch/leaf view formatting, error cases.

### Step 2: `placer.py` (deterministic parts) + `test_routing.py`
**File:** `engines/taxonomy/src/placer.py`

**Protocol-based design for Session 2 integration:**
```python
class PlacementAdapter(Protocol):
    def run_stage1(self, excerpt: dict, tree: LoadedTree) -> BranchSelection: ...
    def run_stage2(self, excerpt: dict, candidates: list[TreeNode]) -> PlacementRanking: ...

class StubPlacementAdapter:
    # Raises NotImplementedError for all calls (Session 1 marker)
```

Implemented functions:
- `classify_excerpt_type(excerpt) -> ExcerptType` — `structural_transition`/`cross_reference` → ALWAYS_STAGED; `editorial_note` → EDITORIAL; all others → TEACHING; missing/null/unknown → EDITORIAL (safe default)
- `route_excerpt(ranking, excerpt_type) -> (PlacementRoute, leaf_path|None, confidence|None, tie_detected)` — Full routing matrix from SPEC §4.A.3
- `place_excerpt(excerpt, tree, adapter) -> PlacementAdditions` — Orchestrates Stage 1/2 via adapter, then routes
- `_should_skip_stage1(tree) -> bool` — `tree.leaf_count <= 200`

**Tie handling:** If top 2 scores within 0.10 and both ≥0.50, force to staged regardless of type.

**Tests (~20):** All routing matrix combinations (teaching/editorial/always-staged × score ranges), tie detection, type classification for all primary_function values, missing/null handling, place_excerpt with mock adapter.

### Step 3: `validator.py` + `test_validator.py`
**File:** `engines/taxonomy/src/validator.py`

- `validate_placement(leaf_path, tree) -> bool` — `leaf_path in tree.leaf_by_path`
- `verify_written_file(path, original_primary_text) -> bool` — Read back UTF-8, parse JSON, compare `primary_text` byte-identical

**Tests (~8):** Valid/invalid leaf paths, branch paths, Arabic text round-trip with diacritics/ZWNJ, corrupted text detection, encoding verification.

### Step 4: `writer.py` + `test_writer.py`
**File:** `engines/taxonomy/src/writer.py`

Four writer functions, all following the same pattern:
- Merge: `output = {**excerpt, **additions.model_dump(mode="json")}` (D-023 provenance)
- Write: `json.dumps(output, ensure_ascii=False, indent=2)`, `encoding="utf-8"`
- Directory creation: `mkdir(parents=True, exist_ok=True)`

| Function | Output Path |
|----------|-------------|
| `write_placed_excerpt` | `{base}/{science}/content/{leaf}/excerpts/{id}.json` |
| `write_staged_excerpt` | `{base}/{science}/staged/{leaf}/excerpts/{id}.json` |
| `write_unplaced_excerpt` | `{base}/{science}/unplaced/{id}.json` |
| `write_pending_excerpt` | `{base}/pending_no_tree/{science}/{id}.json` |

**Tests (~10):** Correct directory structure, D-023 field preservation, Arabic text byte-identical round-trip, `ensure_ascii=False` verification, directory creation.

### Step 5: `diagnostics.py` + `test_diagnostics.py`
**File:** `engines/taxonomy/src/diagnostics.py`

- `compute_batch_report(results, config, tree) -> BatchReport` — Count by lifecycle_stage, build confidence histogram and leaf distribution
- `check_warnings(report) -> list[str]` — Four warning conditions from SPEC §4.A.6
- `compute_median_confidence(confidences) -> float | None` — `statistics.median()`, None if empty
- `compute_editorial_placement_rate(results) -> float | None`

Warning thresholds: median < 0.65 (science mismatch), >40% unplaced, any leaf >25% of placements, >50% editorial live.

**Tests (~10):** Correct counts, histogram bucketing, all 4 warning conditions, edge cases (empty list, zero editorial).

### Step 6: `engine.py` + `test_engine.py`
**File:** `engines/taxonomy/src/engine.py`

`run(config: RunConfig, adapter: PlacementAdapter | None = None, base_path: Path | None = None) -> BatchReport`

Flow:
1. Validate config (non-empty science_id, input_path exists, batch_id non-empty)
2. Load registry, check science_id → if missing: all excerpts to `pending_no_tree`
3. Load tree → if fail: `TAX_TREE_LOAD_ERROR` (batch fatal)
4. Read JSONL line-by-line (UTF-8)
5. Per excerpt: validate required fields → place → validate → write → verify
6. Compute batch report, write to `batch_reports/{batch_id}.json`

When adapter is None or stub raises NotImplementedError: route to unplaced with reason "LLM not available".

**Tests (~8):** Missing required fields, missing expected fields (warning), non-existent science_id, stub adapter (all unplaced), mock adapter (correct routing), empty JSONL, batch report correctness.

## Multi-Model Review Strategy

**The user requires Codex and Gemini as second-pair-of-eyes reviewers.**

After completing each major step:
1. **Self-test:** Run `PYTHONPATH=. python -m pytest engines/taxonomy/tests/ -x -q --tb=short`
2. **Pyright:** Run `python -m pyright engines/taxonomy/src/<module>.py`
3. **Codex review:** Dispatch tree_loader + placer (most complex, most edge cases) to Codex for independent review
4. **Gemini/additional review:** Use for diagnostics + engine integration review

Key areas needing external review:
- v0 normalization (aqidah `__overview` handling is subtle)
- Routing matrix edge cases (tie + always-staged interactions)
- D-023 provenance preservation (writer merge logic)
- Arabic text byte-identical verification (encoding traps)

## Verification

After all modules built:
```bash
# Full test suite
PYTHONPATH=. python -m pytest engines/taxonomy/tests/ -x -v --tb=short

# Type checking
python -m pyright engines/taxonomy/src/

# Smoke test: load all 5 trees
python3 -c "
from engines.taxonomy.src.tree_loader import load_tree
from pathlib import Path
reg = Path('library/sciences/taxonomy_registry.yaml')
for sid in ['nahw', 'sarf', 'balagha', 'imlaa', 'aqidah']:
    t = load_tree(sid, reg)
    print(f'{sid}: {t.leaf_count} leaves, version={t.tree_version}')
"

# Lint
ruff check engines/taxonomy/
```

**Pass criteria:** All tests green, pyright clean, all 5 trees load with correct leaf counts, ruff clean.

## Critical Files to Modify/Create

| File | Action |
|------|--------|
| `engines/taxonomy/src/tree_loader.py` | CREATE |
| `engines/taxonomy/src/placer.py` | CREATE |
| `engines/taxonomy/src/validator.py` | CREATE |
| `engines/taxonomy/src/writer.py` | CREATE |
| `engines/taxonomy/src/diagnostics.py` | CREATE |
| `engines/taxonomy/src/engine.py` | CREATE |
| `engines/taxonomy/tests/conftest.py` | CREATE |
| `engines/taxonomy/tests/test_tree_loader.py` | CREATE |
| `engines/taxonomy/tests/test_routing.py` | CREATE |
| `engines/taxonomy/tests/test_validator.py` | CREATE |
| `engines/taxonomy/tests/test_writer.py` | CREATE |
| `engines/taxonomy/tests/test_diagnostics.py` | CREATE |
| `engines/taxonomy/tests/test_engine.py` | CREATE |

**Do NOT modify:** contracts_core.py, SPEC.md, CLAUDE.md, tree YAML files, cli_adapter.py

## Reusable Existing Code

- `engines/taxonomy/contracts_core.py` — All models (TreeNode, LoadedTree, RunConfig, PlacementAdditions, BatchReport, enums)
- `shared/validation/src/validation.py` — `validate_enrichment_passthrough()` for D-023 checks
- `library/sciences/taxonomy_registry.yaml` — Registry format (list of sciences with versions)
- `integration_tests/smoke_fix_20260329/ibn_aqil_v3/excerpts.jsonl` — Real excerpt format for test factories

## Out of Scope (Session 2)

- `build_stage1_prompt()`, `build_stage2_prompt()` — LLM prompt construction
- `LLMPlacementAdapter` — Real adapter using CLIInstructorAdapter
- Gold baseline LLM accuracy tests
- Actual tree placement via LLM
