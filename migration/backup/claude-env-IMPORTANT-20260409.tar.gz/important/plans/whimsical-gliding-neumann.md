# Autonomous Source Engine Improvement Session

## Context

Owner has granted full autonomy to improve the source engine codebase. Permissions include: decision-making authority (including SPEC changes), API key usage, forward work if bulletproof. Currently 562 tests, 73 Phase C books processed, 22 success / 51 gate_abort / 0 errors.

## Execution Order (sequential, each phase gates on the previous)

### Phase 1: SPEC Compliance Audit
Read every §4 behavioral rule in SPEC_CORE.md. For each rule, verify:
- Is there code implementing it?
- Is there a test exercising it?
- Does the code match the SPEC exactly?

Output: List of gaps, fixes applied, tests added.

### Phase 2: Test Coverage Hardening
Write tests for untested SPEC rules found in Phase 1. Use real Arabic fixtures. Target: every §4 rule has at least one test.

### Phase 3: Phase C Data Mining
Analyze all 73 results to extract:
- Gate_abort root causes (which validation check, which field)
- Consensus disagreement patterns (the 6 books)
- Extraction field coverage (unmapped Shamela card labels)
- Confidence score distributions
- Author identification accuracy patterns

Output: Structured analysis file.

### Phase 4: Code Quality Sweep
- Dead imports, unused functions
- Inconsistent error messages
- Type hint gaps
- Duplicated logic

### Phase 5: Scholar Registry Population (forward work — bulletproof)
Populate science_scope for the ~10 most prominent scholars in the 73-book set. These are unambiguous, well-documented scholars:
- النووي (d. 676 AH) — fiqh, hadith, ulum_al_hadith
- ابن تيمية (d. 728 AH) — aqidah, fiqh, usul_al_fiqh
- ابن القيم (d. 751 AH) — aqidah, fiqh
- ابن كثير (d. 774 AH) — tafsir, tarikh, hadith
- الطبري (d. 310 AH) — tafsir, tarikh
- السيوطي (d. 911 AH) — nahw, hadith, tafsir
- etc.

Only populate what is verifiable. Cross-reference against Usul.ai and known biographical sources.

Then targeted re-run of 5-10 gate_abort books to verify gate_abort rate drops.

### Phase 6: Documentation Sync
Update CLAUDE.md, NEXT.md to reflect all changes.

## Verification
- Run full test suite after each phase
- Commit after each phase with descriptive message
- Push at end

## Constraint
"Do not work ahead" = no new engine code, no normalization engine. Scholar registry population is current-content improvement (the registry exists, the validation check exists, the data is missing).
