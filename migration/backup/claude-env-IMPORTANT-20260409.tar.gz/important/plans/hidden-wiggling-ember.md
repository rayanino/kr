# Plan: Corpus Sweeps on Source + Normalization Engines

## Context

Both engines (source + normalization) are complete and stable — source has 503+ tests, normalization has 420 tests, both evaluated with zero CORE GAPs. But validation so far covers only 63 fixtures (normalization) and 204 books (source). The full Shamela collection has **7,475 items** containing **23,056 .htm files**. This sweep stress-tests both engines at scale to find edge cases invisible at small sample sizes.

**Mode:** Autonomous data collection. NO code fixes, NO SPEC changes, NO contract modifications. Report findings only. Both sweeps cost €0 (fully deterministic, no LLM calls).

---

## Pre-flight Checks (already verified)

- [x] `shamela-export-samples/` exists: 7,475 items, 23,056 .htm files
- [x] `discover_books()` imports and finds 7,475 books
- [x] Source engine imports (`detect_format`, `extract_metadata`) work
- [x] `results/` directory doesn't exist yet (scripts will create it)
- [x] `tests/fixtures/shamela_edge_cases/` doesn't exist yet (create if needed)

---

## Task A: Normalization Corpus Sweep (PRIMARY)

**Script:** `scripts/normalization_corpus_sweep.py`
**Output:** `results/normalization_sweep/corpus_sweep.jsonl` + `CORPUS_SWEEP_SUMMARY.md`

### Step A1: Small sample test (10 books)
```
python scripts/normalization_corpus_sweep.py --collection-dir shamela-export-samples --limit 10
```
- Verify: script runs without crash, produces JSONL + summary
- Check output file structure matches expectations
- Estimate per-book timing for full sweep

### Step A2: Full sweep with --resume
```
python scripts/normalization_corpus_sweep.py --collection-dir shamela-export-samples --resume
```
- Expected: 7,475 books, ~1-3 books/sec → ~40-120 minutes
- Run in background; monitor progress prints every 100 books
- **If hangs >5 min on one book:** Ctrl+C, add manual TIMEOUT entry per NEXT.md instructions, restart with --resume
- **If script crashes:** Fix the SWEEP SCRIPT only (allowed per Rule 5), not engine code

### Step A3: Read summary and write analysis
- Read `results/normalization_sweep/CORPUS_SWEEP_SUMMARY.md`
- Write `results/normalization_sweep/CC_ANALYSIS.md` covering:
  - Crash patterns (what HTML structures break the parser?)
  - Warning patterns at scale (dominant types, new types?)
  - Multi-layer auto-upgrade rate (reasonable?)
  - Passaging contract alignment (which checks fail?)
  - Anomalies (high page loss, zero diacritics, low Arabic ratio)
  - Edge cases (3-5 interesting books saved as fixtures)

### Step A4: Save edge case fixtures
- Create `tests/fixtures/shamela_edge_cases/`
- Copy 3-5 crash-causing or anomalous books from `shamela-export-samples/`
- Document each: what makes it interesting, what it tests

### Step A5: Check file sizes and commit
- Verify `corpus_sweep.jsonl` is < 100MB (estimated ~5-10MB for 7,475 entries)
- If too large: commit only summary .md files
```
git add results/normalization_sweep/ tests/fixtures/shamela_edge_cases/
git commit -m "sweep: Normalization corpus sweep on 7,475 books"
```

---

## Task B: Source Engine Deterministic Sweep

**Script:** `scripts/phases/run_phase_a.py`
**Output:** `results/source_sweep/` (per-book JSON + PHASE_A_SUMMARY.json)

### Step B1: Small sample test (10 books)
```
python scripts/phases/run_phase_a.py shamela-export-samples --output-dir results/source_sweep --limit 10
```
- Verify: produces per-book JSON + summary
- Note: default output dir is `tests/results/source_engine/phase_a` — NEXT.md overrides to `results/source_sweep`

### Step B2: Full sweep with --resume
```
python scripts/phases/run_phase_a.py shamela-export-samples --output-dir results/source_sweep --resume
```
- Expected: 7,475 items, faster than normalization (no HTML parsing pipeline)
- Run in background

### Step B3: Analyze results
Read `results/source_sweep/PHASE_A_SUMMARY.json` and focus on:
- **Format detection:** shamela_html vs other formats
- **Extraction success rate** (excluding UNSUPPORTED_FORMAT — see below)
- **Crash patterns:** what HTML structures cause failures?
- **Duplicate hashes:** identical content across different books

### Step B4: Write analysis — **CRITICAL: UNSUPPORTED_FORMAT separation**
Write `results/source_sweep/CC_ANALYSIS.md`. **Per NEXT.md step 6:**
- The source sweep processes ALL items, including non-book items
- `SRC_UNSUPPORTED_FORMAT` errors are EXPECTED for non-book items
- Report TWO error counts:
  1. Total errors (including UNSUPPORTED_FORMAT)
  2. **Genuine errors** (excluding UNSUPPORTED_FORMAT)
- Analyze genuine errors separately from expected format rejections

### Step B5: Commit — **CRITICAL: No per-book JSON files**
The sweep produces ~7,475 individual JSON files. These MUST NOT be committed.
```
git add results/source_sweep/PHASE_A_SUMMARY.json results/source_sweep/CC_ANALYSIS.md
git commit -m "sweep: Source engine deterministic sweep on 7,475 books (summaries only, per-book JSON local)"
```
- Add `results/source_sweep/*.json` exclusion pattern if needed (but PHASE_A_SUMMARY.json must be committed — use explicit git add, not wildcards)
- Per-book JSON stays on disk for local analysis only

---

## Task C: Cross-Engine Findings Report (if time remains)

After Tasks A and B complete:
- Write `results/CROSS_ENGINE_FINDINGS.md` analyzing:
  - Books succeeding in source but crashing in normalization (or vice versa)
  - Common failure patterns across both engines
  - Corpus statistics for passaging design (size distribution, footnote density, multi-layer frequency)
  - Top 10 most unusual books and why
```
git add results/CROSS_ENGINE_FINDINGS.md
git commit -m "sweep: Cross-engine findings report"
```

---

## Hard Constraints (from NEXT.md Rules)

| Rule | What | Enforcement |
|------|------|-------------|
| **No engine code changes** | `engines/source/src/`, `engines/normalization/src/` are read-only | Verify with `git diff engines/` before each commit |
| **No SPEC/contract changes** | `SPEC.md`, `SPEC_CORE.md`, `contracts.py` untouched | Same git diff check |
| **Script fixes allowed** | `scripts/` can be fixed if sweep crashes at scale | Document what changed and why |
| **No per-book JSON in git** | Task B produces 7K+ files — local only | Explicit `git add` of summary files only |
| **UNSUPPORTED_FORMAT separation** | Expected errors from non-book items | Two-count reporting in CC_ANALYSIS.md |
| **File size < 100MB** | Check before committing JSONL | `ls -lh` before `git add` |
| **Commit prefix** | All commits use `sweep:` prefix | Every commit message |
| **No LLM calls** | Both sweeps are deterministic (€0) | Scripts don't call any API |

---

## Verification Checklist (per NEXT.md)

After each task:
- [ ] Script ran to completion (or saved partial results with --resume)
- [ ] Summary report is written and readable
- [ ] CC_ANALYSIS.md documents findings, not fixes
- [ ] No engine source code was modified (`git diff engines/`)
- [ ] Results committed with `sweep:` prefix
- [ ] File sizes checked before commit (< 100MB per file)

---

## Execution Order

1. **Task A** (primary, do first) — normalization sweep
2. **Task B** — source sweep (can start while waiting for Task A if run in background)
3. **Task C** — cross-engine report (only if A+B complete)

**Parallelization note:** Tasks A and B are independent. Task A's full sweep (~40-120 min) could run in background while Task B's small sample test runs. However, given the autonomous nature and potential need to handle crashes, sequential execution is safer.
