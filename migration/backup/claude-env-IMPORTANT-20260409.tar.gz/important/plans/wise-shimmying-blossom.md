# Audit: Step 4 Pre-Run Preparation (commit c590c79)

**Context:** Deep critical review of 4 deliverables committed in c590c79. Goal: ensure the owner can run 204 books through the pipeline without data loss or incorrect tracking.

---

## CRITICAL: Manifest Overwrite in Two-Run Approach

**The NEXT.md instructs two separate runs to the same output directory. This causes data loss.**

`run_phase_c.py` writes `PHASE_C_MANIFEST.json` and `PHASE_C_SUMMARY.json` to the output directory at end of each run (lines 1023-1026). The manifest is built from `all_results`, which only contains books processed in the *current* run:

- Run 1 (73 Phase C reruns) -> manifest with 73 books
- Run 2 (131 Phase D books) -> **overwrites** manifest with 131 books only

The final manifest would be missing 73 books. Per-book result directories survive (they're separate), but the index is wrong.

Additionally, `run_phase_c.py` hardcodes `result_path: "phase_c/{name}/result.json"` (line 846) regardless of actual output directory. So the manifest would also have wrong paths.

### Fix: Single Run with Merged Collection

Replace the two-run approach with a single run using a merged collection directory.

**NEXT.md before fix:**
```
python scripts/run_phase_c.py phase_c_collection --books scripts/phase_c_books.txt --output-dir .../phase_d/ --budget-eur 20
python scripts/run_phase_c.py phase_d_collection --books scripts/phase_d_books.txt --output-dir .../phase_d/ --budget-eur 35
```

**NEXT.md after fix:**
```
# Step 1: Merge the two collection directories (one-time, ~30 seconds)
xcopy /E /I phase_c_collection combined_collection
xcopy /E /I phase_d_collection combined_collection

# Step 2: Run all 204 books
python scripts/run_phase_c.py combined_collection --books scripts/step4_all_books.txt --output-dir tests/results/source_engine/phase_d/ --budget-eur 50
```

This gives:
- One manifest covering all 204 books
- Correct cost tracking
- The combined book list (`step4_all_books.txt`) is actually used
- Resume works cleanly: `--resume` on the same command

### Verify the merge works

Add check to `verify_step4_books.py`: after merging, all 204 books must be directories in `combined_collection/`. This can't be verified pre-merge, but the script already confirms both source collections are complete.

---

## MEDIUM: Verification Script Display Bugs

`check_category_distribution()` hardcodes "131/131" and "/73" in output messages instead of using `len(phase_d)` and `len(phase_c)`. Logic is correct (pass/fail works), but output is misleading if counts ever change.

### Fix

```python
# Line 70: Change from
messages.append(f"  Phase D: 131/131 in distribution")
# To
messages.append(f"  Phase D: {len(phase_d)}/{len(phase_d)} in distribution")

# Line 73-74: Change from
f"  Phase C: {phase_c_found}/73 in distribution "
# To
f"  Phase C: {phase_c_found}/{len(phase_c)} in distribution "
```

---

## LOW: Missing PYTHONIOENCODING in NEXT.md

Windows consoles default to cp1252 encoding, which can't display Arabic text. The run command should include:

```
set PYTHONIOENCODING=utf-8
```

This is already documented in project memory ("Arabic filenames work correctly with PYTHONIOENCODING=utf-8") but not in NEXT.md.

---

## LOW: result_path Bug in run_phase_c.py (pre-existing, not our bug)

Line 846: `"result_path": f"phase_c/{name}/result.json"` hardcodes `phase_c/` regardless of actual output directory. When writing to `phase_d/`, the manifest says `phase_c/` but results live in `phase_d/`.

**Not fixing** (task says reuse script unchanged). Post-processing (Prompt 3) should use `output_dir / book_name / result.json` instead of the manifest's `result_path`.

---

## Files to Modify

| File | Change |
|------|--------|
| `NEXT.md` | Replace two-run with single merged-collection run + add PYTHONIOENCODING |
| `scripts/verify_step4_books.py` | Fix hardcoded counts in display messages (lines 70, 73) |

## Files Verified Clean (no changes needed)

| File | Status |
|------|--------|
| `scripts/step4_all_books.txt` | 204 books, exact match with sources, correct format |
| `tests/results/source_engine/phase_d/RERUN_BOOKS.json` | 73 books, exact match with phase_c_books.txt, valid JSON |

## Verification

```bash
PYTHONIOENCODING=utf-8 python scripts/verify_step4_books.py && python -m pytest engines/source/tests/ -x -q
```
