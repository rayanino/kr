# Adversarial Review of the IsIdeas Hardening Plan

## 1. Ordering Risks

### FLAW: Step 1 commits the dashboard modifications as part of a "clean quarantine" commit

The plan says Step 1 should "stage and commit all currently unstaged changes." But `git status` shows those unstaged changes include BOTH the `apps/` deletion AND modifications to dashboard files:

- `src/app/globals.css` (modified)
- `src/app/page.tsx` (modified)
- `src/components/frontier-surface.tsx` (modified)
- `src/lib/dashboard.ts` (modified)
- `src/lib/state.ts` (modified)
- `src/lib/tick.ts` (modified)
- `src/lib/types.ts` (modified)
- `tests/redteam.test.ts` (modified)

Committing these in Step 1 means git permanently records the dashboard code changes as part of a "quarantine and governance" commit. Then in Step 3, you delete the dashboard. This creates two problems:

**Problem A**: The commit message for Step 1 will say something about "commit quarantine of apps/ deletion and governance updates" but it silently includes uncommitted dashboard feature work. That is exactly the kind of silent drift the governance docs warn against.

**Problem B**: If anyone later tries to reconstruct what the dashboard looked like at extraction time, the "last known good" version is contaminated with in-progress edits that were never tested or intentionally released. The quarantine copy in Step 2 will include the modifications, but the provenance is muddied.

**Recommendation**: Split Step 1 into two sub-steps. First, commit only the `apps/` deletions, governance docs, and catalog updates (the actual quarantine from the prior session). Explicitly exclude the `src/`, `tests/`, and `runtime/seed/state.json` changes from that commit since those are dashboard modifications that belong to the dashboard's history, not the quarantine's. Then either commit the dashboard changes separately before extraction, or extract first (Step 2) and then handle deletion.

Alternatively, reorder: do Step 2 (extract to disk) first, then Step 1 (commit everything including the deletions). This way the quarantine copy captures the current disk state exactly, and the commit captures the final state. But this loses the ability to have a clean "quarantine only" commit.

The safest order is: **Extract to quarantine -> Commit the apps/ quarantine separately -> Delete dashboard code -> Commit the extraction and safeguards.** Three commits is more honest than two.

---

## 2. Git History and Branch Strategy

### FLAW: This branch is already merged to main and pushed

`git log` shows commit `609a1b2 Merge pull request #13 from rayanino/codex/portfolio-truth-idea-002-p1` already exists in history, and the branch is "ahead of origin by 1 commit" (the `f006bc1` commit). The branch was previously merged to main via PR #13, then had commit `f006bc1` added on top.

This means `main` at commit `f24c9a8` is the original repo with just `about_the_owner.txt` and `on_the_fly_ideas.txt`. All the significant work (164 files, 43,000+ lines) exists only on this branch. But `main` was already updated via earlier merge PRs (the log shows PRs #1 through #13 were merged). Wait -- looking more carefully, `main` at `f24c9a8` ("my files") has only 2 files. All the PR merges happen on this branch's history. That is very strange.

Actually, re-reading: the `git log main -1` returns `f24c9a8 my files`, but the branch history includes many "Merge pull request" commits. This means those merges happened on the branch itself, and main was never actually updated with the merged content. **Main is effectively an empty skeleton.** Every PR merge brought content into this branch, not into main.

**This matters for the hardening plan** because the plan says "merge to main." But the entire repository's content -- all 100+ governance documents, all ideas, all decisions -- exists only on this branch. The hardening plan never explicitly addresses the fact that `main` is essentially empty.

**Recommendation**: The plan should explicitly state that after hardening, this branch's full history will be merged (or force-pushed) to main. A standard PR merge would work, but the PR description must acknowledge that this is not an incremental feature branch -- it is the entire repository being delivered to main for the first time in its hardened form. Consider whether squashing is appropriate given the archaeological value of the commit history.

### CONCERN: Should this be a new branch?

Adding more commits to `codex/portfolio-truth-idea-002-p1` is defensible since this branch IS the repo. But creating a new branch (e.g., `codex/factory-hardening`) from HEAD would make the intent clearer in git history and in the eventual PR. It separates "build the factory and dashboard" (existing history) from "extract the dashboard and harden" (new work). This is optional but cleaner.

---

## 3. Missing File Checks

### CRITICAL MISS: The file literally named "```.txt" in the repo root

There is an untracked file at the repo root named `` ```.txt `` (three backticks followed by .txt). It contains Cisco switch VLAN configuration commands for a networking lab. It has nothing to do with IsIdeas. It is currently listed as an untracked file in `git status`. The plan does not mention it at all.

This file must be deleted. It is a personal artifact that accidentally ended up in the working directory.

### MISS: `.env.local` exists on disk with actual content

`C:/Users/Rayane/Desktop/IsIdeas/.env.local` exists on disk (386 bytes, created Mar 30). It is gitignored but present. The plan mentions deleting `.env.example` but does not mention `.env.local`. Since `.env.local` likely contains actual API keys (given the `.env.example` template references `OPENAI_API_KEY`, `OPENROUTER_API_KEY`, `ANTHROPIC_API_KEY`), it MUST be deleted from disk during Step 3. This is not a git concern (it is gitignored) but it is a security and cleanliness concern for a repo that claims to have no application code.

### MISS: `runtime/local/` directory contains runtime state on disk

`runtime/local/` exists on disk with:
- `baselines/`
- `critique-runs/`
- `proving-runs/`
- `MORNING_REPORT.md`
- `state.json` (13,464 bytes)

This is gitignored, so it is not a git problem. But the plan says to delete `runtime/` entirely. It should be explicit that `runtime/local/` must also be wiped from disk, and its contents should be copied to the quarantine location first (they are part of the dashboard's operational history).

### MISS: `.next/` build artifacts on disk

The plan mentions `.next/` in Step 3's delete list, which is correct. But `.next/` exists on disk and may contain compiled code, caches, and traces. Verify it is cleaned.

### MISS: `node_modules/` on disk

Same as above -- mentioned in the plan, just confirming it exists and must go.

### MISS: `ADVERSARIAL_REVIEW_2026-03-30.md` is tracked and references dashboard code

This 260-line file at the repo root is tracked by git and contains extensive references to `src/lib/postgres-repository.ts`, `src/lib/tick.ts`, runtime architecture, and dashboard code. After extraction, it will reference files that no longer exist.

The plan does not mention this file at all. It needs either:
- A note added at the top: "This review was conducted against commit f006bc1. The application code referenced here has been extracted per ADR-011."
- Or movement to a historical/archive location.

Deleting it would be wrong (it has genuine archaeological value), but leaving it unmodified creates a document that references nonexistent code paths.

### MISS: `ideas/memorization-os/SPEC.md` line 200 references the dashboard

Line 200 reads: "runtime primitives already present in the control tower repo." After extraction, those runtime primitives will NOT be present. This spec document needs updating.

### MISS: Decisions that reference extracted infrastructure

- `decisions/ADR-006-POSTGRES-RUNTIME-UPGRADE.md` -- entirely about the dashboard's Postgres mode. After extraction, this decision applies to the quarantined dashboard, not to IsIdeas. Should it be marked as "superseded by ADR-011" or "applies to extracted control tower only"?

### MISS: `shared/GLOSSARY.md` and `shared/SHARED_PRIMITIVES.md`

These files reference cross-portfolio primitives like `review_event_id`, `memorization_object_id`, `segment_id`. They are legitimate factory artifacts (they define vocabularies for future builds). However, the plan should confirm they stay and are not confused with "application code."

### PARTIAL MISS: `submissions/README.md` references the live app

Line 3: "the live app writes submissions into `runtime/local/state.json`." After extraction, there is no live app. This README needs rewriting.

### PARTIAL MISS: `research/README.md` references the dashboard

Line 5: "The live dashboard currently surfaces research status from the runtime seed snapshot." After extraction, this is false.

---

## 4. Quarantine Location

### RISK: The quarantine directory is a bare filesystem path with no backup

`C:\Users\Rayane\Desktop\IsIdeas_quarantine\` exists and already contains `fixed-text-preservation_2026-03-31/`. The control tower extraction would add `control-tower_2026-03-31/` alongside it.

Problems:

**No version control**: The quarantine directory is not a git repo. Its contents can be silently modified, partially deleted, or corrupted with no detection. For artifacts that represent the "last known state" of extracted code, this is fragile.

**Desktop location**: Storing on the Desktop is convenient but risky. Desktop cleanup, OS reinstalls, or accidental deletion can destroy the quarantine. There is no off-machine backup mentioned.

**Date collision**: Both quarantine entries use `2026-03-31`. If a second extraction of the same type happens on the same date, the naming convention has no disambiguation mechanism.

**Recommendation**: After quarantine, initialize a git repo inside `IsIdeas_quarantine/` (a single `git init && git add -A && git commit` is sufficient). This creates an immutable snapshot with checksums. Optionally push to a private GitHub repo for off-machine safety. The plan should mention this as a post-extraction verification step.

---

## 5. Document Consistency -- Files the Plan Misses

The plan lists documents to update (`ARCHITECTURE.md`, `AUTONOMOUS_LOOPS.md`, `REPO_HEALTH.md`, `IMMEDIATE_NEXT_ACTIONS.md`) but misses these:

### Files that MUST be updated (contain false claims after extraction):

| File | Problem |
|---|---|
| `control_tower/README.md` | Line 5: "the runtime, dashboard, and research loops stay aligned" -- no runtime or dashboard after extraction. Line 13: "runtime and integrity guidance" listed as belonging here. |
| `control_tower/START_HERE.md` | Line 8: "The dashboard and bootstrap runtime are live." -- false after extraction. |
| `control_tower/BOOTSTRAP_PROMPT.md` | Line 18: tells new sessions to read `runtime/README.md` -- that file will not exist. |
| `control_tower/SUPERVISED_PROVING_RUN.md` | Entire file references `npm run runtime:baseline` and `npm run runtime:pilot`. Completely inapplicable after extraction. |
| `control_tower/EMPLOYEE_PROTOCOLS.md` | Line 11: "implement factory/runtime changes" -- no runtime to change. |
| `control_tower/OPERATING_LOOP.md` | Line 15: "runtime loop state" listed as auto-write target. |
| `control_tower/INTEGRITY_POLICY.md` | Line 18: "mutation of other repos from unattended IsIdeas runtime work in v1" -- no runtime. |
| `workflows/CONSISTENCY_AND_SOURCE_OF_TRUTH.md` | Lines 13-16: `runtime/seed/state.json`, `runtime/local/`, and "local Postgres runtime documents" listed as canonical surfaces. Line 32: references `runtime/seed/state.json` in the reconciliation rule. |
| `codex/HUMAN_OPERATING_PLAYBOOK.md` | Line 7: "submit ideas through the dashboard." Line 15: "reviewing every routine runtime action." |
| `codex/START_HERE.md` | Line 9: tells Codex to read `runtime/README.md`. Line 14: "runtime / dashboard" listed as a working lane. |
| `codex/README.md` | Line 10: "build/runtime notes that help the local host." |
| `submissions/README.md` | Line 3: "the live app writes submissions into `runtime/local/state.json`." |
| `research/README.md` | Line 5: "The live dashboard currently surfaces research status from the runtime seed snapshot." |
| `ideas/memorization-os/SPEC.md` | Line 200: "runtime primitives already present in the control tower repo." |
| `ADVERSARIAL_REVIEW_2026-03-30.md` | 260 lines referencing `src/lib/`, `runtime/seed/state.json`, Postgres runtime, etc. |
| `decisions/ADR-006-POSTGRES-RUNTIME-UPGRADE.md` | Entire ADR is about the extracted dashboard's Postgres mode. |
| `workflows/CHATGPT_CODEX_OPERATING_SYSTEM.md` | Line 14: "the repo, runtime, and research surface." |

That is 17 files, not counting the ones the plan already lists. The plan only explicitly names 9 files to edit. It misses at least 8 files that will contain actively false claims.

### What about `runtime/seed/state.json`?

The plan says (Step 7): "runtime/seed/state.json -- remove (this was runtime state for the dashboard)."

This is the most consequential single decision in the plan and the plan treats it casually. `state.json` is 529 lines containing:
- The profile and thesis statement
- All 3 evidence links
- The sole critique artifact reference
- All 10 decision records (D-0001 through D-0010)
- All 5 bottleneck definitions
- All 4 idea records with their full state
- The submission record
- All 6 tool evaluations
- All 2 research artifacts
- All 2 integrity flags
- All 5 loop definitions
- The bootstrap run record

Several governance documents declare `runtime/seed/state.json` as **governed repo truth** (not operational state):
- `workflows/CONSISTENCY_AND_SOURCE_OF_TRUTH.md` line 13
- `runtime/README.md` lines 20-21
- `README.md` line 84

Deleting it means the repo loses the machine-readable representation of its entire portfolio state. The markdown files in `catalog/`, `ideas/`, and `decisions/` contain much of the same information in prose form, but `state.json` is the only structured, parseable representation.

**This is a genuine dilemma, not a clear-cut deletion.** The plan should either:
1. Keep `state.json` in a new location (e.g., `catalog/state.json`) as the machine-readable portfolio snapshot, stripped of runtime-specific fields (loops, runs, tools like pg-boss, runtimeMode).
2. Delete it but explicitly acknowledge what is lost and ensure every piece of information in it is recoverable from the markdown files.
3. Archive it to the quarantine with a note that a future factory tool can reconstruct it from markdown.

The plan currently picks option 2 implicitly without acknowledging the cost.

---

## 6. CLAUDE.md Alignment

### FLAW: CLAUDE.md will be inaccurate after extraction

The root `CLAUDE.md` currently says:

> **Mission**: Build the portfolio, **runtime**, research base, and spec discipline that will later produce unusually strong Islamic-study software systems.

And priority item 5:

> 5. tooling and **runtime** leverage

After extracting the dashboard and declaring IsIdeas a pure document factory, there is no "runtime" to build or leverage within this repo. The word "runtime" appears twice in CLAUDE.md and both uses become false claims.

**Recommendation**: Update CLAUDE.md. The mission should reference "portfolio, research base, and spec discipline." Priority 5 should become something like "tooling leverage and handoff quality." CLAUDE.md is the first file any AI agent reads -- if it says "runtime," agents will try to build or maintain a runtime.

---

## 7. What You Might Be Wrong About

### ASSUMPTION: "Pure markdown factory" is the right end state

The plan aims for zero code files in the repo. But consider:

- `templates/` contains 9 markdown templates. These are fine.
- `shared/SHARED_PRIMITIVES.md` defines primitives like `topic_id` and `excerpt_id`. Right now these are prose. Eventually, a factory this rigorous might want a machine-parseable schema (a `.json` or `.yaml` file) defining these primitives for handoff packets. The FACTORY_SCOPE_BOUNDARY rule banning all `.json` files except "explicitly allowed locations" would need an exception.
- `catalog/QUARANTINED_BUILDS.md` is a table. At scale, a structured format would be more useful.
- `runtime/seed/state.json` is already the machine-readable truth. Deleting it and banning all code files means the factory loses the ability to have machine-parseable state.

The ban on `.ts`, `.tsx`, `.js`, `.jsx`, `.py`, `.sql` is reasonable. But banning `.json` would be overreach. The plan's FACTORY_SCOPE_BOUNDARY definition should explicitly allow `.json` and `.yaml` as structured data formats distinct from application code.

### ASSUMPTION: The .gitignore cleanup in Step 9 should happen after the extraction commit

Step 9 updates `.gitignore` after Step 8's commit. That means Step 8's commit still has the old `.gitignore` with `node_modules/`, `.next/`, etc. If someone checks out that commit and runs `git status`, those entries are still ignored. This is harmless but messy.

Better: fold the `.gitignore` update into Step 8's commit. One clean commit that removes the code AND updates the ignore rules. Otherwise the repo has a commit where the `.gitignore` references patterns that cannot possibly match anything.

### ASSUMPTION: The untracked files belong in Step 1

`git status` shows 4 untracked files:
- `` ```.txt `` -- junk, must be deleted, not committed
- `catalog/HANDOFF_QUEUE.md` -- genuine governance document
- `catalog/QUARANTINED_BUILDS.md` -- genuine governance document
- `decisions/ADR-010-ISIDEAS-IS-FACTORY-ONLY.md` -- genuine decision record
- `ideas/memorization-os/RESEARCH.md` -- genuine factory artifact

The plan says Step 1 commits "all currently unstaged changes." These untracked files should be added, except `` ```.txt `` which should be deleted before any commit. The plan does not distinguish between "add these" and "do not add this junk file."

### ASSUMPTION: Two commits is enough

The plan creates two commits:
1. Quarantine (apps/ deletion + governance updates)
2. Extraction + safeguards

A more honest history would be three:
1. Quarantine of apps/ (the correction from the prior session)
2. Dashboard extraction (pure deletion of src/, scripts/, runtime/, tests/, configs)
3. Safeguards and document hardening

This separates "correct the past mistake" from "make a new strategic decision" from "update documentation." Each commit has a single, clear purpose.

### RISK: No mention of verifying the quarantine copy works

The plan copies files to `IsIdeas_quarantine/control-tower_2026-03-31/` but never says to verify the copy. At minimum: after copying, verify the quarantine directory contains `package.json`, can run `npm install`, and passes `npm test`. If the quarantine copy is broken, the extraction is a data destruction event, not a data preservation event.

---

## Summary of Required Changes to the Plan

### Must fix (will cause incorrect repo state or data loss):

1. **Do not commit dashboard source modifications as part of the quarantine commit.** Split Step 1 to separate apps/ deletion from src/ changes.
2. **Delete `` ```.txt `` from the repo root** before any commit. The plan does not mention it.
3. **Delete `.env.local` from disk** in Step 3. The plan omits this.
4. **Update or annotate `ADVERSARIAL_REVIEW_2026-03-30.md`** -- tracked file with 260 lines referencing extracted code.
5. **Address `runtime/seed/state.json` deliberately** -- this is governed repo truth, not just "dashboard state." Decide explicitly whether to preserve a stripped version.
6. **Update 8 additional files** the plan misses: `control_tower/README.md`, `control_tower/START_HERE.md`, `control_tower/BOOTSTRAP_PROMPT.md`, `control_tower/SUPERVISED_PROVING_RUN.md`, `control_tower/INTEGRITY_POLICY.md`, `submissions/README.md`, `research/README.md`, `codex/HUMAN_OPERATING_PLAYBOOK.md`.
7. **Update `CLAUDE.md`** to remove "runtime" from mission and priority 5.
8. **Update `workflows/CONSISTENCY_AND_SOURCE_OF_TRUTH.md`** to remove runtime references from canonical surfaces.

### Should fix (reduces risk or improves quality):

9. Fold `.gitignore` cleanup into Step 8, not a separate Step 9.
10. Add a verification step: confirm quarantine copy is functional (`npm install && npm test` in quarantine directory).
11. Initialize a git repo inside `IsIdeas_quarantine/` for immutable snapshots.
12. Ensure `FACTORY_SCOPE_BOUNDARY.md` allows `.json` files explicitly (structured data is not application code).
13. Annotate `decisions/ADR-006-POSTGRES-RUNTIME-UPGRADE.md` as superseded or applying to the extracted dashboard.
14. Mark `ideas/memorization-os/SPEC.md` line 200 for update.
15. Update `codex/START_HERE.md`, `codex/README.md`, and `workflows/CHATGPT_CODEX_OPERATING_SYSTEM.md`.
16. Consider three commits instead of two for cleaner separation of concerns.

### Worth noting (judgment calls):

17. The branch naming is acceptable but a new branch would give cleaner PR semantics.
18. The quarantine naming convention needs a disambiguation mechanism for same-date entries.
19. The "pure markdown" goal should be "pure documents" -- allowing `.json`/`.yaml` for structured data.
20. The plan should acknowledge explicitly that `main` is essentially empty and the merge to main is a full-repo delivery, not an incremental change.
