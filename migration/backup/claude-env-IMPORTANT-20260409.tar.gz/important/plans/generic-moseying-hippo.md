# Plan: Architecture C Empirical Validation — Execute 4 Deliverables

## Context

Source and Normalization engines are COMPLETE (1,036 tests, 0 failures). Before committing to Passaging engine design, the architect proposed **Architecture C** — merging atomization + excerpting into a single engine. This experiment empirically validates Architecture C by running LLM teaching-unit extraction on real normalized data and producing an evaluation workbook for the architect.

**Three binary questions this decides:**
- Q1: Can an LLM identify teaching units? (F1 >= 0.70 → viable)
- Q2: Two-phase vs single-phase LLM? (>10pp advantage → two-phase)
- Q3: Does cross-boundary context help? (>=1 missed split detected → soft D-011)

**Our role:** Produce the test infrastructure + run the experiment. We do NOT evaluate results — the architect does that in a separate chat.

---

## Prerequisites (verified)

- All 5 fixtures exist: `tests/fixtures/shamela_real/{03_fiqh,07_balagha,06_usul,02_nahw_muhaqiq,10_no_author}/book.htm`
- Dependencies installed: instructor 1.14.5, openai 2.26.0, pydantic 2.12.5
- `experiments/architecture_test/` directory exists with design docs
- Normalization contracts verified: `DivisionNode.end_unit_index` is INCLUSIVE, `BoundaryContinuityType` has 6 values, `ContentFlags` has 7 boolean fields

---

## Deliverable 1: Normalized Packages

**File to create:** `experiments/architecture_test/produce_packages.py`

**What it does:**
1. Import `normalize_source` from `engines.normalization.src.dispatcher`
2. Import `_make_source_metadata` from `engines.normalization.tests.conftest`
3. For each of 5 fixtures (03_fiqh, 07_balagha, 06_usul, 02_nahw_muhaqiq [multi_layer=True], 10_no_author):
   - Call `normalize_source(htm_path, meta)` → `NormalizedPackage`
   - Write `manifest.json` via `pkg.manifest.model_dump_json(indent=2)`
   - Write `content.jsonl` — one `cu.model_dump_json()` per line
4. Print verification: per-fixture content unit count and leaf division count

**Output:** `experiments/architecture_test/packages/{fixture_name}/manifest.json` + `content.jsonl` (5 packages)

**Key detail:** Only `02_nahw_muhaqiq` has `is_multi_layer=True`. All others `False`.

**Verification:** Each directory has both files. Print table with CU count + leaf div count per fixture.

---

## Deliverable 2: Division Extraction (CRITICAL)

**File to create:** `experiments/architecture_test/extract_divisions.py`

**Algorithm (11 steps from NEXT_CC.md):**

### Step 1-2: Load packages + walk division tree
- Read `manifest.json` → parse division_tree as list of DivisionNode dicts
- Recursive walk to find leaf nodes (empty `children` array)

### Step 3: Assemble cross-page text per leaf division
- Content units at indices `[start_unit_index, end_unit_index]` (INCLUSIVE)
- Join `primary_text` using `boundary_continuity.type`:
  - `mid_sentence` → empty string (no separator)
  - `mid_paragraph`, `mid_argument`, `unknown`, None → `\n`
  - `section_break`, `division_break` → `\n\n`

### Step 4: Arabic word count
```python
len([w for w in text.split() if any('\u0600' <= c <= '\u06FF' for c in w)])
```

### Step 5: Filter to 300-2000 Arabic words

### Step 6: STRICT alignment check (L-003 filter)
- Strip ZWNJ, ZWJ, diacritics (`[\u064B-\u0652\u0670\u0640]`), tatweel, collapse whitespace
- `heading_clean[:15] in text_clean[:100]` — reject if False
- **This filters out 40-60% of divisions** — known L-003 artifact

### Step 7: Exclude non-scholarly (bibliography/index)
- Reject headings containing: `مصادر`, `مراجع`, `فهرس`, `ثبت المصادر`, `المراجع`

### Step 8: Select 2 per fixture
- Sort candidates by distance from 700 words (ascending)
- Skip division at tree index 0 (introductions)
- **03_fiqh exception:** prefer `mid_argument` BC for D-011 test
- **02_nahw_muhaqiq exception:** prefer multi-layer division (`len(cu.text_layers) > 1`)
- If <2 aligned candidates, take what's available + log warning

### Step 9: Extract context_before/context_after
- `context_before`: assemble units at `max(0, start-3)` through `start-1`
- `context_after`: assemble units at `end+1` through `min(last, end+3)`
- Same boundary_continuity join rules

### Step 10: Write output per division
- JSON: `experiments/architecture_test/divisions/{fixture}/div_{start_unit_index}.json`
  - Fields: fixture_name, div_start_unit, div_end_unit, heading_text, heading_path, assembled_text, arabic_word_count, text_layers (rebased), content_flags_aggregated (OR across units), boundary_continuity_last_unit, context_before, context_after, selection_reason
- **Text layers rebasing:** for each unit after the first, add cumulative character offset (sum of preceding `primary_text` lengths + join separator lengths) to `start`/`end`
- **ContentFlags aggregation:** OR across all constituent units' flags. Note actual field names are `has_quran_citation`, `has_hadith_citation`, `has_verse`, `has_table`, etc.

### Step 11: Write readable .md per division
- `experiments/architecture_test/divisions/{fixture}/div_{start_unit_index}_text.md`
- Complete assembled_text (NO truncation), heading, word count, unit range, BC info, context before/after

**Verification:**
- Print summary table: fixture, div_start_unit, heading (50 chars), word count, aligned=True, selection_reason
- Confirm 10 total divisions (2 per fixture)
- Print first 60 stripped chars of text alongside heading — visual alignment check

---

## Deliverable 3: LLM Test Runner

**File to create:** `experiments/architecture_test/run_tests.py`

### API Setup
- OpenRouter via OpenAI SDK: `base_url="https://openrouter.ai/api/v1"`, key from `OPENROUTER_API_KEY` env var
- Instructor wrapping: `instructor.from_openai(client)`
- Model: `anthropic/claude-opus-4.6`, temperature=0, max_tokens=8192

### Pydantic Schemas (defined in NEXT_CC.md)
- `TeachingUnit` — unit_index, start_word, end_word, text_snippet, description_arabic, primary_function, secondary_functions, self_contained, self_containment_notes
- `ExtractionResult` — teaching_units list, total_units, notes
- `ClassifiedSegment` — segment_index, start_word, end_word, text_snippet, scholarly_function, confidence
- `ClassificationResult` — segments list, total_segments
- `FUNCTION_ENUM` — 16 Literal values

### Three Approaches

**A — Single-call joint extraction:** One call per division. System prompt asks LLM to identify teaching units + classify + evaluate self-containment. Response: `ExtractionResult`.

**B — Two-call classify-then-group:** Call 1 classifies segments (`ClassificationResult`). Call 2 groups segments into teaching units using Call 1 results + original text (`ExtractionResult`).

**C — With cross-boundary context:** Same as B, but Call 2 adds `context_before`/`context_after` with markers. Run only on 03_fiqh divisions + any division with `boundary_continuity_last_unit.type == "mid_argument"`.

### Execution Loop
```
for each division JSON:
    run approach A → save results/{fixture}/div_{start}_approach_a.json
    run approach B → save results/{fixture}/div_{start}_approach_b.json
    if should_run_c(division):
        run approach C → save results/{fixture}/div_{start}_approach_c.json
```

### Error Handling
- 2 retries on Instructor validation failure
- On failure: save `{path}_error.json` with error + raw_response
- Continue to next division

### Logging
- Per API call: fixture, div, approach, model, input_tokens, output_tokens, latency_ms

### Output
- Result JSONs in `experiments/architecture_test/results/{fixture}/`
- `experiments/architecture_test/results/RUN_SUMMARY.md` with per-division stats + totals

---

## Deliverable 4: Evaluation Workbook

**File to create:** `experiments/architecture_test/EVALUATION_WORKBOOK.md`

**Generated after D3 completes** (can be part of run_tests.py or a small separate `generate_workbook.py` script).

**Per division section:**
- Heading, fixture, word count, unit range
- **Full Arabic text** (no truncation)
- Approach A results table: #, Words, Function, Self-contained, Snippet + description_arabic per unit
- Approach B results table (same format)
- Approach C results table (if applicable)
- Comparison notes: unit count differences, boundary disagreements

**This is the PRIMARY input for the architect's evaluation.**

---

## Execution Sequence

```
D1: produce_packages.py  →  run  →  verify 5 packages
         ↓
D2: extract_divisions.py →  run  →  verify 10 divisions (2 per fixture)
         ↓
D3: run_tests.py         →  run  →  verify ≥20 result JSONs + RUN_SUMMARY.md
         ↓
D4: EVALUATION_WORKBOOK.md generated  →  verify full Arabic text, all approaches
         ↓
Final verification table
```

**Strict sequential dependencies.** Each deliverable needs the output of the previous one.

---

## Files to Create

| # | File | ~Lines | Purpose |
|---|------|--------|---------|
| 1 | `experiments/architecture_test/produce_packages.py` | 60-80 | Normalize 5 fixtures to disk |
| 2 | `experiments/architecture_test/extract_divisions.py` | 350-450 | Select + extract 10 aligned divisions |
| 3 | `experiments/architecture_test/run_tests.py` | 400-500 | Run 3 LLM approaches on all divisions |
| 4 | `experiments/architecture_test/EVALUATION_WORKBOOK.md` | Generated | Architect's evaluation input |

## Critical Files to Reference During Implementation

| File | Why |
|------|-----|
| `engines/normalization/contracts.py` | DivisionNode, ContentUnit, BoundaryContinuityType, ContentFlags |
| `engines/normalization/src/dispatcher.py` | `normalize_source()` signature |
| `engines/normalization/tests/conftest.py` | `_make_source_metadata()` factory |
| `experiments/architecture_test/NEXT_CC.md` | Exact prompts, schemas, algorithm |

## Verification Checklist

1. `packages/` — 5 directories, each with manifest.json + content.jsonl
2. `divisions/` — 5 directories, each with 2 `.json` + 2 `_text.md` files (10 total)
3. `results/` — at least 20 JSON files (10 divs x 2 approaches min) + RUN_SUMMARY.md
4. `EVALUATION_WORKBOOK.md` — complete, full Arabic text for all 10 divisions
5. All scripts execute without errors
6. Final summary table: fixture | div | heading | words | A units | B units | C units | errors

## Do NOT Do (from NEXT_CC.md)

1. Do NOT modify normalization engine code or tests
2. Do NOT create gold references (architect's job)
3. Do NOT evaluate LLM output quality — save results, report counts
4. Do NOT use any API other than OpenRouter
5. Do NOT skip the alignment check
6. Do NOT truncate Arabic text in the workbook
