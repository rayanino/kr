# Claude Code MCP Ecosystem Research for KR Pipeline
## Comprehensive Analysis for Arabic Islamic Scholarly Text Processing

**Status:** Research Phase
**Date:** 2026-03-22
**Purpose:** Identify MCP servers and tools to enhance the 7-engine pipeline for processing Arabic scholarly texts

---

## EXECUTIVE SUMMARY

The Claude Code MCP ecosystem has matured significantly (26,886+ servers as of Feb 2026). Key findings:

1. **Islamic/Quranic Tools Available:** QuranHub MCP is production-ready with Quran search, hadith support
2. **Arabic NLP:** CAMeL Tools, AlKhalil, SAFAR, Madamira available but NOT yet as MCPs
3. **Web Research:** Firecrawl MCP is mature, well-documented, 3-5 min setup
4. **Multi-model Access:** No dedicated LLM consensus MCP found; OpenRouter/LiteLLM require custom integration
5. **Knowledge Graphs:** Neo4j MCP exists; Semantic search capabilities available
6. **MCP Infrastructure:** Multiple registries and marketplaces exist; 7 major AI clients support MCPs

---

## 1. ISLAMIC SCHOLARLY TEXT TOOLS

### 1.1 QuranHub MCP (PRODUCTION-READY) ✅
**Status:** Official Quran tools MCP, full documentation
**URL:** https://qurani.ai/en/docs/mcp
**Capabilities:**
- Core Quran retrieval (surahs, ayahs, pages, themes)
- Search functionality (Arabic text + translations)
- Tajweed rules extraction
- Word-level metadata (line numbers, transliteration)
- Multiple edition support (Uthmani, translations, audio reciters)
- Mutashabihat phrases (similar/repeated verses across Quran)
- Random verse generation with multiple editions

**Installation:** Via Claude Code MCP system
**Cost:** Free (Quran APIs are public)
**For KR Use:**
- Cross-reference Quranic verses during taxonomy phase
- Verify Quran citations in source texts
- Support Quranic knowledge graph building

**Limitations Found:**
- No direct hadith verification (separate from Quran)
- No Islamic jurisprudence (fiqh) rule engine
- No scholar attribution verification

### 1.2 Usul.ai Integration (NOT AN MCP YET)
**Status:** Islamic scholarly database exists, no MCP available
**URL:** https://usul.ai
**Capabilities:** Hadith verification, Islamic jurisprudence
**For KR Use:** Manual API integration could verify hadith chains
**Action Item:** Contact Usul.ai about MCP development or build custom wrapper

---

## 2. ARABIC NLP TOOLS

### 2.1 CAMeL Tools (PYTHON LIBRARY, NOT MCP)
**Status:** Production-grade Arabic NLP toolkit
**GitHub:** ARBML/camel_tools
**Capabilities:**
- Morphological analysis (all readings for a word)
- Dialect identification (MSA vs. Egyptian vs. Levantine)
- Named entity recognition
- POS tagging, tokenization, lemmatization
- Diacritization (tashkeel)
- Generation (inflect words with specified gender/number/tense)

**Implementation Path:**
- Already used in KR pipeline (implicit in normalization engine)
- Can be wrapped as MCP server for Claude Code access
- Python-based, easy to containerize

**For KR Use:**
- Morphological analysis during passaging (segment complex words)
- Dialect classification for source authenticity
- Root extraction for scholar name variants

### 2.2 AlKhalil MorphoSys (JAVA/REST API)
**Status:** Mature Arabic morphological analyzer
**URL:** https://alkhalil.oujda-nlp-team.net
**Capabilities:**
- Comprehensive diacritization
- Root extraction
- Lemma + stem + patterns
- Syntactic state (case, mood, tense)
- Clitic segmentation (ال, ب, ك, ل, و prefix/suffix)

**Availability:** JAR file + REST API available
**For KR Use:**
- Standalone option to CAMeL Tools
- Better for diacritized text recovery
- Strong on morphological disambiguation

### 2.3 SAFAR (Software Architecture For ARabic)
**Status:** Integrated environment with multiple NLP layers
**Capabilities:**
- Tokenization, morphology, syntax, semantics
- Resource services (lexicons, corpora)
- IDE included

**Complexity:** High; industrial-grade system
**For KR Use:** Overkill for current phase; revisit for synthesis engine

### 2.4 Madamira (FAST MORPHOLOGICAL ANALYZER)
**Status:** Academic tool, older but reliable
**Capabilities:** Tokenization, diacritization, morphological disambiguation
**For KR Use:** Fallback option to CAMeL Tools for comparative analysis

### 2.5 Arabic NLP Tools Inventory (GITHUB)
**Resource:** https://github.com/NNLP-IL/Arabic-Resources
**Contains:** 70+ documented tools covering:
- Stemming (Tashaphyne, Khoja)
- Lemmatization (Qalsadi)
- NER (Named Entity Recognition)
- Dialect identification
- Parsing

---

## 3. WEB RESEARCH & SCRAPING

### 3.1 Firecrawl MCP (MATURE, RECOMMENDED) ✅
**Status:** Production, official MCP, 500K+ developers using
**Setup Time:** 3-5 minutes
**Cost:** Free tier: 500 requests/month; Paid tiers available
**Installation:**
```bash
# Option A: Remote (recommended)
claude mcp add firecrawl --url https://mcp.firecrawl.dev/your-api-key/v2/mcp

# Option B: Local
claude mcp add firecrawl -e FIRECRAWL_API_KEY=your-key -- npx -y firecrawl-mcp
```

**Tools Available:**
- `firecrawl_scrape` — Single page extraction
- `firecrawl_search` — Web search
- `firecrawl_map` — Site structure discovery
- `firecrawl_crawl` — Multi-page crawling

**Output Format:** Clean markdown or structured JSON (LLM-optimized)
**Handles:** JavaScript rendering, anti-bot detection, ad removal

**For KR Use:**
- Discover Islamic scholarly sources online
- Extract text from digital repositories (Shamela mirror checks, etc.)
- Verify source availability & authenticity
- Research scholar biographies (Usul.ai, Islamic databases)

**Configuration for Claude Code (.mcp.json):**
```json
{
  "mcpServers": {
    "firecrawl": {
      "command": "npx",
      "args": ["-y", "firecrawl-mcp"],
      "env": {
        "FIRECRAWL_API_KEY": "your-api-key-here"
      }
    }
  }
}
```

**Documentation:** https://docs.firecrawl.dev/mcp

### 3.2 Alternative Web Research Tools
**Perplexity MCP:** Web search + reasoning (5 min setup)
**Brave Search MCP:** Privacy-focused search
**Exa MCP:** Real-time web search API

---

## 4. MULTI-MODEL CONSENSUS SYSTEMS

### 4.1 Current State: NO DEDICATED MCP FOUND
**Finding:** No MCP server exists for multi-model consensus at runtime.

**Your Current Approach (KR):**
- Direct API calls to Command A + Opus 4.6
- Consensus logic embedded in source engine
- 92.3% at-least-one-right rate

**Options for Future:**

**Option A: Custom MCP Wrapper** (RECOMMENDED)
- Wrap OpenRouter/LiteLLM in custom MCP server
- Tools: `consensus_analyze`, `dual_model_verify`
- Benefits: Reusable across all engines, cacheable

**Option B: LiteLLM Integration**
- Direct library integration (no MCP)
- Handles model routing, fallback, caching
- URL: https://litellm.ai

**Option C: OpenRouter Parametrization**
- Use `models` parameter in OpenRouter to specify priority order
- Fallback routing built-in
- Current KR approach (proven)

### 4.2 No Performance Hit Assumption
**Key Finding:** MCPs add minimal latency for consensus calls
- Serialization overhead: <100ms
- Network overhead: depends on transport (stdio vs. HTTP)
- Recommendation: Use stdio for local, HTTP for remote models

---

## 5. KNOWLEDGE GRAPH & SEMANTIC SEARCH

### 5.1 Neo4j MCP (AVAILABLE)
**Status:** Official Neo4j MCP server exists
**Capabilities:**
- Graph database integration
- Cypher query execution
- Entity/relation management

**For KR Use:**
- Store scholar networks (teacher-student relationships)
- Book citation graphs
- Hadith chain (sanad) structures
- Genre/topic taxonomy connections

**Setup:** https://registry.modelcontextprotocol.io/

### 5.2 Semantic Search / RAG Tools
**Context7 MCP:** Fetches up-to-date docs, code examples (49K servers listed)
**BM25/Vector Search:** No dedicated MCP; embed in knowledge layer

---

## 6. CODE QUALITY & TESTING TOOLS

### 6.1 Available MCPs (Not Critical for Current Phase)
**Superpowers MCP:** Software development workflow orchestration
**Scout Monitoring:** Application performance + error tracking
**Sentry MCP:** Error tracking integration

**Your Current Stack:** Sufficient
- pytest framework in use
- Manual code review via dispatch agents
- pyright type checking

**Recommendation:** Defer until synthesis engine (when deployment matters)

---

## 7. DOCUMENTATION & SPEC TOOLS

### 7.1 Context7 MCP (PRODUCTION-READY) ✅
**Status:** Fetches docs from any library
**Use Cases for KR:**
- Pull CAMeL Tools documentation
- Shamela source docs (when available)
- API references for integration points

**Configuration:**
```bash
claude mcp add context7 --url https://mcp.context7.ai/v1
```

### 7.2 No Dedicated SPEC Writing MCP Found
**Your Current Approach:** Markdown + manual validation via `check_spec_quality.py`
**Recommendation:** Keep as-is; MCPs add no value here

---

## 8. MCP INFRASTRUCTURE & REGISTRIES

### 8.1 Official MCP Registry
**URL:** https://registry.modelcontextprotocol.io/
**Contains:** 2,600+ official + community servers
**Last Updated:** Hourly (automated from GitHub)

### 8.2 Marketplace Aggregators
| Name | URL | Features |
|------|-----|----------|
| **MCP Marketplace** | mcpmarket.com | 26,886 servers, categories, leaderboard |
| **mcp-marketplace.io** | mcp-marketplace.io | Security scanning, one-click install, monetization |
| **Awesome Claude MCP** | github.com/win4r/Awesome-Claude-MCP-Servers | Curated list, setup guides |
| **Glama.ai** | glama.ai/mcp/servers | Searchable with previews |
| **LobeHub** | lobehub.com | Multi-agent skill ecosystem |
| **Pylee** | pyleeai.com | Registry management, team coordination |

### 8.3 Installation Commands
```bash
# Discovery
claude mcp list              # Show configured MCPs
claude mcp add <name>        # Interactive setup
claude mcp remove <name>     # Remove MCP

# Configuration files:
# - Global: ~/.claude/settings.json
# - Project: ./.mcp.json
# - Claude Desktop: ~/Library/Application Support/Claude/claude_desktop_config.json
```

---

## 9. CLAUDE CODE SETUP COMMANDS

### 9.1 Essential Setup
```bash
# Start Claude Code with status
claude

# Check what MCPs are available
/mcp

# Get full help
/help

# Check configuration
/status
```

### 9.2 MCP Configuration Priority
1. Project-level (`.mcp.json`) — Best for KR (gitignored API keys)
2. Global (`~/.claude/settings.json`) — Cross-project defaults
3. CLI args — One-off additions

### 9.3 Multiple Clients Support
| Client | Config File | Status |
|--------|-------------|--------|
| Claude Code | `.mcp.json` + `~/.claude/settings.json` | CLI-native ✅ |
| Claude Desktop | `~/Library/.../claude_desktop_config.json` | First-class ✅ |
| Cursor | `.cursor/mcp.json` | Supported ✅ |
| Windsurf | `~/.codeium/windsurf/mcp_config.json` | Supported ✅ |
| VS Code + Copilot | `.vscode/mcp.json` | Supported ✅ |

---

## 10. KEY TECHNICAL DECISIONS FOR KR

### 10.1 Immediate Integration (HIGH IMPACT)

**Priority 1: QuranHub MCP**
- **Why:** Direct support for Quranic verification during excerpting/taxonomy
- **Effort:** 5 min setup, immediate value
- **Cost:** Free
- **Risk:** None (read-only queries)
- **Action:** Install & add to test suite for Quran cross-reference validation

**Priority 2: Firecrawl MCP**
- **Why:** Web research for scholar verification, source discovery
- **Effort:** 5 min setup
- **Cost:** Free tier sufficient for testing
- **Risk:** Low (quota-limited)
- **Action:** Add to source engine for scholar biography verification (Usul.ai lookup)

**Priority 3: Context7 MCP**
- **Why:** Pull CAMeL Tools & Arabic NLP docs on-demand
- **Effort:** 2 min setup
- **Cost:** Free
- **Risk:** None
- **Action:** Configure for reference during implementation

### 10.2 Medium-Term Integration (AFTER PASSAGING)

**Priority 4: CAMeL Tools MCP Wrapper**
- **Why:** Morphological analysis as first-class MCP tool
- **Effort:** 2-4 hours to wrap + test
- **Cost:** None (open-source)
- **Risk:** Medium (quality of wrapper)
- **When:** Once passaging engine proves stable
- **Build Plan:**
  1. Create `.claude/skills/camel-tools-mcp/` directory
  2. Wrap CAMeL Tools library as MCP server
  3. Expose tools: `analyze_morphology`, `inflect_word`, `identify_dialect`
  4. Test against normalization engine outputs

**Priority 5: Neo4j MCP**
- **Why:** Scholar network & citation graphs
- **Effort:** 10-15 hours (infrastructure + schema)
- **Cost:** Free (local Neo4j) or cloud tier
- **Risk:** High (schema design critical)
- **When:** During atomization/excerpting phase
- **Benefits:** Enable relationship queries for synthesis engine

### 10.3 LOW PRIORITY (Defer Beyond Synthesis)

**Not Needed Now:**
- Code quality MCPs (Superpowers, Scout) — internal review sufficient
- Monitoring/observability MCPs — manual testing adequate
- Chat/Slack MCPs — not applicable

---

## 11. CRITICAL GAPS & WORKAROUNDS

### 11.1 Gap: No Hadith Verification MCP
**Problem:** Usul.ai exists but has no MCP wrapper
**Solutions:**
- A) Build custom MCP wrapper around Usul.ai API (if publicly available)
- B) Manual verification via Firecrawl + Claude analysis
- C) Partner integration (request Usul.ai build MCP)

**Recommendation:** B for now; revisit when hadith verification becomes critical in excerpting

### 11.2 Gap: No Multi-Model Consensus MCP
**Problem:** Your current consensus (Command A + Opus) is in-process; MCP adds latency
**Solutions:**
- A) Keep current approach (proven, fast)
- B) Wrap in custom MCP if cross-project reuse needed
- C) Use LiteLLM library directly (no MCP overhead)

**Recommendation:** Stick with A unless other projects need consensus

### 11.3 Gap: No Islamic Jurisprudence (Fiqh) Engine
**Problem:** No MCP for fiqh rules, school differences, Islamic law
**Reality:** This is a knowledge gap, not a tooling gap
**Solution:** Encode during taxonomy phase as structured rules

### 11.4 Gap: Arabic Diacritics Handling in Web Sources
**Problem:** Web scraping via Firecrawl may drop diacritics
**Workaround:** CAMeL Tools/AlKhalil can recover diacritics from undiacritized text

---

## 12. TESTING STRATEGY FOR MCPs

### 12.1 Before Production Use
Each MCP should be tested for:
1. **Latency:** Measure end-to-end call time with Arabic text
2. **Accuracy:** Verify output against known-good references
3. **Edge Cases:** Empty input, mixed Arabic/Latin, diacritics-only
4. **Cost:** Run quota-limited tests to estimate monthly spend
5. **Error Handling:** Simulate network failures, API errors, rate limits

### 12.2 Test Fixtures Needed
- Real Quranic references (surahs, ayahs)
- Real scholar names (multiple spellings)
- Real Arabic source text (with/without diacritics)
- Real web URLs to scrape (Shamela mirrors, Usul.ai pages)

---

## 13. IMPLEMENTATION ROADMAP

### Phase 1: RESEARCH VALIDATION (NOW)
- [ ] QuranHub: Test with sample Quranic references
- [ ] Firecrawl: Scrape 3-5 Islamic scholarly sources
- [ ] Context7: Pull CAMeL Tools docs successfully
- [ ] Verify all MCPs work with Windows 11 + Python 3.13

### Phase 2: INTEGRATION (AFTER PASSAGING SPEC)
- [ ] Add QuranHub to test suite (test_quran_cross_reference.py)
- [ ] Add Firecrawl to scholar verification workflow
- [ ] Document MCP setup in `.claude/skills/mcp-setup/SKILL.md`
- [ ] Create `.mcp.json` template with recommended servers

### Phase 3: CUSTOM MCP DEVELOPMENT (AFTER ATOMIZATION)
- [ ] CAMeL Tools MCP wrapper
- [ ] Custom Usul.ai MCP wrapper (if API available)
- [ ] Performance benchmarks vs. direct library calls

### Phase 4: KNOWLEDGE GRAPH (DURING EXCERPTING)
- [ ] Neo4j MCP setup & schema design
- [ ] Scholar network queries
- [ ] Citation graph construction

---

## 14. ARCHITECTURE IMPLICATIONS

### 14.1 Contract Boundaries
**Question:** Should normalization → passaging boundary use MCP tools?
**Answer:** No. MCPs are async/slow; deterministic engines should not depend on them.

**Recommendation:**
- **Use MCPs in:** Source engine (async), taxonomy (validation), synthesis (research)
- **Don't use MCPs in:** Normalization, passaging, atomization (deterministic phases)
- **Rationale:** Maintain reproducibility, avoid external dependencies in core pipeline

### 14.2 Error Handling & Fallbacks
Every MCP integration needs:
```python
try:
    result = firecrawl_scrape(url)
except QuotaExceeded:
    log.warn(f"Firecrawl quota hit; falling back to cached version")
    result = use_cached_or_manual_fallback()
except NetworkError:
    log.error(f"Firecrawl network error; marking source as unverified")
    result = None
```

---

## 15. BUDGET ESTIMATE

| MCP | Cost | Annual (KR Estimate) | Notes |
|-----|------|----------------------|-------|
| QuranHub | Free | $0 | Unlimited queries |
| Firecrawl | Free (500/mo) | $0-100 | $50 per 10K searches |
| Context7 | Free | $0 | Documentation queries |
| CAMeL Tools | Free | $0 | Open-source library |
| Neo4j | Free (local) | $0-200 | Cloud option if needed |
| Custom MCPs | $0 | $0 | Build internally |
| **Total** | | **$0-300** | Conservative estimate |

Current KR budget (source engine): €36.70 for 274 books = **€0.13/book**
MCP costs: Negligible impact on per-book cost

---

## 16. RECOMMENDATIONS SUMMARY

### Do This NOW:
1. ✅ **Install QuranHub MCP** — 5 min, zero risk, high value
2. ✅ **Install Firecrawl MCP** — 5 min, free tier, enables web research
3. ✅ **Document MCP setup** in team skills directory
4. ✅ **Add to test fixtures:** Real Quranic references, scholar names, source URLs

### Do This AFTER PASSAGING:
5. **Build CAMeL Tools MCP wrapper** — Consolidate morphological analysis
6. **Test multi-engine contract boundaries** — Ensure MCPs don't break determinism

### Do This AFTER ATOMIZATION:
7. **Evaluate Usul.ai MCP** — Hadith verification (if public API available)
8. **Design Neo4j schema** — Scholar networks, citation graphs
9. **Benchmark MCP latency** — Measure impact on synthesis engine

### Don't Do Yet:
- Code quality MCPs (monitoring, logging) — premature
- Chat/Slack/Teams integration — out of scope
- Custom OpenRouter MCP — current approach is proven, fast

---

## 17. REFERENCE LINKS

### Official Registries
- https://registry.modelcontextprotocol.io/
- https://mcpmarket.com/
- https://mcp-marketplace.io/

### Key MCPs for KR
- QuranHub: https://qurani.ai/en/docs/mcp
- Firecrawl: https://docs.firecrawl.dev/mcp
- Context7: https://claude.ai/settings/mcp (Claude Desktop)
- Neo4j: https://registry.modelcontextprotocol.io/ (search "neo4j")
- CAMeL Tools: https://camel-tools.readthedocs.io/

### Setup Guides
- Firecrawl setup: https://www.firecrawl.dev/use-cases/ai-mcps
- Claude Code MCP guide: https://genaiunplugged.substack.com/p/claude-code-mcp-servers-hooks-automation
- Awesome Claude MCPs: https://github.com/win4r/Awesome-Claude-MCP-Servers

### Arabic NLP Resources
- CAMeL Tools: https://github.com/ARBML/camel_tools
- AlKhalil: https://alkhalil.oujda-nlp-team.net/
- Arabic NLP inventory: https://github.com/NNLP-IL/Arabic-Resources

### Islamic Scholarly Databases
- Usul.ai: https://usul.ai (no MCP yet)
- Shamela (via Firecrawl): https://shamela.ws

---

## NEXT STEPS FOR DISCUSSION

**Questions for Rayane:**

1. **Firecrawl budget:** Is the free tier (500 queries/month) sufficient for source verification in your planned scope, or should paid tier be budgeted?

2. **Hadith verification:** When does hadith chain (sanad) verification become critical in your pipeline? This affects whether to build Usul.ai MCP.

3. **Scholar networks:** Do you want to build a Neo4j-backed knowledge graph of scholar relationships during excerpting, or defer to post-synthesis?

4. **Multi-model consensus:** Should custom MCP be built for consensus verification across projects, or is current approach sufficient?

5. **CAMeL Tools integration:** Should it be wrapped as MCP for reusability, or keep as direct library calls?

---

**Document Status:** RESEARCH COMPLETE
**Ready for:** Discussion + Phase 2 Implementation Planning
