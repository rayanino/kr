# BUGFIX: MAX_TOKENS scaling threshold too high

## Context

The ibn_aqil_v3 integration test (2026-03-28) produced 0 excerpts because its first chunk (1987 words, 15 text layers) hit the 8192 MAX_TOKENS limit on classification output (`finish_reason: "length"`). All 3 retries failed with EX-C-001. The threshold for switching to 32768 tokens was `word_count > 2000`, missing this chunk by 13 words. Dense multi-layer text generates disproportionately large classification output.

## Changes (4 files)

### 1. `engines/excerpting/src/phase2_classify.py` (lines 88-102)

Change threshold from 2000 to 1500 in `_compute_classify_max_tokens()`:
- Line 100: `if word_count > 2000:` → `if word_count > 1500:`
- Update docstring (lines 89-93): reflect new threshold and add empirical note

### 2. `engines/excerpting/tests/test_phase2_hardening.py` (lines 1662-1691)

Update `TestMaxTokenBoundaryValues`:
- Class docstring: 2000 → 1500
- Parametrize values: boundary tests at 1500 instead of 2000
  - `(2000, 8192, False)` → `(1500, 8192, False)` (exactly at threshold → 8192)
  - `(2001, 32768, False)` → `(1501, 32768, False)` (just above → 32768)
  - Keep 4000/4001 tests unchanged

### 3. `engines/excerpting/tests/test_phase2_normalize.py` (lines 365-384)

Update `TestComputeClassifyMaxTokens`:
- Parametrize: `(2000, 8192)` → `(1500, 8192)`, `(2001, 32768)` → `(1501, 32768)`
- Add `(1987, 32768)` to confirm the ibn_aqil_v3 case is now covered
- Keep `(500, 8192)`, `(3000, 32768)`, `(4001, 32768)` unchanged

### 4. No SPEC change needed

The SPEC (§5.5.1) defines the *mechanism* (adaptive MAX_TOKENS based on word count) but the specific threshold is an implementation detail. The docstring is the authority here.

## Verification

1. Run full test suite: `python -m pytest engines/excerpting/tests/ -x -q` — expect 595 passed, 0 failed
2. Re-run ibn_aqil_v3 integration test with `--max-chunks 1` — expect >0 excerpts
3. Save output to `integration_tests/run_20260328_fix/ibn_aqil_v3/`
4. Commit and push
