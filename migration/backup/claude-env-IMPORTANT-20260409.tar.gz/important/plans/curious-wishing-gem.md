# Plan: Overnight Autonomous Work Setup

## Context

The user wants to maximize their remaining 50% of 20x plan + 2x weekend bonus by running Claude Code autonomously for ~8 hours overnight. OpenRouter key is charged for LLM API calls. Need to determine the best setup for unattended autonomous operation.

## Analysis: What Actually Works

### The Core Problem

Claude Code sessions need:
1. **Permission approvals** — every tool call can prompt for approval
2. **An active terminal** — if the terminal/computer sleeps, the session dies
3. **Context management** — long sessions hit context limits and auto-compact

### Option A: Loop Script (RECOMMENDED)

Write a bash loop that launches sequential `claude -p` (headless) sessions. Each session reads NEXT.md, executes one task, commits, and exits. The loop relaunches for the next task.

**Setup:**
```bash
# overnight.sh — run from the kr/ project root
#!/usr/bin/env bash
set -e

MAX_ITERATIONS=20
SLEEP_BETWEEN=10

for i in $(seq 1 $MAX_ITERATIONS); do
    echo "=== Session $i of $MAX_ITERATIONS — $(date) ==="

    # Check if all tasks are done
    if grep -q "ALL_TASKS_COMPLETE" NEXT.md 2>/dev/null; then
        echo "All tasks marked complete. Stopping."
        break
    fi

    # Launch Claude Code in headless mode
    claude -p "Read NEXT.md. Execute the FIRST incomplete task (marked with [ ]). When done, mark it [x] in NEXT.md, commit your work, and stop. Do NOT proceed to the next task — just do ONE task per session." \
        --allowedTools "Bash,Read,Write,Edit,Glob,Grep,Agent" \
        --model claude-opus-4-6

    echo "Session $i complete. Sleeping ${SLEEP_BETWEEN}s..."
    sleep $SLEEP_BETWEEN
done

echo "=== Overnight run complete — $(date) ==="
```

**Pros:** Most robust. Each session gets fresh context. Failures don't cascade.
**Cons:** Needs NEXT.md structured as a checklist. Slightly slower (session startup overhead).

### Option B: Single Long Session

```bash
claude -p "$(cat NEXT.md)" \
    --allowedTools "Bash,Read,Write,Edit,Glob,Grep,Agent" \
    --model claude-opus-4-6
```

**Pros:** Simplest setup.
**Cons:** If context fills up or session crashes at task 3 of 10, tasks 4-10 never run. No recovery.

### Option C: `--continue` Loop

```bash
# First session
claude -p "Read NEXT.md and start task 1" --allowedTools "..."

# Subsequent sessions continue the conversation
for i in $(seq 2 20); do
    claude --continue -p "Continue with the next task from NEXT.md" --allowedTools "..."
done
```

**Pros:** Preserves conversation history across sessions.
**Cons:** Context accumulates — later sessions may hit limits anyway.

## Recommended Setup

### 1. Structure NEXT.md as a Checklist

Rewrite NEXT.md with discrete, independent tasks that each session can pick up:

```markdown
# NEXT — Overnight Autonomous Tasks

## Rules
- Execute ONE task per session, then stop
- Commit after each task
- Mark completed tasks with [x]
- When all tasks are [x], write ALL_TASKS_COMPLETE at the top
- Do NOT modify engine source code
- Do NOT modify SPECs
- Track costs in COST_LOG.json

## Tasks (execute in order)

- [ ] Task 1: Fill 6 remaining zero-coverage categories with ~20 more LLM probes
- [ ] Task 2: Run analysis script on Phase E results — genre stability report
- [ ] Task 3: ... (more tasks)
```

### 2. Keep Computer Awake

On Windows 11:
- Settings > System > Power > Screen and sleep > Set "Sleep" to "Never" (restore tomorrow)
- Or use `powercfg -change -standby-timeout-ac 0` in admin PowerShell

### 3. Run the Loop Script

```bash
cd /c/Users/Rayane/Desktop/kr
bash overnight.sh 2>&1 | tee overnight_log.txt
```

### 4. Permission Setup

The `--allowedTools` flag in `claude -p` whitelists specific tools. For the KR project's needs:

```
--allowedTools "Bash,Read,Write,Edit,Glob,Grep,Agent"
```

This covers all tools the overnight tasks need without using `--dangerouslySkipPermissions`.

## What Tasks to Queue for Tonight

Based on where the project stands (Phase E complete, 274 books, normalization engine at Session 7):

### Safe for autonomous execution (no code changes needed):
1. Fill the 6 zero-coverage Shamela categories (~20 more LLM probes)
2. Generate a comprehensive cross-phase analysis report (C+D+E comparison)
3. Run the full normalization sweep on Phase E books (extend calibration)
4. Produce a master genre/author/trust coverage report across all 274 books

### Risky for autonomous execution (needs review):
- Writing new SPECs (needs architect judgment)
- Fixing engine bugs (needs quality review)
- Starting new engine development (needs design decisions)

## Verification

After waking up:
- Check `overnight_log.txt` for errors
- Run `git log --oneline -20` to see commits made overnight
- Read NEXT.md to see which tasks completed
- Check COST_LOG.json for total spend
