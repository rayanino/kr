# Plan: CLI Adapter Implementation

## Context

The excerpting engine's LLM calls currently go through OpenRouter ($292/full run). The owner's Max/Pro subscriptions make CLI calls free ($0). A 4-reviewer architecture review approved a CLI backend transition. The formal adapter SPEC (`shared/llm/CLI_ADAPTER_SPEC.md`) has been written. This session implements it.

**Governing SPEC:** `shared/llm/CLI_ADAPTER_SPEC.md` (766 lines, 13 sections)
**Decision record:** `docs/superpowers/specs/2026-03-28-cli-backend-review-decisions.md`
**Baseline:** 766 tests passing, 2 skipped, 0 failed

---

## Step 1: Create package markers

**Files:**
- `shared/llm/__init__.py` — empty (package marker)
- `shared/llm/tests/__init__.py` — empty (package marker)

Note: `shared/llm/` directory already exists (contains `CLI_ADAPTER_SPEC.md`). Need to create `tests/` subdirectory.

---

## Step 2: Implement `shared/llm/cli_adapter.py`

The main adapter file. ~400-500 lines. All behavior specified in SPEC §2-§7. Key components:

### 2a. Imports and logger
- `from __future__ import annotations`
- stdlib: `dataclasses`, `json`, `logging`, `os`, `shutil`, `subprocess`, `tempfile`, `time`
- `pathlib.Path`, `typing` (Any, Callable, TypeVar)
- `pydantic.BaseModel`, `pydantic.ValidationError`
- Logger: `logging.getLogger("kr.shared.llm.cli_adapter")`

### 2b. Exception class (SPEC §6.1)
```python
class CLIBackendError(Exception):
    def __init__(self, message: str, backend: str = "", exit_code: int | None = None):
        super().__init__(message)
        self.backend = backend
        self.exit_code = exit_code
```

### 2c. Response dataclasses (SPEC §7.1)
- `_CLIUsage` — with `model_dump()` method returning dict
- `_CLIMessage` — content field
- `_CLIChoice` — finish_reason + message
- `CLIResponse` — model, usage, choices, backend, latency_seconds

### 2d. Helper functions
- `_get_oauth_token()` — reads `~/.claude/.credentials.json` → `data["claudeAiOauth"]["accessToken"]` (SPEC §6.3)
- `_check_tool_available(tool_name)` — `shutil.which()` check (SPEC §6.4)
- `patch_additional_properties(schema)` — recursive `additionalProperties: false` injection for Codex (SPEC §5.3)
- `extract_json(raw_output)` — 4-step JSON extraction: direct parse → brace extraction → markdown fence strip → raise (SPEC §4.5)

### 2e. Namespace classes (SPEC §2.2)
- `_CompletionsNamespace` — holds `create()` method (the core dispatch logic)
- `_ChatNamespace` — holds `completions` attribute

### 2f. `CLIInstructorAdapter` class (SPEC §2.1)
- `__init__(default_backend="claude")` — hook registry, namespace wiring, tool availability cache
- `on(event, callback)` — hook registration (SPEC §2.4)
- Internal `_fire_hooks(event, *args, **kwargs)` — calls all registered callbacks

### 2g. The `create()` method — core logic (SPEC §2.3, §3, §4)
Located in `_CompletionsNamespace`. This is the main complexity:

1. **Provider routing** (§3.1): model prefix → backend selection
2. **Command construction** per backend:
   - Claude (§3.2): `ANTHROPIC_API_KEY={token} claude -p "{prompt}" --bare --no-session-persistence --max-turns 2 --output-format json --model opus --system-prompt "{system}"`
   - Codex (§3.3): `codex exec "{prompt}" --output-schema {file} -s read-only -o {file}`
   - Gemini (§3.4): `gemini -p "{prompt}" -y --output-format text`
3. **System prompt augmentation** (§5.1): append JSON schema directive
4. **Retry loop** (§4.2): `max_retries + 1` total attempts
   - On `ValidationError` → augment prompt with error feedback (§4.3)
   - On `JSONDecodeError` → augment prompt with parse error (§4.4)
   - On `TimeoutExpired` → exponential backoff
   - On `CalledProcessError` → auth refresh if auth error, then backoff
5. **Hook firing** at each lifecycle point
6. **Temp file cleanup** for Codex (INV-6)

### Key design decisions to follow exactly:
- DD-1: `max_retries=N` → N+1 total attempts
- DD-2: Schema enforcement = prompt-based + Pydantic post-validation
- DD-4: `--bare` mandatory for Claude
- DD-5: `--max-turns 2` mandatory for Claude
- DD-6: `additionalProperties: false` recursive for Codex
- DD-7: OAuth token refresh on auth error (within same attempt)
- DD-8: JSON extraction handles raw JSON, markdown fences, surrounding text
- DD-9: `temperature` accepted but NOT passed to CLI, IS included in hook payloads
- INV-7: OAuth token NEVER logged/printed/in hooks — only in subprocess env var

---

## Step 3: Implement `shared/llm/tests/test_cli_adapter.py`

30 unit tests as specified in SPEC §10.2. All mock `subprocess.run`. Key patterns:

- Local test models: `SimpleResponse(answer: str, confidence: float)` and `ValidatedResponse` with `@model_validator`
- Fixture: `adapter` fixture returning `CLIInstructorAdapter()`
- Mock: `@patch("subprocess.run")` and `@patch("shared.llm.cli_adapter._get_oauth_token")`
- Mock `shutil.which` to return a path (tool availability check)

Tests 1-11: Interface + routing + command flags + schema embedding
Tests 12-16: Retry behavior (validation error, JSON parse, timeout, subprocess error)
Tests 17-19: Hook firing
Tests 20-22: OAuth token management
Tests 23-24: JSON extraction
Tests 25: CLI tool not found
Tests 26-27: Retry count semantics
Test 28: model_validator feedback
Test 29: temperature logged not passed
Test 30: CLIResponse usage is null

---

## Step 4: Modify `scripts/run_integration_test.py`

### 4a. Add `--backend` argument (SPEC §8.2)
In `parse_args()`, add after `--max-chunks`:
```python
parser.add_argument(
    "--backend",
    choices=["cli", "api"],
    default="api",
    help="LLM backend: 'cli' for CLI tools, 'api' for OpenRouter (default: api)",
)
```

### 4b. Add `create_cli_client()` function (SPEC §9.1)
After `create_client()`:
```python
def create_cli_client():
    from shared.llm.cli_adapter import CLIInstructorAdapter
    return CLIInstructorAdapter()
```

### 4c. Update `run_pipeline()` signature
Add `backend: str = "api"` parameter.

### 4d. Modify client creation block (SPEC §9.2)
Replace the current `if mock: ... else: ...` with three-way branch: `if mock: ... elif backend == "cli": ... else: ...`

### 4e. Config override for CLI escalation model (SPEC §9.3)
When `backend == "cli"`, override `ESCALATION_MODEL` to `google/gemini-2.5-pro`.

### 4f. Update `main()` to pass `backend` through
Pass `args.backend` to `run_pipeline()`. Print backend in summary. Update pre-checks: when `--backend cli`, don't require `OPENROUTER_API_KEY`.

---

## Step 5: Modify `scripts/run_full_integration.py`

### 5a. Add `--backend` argument (SPEC §8.3)
In `main()` argparse:
```python
parser.add_argument(
    "--backend",
    choices=["cli", "api"],
    default="api",
    help="LLM backend passed to run_integration_test.py",
)
```

### 5b. Pass `--backend` to subprocess command
In `run_batch()`, add `"--backend", backend` to the `cmd` list. Accept `backend` as parameter.

### 5c. Skip OPENROUTER_API_KEY check when `--backend cli`
Modify the API key check in `main()` to only require it when `backend == "api"`.

---

## Step 6: Verification (all 5 checks)

```bash
# 1. Existing tests unchanged
PYTHONPATH=. python -m pytest engines/excerpting/tests/ -q --tb=short
# Expected: 766 passed, 2 skipped

# 2. New adapter tests
PYTHONPATH=. python -m pytest shared/llm/tests/ -v --tb=short
# Expected: 30 passed

# 3. Combined count
PYTHONPATH=. python -m pytest engines/excerpting/tests/ shared/llm/tests/ -q --tb=short
# Expected: 796 passed, 2 skipped

# 4. Import check
PYTHONPATH=. python -c "from shared.llm.cli_adapter import CLIInstructorAdapter, CLIBackendError, CLIResponse; print('OK')"

# 5. Interface check
PYTHONPATH=. python -c "
from shared.llm.cli_adapter import CLIInstructorAdapter
a = CLIInstructorAdapter()
assert hasattr(a, 'chat')
assert hasattr(a.chat, 'completions')
assert callable(a.chat.completions.create)
assert callable(a.on)
print('Interface OK')
"
```

---

## Step 7: Commit and push

Single commit with all 6 files (2 new, 2 empty markers, 2 modified).

---

## Critical files

| File | Action | Lines est. |
|------|--------|-----------|
| `shared/llm/__init__.py` | CREATE | 0 |
| `shared/llm/cli_adapter.py` | CREATE | ~450 |
| `shared/llm/tests/__init__.py` | CREATE | 0 |
| `shared/llm/tests/test_cli_adapter.py` | CREATE | ~600 |
| `scripts/run_integration_test.py` | MODIFY | ~30 lines added |
| `scripts/run_full_integration.py` | MODIFY | ~15 lines changed |

## Reuse

- `_make_mock_instructor_client` pattern (conftest.py:205-222) — reference for mock compatibility
- `make_hook_logger` (run_integration_test.py:71-159) — defines exact attribute access on CLIResponse
- `create_client()` (run_integration_test.py:48-63) — pattern to parallel with `create_cli_client()`
- `patch_additional_properties` algorithm from SPEC §5.3 — copy exactly

## Do NOT

- Modify any files in `engines/excerpting/`
- Import `instructor` from the adapter
- Use `MagicMock` for namespace chain
- Add `--backend` to `run_pipeline.py`
- Run real CLI calls in tests
