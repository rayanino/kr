# Plan: Patch All 6 Observability Gaps + Fix Analyzer Bugs

## Context

The evaluation layer (analyzer v1) works but is limited by what the runner emits. Six observability gaps mean the analyzer must infer things it could know directly. This plan patches the runner to emit richer artifacts and upgrades the analyzer to consume them, plus fixes one bug found during review.

## Scope boundaries

- **In scope:** Runner output improvements, analyzer upgrades, one analyzer bug fix
- **Out of scope:** Prompt changes, engine logic changes, dashboard/UI, `validate_batch` signature changes (too many test callers)

## Part A: Runner patches (`scripts/run_integration_test.py`)

### A1: Phase 2a/2b failure ledgers

**Problem:** Failed Phase 2a/2b chunks are simply absent from results — no artifact records the failure.

**Fix:** After each phase call, diff input chunks vs output results. Write failure ledgers.

**Location:** `run_pipeline()`, lines 662-714 (after Phase 2a and Phase 2b blocks)

```python
# After Phase 2a (line ~687, after _serialize_classifications)
phase2a_failures = []
for chunk in chunks:
    if chunk.chunk_id not in classified:
        phase2a_failures.append({
            "chunk_id": chunk.chunk_id,
            "source_id": chunk.source_id,
            "div_id": chunk.div_id,
            "word_count": chunk.word_count,
        })
if phase2a_failures:
    _write_jsonl(output_dir / "phase2a_failures.jsonl", phase2a_failures)
    all_errors.append(
        f"phase2a_chunk_failures:{len(phase2a_failures)}"
    )
    logger.warning(
        "%d chunk(s) failed Phase 2a: %s",
        len(phase2a_failures),
        [f["chunk_id"] for f in phase2a_failures],
    )

# After Phase 2b (line ~714, after _serialize_groupings)
phase2b_failures = []
for chunk_id in classified:
    if chunk_id not in grouped:
        phase2b_failures.append({"chunk_id": chunk_id})
if phase2b_failures:
    _write_jsonl(output_dir / "phase2b_failures.jsonl", phase2b_failures)
    all_errors.append(
        f"phase2b_chunk_failures:{len(phase2b_failures)}"
    )
```

**New helper:**
```python
def _write_jsonl(path: Path, records: list[dict]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
```

**Files:** `scripts/run_integration_test.py`
**Tests affected:** None (additive output)

### A2: Validation drops as first-class artifacts

**Problem:** When `validate_batch` drops an excerpt (EX-V-002), only the error code string is recorded — not WHICH excerpt was dropped.

**Fix:** Add `validation_drops` field to `Phase3Result`. Compute drops in the orchestrator via set diff (no changes to `validate_batch`'s signature, so no test breakage).

**File 1:** `engines/excerpting/src/phase3_orchestrator.py`
```python
@dataclass
class Phase3Result:
    excerpts: list[ExcerptRecord] = field(default_factory=list)
    gate_entries: list[dict[str, object]] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    timings: dict[str, float] = field(default_factory=dict)
    validation_drops: list[dict[str, object]] = field(default_factory=list)  # NEW

# In run_phase3(), after validate_batch:
validated_excerpts, validation_errors = validate_batch(all_excerpts)
result.errors.extend(validation_errors)
result.excerpts = validated_excerpts

# NEW: Record exactly which excerpts were dropped
validated_ids = {e.excerpt_id for e in validated_excerpts}
for exc in all_excerpts:
    if exc.excerpt_id not in validated_ids:
        result.validation_drops.append({
            "excerpt_id": exc.excerpt_id,
            "source_id": exc.source_id,
            "div_id": exc.div_id,
            "chunk_index": exc.chunk_index,
            "unit_index": exc.unit_index,
            "error_codes": [
                e for e in validation_errors
                # Can't map per-unit, but count is correct
            ],
            "text_snippet": exc.text_snippet[:80] if exc.text_snippet else "",
        })
```

Wait — we CAN'T map error codes to specific excerpts in the orchestrator since `validate_batch` returns a flat list of error codes. But we CAN identify WHICH excerpts were dropped (the set diff). The error codes are just `["EX-V-002", "EX-V-002"]` — we know each dropped excerpt corresponds to one EX-V-002.

Simpler:
```python
# In run_phase3(), after validate_batch:
validated_ids = {e.excerpt_id for e in validated_excerpts}
for exc in all_excerpts:
    if exc.excerpt_id not in validated_ids:
        result.validation_drops.append({
            "excerpt_id": exc.excerpt_id,
            "source_id": exc.source_id,
            "div_id": exc.div_id,
            "chunk_index": exc.chunk_index,
            "unit_index": exc.unit_index,
            "text_snippet": exc.text_snippet[:80] if exc.text_snippet else "",
        })
```

**File 2:** `scripts/run_integration_test.py` — write drops to file
```python
# After writing excerpts and gate_queue (line ~756):
if phase3_result.validation_drops:
    _write_jsonl(
        output_dir / "validation_drops.jsonl",
        phase3_result.validation_drops,
    )
    logger.info(
        "Wrote %d validation drop(s) to validation_drops.jsonl",
        len(phase3_result.validation_drops),
    )
```

**Tests affected:** `Phase3Result` gets a new optional field — backward compatible. No test uses the old 4-field constructor positionally.

### A3: Gate queue verification

**Problem:** `verify_gate_queue()` exists in `writer.py` but is never called by the runner.

**Fix:** Call it after writing gate_queue.

**Location:** `run_pipeline()`, line ~756 (after `write_gate_queue`)

```python
if phase3_result.gate_entries:
    write_gate_queue(phase3_result.gate_entries, output_dir)
    # V-P3-7: Paranoid read-back verification
    from engines.excerpting.src.writer import verify_gate_queue
    gate_path = output_dir / "gate_queue.jsonl"
    gate_errors = verify_gate_queue(
        phase3_result.gate_entries, gate_path
    )
    all_errors.extend(gate_errors)
```

**Files:** `scripts/run_integration_test.py`
**Tests affected:** None

### A4: Trace metadata (semantic_phase)

**Problem:** Raw trace files don't record semantic phase or chunk_id. The analyzer must infer from content.

**Fix:** Modify `make_hook_logger` to accept a mutable context dict. Runner sets `semantic_phase` before each phase call.

**Location:** `make_hook_logger()` (lines 87-177)

```python
def make_hook_logger(
    output_dir: Path, client_name: str
) -> tuple[
    Callable[..., None],
    Callable[..., None],
    Callable[..., None],
    dict[str, Any],       # NEW: mutable context
]:
    # ... existing setup ...
    trace_context: dict[str, Any] = {
        "semantic_phase": None,
        "chunk_id": None,
    }

    def on_request(**kwargs: Any) -> None:
        # ... existing code ...
        entry: dict[str, Any] = {
            "call_id": call_id,
            "semantic_phase": trace_context.get("semantic_phase"),  # NEW
            "chunk_id": trace_context.get("chunk_id"),              # NEW
            "model": kwargs.get("model"),
            # ... rest unchanged ...
        }
        # ...

    return on_request, on_response, on_error, trace_context
```

**Runner changes** — update hook registration to capture context:
```python
# For each client registration:
req_hook, resp_hook, err_hook, trace_ctx = make_hook_logger(output_dir, name)
# Store contexts by client name
trace_contexts[name] = trace_ctx
```

Set phase before each call:
```python
# Before Phase 2a
for ctx in trace_contexts.values():
    ctx["semantic_phase"] = "classification"
classified = run_phase2a(...)

# Before Phase 2b
for name, ctx in trace_contexts.items():
    if name == "enrich":
        ctx["semantic_phase"] = "grouping"

# Before Phase 3
for name, ctx in trace_contexts.items():
    if name == "enrich":
        ctx["semantic_phase"] = "enrichment"
    elif name == "verify":
        ctx["semantic_phase"] = "verification"
    elif name == "escalation":
        ctx["semantic_phase"] = "escalation"
```

**Limitation:** `chunk_id` cannot be set from the runner because phase functions iterate over chunks internally. This requires engine-level changes (threading a context through `run_phase2a` → `classify_chunk`). **Deferred.** Documented as remaining gap.

**Files:** `scripts/run_integration_test.py`
**Tests affected:** None (additive; old 3-tuple callers of `make_hook_logger` don't exist outside this file)

### A5: Propagate call-level errors to processing_log

**Problem:** ibn_aqil_v3 has 6 error files in `raw_llm_responses/` but `processing_log.error_count` is 0. The runner only tracks phase-result errors, not call-level errors.

**Fix:** After all phases, count error files and include in processing_log metadata.

**Location:** `run_pipeline()`, before writing processing_log (~line 757)

```python
# Count call-level LLM errors
llm_error_count = 0
resp_dir = output_dir / "raw_llm_responses"
if resp_dir.is_dir():
    llm_error_count = len(list(resp_dir.glob("*_error.json")))
if llm_error_count > 0:
    all_errors.append(f"llm_call_errors:{llm_error_count}")
```

**Files:** `scripts/run_integration_test.py`
**Tests affected:** None

## Part B: Analyzer bug fix

### B1: Synthetic book-level key collision in packet.py

**Problem:** When creating synthetic book-level failure cards for zero-output books, the key uses `div_id="(book-level)"`. If multiple books share the same `source_id` (true in test data), only the first card is created.

**Fix:** Include `book_name` in the synthetic div_id.

**Location:** `scripts/excerpting_eval/packet.py`, line 84

```python
# Before:
book_key = CanonicalUnitKey(
    source_id=r.source_id,
    div_id="(book-level)",
    chunk_index=0,
    unit_index=0,
)

# After:
book_key = CanonicalUnitKey(
    source_id=r.source_id,
    div_id=f"(book-level:{r.book_name})",
    chunk_index=0,
    unit_index=0,
)
```

**Files:** `scripts/excerpting_eval/packet.py`

## Part C: Analyzer upgrades

### C1: Consume validation_drops.jsonl

**Location:** `scripts/excerpting_eval/ingest.py` — add to `load_book_run()`

```python
# Load validation drops
validation_drops = load_jsonl(run_dir / "validation_drops.jsonl")
# Return in result dict
return {
    ...
    "validation_drops": validation_drops,
}
```

**Location:** `scripts/excerpting_eval/analysis.py` — upgrade `detect_unit_loss()`

When `validation_drops.jsonl` exists, match dropped excerpt_ids to lost unit indices. Upgrade evidence_basis from `inferred_moderate_confidence` to `observed`.

```python
def detect_unit_loss(ledger, processing_log, run_dir_str, validation_drops=None):
    lost = [e for e in ledger.values() if e.has_phase2b and not e.has_excerpt]
    if not lost:
        return []

    # If validation_drops.jsonl is available, we know exactly which units
    dropped_unit_indices = set()
    if validation_drops:
        for drop in validation_drops:
            dropped_unit_indices.add(drop.get("unit_index"))

    if validation_drops and all(
        e.key.unit_index in dropped_unit_indices for e in lost
    ):
        # All lost units confirmed in validation_drops → OBSERVED
        evidence_basis = EvidenceBasis.OBSERVED
        interpretation = (
            f"All {len(lost)} lost unit(s) confirmed in validation_drops.jsonl. "
            f"Dropped unit indices: {sorted(dropped_unit_indices)}"
        )
    else:
        # Fall back to count correlation
        ...existing logic...
```

### C2: Consume phase2a/2b failure ledgers

**Location:** `scripts/excerpting_eval/ingest.py` — add to `load_book_run()`

```python
phase2a_failures = load_jsonl(run_dir / "phase2a_failures.jsonl")
phase2b_failures = load_jsonl(run_dir / "phase2b_failures.jsonl")
return {
    ...
    "phase2a_failures": phase2a_failures,
    "phase2b_failures": phase2b_failures,
}
```

**Location:** `scripts/excerpting_eval/analysis.py` — new detector

```python
def detect_phase_failures(
    chunk_records, phase2a_failures, phase2b_failures, run_dir_str,
):
    anomalies = []
    if phase2a_failures:
        anomalies.append(Anomaly(
            anomaly_id="ANO-P2A-FAILURES",
            category="phase2a_chunk_failures",
            severity="structural_fail",
            evidence_basis=EvidenceBasis.OBSERVED,  # Now confirmed by failure ledger!
            summary=f"{len(phase2a_failures)} chunk(s) failed Phase 2a classification",
            observed_facts=[
                f"Failed chunks: {[f['chunk_id'] for f in phase2a_failures]}"
            ],
            ...
        ))
    return anomalies
```

When failure ledgers exist, the analyzer upgrades from `inferred_moderate_confidence` ("chunk is absent, might not have been attempted") to `observed` ("chunk was attempted and explicitly failed").

### C3: Consume trace semantic_phase when present

**Location:** `scripts/excerpting_eval/ingest.py` — update `load_llm_traces()`

```python
# When loading request JSON:
request = load_json(req_file)
explicit_phase = request.get("semantic_phase")  # NEW field from runner

if explicit_phase:
    inferred = SemanticPhase(explicit_phase)  # Trust it
else:
    inferred = infer_semantic_phase(request)  # Fall back to content inference
```

Backward compatible: old run directories without `semantic_phase` field use content inference as before.

### C4: Include call-level error count awareness

**Location:** `scripts/excerpting_eval/analysis.py` — update `detect_artifact_log_contradiction()`

When `llm_call_errors:N` appears in processing_log errors but `error_count` was 0 in the OLD format, use the new error string as additional evidence. Also check for error files directly in the run directory.

## Implementation order

1. **A4** — trace metadata (modifies `make_hook_logger` signature — do first)
2. **A1** — failure ledgers + `_write_jsonl` helper
3. **A2** — validation drops (`Phase3Result` + orchestrator + runner)
4. **A3** — gate queue verification (3 lines)
5. **A5** — call-level error propagation
6. **B1** — packet bug fix (1 line)
7. **C1-C4** — analyzer upgrades (consume new artifacts)
8. **Verify** — re-run all 3 scripts on `integration_tests/run_20260328/`

## Verification plan

After implementation:

```bash
# Re-run per-book analysis (should still pass all 6 regression checks)
python scripts/analyze_excerpting_run.py integration_tests/run_20260328/taysir
python scripts/analyze_excerpting_run.py integration_tests/run_20260328/ibn_aqil_v3

# Campaign + packet
python scripts/analyze_excerpting_campaign.py integration_tests/run_20260328
python scripts/export_excerpting_review_packet.py integration_tests/run_20260328

# Existing engine tests must still pass
python -m pytest engines/excerpting/tests/ -x -q
```

**New verification points:**
- Analyzer gracefully handles MISSING new artifacts (backward compat with old runs)
- When validation_drops.jsonl exists, taysir evidence upgrades to `observed`
- When phase2a_failures.jsonl exists, ibn_aqil_v3 gets `phase2a_chunk_failures` anomaly
- Trace entries include `semantic_phase` field when from patched runner

## Critical files

| File | Changes |
|------|---------|
| `scripts/run_integration_test.py` | A1, A3, A4, A5 (runner patches) |
| `engines/excerpting/src/phase3_orchestrator.py` | A2 (validation_drops field + computation) |
| `scripts/excerpting_eval/packet.py` | B1 (bug fix) |
| `scripts/excerpting_eval/ingest.py` | C1, C2, C3 (consume new artifacts) |
| `scripts/excerpting_eval/analysis.py` | C1, C2, C4 (upgraded detectors) |

## Remaining gap after all patches

**chunk_id in traces:** Cannot be set from the runner because phase functions (`run_phase2a`, `run_phase2b`) iterate over chunks internally. Setting chunk_id requires threading a context object through `run_phase2a` → `classify_chunk` → Instructor call. This is an engine-level change affecting `phase2_classify.py` and `phase2_group.py`. **Deferred** — documented as the one remaining limitation. The analyzer continues to infer chunk association from call sequence.
