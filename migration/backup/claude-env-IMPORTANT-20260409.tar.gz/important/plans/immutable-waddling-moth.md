# Audit Synthesis: Execution-Ready Action Plan for IsIdeas

## Context

Three independent audits (Claude, Codex, ChatGPT) were produced on 2026-03-31 after IsIdeas underwent a factory-only scope correction. The repo previously contained ~40,000 lines of application code across two implementation surfaces. That code has been quarantined. The goal here is to synthesize the three audits into one ranked action plan — not re-audit the repo.

**Post-draft revision:** An adversarial reviewer found 6 issues in the initial synthesis. All 6 were accepted (5 fully, 1 softened). Changes are incorporated below.

---

## Shared Findings (all three audits agree)

1. **Implementation code is gone.** No `src/`, `apps/`, `package.json`, build configs, or runtime state remain in tracked files. The repo is structurally a pure markdown factory.

2. **The dashboard was the dangerous drift vector.** All three identify the control tower dashboard (disguised as "factory infrastructure") as the subtler and more dangerous problem, not the quarantined product app.

3. **No automated in-repo scope guard exists (CF-004).** All three flag this as the main residual enforcement gap. All three also agree it is a deliberate tradeoff — reintroducing toolchain surface to guard against toolchain would be self-defeating.

4. **Documentation language carried the old scope mistake.** Even after code removal, active docs still used runtime/control-plane framing that could normalize re-entry. Claude and Codex both fixed this in their sessions.

5. **I-002 curriculum sourcing is the factory's next productive move.** All three converge: source a specific published curriculum sequence, then begin the authority-boundary data model.

6. **The quarantine pattern and handoff exit lane are correct.** All three affirm these as load-bearing structural decisions that should not be changed.

7. **Quarantine custody model is fragile.** All three audits touch on this: Claude created the quarantine to a local desktop path without flagging fragility, Codex accepted it silently, ChatGPT called it out explicitly. The convergence is stronger than any single finding suggests — and `workflows/QUARANTINE_PROTOCOL.md` itself hardcodes the local Windows path in its procedure steps, meaning every future quarantine will replicate the fragility.

---

## Important Disagreements

| Topic | ChatGPT | Claude | Codex |
|---|---|---|---|
| **PR merge urgency** | THE single best move — merge immediately | Worked on the branch; didn't emphasize merge urgency separately | Worked on the branch; didn't flag merge urgency |
| **External enforcement gate** | Strongly demands forbidden-file PR check | Lists as open question | Treats as open tradeoff (CF-004) |
| **Self-ratification risk** | Finding #5: require owner approval for 3 mutation classes | Not flagged explicitly | Not flagged explicitly |
| **Lifecycle vocabulary** | Rename `Priority` to `Lane` in IDEA_REGISTRY | Not flagged | Not flagged |
| **Quarantine custody** | Local desktop path is fragile, non-portable | Created the quarantine there; didn't flag fragility | Not flagged |
| **Process-infrastructure drift** | Warns governance surfaces could become bureaucracy-heavy | Notes 16 workflow docs are "comprehensive" (positive) | Not flagged |
| **Handoff freeze rule** | Handoff items should be read-only unless re-opened by ADR | Not mentioned | Not mentioned |
| **Permanent dashboard ban** | Ban permanently, not "ban unless small" | Not mentioned explicitly | Not mentioned explicitly |

---

## Ranked Action Plan

### DO NOW (blocks everything else or prevents recurrence)

**1. Commit all pending work, then merge PR#14 to main**
- Severity: **CRITICAL**
- Source: ChatGPT (primary), Claude/Codex (implicit — both worked on this branch)
- Why: Until the corrected branch is the default state, every hardening change is a proposal, not reality. A single new commit to `main` could bypass all safeguards. This is the #1 action.
- **Prerequisite (from adversarial review):** Codex's resolutions of CF-001 through CF-003 are currently uncommitted (12 modified files + 3 untracked audit files). If PR#14 is merged now, it includes only Claude's commits — Codex's doc fixes and the audit artifacts get left behind. Commit and push these first.
- How: (a) Commit all pending changes + untracked audit files. (b) Push. (c) Merge PR#14 to main. (d) Delete the feature branch. (e) Verify main now has ADR-010, ADR-011, ADR-012, FACTORY_SCOPE_BOUNDARY, QUARANTINE_PROTOCOL, and all hardening + doc-fix changes.

**2. Add owner-approval requirement with GitHub-level enforcement**
- Severity: **HIGH**
- Source: ChatGPT (unique finding, but structurally sound)
- Why: EMPLOYEE_PROTOCOLS says Codex "may not silently self-ratify frontier status" but doesn't require explicit owner approval for the three most dangerous mutation types: (a) frontier promotion, (b) handoff promotion, (c) changes to scope-boundary or governance docs. These are the exact mutations where AI-led self-confirmation causes drift.
- **Enforcement (strengthened per adversarial review):** Prose-only rules already failed to prevent the original drift. The existing anti-self-ratification language was "good but insufficient" (ChatGPT's words). Adding more markdown to guard against the failure of markdown is circular. The enforcement must be at GitHub level.
- How: (a) Enable branch protection on `main` requiring owner review for all PRs. (b) Add `CODEOWNERS` file making the owner a required reviewer for `control_tower/`, `decisions/`, `workflows/`, and `catalog/IDEA_REGISTRY.md`. (c) Update `EMPLOYEE_PROTOCOLS.md` to document the three mutation classes and point to the GitHub-level controls.
- Files: `.github/CODEOWNERS`, `control_tower/EMPLOYEE_PROTOCOLS.md`, GitHub repo settings
- **Acknowledged tradeoff:** This introduces a `.github/` directory. It is not application code — it is platform-level access control. Same category as the forbidden-file gate (action #3). Both can share one exception-documenting ADR.

**3. Install external forbidden-file gate**
- Severity: **HIGH** (promoted from MEDIUM per adversarial review)
- Source: All three (ChatGPT strongest)
- Why: The repo has no automated check that fails when forbidden file types appear. This is the CF-004 tradeoff. The forbidden-file gate directly prevents mechanical recurrence of the single most dangerous failure mode. It is more impactful than a vocabulary fix.
- How: GitHub Actions workflow with a file-pattern check. Rejects PRs containing `.ts`, `.tsx`, `.js`, `.jsx`, `.py`, `package.json`, build configs, etc. per the list in `FACTORY_SCOPE_BOUNDARY.md`.
- Tradeoff: Reintroduces a minimal `.github/workflows/` presence. Document the exception in a single ADR alongside the CODEOWNERS exception from action #2.

**4. Fix lifecycle vocabulary: rename `Priority` to `Lane`**
- Severity: **MEDIUM** (demoted from DO NOW #3 per adversarial review — still important but less impactful than enforcement gates)
- Source: ChatGPT (unique finding)
- Why: `IDEA_REGISTRY.md` uses a column called `Priority` but the values are lane labels (`handoff`, `challenge`, `watch`). This is a mislabeled semantic that will cause confusion in future portfolio reads. Small fix, prevents definitional drift.
- How: Rename the column header from `Priority` to `Lane` in `catalog/IDEA_REGISTRY.md`.
- File: `catalog/IDEA_REGISTRY.md`

### DO LATER (important but not blocking)

**5. Move quarantine custody to a durable reference**
- Severity: **HIGH-early** (promoted per adversarial review)
- Source: ChatGPT (explicit), Claude/Codex (implicit — both accepted without questioning durability)
- Why: `QUARANTINED_BUILDS.md` points to `C:\Users\Rayane\Desktop\IsIdeas_quarantine\`. But more importantly, `workflows/QUARANTINE_PROTOCOL.md` line 10 hardcodes the same local path in its procedure steps. Every future quarantine operation will replicate the fragility. The protocol is the vector, not just the current entries.
- How: (a) Push quarantine repos to GitHub as private repos. (b) Update references in `catalog/QUARANTINED_BUILDS.md`, `workflows/QUARANTINE_PROTOCOL.md`, and `decisions/ADR-011-EXTRACT-CONTROL-TOWER-DASHBOARD.md` to use the durable URLs.
- Files: `catalog/QUARANTINED_BUILDS.md`, `workflows/QUARANTINE_PROTOCOL.md`, `decisions/ADR-011-EXTRACT-CONTROL-TOWER-DASHBOARD.md`

**6. Add handoff-freeze rule**
- Severity: **LOW-MEDIUM**
- Source: ChatGPT (unique finding)
- Why: Once an idea enters HANDOFF_QUEUE, substantive changes should require a formal re-open ADR. Without this, handoff refinement becomes slow-motion implementation creep.
- How: Add a rule to `catalog/HANDOFF_QUEUE.md` or `workflows/PROMOTION_CHECKLISTS.md`: "Handoff items are effectively read-only. Substantive changes require an ADR to re-open from handoff to factory."

**7. Source one specific published curriculum sequence for I-002**
- Severity: **MEDIUM** (factory productivity, not structural risk)
- Source: All three audits
- Why: This is the factory's next legitimate work item. The 4-step re-entry path starts here.
- How: Research task — obtain a detailed Dars-e-Nizami text list or equivalent published sequence.

### REJECT

**8. Ban in-repo dashboards permanently (as separate rule)**
- Why reject: The primary barrier is `decisions/ADR-011-EXTRACT-CONTROL-TOWER-DASHBOARD.md`, which records WHY the dashboard was dangerous (same-commit as product MVP, naming convention masking structural identity). A future session would have to explicitly contradict ADR-011 to reintroduce a dashboard. `FACTORY_SCOPE_BOUNDARY.md` provides the secondary barrier by forbidding application file types. A separate dashboard-ban rule is redundant on top of these two existing structural barriers.
- (Note per adversarial review: FACTORY_SCOPE_BOUNDARY's file-type list alone would not catch a markdown-with-embedded-HTML dashboard. ADR-011's recorded reasoning is the stronger defense.)

**9. Add process-infrastructure pruning/expiry rules** (softened from hard reject)
- Why reject the full system: ChatGPT's concern about bureaucracy drift is valid as a warning but wrong as a standalone action item. Adding expiry rules to governance docs is meta-governance that adds bureaucracy to fight bureaucracy.
- **Concession (per adversarial review):** A single line in `control_tower/OPERATING_LOOP.md` — "if a governance surface has not been meaningfully updated in 3 cycles, flag it for removal review" — would cost nearly nothing and address the concern without creating new bureaucracy. This is acceptable as a one-line addition, not a new system.

**10. Add in-repo automated guard (toolchain inside the repo)**
- Why reject: All three audits agree this is a deliberate tradeoff. Reintroducing `package.json` or scripts to guard against `package.json` is self-defeating. If enforcement is desired, it goes OUTSIDE the repo (see action #3).

---

## Single Best Next Move

**Commit all pending work, then merge PR#14 to main.**

ChatGPT is right: until the corrected branch is the default repo state, every other improvement is reversible by drift. The adversarial reviewer caught a critical sequencing gap: Codex's uncommitted CF-001/CF-002/CF-003 resolutions and the audit artifacts would be left behind if PR#14 is merged without committing first. So the actual best next move is: commit → push → merge.

---

## Concrete Next 3 Steps

1. **Commit all pending changes + audit files, push, then merge PR#14 to main.** This includes Codex's 12 modified files (CF-001 through CF-003 resolutions) and 3 untracked audit files. Verify main now has ADR-010, ADR-011, ADR-012, FACTORY_SCOPE_BOUNDARY, QUARANTINE_PROTOCOL, all hardening changes, AND all doc-fix changes. Delete the feature branch after merge.

2. **Set up GitHub-level owner-approval enforcement.** Enable branch protection requiring owner review for PRs. Add `CODEOWNERS` making the owner required reviewer for `control_tower/`, `decisions/`, `workflows/`, and `catalog/IDEA_REGISTRY.md`. Update `EMPLOYEE_PROTOCOLS.md` to document the three mutation classes. Write a single ADR documenting why `.github/` is an acceptable exception to the pure-markdown boundary.

3. **Install the external forbidden-file gate.** GitHub Actions workflow rejecting PRs with forbidden file types per `FACTORY_SCOPE_BOUNDARY.md`. Share the ADR from step 2 for the `.github/` exception.

---

## Adversarial Review Record

**Reviewer:** architect-reviewer agent (dispatched by Claude Opus 4.6)
**Findings:** 6 issues (1 critical, 2 high, 2 medium, 1 low)
**Disposition:** All 6 accepted (5 fully incorporated, 1 softened from hard reject to concession)
**Key changes from review:**
- Step 1 prerequisite: commit uncommitted Codex work before merging
- Owner-approval elevated from prose-only to GitHub-level enforcement (CODEOWNERS + branch protection)
- Forbidden-file gate promoted from DO LATER to DO NOW
- Vocabulary fix demoted from DO NOW #3 to DO NOW #4
- Quarantine custody promoted within DO LATER to HIGH-early with protocol-as-vector noted
- Dashboard-ban rejection strengthened with ADR-011 citation
- Process-infra rejection softened to allow one-line staleness check

---

## Verification

After execution, verify:
- [ ] `main` branch contains all 5 hardening commits + Codex doc-fix commit + audit artifacts
- [ ] Feature branch deleted
- [ ] Branch protection enabled on `main` with owner review required
- [ ] `CODEOWNERS` file exists and covers `control_tower/`, `decisions/`, `workflows/`, `catalog/IDEA_REGISTRY.md`
- [ ] GitHub Actions workflow rejects PRs with forbidden file types
- [ ] `EMPLOYEE_PROTOCOLS.md` documents the three mutation classes with pointer to GitHub controls
- [ ] `IDEA_REGISTRY.md` column renamed from `Priority` to `Lane`
- [ ] ADR exists documenting the `.github/` exception to pure-markdown boundary
