# Plan: Apply 14 Dual-Reviewer Audit Fixes to Excerpting Engine

## Context

Session 5/6 built Phase 3.4 (validation), the Phase 3 orchestrator, output writer, and pipeline
wrapper. A dual-reviewer audit found 27 issues — 14 require code changes (2 CRITICAL, 5 HIGH,
7 MEDIUM/LOW). Fix 6 is subsumed by Fix 2, so 13 actual code changes + 1 SPEC errata update.

The core problems are: (a) corrupt excerpts silently pass validation instead of being dropped,
(b) consensus crashes silently lose gate entries, (c) broad `except Exception` catches hide
programming bugs in deterministic code, and (d) several minor compliance gaps.

**Test baseline:** 540 passed, 2 skipped, 0 failed.
**Target:** >=550 passed (10+ new tests), 0 failed.

## Execution Order — Grouped by File

Four source files, one errata file, then tests. Grouped to minimize context switches.
After each file: `pyright` check + `pytest -x -q` on affected tests.

---

### Batch 1: `engines/excerpting/src/phase3_orchestrator.py` (Fixes 3, 2a, 8, 13)

**Fix 3 (HIGH)** — Remove try/except around `build_deterministic_excerpts` (lines 93-103)
- Delete lines 96-103 (the `except Exception` block)
- Keep only: `excerpts = build_deterministic_excerpts(chunk, units, segments)` + `all_excerpts.extend(excerpts)`
- Programming bugs in deterministic code must crash

**Fix 2a (CRITICAL)** — Remove try/except around `run_consensus` (lines 147-164)
- Delete lines 158-164 (the `except Exception` block)
- Keep the successful path: `all_excerpts, gate_entries = run_consensus(...)` + `result.gate_entries.extend(gate_entries)`
- Keep timing/logging lines AFTER (lines 165-170)
- Consensus crash now propagates up to pipeline

**Fix 8 (MEDIUM)** — Narrow enrichment exception catch (lines 128-134)
- Add `if isinstance(exc, (TypeError, AttributeError, NameError, KeyError)): raise` at top of except block (line 129)
- Keep rest of handler (log + append error code) for LLM/network failures

**Fix 13 (LOW)** — Fix misleading skip log (line 172)
- Change `"Phase 3 consensus: SKIPPED (no verify client)."` to:
  `"Phase 3 consensus: SKIPPED (enrich_client=%s, verify_client=%s).", enrich_client is not None, verify_client is not None`

**Verification:** `grep -c "except Exception" phase3_orchestrator.py` → exactly 1 (enrichment only)

---

### Batch 2: `engines/excerpting/src/pipeline.py` (Fixes 4, 9, 2b, 12)

**Fix 4 (HIGH)** — Remove try/except around `run_phase1` (lines 103-108)
- Delete the try/except. Keep only: `chunks, _p1_validation = run_phase1(package, config)`
- Phase 1 is deterministic — bugs must crash

**Fix 9 (MEDIUM)** — Narrow Phase 2 exception catch (lines 127-130)
- Add `if isinstance(exc, (TypeError, AttributeError, NameError, KeyError)): raise` at top of except block (line 128)
- Keep rest of handler for LLM/network failures

**Fix 2b (CRITICAL)** — Add try/except around Phase 3 call (lines 147-156)
- Wrap the existing `phase3_result = run_phase3(...)` call in:
  ```python
  try:
      phase3_result: Phase3Result = run_phase3(...)
  except Exception as exc:
      if isinstance(exc, (TypeError, AttributeError, NameError, KeyError)):
          raise
      logger.error("Phase 3 failed for %s: %s", source_id, exc)
      result.errors.append(f"PHASE3_FATAL: {exc}")
      return result
  ```
- Consensus crash → Phase 3 crash → pipeline catches → returns empty result with error

**Fix 12 (LOW)** — Capture verify_gate_queue return value (line 177)
- Change `verify_gate_queue(result.gate_entries, gate_path)` to:
  `gate_errors = verify_gate_queue(result.gate_entries, gate_path)` + `result.errors.extend(gate_errors)`

**Verification:** `grep -c "except Exception" pipeline.py` → exactly 2 (Phase 2 + Phase 3)

---

### Batch 3: `engines/excerpting/src/phase3_validation.py` (Fixes 1, 5, 10, 14)

**Fix 1 (CRITICAL)** — V-P3-2 must DROP excerpt, not just log
- Add `from typing import Optional` import (if not already present; but `from __future__ import annotations` is already there, so just use `Optional` in the annotation — confirm it's importable)
- Change `validate_excerpt` return type → `tuple[Optional[ExcerptRecord], list[str]]` (line 68)
- After V-P3-2 check (line 82-91): set `drop = True` flag when snippet mismatch occurs
- Change `logger.warning` to `logger.error` (line 84)
- Before the return (line 214): `if drop: return (None, errors)`
- In `validate_batch` (line 251): check `if modified_exc is not None:` before `validated.append(modified_exc)`
- Add `dropped_count` tracking + log after loop: `logger.error("V-P3-2: Dropped %d excerpts...", dropped_count)`

**Fix 5 (HIGH)** — V-P3-1 duplicate IDs → raise ValueError (lines 241-247)
- Replace the entire `if duplicate_ids:` block with:
  ```python
  if duplicate_ids:
      raise ValueError(
          f"V-P3-1: Duplicate excerpt IDs detected — "
          f"this is a bug in the ID generation algorithm: {duplicate_ids}"
      )
  ```
- Remove the `error_code = ExcerptingErrorCodes.EX_V_002` (wrong code anyway)

**Fix 10 (MEDIUM)** — V-P3-9 isinstance guard (lines 203-212)
- Add `if not isinstance(ct, ScholarlyFunction):` check before `ct.value`
- Non-enum → emit `EX_M_010` + log warning with repr(ct)
- Valid enum but unknown value → existing check with `ct.value`

**Fix 14 (LOW)** — Add design decision comments
- Before V-P3-8 block (line 179): DD-S56-1 comment about marker substring search
- Before V-P3-1 block (line 233): DD-S56-2 comment about batch-level scope

**Verification:**
- `grep "logger.warning.*EX_V_002" phase3_validation.py` → 0 hits
- `grep "EX_V_002" phase3_validation.py` → only in V-P3-2 block

---

### Batch 4: `engines/excerpting/src/writer.py` (Fixes 7, 11)

**Fix 11 (LOW)** — Guard write_gate_queue against empty input (line 73+)
- Add at top of function body: `if not gate_entries: logger.info("No gate entries..."); return output_dir / "gate_queue.jsonl"`

**Fix 7 (MEDIUM)** — Gate queue verification retry before halt (lines 176+)
- When `missing` is non-empty: log warning, call `write_gate_queue(gate_entries, gate_path.parent)`, re-read + re-verify
- Extract read+compare into helper (or inline once) to avoid duplication
- If STILL missing after retry → raise `GateQueueVerificationError`
- Keep immediate raise on "file does not exist" (no retry for missing file)
- Need to import `write_gate_queue` within `verify_gate_queue` or refactor to avoid circular dependency (both are in same file — no issue)

---

### Batch 5: `reference/SPEC_ERRATA.md` — Append 3 errata notes

**Note:** NEXT.md calls them SPEC-NOTE-4/5/6 but those numbers are already taken (4-9 exist).
Renumber to SPEC-NOTE-10/11/12 to avoid collision.

- **SPEC-NOTE-10:** V-P3-1 has no error code → implementation raises ValueError
- **SPEC-NOTE-11:** V-P3-8 uses substring search (equivalent per Phase 1 assembly)
- **SPEC-NOTE-12:** V-P3-1 batch scope vs per-chunk scope (strictly more thorough)

---

### Batch 6: Tests — `engines/excerpting/tests/test_phase3_validation.py` + new test files

**Test group 1 — Fix 1 (V-P3-2 drop):** 4 tests
- `validate_excerpt` returns `(None, [EX_V_002])` when primary_text[:80] != text_snippet
- `validate_batch` excludes None entries from result list
- Valid excerpts are NOT dropped (regression guard)
- Dropped count logged correctly (caplog check)

**Test group 2 — Fix 2 (consensus crash → Phase 3 crash):** 2 tests
- Mock `run_consensus` to raise RuntimeError → `run_phase3` propagates the exception
- `run_excerpting` catches Phase 3 crash → returns ExcerptingResult with `"PHASE3_FATAL"` in errors
- File: `test_phase3_orchestrator.py` or new `test_pipeline.py` (wherever orchestrator/pipeline tests live)

**Test group 3 — Fix 5 (V-P3-1 ValueError):** 2 tests
- `validate_batch` with duplicate excerpt_ids raises ValueError
- Error message includes the duplicate IDs
- Existing V-P3-1 tests in `TestVP31IdUniqueness` need update (they currently expect EX_V_002)

**Test group 4 — Fix 7 (gate queue retry):** 3 tests
- First verify fails, retry succeeds → no exception
- First verify fails, retry fails → GateQueueVerificationError
- File not found → immediate GateQueueVerificationError (no retry)
- These go in a new `TestGateQueueRetry` class (location: existing writer test file or test_phase3_validation.py)

**Test group 5 — Fix 10 (V-P3-9 isinstance):** 1 test
- Inject raw string via `model_copy(update={"content_types": ["not_an_enum"]})` → EX_M_010 emitted, no crash
- Existing `TestVP39ContentTypes` class (lines 406-425) — add to it

**Total: >=12 new tests** (exceeds the >=10 requirement)

---

## Critical Files

| File | Fixes | Lines to Change |
|------|-------|----------------|
| `engines/excerpting/src/phase3_orchestrator.py` | 3, 2a, 8, 13 | ~93-103, ~128-134, ~147-164, ~172 |
| `engines/excerpting/src/pipeline.py` | 4, 9, 2b, 12 | ~103-108, ~127-130, ~147-156, ~177 |
| `engines/excerpting/src/phase3_validation.py` | 1, 5, 10, 14 | ~66-91, ~179, ~203-212, ~233-247 |
| `engines/excerpting/src/writer.py` | 7, 11 | ~73+, ~176+ |
| `reference/SPEC_ERRATA.md` | errata | append |
| `engines/excerpting/tests/test_phase3_validation.py` | tests 1,3,5 | append |
| `engines/excerpting/tests/test_phase3_orchestrator.py` | tests 2 | append or new |
| `engines/excerpting/tests/test_writer.py` | tests 4 | append or find existing |

## Reusable Infrastructure

- `_make_excerpt_record(**overrides)` in `conftest.py` (line 142) — all test groups use this
- `_make_mock_instructor_client()` in `conftest.py` (line 205) — Fix 2 tests need mock clients
- `_make_normalized_package()` in `conftest.py` (line 329) — pipeline-level tests for Fix 2
- `ExcerptingErrorCodes` enum from `contracts.py` — all error code assertions
- `caplog` pytest fixture — for dropped-count log verification (Fix 1)

## Verification Checklist (post-implementation)

1. `python -m pytest engines/excerpting/tests/ -v --tb=short` → >=550 passed, 0 failed
2. `grep -c "except Exception" engines/excerpting/src/phase3_orchestrator.py` → exactly 1
3. `grep -c "except Exception" engines/excerpting/src/pipeline.py` → exactly 2
4. `grep "logger.warning.*EX_V_002" engines/excerpting/src/phase3_validation.py` → 0 hits
5. `grep "EX_V_002" engines/excerpting/src/phase3_validation.py` → only in V-P3-2 block
6. New test count >= 10 added
7. `python -m pyright engines/excerpting/src/phase3_validation.py` → 0 errors
8. `python -m pyright engines/excerpting/src/phase3_orchestrator.py` → 0 errors
9. `python -m pyright engines/excerpting/src/pipeline.py` → 0 errors
10. `python -m pyright engines/excerpting/src/writer.py` → 0 errors

## Risks and Mitigations

- **Fix 1 return type change:** `validate_batch` is the only caller of `validate_excerpt` (confirmed by reading). The None handling is added to `validate_batch` in the same fix.
- **Fix 2 removing consensus try/except:** Existing tests that mock consensus failures will need updating to expect propagated exceptions instead of error codes. Check test_phase3_orchestrator.py for affected tests.
- **Fix 5 changing V-P3-1 behavior:** Existing `TestVP31IdUniqueness` tests (lines 51-76) expect error codes, not ValueError. Must update those tests.
- **Fix 7 retry calling write_gate_queue:** Both functions are in writer.py — no import issues.
- **SPEC-NOTE numbering:** NEXT.md says 4/5/6 but those are taken. Using 10/11/12.

## Do NOT Do

Per NEXT.md constraints:
1. Do NOT implement processing_log.jsonl (PE-6)
2. Do NOT modify Phase 1, Phase 2, or Phase 3.1-3.3 code
3. Do NOT modify contracts.py unless required
4. Do NOT change V-P3-8 approach (correct per DD-S56-1)
5. Do NOT add new SPEC error codes
6. Do NOT proceed beyond this task
