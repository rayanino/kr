# Plan: KR `.claude/` Configuration Audit & Fix

## Context

After a best-practices digestion session (analyzing patterns from Boris Cherny and Thariq at Anthropic), changes were applied and reviewed by Codex CLI (GPT-5.4). Codex caught several cargo-cult patterns that were reverted. This plan addresses the HIGH and MEDIUM priority items that Codex flagged but weren't fixed, plus independent audit findings.

**Problem:** Stale validation scripts produce false positives (training the user to dismiss warnings), stale docs say hooks are "pending" when they're live, and 8 of 22 agents lack trigger-condition descriptions (meaning the model can't decide WHEN to dispatch them).

---

## Phase 1: Fix Stale Validation Scripts (HIGH — foundational)

### 1A. Fix `scripts/verify_metadata_flow.py` regex

**File:** `scripts/verify_metadata_flow.py` — lines 84, 87, 90

**Problem:** The section-matching regex `r'3\.\s*Output\s*Contract'` assumes all SPECs use `## 3. Output Contract`. But excerpting uses `## §2.1 — Input Contract` and `## §2.2 — Output Contract`. The regex finds zero fields for excerpting, producing false warnings at the atomization→excerpting boundary.

**Evidence from grep:**
- 6 engines: `## 2. Input Contract` / `## 3. Output Contract`
- Excerpting: `## §2.1 — Input Contract` / `## §2.2 — Output Contract`

**Fix:** Replace hardcoded section-number patterns with flexible patterns that match on "Input Contract" or "Output Contract" regardless of numbering scheme:

```python
# Line 84: was r'3\.\s*Output\s*Contract'
upstream_output = extract_field_names(upstream_text, r'.*?Output\s*Contract')

# Line 87: was r'2\.\s*Input\s*Contract'
downstream_input = extract_field_names(downstream_text, r'.*?Input\s*Contract')

# Line 90: was r'3\.\s*Output\s*Contract'
downstream_output = extract_field_names(downstream_text, r'.*?Output\s*Contract')
```

The enclosing regex at line 42 already anchors on `##\s+`, so `.*?Output\s*Contract` will match any heading containing those words.

**Verify:** `python scripts/verify_metadata_flow.py --verbose` — excerpting boundary should show non-empty field sets.

### 1B. Fix `scripts/quality_gate.py` PIPELINE_ORDER

**File:** `scripts/quality_gate.py` — line 19

**Problem:** Missing passaging and atomization. Both exist under `engines/` with `SPEC.md`, `contracts.py`, and `src/`.

**Fix:** Change line 19:
```python
# FROM:
PIPELINE_ORDER = ["source", "normalization", "excerpting", "taxonomy", "synthesis"]
# TO:
PIPELINE_ORDER = ["source", "normalization", "passaging", "atomization", "excerpting", "taxonomy", "synthesis"]
```

**Verify:** `python scripts/quality_gate.py --mode contracts --paths engines/passaging/contracts.py` — passaging is recognized.

### 1C. No change to `stop-quality-gate.sh`

The hook (lines 94-98) already correctly checks `verify_metadata_flow.py`'s exit code. Once 1A fixes the regex, the stop hook benefits automatically. The script's exit-0 behavior is intentional (informational tool, not blocker).

---

## Phase 2: Fix Stale Documentation (HIGH)

### 2A. Rewrite `.claude/HOOK_WIRING.md`

**Problem:** Says "These hook scripts are ready but need to be wired into `.claude/settings.json`" — but they've been wired since the previous session (settings.json lines 113-141).

**Fix:** Rewrite to reflect current state — hooks are LIVE. Keep verification instructions (still useful). Add cross-reference to MCP_ACTION_PLAN.md for manual MCP cleanup.

---

## Phase 3: Agent Description Rewrites (HIGH — 8 agents)

Per Thariq (Anthropic): "The description field is not a summary — it's a description of WHEN TO TRIGGER. Write it for the model."

Only `arabic-reviewer` was updated previously. These 8 need trigger conditions added:

| Agent | Current Issue | New Description |
|-------|--------------|-----------------|
| `audit-comparator` | No trigger | `Merges Auditor A and B defect inventories, classifies findings as BOTH_FOUND / A_ONLY / B_ONLY, and produces a deduplicated defect list. Use after both spec-auditor-a and spec-auditor-b complete independent audits on the same SPEC.` |
| `consolidator` | No trigger | `Compares Verifier A and B verdicts, resolves disagreements through investigation, and produces final verdicts with mandatory 5-round self-review. Use after both verifier-a and verifier-b complete verification on the same batch during EVALUATE phase.` |
| `integrity-auditor` | No trigger | `Runs the kr-integrity checklist on a revised SPEC for ambiguous rules, missing error paths, corruption vectors (T1-T7), and contract alignment. Use as the final gate after a SPEC has been audited and revised, before approving it for build.` |
| `model-researcher` | No trigger | `Compares frontier LLMs on classical Arabic scholarly text capability for KR consensus role assignment. Use when selecting or updating model assignments for multi-model consensus roles, or when a new frontier model is released.` |
| `spec-writer` | No trigger | `Writes or refines a SPEC section with full precision, producing implementation-ready prose with concrete Arabic examples. Use when creating a new SPEC section, rewriting a section flagged by auditors, or refining rules that lack testable examples.` |
| `spec-auditor-a` | No trigger | `Cold reads a SPEC against silent failure patterns 1-4 (hollow examples, circular definitions, hand-waving technology, phantom metadata). Use when auditing a new or revised engine SPEC. Dispatch alongside spec-auditor-b for independent dual-audit coverage.` |
| `spec-auditor-b` | No trigger | `Cold reads a SPEC against silent failure patterns 5-7 (untestable rules, missing error paths, scope creep) and all 7 corruption threats (T1-T7). Use when auditing a new or revised engine SPEC. Dispatch alongside spec-auditor-a for independent dual-audit coverage.` |
| `triage-analyst` | No trigger | `Runs zero-cost automated checks on pipeline output to assign risk tiers (LOW/MEDIUM/HIGH) before expensive N-version verification. Use as the first evaluation stage before dispatching verifier-a and verifier-b.` |

---

## Phase 4: Skill Description Fix (MEDIUM — 1 skill)

### 4A. Fix `codex-verify/SKILL.md` description

**Current:** `Independent code review via Codex MCP for D-041 multi-model verification`
**Proposed:** `Independent code review via Codex MCP for D-041 multi-model verification. Use after writing or modifying engine source code, contracts.py, or test files to get a cross-model structural review.`

`recursive-improve/SKILL.md` already has adequate trigger text — no change needed.

---

## Phase 5: Skill Preloading Expansion (MEDIUM — 4 agents)

Add `skills:` frontmatter to agents that reference these skills in their body text:

| Agent | Skills to Add | Rationale |
|-------|--------------|-----------|
| `spec-writer` | `spec-examples, domain-glossary` | Body explicitly says "read domain-glossary" and "use spec-examples" |
| `test-engineer` | `arabic-text` | Principle 2: all tests must use real Arabic fixtures |
| `spec-auditor-a` | `knowledge-safety` | Checks T1-T7 corruption threats defined in the skill |
| `spec-auditor-b` | `knowledge-safety` | Same |

---

## Phase 6: Merge Redundant Bash Matchers (MEDIUM)

**File:** `.claude/settings.json` — PreToolUse section

**Problem:** 3 separate `"matcher": "Bash"` entries (lines 83-92, 113-121, 123-131) fire independently on every Bash command.

**Fix:** Merge into 1 entry with 3 hooks in the `hooks` array. Each script's own disable flag in `hooks-config.json` preserves independent toggle capability.

```json
{
  "matcher": "Bash",
  "hooks": [
    { "type": "command", "command": "...(inline destructive blocker)...", "timeout": 5 },
    { "type": "command", "command": "\"$CLAUDE_PROJECT_DIR/.claude/hooks/circuit-breaker.sh\"", "timeout": 5 },
    { "type": "command", "command": "\"$CLAUDE_PROJECT_DIR/.claude/hooks/cost-guard.sh\"", "timeout": 10 }
  ]
}
```

**Verify:** `jq . .claude/settings.json` passes. Count of `"matcher": "Bash"` entries = 1 (was 3).

---

## Phase 7: Verification

After all changes:

1. `python scripts/verify_metadata_flow.py --verbose` — excerpting boundary shows non-empty field sets
2. `python scripts/quality_gate.py --mode contracts --paths engines/passaging/contracts.py` — passaging recognized
3. Read `.claude/HOOK_WIRING.md` — no stale "needs to be wired" language
4. Grep all agent descriptions for trigger conditions — all 22 have them
5. `jq . .claude/settings.json` — valid JSON after settings merge
6. Run `python -m pytest engines/*/tests/ shared/*/tests/ -q --tb=line` — full test suite still passes

---

## Execution Order

```
Phase 1A (regex fix)          ─┐
Phase 1B (PIPELINE_ORDER fix) ─┼── Independent, do first
Phase 2A (HOOK_WIRING.md)     ─┘
Phase 3  (8 agent descriptions)── Independent, parallel-safe
Phase 4  (1 skill description) ── Independent
Phase 5  (4 agent skills)      ── Independent
Phase 6  (settings.json merge) ── Do LAST (triggers approval prompt)
Phase 7  (verification)        ── After all above
```

---

## Items Intentionally Excluded

| Item | Reason |
|------|--------|
| MCP cleanup (Steps 1-3 in MCP_ACTION_PLAN.md) | Requires manual Claude Desktop restart — not a code change |
| Per-agent `permissionMode` | Reviewers already lack Write/Edit tools (tool list constrains them). Builders have Write/Edit by design. Low value. |
| Per-agent `isolation: worktree` | spec-adversary writes to reference/ (needs main tree access). deep-researcher's web searches don't benefit from file isolation. Low value. |
| `recursive-improve/SKILL.md` | Already has adequate trigger text |
| `evaluation-methodology/SKILL.md` | Has `disable-model-invocation: true` — trigger less important |
| Verify acceptEdits + ask rules | Configuration is correct (verified by reading settings.json). acceptEdits auto-approves edits, ask rules prompt for destructive Bash commands. |

---

## Risk Assessment

| Phase | Risk | Mitigation |
|-------|------|-----------|
| 1A (regex) | Medium — could break field extraction for other engines | Test with `--verbose` across ALL 6 boundaries |
| 1B (PIPELINE_ORDER) | Low — adding 2 strings to a list | Matches verify_metadata_flow.py's correct list |
| 2A (docs) | None — pure documentation | Read after writing |
| 3-5 (frontmatter) | Low — metadata-only changes | No behavioral impact |
| 6 (settings.json) | Medium — malformed JSON breaks all hooks | Validate with `jq` before committing |
