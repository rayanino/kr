# Overnight Autonomous Work Plan — KR Pipeline Hardening & Environment Optimization

## Context

The KR pipeline has 2 of 7 engines complete (Source: 758 tests, Normalization: 470 tests). The Excerpting Engine SPEC is being designed by the architect in Claude Chat. The owner is sleeping for ~8 hours and has granted full autonomy to improve the project.

**What prompted this:** The owner wants maximum use of overnight time to improve the pipeline, strengthen knowledge integrity, and optimize the development environment for ALL future sessions.

**Intended outcome:** A safer, more capable development environment with stronger knowledge integrity guards, fixed known limitations, and better tooling — all without breaking any existing tests or reducing quality.

**Guiding principle:** "The library IS the user's knowledge. An error here is an error in his mind." This is the owner's study of his religion — errors propagate into his understanding of Islam.

---

## Operational Constraints — READ FIRST

**Autonomy:** NEVER ask the user a question. NEVER break for input. If ambiguous, make the conservative decision and log it to `.claude/pending_decisions.log`. If blocked, work around the obstacle.

**Context management:** NEVER use /clear. Use /smart-compact proactively when context exceeds ~60%. After any compaction, immediately re-read NEXT.md and the active engine's CLAUDE.md. 1M context window available but quality degrades at high usage — keep lean.

**Time:** Infinite. No rush. Quality is the ONLY metric. If a phase takes 5 hours instead of 2, that's fine. Never sacrifice quality for speed.

**Budget:** $100 OpenRouter credits available. Rules:
- Every API call MUST persist its full output to a results file (RESULT_PRESERVATION.md rules)
- No spending on unstable tests, bad prompts, or loose architecture
- Before calling an LLM, verify the prompt is solid and the result will be reusable
- Track all spending in `tests/results/COST_LOG.json`

**No breaking:** Yesterday a /clear command killed an entire overnight session. That MUST NOT happen. If an operation could kill context, don't do it. Commit frequently so nothing is lost.

---

**Critical discoveries from research:**
- Library registries are **empty** (`scholars.json = {}`). No library data verification needed.
- L-011 (writer recovery) is **already fixed** in code (writer.py:192-203) but KNOWN_LIMITATIONS.md is stale.
- 48 books produce **zero content units** silently — potential T-1 violation.
- 3 bare `except Exception` handlers could be **silently swallowing data corruption**.
- **Serena MCP works** (initially reported broken — verified connected).
- **Codex MCP is misconfigured**: `codex mcp` is a management command, not a server. Codex CLI doesn't expose MCP server mode. GPT-5.4 must be accessed via litellm/instructor instead.
- **Triple Context7** and **double Tavily** waste context with duplicate tools.

---

## Phase 0: Environment Optimization (~2.5 hours)

**Philosophy:** The environment is already excellent (top 1% — 10 connected MCPs, 19 plugins, 11 hooks, bypassPermissions, max effort). Focus on: fixing what's broken, removing noise, and adding targeted safety hooks that protect knowledge integrity in ALL future sessions.

### 0A. Fix & Clean MCP Servers (20 min)

**Remove broken/irrelevant MCPs:**
- `codex` — Misconfigured. Codex CLI doesn't have MCP server mode. Remove entry.
- `fetch` — Fails to connect. Redundant with Firecrawl/Tavily/WebFetch. Remove.
- `office-word` — Fails to connect. Irrelevant to KR. Remove.

**Remove duplicate MCPs:**
- Keep `plugin:context7:context7` (best integrated). Remove standalone `context7`.
- Keep `claude.ai tavily` (cloud-hosted, reliable). Remove standalone `tavily`.
- This eliminates ~10 duplicate deferred tools from context.

**Document GPT-5.4 access:** Create `.claude/GPT54_USAGE.md` noting:
- GPT-5.4 is available via `codex` CLI for code review: `codex -q "review this code for bugs"`
- For consensus in Python scripts, use litellm: `completion(model="openai/gpt-5.4", ...)`
- NOT available as MCP tool — use Bash or litellm integration

**Consider disabling irrelevant global plugins:**
- `gopls-lsp` — Go language server. KR is 100% Python. Disable.

Files: `~/.claude/settings.json` (global MCP entries), `.claude/GPT54_USAGE.md` (new)

### 0B. Add Overnight Autonomous Safety Hooks (30 min)

**1. No-Ask-Human Hook (PreToolUse, project settings)**

When no human is available, blocks AskUserQuestion and forces autonomous decision-making. Logs all autonomous decisions for morning review.

```json
{
  "matcher": "AskUserQuestion",
  "hooks": [{
    "type": "command",
    "command": "bash -c 'if [ -z \"$CC_ALLOW_QUESTIONS\" ]; then mkdir -p .claude && echo \"[$(date -u +%Y-%m-%dT%H:%M:%SZ)] AUTONOMOUS DECISION NEEDED — see conversation\" >> .claude/pending_decisions.log; echo \"BLOCKED: Owner sleeping. Decide autonomously per CLAUDE.md and SPEC rules. Log uncertainty to .claude/pending_decisions.log\"; exit 1; fi'",
    "timeout": 5
  }]
}
```

Toggle: `export CC_ALLOW_QUESTIONS=1` when human is present.

**2. StopFailure Hook (project settings)**

Captures session state on unexpected termination (API errors, rate limits, disconnects). Ensures no context is lost.

```json
{
  "hooks": {
    "StopFailure": [{
      "hooks": [{
        "type": "command",
        "command": "cd \"$CLAUDE_PROJECT_DIR\" && python3 scripts/session_stop.py 2>/dev/null; echo \"[$(date -u '+%Y-%m-%dT%H:%M:%SZ')] STOP_FAILURE: Session ended unexpectedly\" >> .claude/failure_log.txt",
        "timeout": 15
      }]
    }]
  }
}
```

Files: `.claude/settings.json` (hook entries)

### 0C. Add Knowledge Integrity Hooks (40 min)

These hooks prevent the most dangerous class of error — silent knowledge corruption.

**1. D-023 Metadata Flow on ALL src/ changes (pre-commit)**

Currently `boundary-check.sh` only fires on contracts.py edits. But a function in ANY engine src/ file could drop upstream metadata fields. Extend trigger.

Add to `.claude/hooks/pre-commit-check.sh`:
```bash
# D-023: Verify metadata flow for ANY engine source changes
if [ -n "$MODIFIED_SRC" ]; then
    echo "--- D-023 metadata flow verification ---"
    python3 scripts/verify_metadata_flow.py 2>&1 | tail -5
fi
```

**2. Frozen Source Immutability Guard (pre-commit, BLOCKING)**

Principle 18: frozen sources never change after freezing. Currently no automated enforcement.

Add to `.claude/hooks/pre-commit-check.sh`:
```bash
# BLOCKING: Frozen source files must never be modified
MODIFIED_FROZEN=$(git diff --cached --name-only | grep -E 'library/sources/.*/frozen/')
if [ -n "$MODIFIED_FROZEN" ]; then
    echo "BLOCKED: Frozen source files modified — violates Principle 18 (immutable after freezing)"
    echo "Affected: $MODIFIED_FROZEN"
    BLOCK=1
fi
```

**3. Cross-Engine Contract Auto-Validation (pre-commit, advisory)**

When contracts.py or output-related files change, auto-verify all engine boundaries still align.

Add to `.claude/hooks/pre-commit-check.sh`:
```bash
# ADVISORY: Cross-engine contract validation on boundary file changes
CONTRACTS_CHANGED=$(git diff --cached --name-only | grep -E 'contracts\.py$')
if [ -n "$CONTRACTS_CHANGED" ]; then
    echo "--- Cross-engine contract check ---"
    PYTHONIOENCODING=utf-8 python tools/check_cross_engine_contracts.py 2>&1 | tail -10
fi
```

Files: `.claude/hooks/pre-commit-check.sh`

### 0D. Enhance Session State & Recovery (40 min)

**Enrich `scripts/session_stop.py`:**
Current state capture is basic (git status, branch, NEXT.md head). Add:
- Last test run results (parse pytest output if available)
- Active SPEC section being worked on (deeper NEXT.md parse)
- Uncommitted diff summary (not just file list)
- Time since last commit
- Summary of work done this session (from git log since session start)

**Enhance post-compaction hook:**
After printing invariants, also output:
- Active engine's `CLAUDE.md` first 40 lines (gives full build context)
- Most recent test run timestamp and result
- The specific KNOWN_LIMITATIONS that are being worked on

Files: `scripts/session_stop.py`, `.claude/settings.json` (compact hook command)

### 0E. Set Up GitHub Actions CI/CD (30 min)

Every push should automatically run the full test suite. Currently ALL testing is manual. This catches regressions that slip past pre-commit hooks (e.g., cross-engine failures, slow tests skipped locally).

Create `.github/workflows/test.yml`:
```yaml
name: KR Pipeline Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: '3.13' }
      - run: pip install -r requirements.txt
      - run: python -m pytest engines/source/tests/ engines/normalization/tests/ shared/*/tests/ -v --tb=short
      - run: python scripts/verify_metadata_flow.py
      - run: PYTHONIOENCODING=utf-8 python tools/check_cross_engine_contracts.py
```

Files: `.github/workflows/test.yml` (new)

### Critical Files — Phase 0
- `~/.claude/settings.json` — global MCP cleanup
- `.claude/settings.json` — overnight hooks, StopFailure
- `.claude/hooks/pre-commit-check.sh` — D-023, frozen source, cross-engine hooks
- `scripts/session_stop.py` — richer state capture
- `.github/workflows/test.yml` — CI/CD (new)
- `.claude/GPT54_USAGE.md` — Codex/GPT-5.4 documentation (new)

---

## Phase 1: Knowledge Integrity Scripts (~2 hours)

### 1A. Normalized Package Data Integrity Verifier (90 min)

**New script: `scripts/verify_normalized_integrity.py`**

A comprehensive **data-level** checker. Current hooks catch code-level errors (type mismatches, missing fields). This catches **content-level** errors — the most dangerous class for a knowledge library.

**Five integrity checks:**

1. **Zero-content detection with classification** — 48 books produce zero content units but report status=OK. For each, open the frozen source and classify: `genuinely_empty` (no Arabic text in HTML), `parser_bug` (Arabic text exists but was not extracted — T-1 violation), `structure_anomaly` (unusual HTML the parser can't handle). Any `parser_bug` is a critical finding.

2. **Diacritics drift detection** — Store diacritics counts per-book from the normalization sweep. On re-normalization, flag any book whose count changes by >0.1%. Catches silent diacritics stripping that would change the meaning of Quranic verses, hadith, and scholarly text.

3. **Layer attribution consistency** — For multi-layer books: (a) verify layer segment boundaries don't exceed primary_text length, (b) verify every character in primary_text is attributed to exactly one layer — no gaps, no overlaps. Catches T-2 (attribution corruption — the worst failure mode: studying text believing the wrong person wrote it).

4. **Primary text hash chain** — SHA-256 of each content unit's primary_text. Store in verification manifest. On re-normalization, detect any text changes. Catches T-1 (silent text corruption).

5. **Cross-engine ID referential integrity** — source_id in normalized manifests must be consistent with source format expectations.

**Interface:** Subcommands: `check-package <path>`, `check-corpus <sweep-jsonl>`, `check-drift <old> <new>`
**Output:** ValidationResult-compatible. Exit 1 on FATAL, 0 on clean/warnings.

Files: `scripts/verify_normalized_integrity.py` (new)

### 1B. Silent Exception Handler Audit (30 min)

Found 3 bare `except Exception` handlers in shamela.py and 2 in engine.py that could silently swallow errors.

**The most dangerous:** `shamela.py` around line 458 — `except Exception: continue` in a file reading loop. If an encoding error hits a book with critical scholarly content, the entire file is skipped without ANY log entry. This is T-1 manifested: silent data loss.

**Action:** Add `logger.warning(...)` to every exception handler in fallback paths. Log: exception type, message, file path being processed, and which operation failed. Do NOT change control flow — just add visibility.

This means if a book is being silently skipped, we'll now see it in logs and can investigate.

Files: `engines/normalization/src/normalizers/shamela.py`, `engines/source/src/engine.py`

### Critical Files — Phase 1
- `scripts/verify_normalized_integrity.py` (new)
- `engines/normalization/contracts.py` (read — schema reference)
- `results/normalization_sweep_v2/corpus_sweep.jsonl` (read — baseline data)
- `engines/normalization/src/normalizers/shamela.py` (add logging)
- `engines/source/src/engine.py` (add logging)

---

## Phase 2: Known Limitation Fixes (~2 hours)

Each fix follows the same discipline: read the SPEC rule, understand the limitation, implement the fix, write a targeted test, run the full test suite, commit.

### 2A. Update KNOWN_LIMITATIONS.md: Mark L-011 as FIXED (5 min)

`writer.py:192-203` already implements prev-only orphan recovery with `latest_prev.rename(final_dir)` fallback to `shutil.move()`. The documentation is stale. Mark as RESOLVED with the commit that fixed it.

### 2B. L-009: Guillemet Hadith Distance 50→80 (30 min)

**Problem:** Content flagger misses hadith citations where the narrator attribution (`قال`) is more than 50 characters before the guillemet-quoted text (`«...»`). Long isnad chains (chains of narrators) commonly exceed 50 chars.

**Fix:** `content_flagger.py` line 83: change `{0,50}` to `{0,80}`.

**Validation protocol:**
1. Run content flagger on all 13 core fixtures BEFORE fix. Record hadith flag counts.
2. Apply fix.
3. Re-run. Compare counts. Accept if increase is ≤5% of flagged pages (expected: catching 2-5 additional legitimate hadith citations).

**Test:** Parametrized test with Arabic text where `قال الرسول صلى الله عليه وسلم لأصحابه رضي الله عنهم أجمعين` (65 chars) precedes `«الحديث»`.

**Risk:** LOW — only affects a boolean content flag (has_hadith). Does not modify primary text, layer attribution, or structural markers.

### 2C. L-008: Conditional Reasoning Markers with Position Check (60 min)

**Problem:** `إذا` (if), `لو` (if/would), `إن` (indeed/if) excluded from boundary continuity's argument flow detection because they fire on 15-19% of pages (too noisy).

**Fix:** Re-enable these markers with a **sentence-initial position requirement**. Only trigger when the marker appears after terminal punctuation (`.`, `؟`, `!`, `:`) or at position 0. This filters mid-sentence uses (common in Arabic) while capturing structural argument markers (e.g., `إذا ثبت هذا فنقول:` — "If this is established, then we say:").

**Implementation:**
```python
def _is_sentence_initial(text: str, match_start: int) -> bool:
    """Check if match position follows terminal punctuation or is at text start."""
    if match_start == 0:
        return True
    # Look backward past whitespace for terminal punctuation
    i = match_start - 1
    while i >= 0 and text[i] in ' \t\n\r':
        i -= 1
    if i < 0:
        return True
    return text[i] in '.؟!:'
```

**Tests:** 3 cases:
1. `إذا ثبت هذا فنقول:` at start of text → trigger (sentence-initial)
2. `...والمسألة إذا كانت كذلك...` mid-sentence → NO trigger
3. `.إذا نظرنا في هذه المسألة` after period → trigger

**Risk:** LOW-MEDIUM — boundary continuity is advisory metadata for the passaging engine. Does not affect primary text or layer attribution. But careful testing needed since it affects 15-19% of fiqh/usul pages.

### 2D. L-004: Conjunction Prefixes on Transition Markers (30 min)

**Problem:** Layer detector misses transition markers prefixed with Arabic conjunction letters `و` (and) and `ف` (then). For example, `وقال المصنف:` ("and the author said:") is not detected because the regex expects whitespace before `قال`.

**Fix:** Add optional conjunction prefix `(?:[وف])?` before marker words in the layer detection regex.

**Validation:** Run layer detection on ibn_aqil multi-layer fixture before and after. Count markers found. Accept if increase is 0-5 new markers (expected: catching legitimate prefixed transition markers).

**Test:** Page containing `وقال المصنف رحمه الله:` should detect a SHARH→MATN transition.

**Risk:** MEDIUM — layer detection directly affects T-2 (attribution). However, the fix direction is SAFE: detecting more transition markers means more granular layer boundaries, which is the conservative direction (fewer characters attributed to wrong layer).

### 2E. Full L-001 through L-012 Audit (15 min)

Cross-check every limitation against current code. Mark any that have been silently resolved. Update descriptions with current state.

### Critical Files — Phase 2
- `engines/normalization/KNOWN_LIMITATIONS.md` (update)
- `engines/normalization/src/content_flagger.py` (L-009)
- `engines/normalization/src/boundary_continuity.py` (L-008)
- `engines/normalization/src/layer_detector.py` (L-004)
- `engines/normalization/tests/test_content_flagger.py` (new tests)
- `engines/normalization/tests/test_boundary_continuity.py` (new tests)
- `engines/normalization/tests/test_layer_detection.py` (new tests)

---

## Phase 3: SPEC Quality & Cross-Engine Prep (~1 hour)

### 3A. Normalization SPEC Gap Fixes (30 min)

Three gaps found by analysis:

1. **§5 Validation severity missing:** L-010 documents that division overlap should be WARNING not FATAL, but the SPEC doesn't specify severity for each of the 10 validation checks. Add explicit severity classification (FATAL/WARNING) to each check. This prevents future implementers from crashing on 15.3% of the corpus.

2. **§4.A.5 Bold threshold divergence:** SPEC says 80-char threshold; implementation uses 50 (L-005). Add a calibration note: "Threshold 50 adopted after calibration on 13 fixtures. SPEC value 80 was provisional. See L-005."

3. **§4.B.8 Conditional marker exclusion:** L-008 exclusion is not documented in SPEC. Add note about the sentence-initial fix applied this session.

**Verify after:** `python3 scripts/check_spec_quality.py engines/normalization/SPEC.md`

### 3B. Normalization-to-Downstream Boundary Contract Test (30 min)

**New: `tests/test_normalization_boundary.py`**

Load a real normalized package from fixtures and verify it meets downstream expectations:
- `unit_index` values are contiguous (0, 1, 2, ...)
- `boundary_continuity` is populated for all units
- `structural_markers` is non-empty for at least some pages
- `division_tree` in manifest is valid (all nodes have required fields)
- `text_layers` segments don't overlap and cover full text for multi-layer books
- All required `NormalizedManifest` fields are present and non-null

**Risk:** VERY LOW — read-only test, no engine changes.

### Critical Files — Phase 3
- `engines/normalization/SPEC.md` (3 updates)
- `engines/passaging/contracts.py` (read — downstream expectations)
- `tests/test_normalization_boundary.py` (new)

---

## Phase 4: Documentation & Session Handoff (~30 min)

### 4A. Run Full Test Suite — Zero Regressions
```bash
python -m pytest engines/normalization/tests/ -v --tb=short
python -m pytest engines/source/tests/ -v --tb=short
python -m pytest shared/*/tests/ -q
```

### 4B. Update Documentation
- `KNOWN_LIMITATIONS.md` — Mark fixed items, update descriptions
- `NEXT.md` — Add findings relevant to excerpting SPEC design

### 4C. Create OVERNIGHT_SESSION_REPORT.md
Comprehensive report for morning review:
- Every change made with commit hash
- Fixes applied with before/after data
- New scripts created with purpose and usage
- Environment changes with rationale
- Test results (full suite pass/fail)
- Autonomous decisions made and their reasoning
- Findings for the architect (SPEC gaps, zero-content books, etc.)

---

## Verification Checklist

After ALL changes, before final commit:
1. `python -m pytest engines/normalization/tests/ -v --tb=short` → all pass
2. `python -m pytest engines/source/tests/ -v --tb=short` → all pass
3. `python -m pytest shared/*/tests/ -q` → all pass
4. `python3 scripts/verify_metadata_flow.py` → D-023 clean
5. `python3 scripts/check_spec_quality.py engines/normalization/SPEC.md` → pass
6. `python3 scripts/check_compliance.py --all` → pass
7. `PYTHONIOENCODING=utf-8 python tools/check_cross_engine_contracts.py` → boundary clean
8. New `scripts/verify_normalized_integrity.py` runs without errors

---

## What NOT To Do

1. **Do NOT rewrite consensus module** — Working code with tested consumer. Extend when excerpting needs it.
2. **Do NOT touch source engine core implementation** — 758 tests, 100% corpus sweep. Exception: adding logging to silent exception handlers (visibility, not behavior change).
3. **Do NOT start passaging/excerpting implementation** — SPECs not ready. Architect territory.
4. **Do NOT populate library registries** — Pipeline-first: correct pipeline before population.
5. **Do NOT fix L-005 (bold threshold), L-006 (hashiyah), L-007 (marker-only MATN)** — Require multi-layer fixture data beyond ibn_aqil. Risk of introducing bugs without calibration data.
6. **Do NOT install unnecessary tools** — Environment is already excellent. Surgical fixes, not bloat.
7. **Do NOT make changes that reduce accuracy** — When in doubt, the conservative choice always wins.

---

## Commit Strategy

- One commit per logical change (not per file)
- Commit message: conventional format with clear scope (e.g., `env: add frozen source integrity hook`)
- Commit after each Phase subsection completes
- Push periodically (every 2-3 commits)
- Test suite must pass before each commit (pre-commit hook enforces this)
- Final push after Phase 4 verification checklist passes

---

## Session Continuity Protocol

**Between phases:** Update `.claude/session_state.json` with current phase and progress.

**On compaction:** Post-compaction hook restores invariants. Immediately after:
1. Re-read NEXT.md
2. Re-read this plan file to know where I am
3. Re-read the active engine's CLAUDE.md
4. Continue from where I left off

**On obstacle:** If blocked by a tool failure, permission issue, or unexpected state:
1. Log the issue to `.claude/pending_decisions.log`
2. Skip the blocked subtask
3. Move to the next subtask
4. Return to the blocked item later if the obstacle resolves

**On completion of all phases:** Write comprehensive OVERNIGHT_SESSION_REPORT.md, update NEXT.md with findings, push everything. Do NOT stop working — look for additional improvements.

**If all planned work is done:** Look for more beneficial work:
- Run the new integrity verifier on available data and document findings
- Investigate the 48 zero-content books more deeply
- Review and improve existing quality scripts
- Strengthen test fixtures
- ANY improvement that makes the library more trustworthy
