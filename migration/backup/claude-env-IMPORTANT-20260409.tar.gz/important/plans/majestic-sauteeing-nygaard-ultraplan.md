# Plan: Connect Research Pipeline — Codex → KB → Dashboard

## Context

Three pieces exist independently with no data flow between them:

1. **Codex Orchestrator** (`scripts/overnight_codex_orchestrator.py`) — runs analysis tasks via Codex CLI, writes results to `overnight_codex/results/{task_id}/final_response.json` as JSON packets with `findings` (string arrays), `action_items`, `evidence`, `summary`.
2. **KB Digestion Pipeline** (`scripts/digest_dr.py`) — processes `.md` DR response files into structured `Finding` objects in `overnight_codex/autonomous/knowledge_base/findings.jsonl`. Cross-references, quality gates, generates follow-ups.
3. **Dashboard** (`scripts/autonomous_dashboard/app.py`) — FastAPI app reading KB JSONL files. Already works if the KB has data.

The gap: the orchestrator produces results but never feeds them into the KB. The dashboard reads the KB but has no visibility into Codex run status. There's no single entry point.

```
┌──────────────────┐        ┌─────────────┐        ┌───────────┐
│ Codex Orchestrator│  ???   │  KB / JSONL  │  reads  │ Dashboard │
│ results/*/*.json  │───X───▶│ findings etc │───────▶│ :8000     │
└──────────────────┘        └─────────────┘        └───────────┘
```

## Design

Add two components:

1. **Ingestion bridge** (`scripts/ingest_codex_results.py`) — converts Codex task result packets into KB `Finding` objects
2. **Unified launcher** (`scripts/run_research_pipeline.py`) — single entry point that runs orchestrator → ingestion → dashboard

```mermaid
graph LR
    A[run_research_pipeline.py] -->|1. launch| B[overnight_codex_orchestrator.py]
    B -->|writes| C[results/*/final_response.json]
    A -->|2. launch| D[ingest_codex_results.py]
    D -->|reads| C
    D -->|writes| E[knowledge_base/*.jsonl]
    D -->|calls| F[cross_reference_findings.py]
    A -->|3. launch| G[dashboard :8000]
    G -->|reads| E
```

## Step 1: Ingestion Bridge — `scripts/ingest_codex_results.py`

**New file.** ~120 lines. Scans Codex result directories and converts them to KB findings.

**Data mapping:**
- Each `final_response.json` has `findings: list[str]` — plain text strings
- Each `packet.json` has `task_id`, `name`, `category`, `status`
- Reuse `classify_severity()` and `classify_category()` from `scripts/process_dr_response.py` for heuristic classification
- Generate `Finding` objects with `source_type="codex_task"`, `source_id=task_id`

**Dedup strategy:** Track ingested task IDs in `overnight_codex/autonomous/knowledge_base/codex_ingestion_log.jsonl`. Skip tasks already ingested. Support `--force` to re-ingest.

**Pipeline after ingestion:**
- After writing new findings to `findings.jsonl`, call `cross_reference_findings.cross_reference()` to update contradictions
- Write a `DigestionRecord` to `digestion_log.jsonl` for each ingested task (so it appears on the dashboard's digestion page)

**Key functions:**
```python
def ingest_all(results_dir: Path, force: bool = False) -> int:
    """Scan results, convert to findings, cross-reference. Returns count ingested."""

def _convert_task_to_findings(packet: dict, payload: dict) -> list[Finding]:
    """Convert one Codex result's findings + action_items to Finding objects."""

def _already_ingested(task_id: str) -> bool:
    """Check codex_ingestion_log.jsonl for prior ingestion."""
```

**Reuses:**
- `scripts/autonomous_schemas.py` — `Finding`, `DigestionRecord`, `append_jsonl`, `KB_DIR`, etc.
- `scripts/process_dr_response.py` — `classify_severity()`, `classify_category()`
- `scripts/cross_reference_findings.py` — `cross_reference()`, `persist_cross_references()`

**CLI:**
```bash
python scripts/ingest_codex_results.py                    # Ingest new results only
python scripts/ingest_codex_results.py --force            # Re-ingest all
python scripts/ingest_codex_results.py --results-dir PATH # Custom results path
```

## Step 2: Hook Ingestion into Orchestrator

**File:** `scripts/overnight_codex_orchestrator.py`

**Change:** In the end-of-run block (line ~2582), after `maybe_append_findings()`, add a call to the new ingestion bridge:

```python
maybe_append_findings()
ingest_results_to_kb()   # NEW — converts results to KB findings
```

New function `ingest_results_to_kb()` (same pattern as `maybe_append_findings()`):
```python
def ingest_results_to_kb() -> None:
    """Feed Codex task results into the autonomous KB."""
    try:
        from scripts.ingest_codex_results import ingest_all
        count = ingest_all(RESULTS_DIR)
        if count:
            log_decision("Ingested Codex results into KB", {"count": count})
    except Exception as exc:
        log_decision("Failed to ingest Codex results into KB", {"error": str(exc)})
```

## Step 3: Unified Launcher — `scripts/run_research_pipeline.py`

**New file.** ~100 lines. Three modes:

| Mode | What it does |
|------|-------------|
| `--full` (default) | Run orchestrator → ingest → start dashboard |
| `--ingest-only` | Just ingest existing results into KB (no Codex run) |
| `--dashboard-only` | Just start the dashboard |

```bash
python scripts/run_research_pipeline.py                        # Full pipeline
python scripts/run_research_pipeline.py --hours 4              # Shorter overnight run
python scripts/run_research_pipeline.py --ingest-only          # Just process existing results
python scripts/run_research_pipeline.py --dashboard-only       # Just view dashboard
python scripts/run_research_pipeline.py --skip-dashboard       # Run + ingest, no dashboard
```

**Implementation:**
1. Run `overnight_codex_orchestrator.run_overnight()` with passed args (hours, manifest, etc.)
2. Run `ingest_codex_results.ingest_all()` 
3. Print summary (tasks run, findings ingested, contradictions found)
4. Start uvicorn on port 8000 (foreground, Ctrl+C to stop)

## Step 4: Add Codex Run Status to Dashboard

**File:** `scripts/autonomous_dashboard/store.py` — add `get_codex_run_stats()`:
- Reads `overnight_codex/state.json` for last run status, task counts
- Reads `overnight_codex/.heartbeat` for live run detection

**File:** `scripts/autonomous_dashboard/app.py` — extend `/status` route to include Codex stats.

**File:** `scripts/autonomous_dashboard/templates/status.html` — add a "Codex Run" card showing last run time, tasks completed/failed, whether a run is active.

## Files Modified/Created

| File | Action |
|------|--------|
| `scripts/ingest_codex_results.py` | **CREATE** — ingestion bridge |
| `scripts/run_research_pipeline.py` | **CREATE** — unified launcher |
| `scripts/overnight_codex_orchestrator.py` | **EDIT** — add `ingest_results_to_kb()` call at end-of-run |
| `scripts/autonomous_dashboard/store.py` | **EDIT** — add `get_codex_run_stats()` |
| `scripts/autonomous_dashboard/app.py` | **EDIT** — pass codex stats to `/status` |
| `scripts/autonomous_dashboard/templates/status.html` | **EDIT** — add Codex run card |

## Verification

1. **Unit: ingestion bridge** — create a fake `results/test-task/` with a `packet.json` + `final_response.json`, run `ingest_codex_results.py`, verify `findings.jsonl` has new entries with `source_type="codex_task"`.
2. **Dedup** — run ingestion twice, verify no duplicate findings.
3. **Dashboard** — start dashboard, verify `/findings` shows ingested Codex findings, `/status` shows Codex run stats.
4. **End-to-end** — `python scripts/run_research_pipeline.py --ingest-only` then `--dashboard-only`, verify the full flow.
5. **Orchestrator hook** — after a real or dry-run orchestrator run, verify `ingest_results_to_kb()` is called and logs to `decisions.log`.