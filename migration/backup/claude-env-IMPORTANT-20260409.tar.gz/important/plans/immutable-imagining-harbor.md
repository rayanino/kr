# Plan: Fix compute_page_range IndexError on Split Chunks

## Context

When `split_oversized_division()` splits an oversized chunk into two halves, it correctly
partitions `join_points` between the halves (line 712-727) but copies ALL `physical_pages`
to each half (lines 767, 795). This breaks the invariant `len(physical_pages) == len(join_points) + 1`
that `compute_page_range()` assumes at line 386, causing an `IndexError` crash.

**Affected packages:** ibn_aqil_v1, ext_39_masala, taysir (3 of 5 test packages).

**Baseline:** 590 tests passing, 0 skipped, 0 failed (updated from NEXT.md's 588 — commit 23da2e82 added 2 preamble tests).

## Pre-Implementation Analysis (Complete)

### Finding 1: Partition formula is correct for all cases

The proposed formula:
```python
pages_0 = chunk.physical_pages[:len(jp_0) + 1]
pages_1 = chunk.physical_pages[len(jp_0):]
```

Verified for:
- **Normal 2-way split** (e.g., 10 pages/9 jp, split 4/5): pages_0 gets 5, pages_1 gets 6, overlap at boundary page. Both satisfy invariant.
- **All join_points to one half** (jp_0=9, jp_1=0): pages_0 = all 10 pages, pages_1 = 1 page. Invariant holds.
- **All join_points to other half** (jp_0=0, jp_1=9): pages_0 = 1 page, pages_1 = all 10 pages. Invariant holds.
- **Recursive 3+-way split**: Each recursive call starts with correctly-partitioned data, so the same logic applies. The renumbering at lines 821-839 only touches chunk_id and split_info, not physical_pages.
- **Boundary overlap**: `pages_0[-1] == pages_1[0]` always — intentional per DD-2 (teaching units near the split boundary need the boundary page in both halves).

### Finding 2: Defensive guard is the right clamp

At line 386, the crash happens when `i-1 >= len(offsets)`:
```python
page_start = offsets[i - 1] if i > 0 else 0  # IndexError when i-1 >= len(offsets)
```

The fix `n_pages = min(len(physical_pages), len(offsets) + 1)` correctly limits iteration to pages that have defined character ranges. No code path after the loop depends on having iterated ALL physical_pages — it only builds `overlapping_indices` for page number lookup.

### Finding 3: No other consumers assume length relationships

Grep for `.physical_pages` across the engine shows ONLY:
- `phase1_assembly.py:767,795` — the bug site (copies to splits)
- `phase3_deterministic.py:556` — sole call site: passes to `compute_page_range`
- `contracts.py:90`, `SPEC.md:410,1479` — documentation only
- `test_phase3_deterministic.py:2771` — checks `ExcerptRecord.physical_pages` (the PageRange output, different field)

No other code assumes a specific length for `chunk.physical_pages`. Partitioning will not break anything.

### Finding 4: Test helpers are sufficient

`_make_assembled_chunk(**overrides)` in conftest.py accepts arbitrary overrides including `physical_pages` and `assembly_metadata`. No new helper needed. Pattern from `test_phase3_deterministic.py:470-498` shows how to construct `PhysicalPage` and `JoinPoint` objects.

`_make_oversized_chunk()` does NOT set physical_pages or join_points (only text/layers). New test must construct these explicitly.

### Finding 5: Import additions needed

`test_phase1_split.py` needs: `JoinPoint` from excerpting contracts, `PhysicalPage` + `BoundaryContinuityType` from normalization contracts.

`test_phase3_deterministic.py` already has all needed imports.

## Changes

### Change 1: Partition physical_pages in split_oversized_division

**File:** `engines/excerpting/src/phase1_assembly.py`
**Lines:** 756-811

Before chunk_0 construction (around line 755), add:
```python
# Partition physical_pages to match join_point partitioning.
# jp_0 covers the first N page boundaries -> first N+1 pages.
# The boundary page (index len(jp_0)) is shared between both halves
# so that teaching units near the split boundary get correct page refs.
pages_0 = chunk.physical_pages[:len(jp_0) + 1]
pages_1 = chunk.physical_pages[len(jp_0):]
```

Then at line 767: `physical_pages=chunk.physical_pages` -> `physical_pages=pages_0`
And at line 795: `physical_pages=chunk.physical_pages` -> `physical_pages=pages_1`

### Change 2: Defensive guard in compute_page_range

**File:** `engines/excerpting/src/phase3_deterministic.py`
**Line:** 386

Replace:
```python
for i in range(len(physical_pages)):
```
With:
```python
# Defensive: clamp to pages addressable by join_points.
# After the split fix, len(physical_pages) == len(offsets) + 1 always holds.
# This guard prevents IndexError if a future code path breaks that invariant.
n_pages = min(len(physical_pages), len(offsets) + 1)
for i in range(n_pages):
```

### Change 3: Test 1 — Split chunk physical_pages partitioning

**File:** `engines/excerpting/tests/test_phase1_split.py`

Add imports: `JoinPoint` from excerpting contracts, `PhysicalPage` + `BoundaryContinuityType` from normalization contracts.

Add test method to `TestSplitOversizedDivision`:
- Construct a chunk with 10 physical_pages (pages numbered 50-59), 9 join_points with char_offsets evenly spaced, and oversized text
- Split it and verify:
  - `len(result[i].physical_pages) == len(result[i].assembly_metadata.join_points) + 1` for each chunk
  - Boundary page overlap: `result[0].physical_pages[-1] == result[1].physical_pages[0]`
  - Pages come from correct portions of the original
  - Union covers full original range

### Change 4: Test 2 — compute_page_range with split-like dimensions

**File:** `engines/excerpting/tests/test_phase3_deterministic.py`

Add to `TestPageRange`:
- Create scenario with 40 pages and 39 join_points (correctly-partitioned state)
- Verify correct PageRange output for a unit spanning multiple pages

### Change 5: Test 3 — compute_page_range defensive guard

**File:** `engines/excerpting/tests/test_phase3_deterministic.py`

Add to `TestPageRange`:
- Create scenario where `len(physical_pages) > len(join_points) + 1` (the broken pre-fix state)
- Verify function returns a sensible result instead of crashing

## Files Modified

| File | Change |
|------|--------|
| `engines/excerpting/src/phase1_assembly.py` | Partition physical_pages alongside join_points |
| `engines/excerpting/src/phase3_deterministic.py` | Add defensive loop clamp |
| `engines/excerpting/tests/test_phase1_split.py` | Test 1: split partitioning verification |
| `engines/excerpting/tests/test_phase3_deterministic.py` | Tests 2-3: page range with split dimensions + defensive guard |

## Do NOT touch

- `constituent_unit_indices` sharing (I-AC-4) — correct, must stay shared
- join_points partitioning logic (lines 712-727) — already correct
- Any Phase 2 or Phase 3 code except the defensive guard
- Nothing beyond what's specified here

## Verification

1. `python -m pyright engines/excerpting/src/phase1_assembly.py` — 0 errors
2. `python -m pyright engines/excerpting/src/phase3_deterministic.py` — 0 errors
3. `python -m pytest engines/excerpting/tests/test_phase1_split.py -v --tb=short` — all pass
4. `python -m pytest engines/excerpting/tests/test_phase3_deterministic.py -v --tb=short` — all pass
5. `python -m pytest engines/excerpting/tests/ -v --tb=short` — >= 593 passed (590 baseline + 3 new), 0 failed
6. Mock integration test on all 5 packages (no crash):
```bash
for pkg in experiments/format_diversity_test/packages/*/; do
    echo "=== $(basename $pkg) ==="
    PYTHONPATH=. python scripts/run_integration_test.py --mock --package-path "$pkg" --output-dir "/tmp/mock_$(basename $pkg)" 2>&1 | tail -5
done
```
