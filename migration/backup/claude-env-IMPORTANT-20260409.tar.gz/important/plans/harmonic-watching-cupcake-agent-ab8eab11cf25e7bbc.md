# Evaluator Hardening Plan -- DR Audit Response

## Overview

Harden the creative output evaluator (scripts/overnight_codex_evaluator.py) and close all bypass paths identified by the ChatGPT Deep Research audit. Governing doctrine: **stagnation over corruption** -- near-zero false positives, even at the cost of many false negatives. After hardening, PASS should be rare and earned.

---

## Dependency Graph

Unit 1 (Backlog Bypass Closure) -- no deps, CRITICAL, do first. Unit 2 (Eliminate Provisional) -- no deps, independent. Unit 3 (Evidence Fidelity Dimension) -- no deps, independent. Unit 4 (Harden Strategic Depth) -- no deps, independent. Unit 5 (Tighten Inflation Check) -- no deps, independent. Unit 6 (Raise PASS Thresholds) -- depends on Units 2-5. Unit 7 (Morning Report Fix) -- depends on Unit 1. Unit 8 (Adversarial Test Cases) -- depends on Units 2-6.

**Parallelizable:** Units 1, 2, 3, 4, 5 are fully independent of each other.
**Sequential:** Unit 6 after 2-5. Unit 7 after 1. Unit 8 after 2-6.

---

## Unit 1: Close the Backlog Bypass Path (F-C1)

**Priority:** CRITICAL -- without this, the evaluator is entirely circumventable.

**Root cause:** _write_result_artifacts() at orchestrator line 1991 writes actionable.json and final_response.json BEFORE the evaluator runs at line 614. Three downstream consumers read these artifacts without checking evaluator verdict:

1. sync_backlog_from_artifacts() in scripts/overnight_codex_backlog.py line 391
2. append_findings() in scripts/append_codex_findings.py line 83
3. collect_actionable_items() in scripts/append_creative_findings.py line 47

**Strategy:** Two-pronged fix: (A) stamp artifacts with evaluator verdict so downstream readers can gate on it, and (B) add gating logic to all three consumers.

### Changes

#### File: scripts/overnight_codex_orchestrator.py

**Change 1a: Make _run_creative_evaluator return the verdict.** Currently returns None. Change return type to str or None. Return eval_result.verdict on success, None on failure.

**Change 1b: Write evaluator verdict sidecar.** After the evaluator runs in _finalize_task_result, write result_dir/evaluator_verdict.json containing verdict, evaluator_total, and idea_class_evaluator. Sidecar avoids modifying the already-written final_response.json.

**Change 1c: Gate actionable.json writing on evaluator verdict.** Extract actionable.json write from _write_result_artifacts lines 1187-1189 into a new helper _write_actionable_artifacts(task, result_dir, payload). Call from _finalize_task_result only when verdict is pass.

#### File: scripts/overnight_codex_backlog.py

**Change 1d: Gate _upsert_result_action_items on evaluator verdict.** In sync_backlog_from_artifacts() line 391, check evaluator_verdict.json sidecar before calling _upsert_result_action_items. If exists and verdict != pass, skip. If missing and task_id starts with creative-, skip (stagnation over corruption). Non-creative tasks pass through unchanged.

#### File: scripts/append_codex_findings.py

**Change 1e:** Same sidecar-check pattern before processing each actionable.json.

#### File: scripts/append_creative_findings.py

**Change 1f:** Same sidecar-check pattern before processing each actionable.json.

---

## Unit 2: Eliminate Provisional Verdict (F-C5)

### Changes in scripts/overnight_codex_evaluator.py

**Change 2a:** Remove elif branch at lines 472-475 that sets verdict=provisional. Logic becomes: no rejection_reasons then pass, else reject.

**Change 2b:** Update route_to_findings: check verdict != pass (defense-in-depth).

**Change 2c:** Update verdict comment at line 110: reject or pass only.

### Test impact

- test_golden_payload_passes: assert verdict == pass
- test_partial_payload_provisional_or_reject: assert verdict == reject

---

## Unit 3: Add Evidence Fidelity Dimension (F-C4)

### Changes in scripts/overnight_codex_evaluator.py

**Change 3a: Add SYMBOL_REGISTRY constant.** Static dict mapping engine name to frozenset of class names from contract files (~188 total). Covers: excerpting (29), taxonomy (39), normalization (38), synthesis (41), source (41).

**Change 3b: Add _extract_claimed_symbols(text) helper.** Regex for CamelCase identifiers filtered against registry.

**Change 3c: Add check_evidence_fidelity(payload) returning DimensionResult.** Scoring: 0 claims = score 2 (neutral), all verified = 4, 1 fabricated = 1, 2+ fabricated = 0. Pass threshold: >= 2.

**Change 3d:** Wire into GOLDEN_DIMENSIONS and evaluate_creative_output. Content max becomes 24. Update scaling ratio to 32/24.

**Change 3e:** Update classification thresholds: benchmark_grade >= 20, major >= 15.

### Test impact

- Fix golden payload TaxonomyNode to TreeNode in secondary_required_changes
- Add evidence_fidelity to test_result_has_all_dimensions expected set

---

## Unit 4: Harden Strategic Depth (F-H1, F-H2)

### Changes in scripts/overnight_codex_evaluator.py

**Change 4a: Expand SHALLOW_PATTERNS (+6 patterns).** Field propagation, Caching, Observability, Hashing, Synonym bypass for field addition, Ledger/store.

**Change 4b: Expand vague_risk_patterns (+5 patterns).** Backward-compat hedging, Generic complexity, Unspecified dependency, Handwave, Time hedging.

**Change 4c: Single-engine scope cap.** If fewer than 2 engines mentioned, cap strategic_depth score at max 2.

---

## Unit 5: Tighten Inflation Check (F-C2)

### Changes in scripts/overnight_codex_evaluator.py

**Change 5a:** MAX_INFLATION_DELTA: 8 to 4.

**Change 5b: Per-dimension inflation penalty.** 3 checked dimensions: self=4 and evaluator<=1 adds +4 each. 5 unchecked dimensions: self=4 adds +1 each.

**Change 5c:** Scoring tiers: delta<=0 gives score 4, delta<=4 gives score 2, else score 0.

**Change 5d:** Dynamic scaling: int(evaluator_total * 32 / (len(GOLDEN_DIMENSIONS) * 4)).

### Golden payload verification: delta ~0, PASS.

---

## Unit 6: Raise PASS Thresholds (F-C3)

**Depends on:** Units 2-5.

repo_grounding: >= 2 to >= 3. structural_completeness: stays >= 3. strategic_depth: >= 2 to >= 3. concreteness: >= 2 to >= 3. inflation_check: delta <= 8 to <= 4. evidence_fidelity: >= 2.

Golden payload scores 4/4 on all dimensions. PASS verified.

---

## Unit 7: Morning Report Fix (F-H5)

**Depends on:** Unit 1.

**Change 7a:** Return dict from _run_creative_evaluator containing verdict and idea_class_evaluator.

**Change 7b:** In _finalize_task_result, override result.idea_class with evaluator class.

---

## Unit 8: Adversarial Bypass Test Cases

**Depends on:** Units 2-6.

**Change 8a-c:** Add 3 adversarial bypass payloads: bypass_a_granularity_tagging, bypass_b_provenance_ledger, bypass_c_taxonomy_accelerator.

**Change 8d:** TestAdversarialBypasses class, 3 tests asserting verdict == reject.

**Change 8e:** Update existing assertions for no-provisional and evidence_fidelity.

**Change 8f:** Fix golden payload TaxonomyNode to TreeNode.

Verification: 3 adversarial REJECT, golden PASS, 25 evaluator + 39 runtime = 64 tests.

---

## Implementation Sequence

Phase 1 (parallel): Units 1, 2, 3, 4, 5. Phase 2: Unit 6. Phase 3: Units 7, 8. Phase 4: Full regression run.

## Risk Register

Golden payload breaks: All 6 scores verified at 4/4. Symbol registry stale: Code-level constant. Shallow patterns false-positive: Structural indicators, review after week 1. Sidecar missing on crash: Skip = stagnation over corruption. Scaling ratio drift: Dynamic formula. 61 tests regress: Full suite after each unit.

## Files Modified

Primary: scripts/overnight_codex_evaluator.py (Units 2-6), scripts/overnight_codex_orchestrator.py (Units 1, 7), tests/test_overnight_codex_evaluator.py (Unit 8). Secondary: scripts/overnight_codex_backlog.py (Unit 1), scripts/append_codex_findings.py (Unit 1), scripts/append_creative_findings.py (Unit 1).
