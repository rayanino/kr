# Overnight Hifz Module Enhancement Plan

## Context

The QuranApp is a fork of quran.com-frontend-next with a comprehensive Hifz memorization module built across 5 phases. The foundation is solid (FSRS scheduling, IndexedDB persistence, 12 hooks, 8 services, 5 pages, 40+ components). What's missing are the **smart, polished features** that transform it from a tracking tool into an intelligent memorization companion.

**User profile**: Planning ahead — building for all Hifz levels. Wants highest quality, creative freedom granted.

**Priorities**: (1) Memorization workflow with audio integration (critical), (2) Tasteful gamification, (3) Polish everything.

**Git strategy**: One commit per completed feature on the `production` branch.

**Execution method**: Hybrid — direct sequential execution from this plan (no GSD overhead) with file-based state tracking in `.planning/PROGRESS.md` for resilience against context compression.

---

## Phase 0: Environment Setup

### Goal
Prepare the optimal environment for autonomous development at the highest quality standard.

### Steps

**A. Add test-on-commit safety hook**
Configure Husky to run `yarn test` before each commit alongside existing lint-staged. This catches breakage before it gets committed.

**B. Verify dev server**
- Start dev server (`yarn dev`) and confirm it compiles cleanly
- Verify existing Hifz pages load correctly (`/hifz`, `/hifz/review`, `/hifz/test`, `/hifz/progress`, `/hifz/settings`)

**C. Verify test suite**
- Run `yarn test` to confirm all existing tests pass
- Run `yarn lint` to confirm clean baseline
- Note any pre-existing failures to avoid false alarms

**D. Create progress tracking**
- Create `.planning/PROGRESS.md` for state persistence across context compression

**E. Save autonomous session memory**
- Write to memory system: what I'm doing, plan file location, progress file location, key rules
- This persists across conversations — if session dies, new session can pick up

**F. Set up self-continuation**
- Verify I can re-read this plan file and PROGRESS.md at any time
- Confirm subagent delegation works (test launching a simple agent)
- Establish the never-stop loop

### Environment Assessment
**Already excellent (47 agents, 15+ plugins, comprehensive hooks) — no additional tools needed.**

Tools I'll actively use during execution:
- `code-simplifier` agent — after each feature to refine code
- `code-reviewer` agent — after each feature to catch issues
- `frontend-design` skill — for all UI work (distinctive, production-grade design)
- `Context7` MCP — for up-to-date library documentation
- `Serena` MCP — for semantic code navigation and precise edits
- Husky + lint-staged — automatic quality gates on every commit

---

## Feature 1: Stabilize & Commit Baseline

### Goal
Clean baseline — commit existing SSR fixes, verify dev server.

### Steps
1. Verify dev server compiles cleanly (`yarn dev`)
2. Navigate to `/2` (Al-Baqarah) — confirm no hydration errors
3. Navigate to `/hifz` — confirm dashboard renders
4. Commit the two modified files:
   - `src/components/QuranReader/TranslationView/ActionButtons.tsx`
   - `src/components/QuranReader/TranslationView/TranslationViewCell.tsx`
5. Commit message: `fix: use dynamic imports for Hifz components to prevent SSR hydration errors`

### Verification
- Dev server running without errors
- No console warnings on surah pages
- `/hifz` dashboard loads

---

## Feature 2: Hifz Onboarding Wizard 
### Goal
Guided first-time setup for new Hifz users — welcoming, clear, sets up their HifzPlan.

### Architecture
- **Route**: `/hifz/setup` (dedicated page, not modal — wizard has 5 steps, too much for modal)
- **State**: Local React state for in-progress form; saves to IndexedDB + Redux on final confirmation
- **Detection**: Dashboard checks if plan exists; shows "Get Started" card if not

### Files to Create
```
src/pages/hifz/setup.tsx                    -- Page shell (getStaticProps for chaptersData)
src/components/Hifz/OnboardingWizard/
  OnboardingWizard.tsx                      -- Container with step state machine
  OnboardingWizard.module.scss
  steps/
    WelcomeStep.tsx                         -- Bismillah welcome + how the system works
    SurahSelectStep.tsx                     -- Choose starting surah + verse
    DailyGoalStep.tsx                       -- Daily verses (1-20), level presets
    ScheduleStep.tsx                        -- Active days, SabaqPara window, Manzil juz
    ConfirmStep.tsx                         -- Summary + estimated completion + "Start Memorizing"
```

### Files to Modify
- `src/utils/navigation.ts` — add `HIFZ_SETUP_URL = '/hifz/setup'`
- `src/components/Hifz/HifzDashboard/HifzDashboard.tsx` — add first-time-user "Get Started" card at top when no plan exists
- `src/components/Hifz/HifzDashboard/DailyScheduleCard/DailyScheduleCard.tsx` — change empty-state link from `HIFZ_SETTINGS_URL` to `HIFZ_SETUP_URL`

### Key Details
- Wizard state: `{ step, currentSurah, currentVerse, dailyNewVerses, sabaqParaDays, manzilJuzCount, activeDays }`
- Defaults: dailyNewVerses=5, sabaqParaDays=7, manzilJuzCount=1, activeDays=[0-6], currentSurah=1
- SurahSelectStep: suggest Juz 30 (Surah 78+), Al-Baqarah, Al-Kahf as common starting points
- DailyGoalStep: Beginner(3), Intermediate(5), Advanced(10), Custom presets
- ConfirmStep: calculate estimated completion date: `remainingVerses / (dailyNewVerses * activeDaysPerWeek / 7)`
- On confirm: `db.put('plan', plan, 'current')` then `dispatch(setPlan(plan))` then `router.push('/hifz')`

### Verification
- Navigate to `/hifz/setup` — wizard renders with step indicator
- Complete all 5 steps — plan saved, redirected to dashboard
- Dashboard shows schedule based on new plan
- Revisit `/hifz` without plan — "Get Started" card appears

---

## Feature 3: Audio-Assisted Memorization 
### Goal
Listen-Practice-Test cycle that integrates the existing audio player with Hifz — the core memorization workflow.

### Architecture

**Core Hook** (`src/hooks/hifz/useAudioMemorization.ts`):
- useReducer-based state machine: `IDLE → LISTEN → PRACTICE → TEST → (next verse or END)`
- Bridges XState audio machine (via `AudioPlayerMachineContext`) with Hifz Redux state
- Tracks per-verse metrics: listenCount, hintsUsed, audioHintsUsed
- No new Redux slice needed — session state is transient

**Reducer State:**
```typescript
{
  phase: 'IDLE' | 'LISTEN' | 'PRACTICE' | 'TEST';
  verseQueue: string[];
  currentIndex: number;
  listenCount: number;
  practiceAudioHints: number;
  revealedWordCount: number;
  totalWordCount: number;
  verseMetrics: Array<{ verseKey, listenCount, hintsUsed, audioHintsUsed, rating }>;
  sessionStartedAt: number | null;
}
```

**Hook Return:**
```typescript
{
  phase, currentVerseKey, verseQueue, currentIndex, listenCount, hintsUsed,
  revealedWordCount, totalWordCount, isAudioPlaying, canReplayAudio, progressPercent,
  startSession, advancePhase, replayAudio, revealNextWord, revealAllWords,
  rateAndContinue, setPlaybackRate, endSession
}
```

### Files to Create
```
src/hooks/hifz/useAudioMemorization.ts                             -- Core orchestration hook
src/components/Hifz/AudioMemorization/
  AudioMemorizationSession.tsx + .module.scss                       -- Full session container
  PhaseIndicator.tsx + .module.scss                                 -- LISTEN/PRACTICE/TEST step indicator
  VerseAudioCard.tsx + .module.scss                                 -- Phase-aware verse display
  ProgressiveWordReveal.tsx + .module.scss                          -- Word-by-word reveal
  SessionSummary.tsx + .module.scss                                 -- End-of-session report
```

### Files to Modify
- `src/components/Hifz/MemorizationMode/MemorizationControls/MemorizationControls.tsx` — add "Audio Memorize" button in the controls toolbar (new button in the first `group` div)
- `src/components/Hifz/MemorizationMode/HiddenVerse/HiddenVerse.tsx` — add optional `revealMode: 'full' | 'progressive'` and `revealedWordCount` props; render `ProgressiveWordReveal` when `progressive`
- `src/components/Hifz/ReviewQueue/ReviewCard/ReviewCard.tsx` — add optional "Listen First" audio button before the reveal
- `src/components/QuranReader/TranslationView/TranslationViewCell.tsx` — conditionally render inline phase controls when audio memorization targets this verse

### Data Flow
```
"Audio Memorize" clicked → startSession(verseKeys)
  → Phase = LISTEN: audio plays (PLAY_AYAH event to XState), text visible
  → User replays as needed (INCREMENT_LISTEN)
  → "Practice" clicked → Phase = PRACTICE: text hidden (hideVerse Redux), audio hints available
  → User tries reciting, can reveal words one-by-one or replay audio
  → "Test" clicked → Phase = TEST: no hints, FSRS rating buttons shown
  → User rates → reviewVerse() to IndexedDB, NEXT_VERSE
  → Repeat for each verse → END: show SessionSummary
```

### Audio Integration Points (existing infrastructure, no changes to XState machine)
- `audioService.send({ type: 'PLAY_AYAH', surah, ayahNumber })` — play verse
- `audioService.send({ type: 'TOGGLE' })` — pause/resume
- `audioService.send({ type: 'SET_PLAYBACK_SPEED', playbackRate })` — slow down
- Subscribe to `state.matches('VISIBLE.AUDIO_PLAYER_INITIATED.ENDED')` — detect playback end
- Word-level audio from `playWordByWordAudio` in `src/components/dls/QuranWord/playWordAudio.ts`

### Verification
- From QuranReader with memorization mode: click "Audio Memorize" — session starts
- LISTEN phase: audio plays, text visible, replay button works
- PRACTICE phase: text hidden, word-by-word reveal works, audio hint works
- TEST phase: no hints available, FSRS rating buttons shown
- Rate and move to next verse — flow is smooth
- Session end: summary shows metrics (verses reviewed, hints used, time)
- From ReviewCard: "Listen First" button plays verse audio before rating

---

## Feature 4: Enhanced Daily Review 
### Goal
Transform the flat review queue into a structured 3-block journey (Sabaq → SabaqPara → Manzil) with block completion celebrations.

### Architecture

**New Hook** (`src/hooks/hifz/useStructuredReview.ts`):
- Extends `useHifzReview` pattern but organizes cards by `ScheduleCategory`
- Returns: `{ currentBlock, currentCard, blockProgress, overallProgress, reviewCurrent, isBlockComplete, isDayComplete, moveToNextBlock }`
- Loads today's schedule via `useTodaySchedule`, fetches records per block
- Filters to due cards using `getDueCards`

### Files to Create
```
src/hooks/hifz/useStructuredReview.ts                                    -- 3-block structured review
src/components/Hifz/ReviewQueue/BlockHeader/BlockHeader.tsx + .module.scss -- Block name + progress
src/components/Hifz/ReviewQueue/BlockCompletion/BlockCompletion.tsx + .module.scss -- Block done celebration
src/components/Hifz/ReviewQueue/DailyCompletion/DailyCompletion.tsx + .module.scss -- All blocks done
```

### Files to Modify
- `src/components/Hifz/ReviewQueue/ReviewQueue.tsx` — rewrite to use structured 3-block flow
- `src/components/Hifz/ReviewQueue/ReviewQueue.module.scss` — updated styles
- `src/components/Hifz/ReviewQueue/ReviewCard/ReviewCard.tsx` — add verse context (surah name from chaptersData), compute dynamic FSRS intervals (replace hardcoded "1d", "3d", "10d", "30d" with actual `hifzFSRS.next()` preview)
- `src/components/Hifz/ReviewQueue/ReviewCard/ReviewCard.module.scss`

### Key Details
- ReviewQueue phases: `'reviewing'` → `'block-complete'` → `'reviewing'` (next block) → ... → `'day-complete'`
- BlockHeader: category name, color badge, progress bar (e.g., "Sabaq 3/8 reviewed")
- BlockCompletion: category-specific message ("Sabaq Complete!"), block stats, "Continue to SabaqPara" button
- DailyCompletion: "Ma sha Allah! Today's review is complete!" + total stats + streak
- ReviewCard enhancement: show surah name, compute real FSRS intervals by calling `hifzFSRS.next(card.fsrsCard, now, rating)` for each rating option
- Edge case: if a block has no due cards, auto-skip to next block

### Verification
- Navigate to `/hifz/review` — see BlockHeader with first block (Sabaq)
- Complete all Sabaq cards — see BlockCompletion celebration
- Click continue — SabaqPara block starts
- Complete all blocks — DailyCompletion with full stats
- Review intervals on rating buttons reflect actual FSRS computation (not hardcoded)

---

## Feature 5: Progress Analytics & Predictions 
### Goal
Add an analytics page with memory strength heatmap, completion predictions, weak ayah identification, and weekly summary.

### Architecture
- **Route**: `/hifz/analytics` (new page, separate from existing `/hifz/progress` which shows factual tables)
- **Service**: `src/utils/hifz/analyticsService.ts` for computation functions
- **Hook**: `src/hooks/hifz/useHifzAnalytics.ts`

### Files to Create
```
src/pages/hifz/analytics.tsx
src/utils/hifz/analyticsService.ts                                       -- getWeakAyahs, computeCompletionProjection, computeMemoryStrengthByJuz, computeWeeklySummary
src/hooks/hifz/useHifzAnalytics.ts                                       -- Load all analytics data
src/components/Hifz/Analytics/
  HifzAnalytics.tsx + .module.scss                                        -- Main layout (4 sections)
  MemoryStrengthGrid/MemoryStrengthGrid.tsx + .module.scss                -- 6x5 juz heatmap (green/yellow/red/gray)
  CompletionProjection/CompletionProjection.tsx + .module.scss            -- Estimated completion card
  WeakAyahs/WeakAyahs.tsx + .module.scss                                 -- Lowest-stability verses table (top 10)
  WeeklySummary/WeeklySummary.tsx + .module.scss                          -- CSS-only bar chart, 8 weeks
```

### Files to Modify
- `src/utils/navigation.ts` — add `HIFZ_ANALYTICS_URL = '/hifz/analytics'`
- `src/components/Hifz/HifzDashboard/HifzDashboard.tsx` — add link/card to analytics page

### Key Details
- MemoryStrengthGrid: 30 cells (one per juz), color by avg FSRS stability. Hover shows detail.
- CompletionProjection: `(6236 - versesStarted) / (dailyNewVerses * activeDaysPerWeek / 7)` = days remaining
- WeakAyahs: sort all records by `fsrsCard.stability` ascending, take 10. Show verseKey, surah name, stability, last reviewed, next due. Each row links to verse in reader.
- WeeklySummary: CSS-only bars (no chart library) — verses reviewed per week for last 8 weeks. Current vs previous week comparison.
- All sections handle empty state gracefully

### Verification
- Navigate to `/hifz/analytics` — all 4 sections render
- Juz heatmap shows correct colors (gray for unstarted)
- Completion projection shows reasonable date
- Weak ayahs table sorted by stability ascending
- Weekly summary bars correspond to actual session data

---

## Feature 6: Achievement & Milestone System 
### Goal
Tasteful, respectful gamification — celebrate consistency, progress, and mastery.

### Architecture
- **Storage**: localStorage (not IndexedDB — avoids schema version bump; achievement data is tiny and derivable from primary data)
- **Registry**: Static definitions in `src/utils/hifz/achievements.ts`
- **Hook**: `src/hooks/hifz/useAchievements.ts` — checks achievements against current data, detects newly earned ones

### Achievement Categories

**Consistency** (streak milestones):
- `streak-3`: "Getting Started" — 3-day streak
- `streak-7`: "Week Warrior" — 7-day streak
- `streak-30`: "Monthly Master" — 30-day streak
- `streak-100`: "Century of Devotion" — 100-day streak

**Progress** (memorization milestones):
- `verses-10`: "First Steps" — 10 verses memorized
- `verses-100`: "Steadfast Learner" — 100 verses memorized
- `juz-1`: "First Juz" — Complete 1 juz
- `surah-fatiha`: "The Opening" — Complete Al-Fatiha
- `juz-amma`: "Juz Amma" — Complete Juz 30

**Mastery** (quality milestones):
- `perfect-review-5`: "Sharp Memory" — 5 Easy ratings in a row
- `zero-due`: "All Caught Up" — 0 cards due (min 50 cards)
- `full-day`: "Complete Day" — All 3 blocks completed

### Files to Create
```
src/utils/hifz/achievements.ts                                          -- Registry + check logic
src/hooks/hifz/useAchievements.ts                                       -- Load/check/detect hook
src/components/Hifz/Achievements/
  AchievementGallery/AchievementGallery.tsx + .module.scss               -- Grid of all achievements
  AchievementCard/AchievementCard.tsx + .module.scss                     -- Single achievement
  AchievementToast/AchievementToast.tsx + .module.scss                   -- Popup on earn
```

### Files to Modify
- `types/Hifz.ts` — add `AchievementCategory` enum + `Achievement` interface
- `src/components/Hifz/HifzDashboard/HifzDashboard.tsx` — add achievements summary section (3 most recent earned + "View All")

### Key Details
- On dashboard mount: `checkAchievements(stats, plan, sessions)` → compare with localStorage → detect newly earned
- AchievementCard: earned = full color + date; unearned = grayed + progress bar toward threshold
- AchievementToast: gold/amber accent, slide-up animation, auto-dismiss 5s
- Gallery shows all achievements grouped by category

### Verification
- Dashboard shows achievements summary section
- With test data: "First Steps" shows as earned when 10+ verses memorized
- Toast appears on newly earned achievement
- Gallery shows earned in color, unearned grayed with progress

---

## Feature 7: UI Polish & Refinements 
### Goal
Sweep across all Hifz components — skeletons, empty states, transitions, consistent styling.

### Shared Components to Create
```
src/components/Hifz/shared/Skeleton/Skeleton.tsx + .module.scss          -- Animated placeholder bar
src/components/Hifz/shared/EmptyState/EmptyState.tsx + .module.scss      -- Icon + message + CTA
```

### Changes

**A. Loading Skeletons** — Replace `{t('loading') || 'Loading...'}` text in:
- ProgressOverview, StreakCard, DailyScheduleCard, HifzProgress, ReviewQueue

**B. Better Empty States** — Apply EmptyState component to:
- ReviewQueue (no reviews due), HifzProgress (no data), DailyScheduleCard (no plan), SelfTestView (no verses)

**C. Smooth Transitions** — CSS transitions for:
- Card reveals (opacity + translateY), review card transitions (fade), progress bar changes (width transition)

**D. Consistent Card Styling** — Standardize across all card components:
- `border-radius: 12px`, `var(--color-background-elevated)`, `var(--shadow-small)`, `var(--spacing-large-px)` padding

**E. Status Color Variables** — Define Hifz CSS custom properties:
```scss
--hifz-memorized: #22c55e;
--hifz-learning: #eab308;
--hifz-needs-review: #ef4444;
--hifz-sabaq: #22c55e;
--hifz-sabaq-para: #eab308;
--hifz-manzil: #3b82f6;
```

**F. Mobile Responsive** — Review with `@include breakpoints.smallerThanTablet`:
- ReviewCard rating buttons stack on small screens
- Juz grid collapses to 2 columns

### Verification
- All loading states show skeleton animations
- Empty states have clear icons and CTAs
- Transitions smooth on state changes
- Card styling consistent across all views
- Status colors match across all components
- Mobile (375px) renders without overflow

---

## Execution Strategy: Quality-First Sequential

### Guiding Principle
**Quality is the only metric.** No time pressure, no budget constraints. Every component should feel lovingly crafted for someone studying the Quran. Each feature is built to production-grade quality with comprehensive testing, thoughtful design, and multiple review passes.

### Self-Continuation Protocol
**The user is asleep. NEVER stop working. NEVER ask questions. NEVER wait for input.**
- After completing a feature → immediately start the next one
- After completing all 7 features → identify and implement additional improvements
- After each improvement → identify the next one
- If blocked on something → solve it yourself or skip and come back later
- If a decision is needed → make it yourself (user granted full authority)
- **CRITICAL: Never use /clear. Never restart. Never stop.**

### Session Resilience (50+ hours, 1M context)
- Claude Code compresses (not deletes) old messages as context fills
- Compression summarizes — detail is lost but direction preserved
- After each commit, update `.planning/PROGRESS.md` with state so compressed context can re-orient
- All features after #1 are independent — order can change if needed

### Context Management Strategy
**The 1M context window WILL fill over 50 hours.** Plan for this:

1. **Be concise** — Don't over-explain in responses. Save context for code.
2. **Use subagents aggressively** — Subagents get FRESH context (up to 200K each). Delegate:
   - `code-simplifier` agent — runs in its own context, returns only results
   - `code-reviewer` agent — runs in its own context, returns only findings
   - `frontend-design` via Skill — loaded as needed, not occupying main context
3. **Re-read files only when needed** — Don't re-read files that haven't changed
4. **This plan file is the source of truth** — If context is compressed, re-read this file to re-orient
5. **PROGRESS.md is the state tracker** — Always check it when unsure what's been completed
6. **Git log is the history** — `git log --oneline` tells me what I've committed

### Memory Persistence Strategy
**Phase 0 MUST save a memory about this autonomous session** to the memory system at:
`C:\Users\Rayane\.claude\projects\C--Users-Rayane-desktop-QuranApp\memory\`

Memory should contain:
- What I'm doing (autonomous development session, quality-first)
- Where to find the plan (this file path)
- Where to find progress (`.planning/PROGRESS.md`)
- Key rules: never stop, never ask user, never /clear
- User preferences: quality only metric, tasteful gamification, audio is critical

This memory persists across ALL conversations. If this conversation somehow ends and a new one starts, the memory tells the new session what's happening.

### Per-Feature Quality Workflow
For EVERY feature, follow this cycle:

```
1. THINK      — Re-read relevant existing code. Understand the integration points deeply.
2. DESIGN     — Use frontend-design skill for all UI work (distinctive, production-grade)
3. TEST FIRST — Write tests before implementation (TDD via Vitest for hooks/services)
4. IMPLEMENT  — Build the feature following existing codebase patterns
5. SIMPLIFY   — Run code-simplifier agent to refine all new code
6. REVIEW     — Run code-reviewer agent to catch quality/security/performance issues
7. FIX        — Address all review findings
8. VERIFY     — yarn test + yarn lint + dev server compilation + manual page check
9. COMMIT     — Only when everything passes and code is clean
10. TRACK     — Update .planning/PROGRESS.md with completion state
```

### Quality Standards for This App

**Code Quality:**
- Follow ALL existing ESLint rules (max 30 lines/function, max 150 lines/file)
- Full TypeScript types — no `any`, proper interfaces for all props
- useCallback/useMemo where appropriate for performance
- Proper error handling with user-friendly fallbacks
- Event logging via existing `logButtonClick` / `logValueChange` patterns

**UI/UX Quality:**
- Use `frontend-design` skill for every UI component — distinctive, not generic
- RTL-aware (use CSS logical properties: `inline-size` not `width`, `inset-inline` not `left`)
- Accessible (ARIA labels, keyboard navigation, screen reader support)
- Responsive (mobile-first, tested at 375px and 1024px+)
- Consistent with existing design language (CSS variables, SCSS modules, existing components)
- Appropriate aesthetic for Quran study — calming, respectful, spiritually fitting

**Testing:**
- Unit tests for all hooks and service functions (Vitest)
- Test edge cases: empty data, first-time user, offline, large datasets
- Follow existing test patterns in the codebase

**Spiritual Context:**
- Achievement names and messages should be respectful and encouraging
- UI copy should be warm but not trivializing
- Colors and design should feel appropriate for sacred text study
- Consider Islamic design elements (geometric patterns, calligraphic accents) where tasteful

### Feature Sequence

| # | Feature | Commit Message |
|---|---------|----------------|
| 0 | Environment setup | (no commit) |
| 1 | Stabilize baseline | `fix: use dynamic imports for Hifz SSR hydration` |
| 2 | Onboarding wizard | `feat: add Hifz onboarding wizard for first-time setup` |
| 3 | Audio-assisted memorization | `feat: add audio-assisted memorization with listen-practice-test cycle` |
| 4 | Enhanced daily review | `feat: restructure review into 3-block guided journey` |
| 5 | Progress analytics | `feat: add Hifz analytics with predictions and memory heatmap` |
| 6 | Achievement system | `feat: add tasteful achievement and milestone system` |
| 7 | UI polish | `style: add skeletons, empty states, transitions, and consistent styling` |

### Beyond Feature 7: Continuous Improvement (infinite time)
After completing all 7 planned features, **do not stop**. Continue identifying and implementing improvements:

**High-value additions to explore:**
- Notification/reminder system for daily review
- Enhanced accessibility audit (screen reader, keyboard navigation)
- Performance optimization (Web Workers for heavy computation, lazy loading)
- Comprehensive test coverage for all Hifz hooks and services
- Storybook stories for all new components
- i18n keys for new strings (currently using English fallbacks)
- Dark mode polish for all Hifz components
- PWA enhancements (offline Hifz data, background sync)
- Verse tafsir integration for deeper study context
- Social/sharing features (share progress milestones)
- Data visualization improvements
- Export/share progress reports

**Decision protocol for unplanned features:**
- If it makes the app a better Quran study companion → do it
- If it requires external APIs/services → implement with graceful fallbacks
- If it touches core app architecture → be extra careful, test thoroughly
- If unsure about scope → start small, iterate

### State Tracking
After each feature commit, write to `.planning/PROGRESS.md`:
```
## Feature N: [name] ✅
- Committed: [hash]
- Files created: [list]
- Files modified: [list]
- Tests added: [list]
- Review findings addressed: [summary]
- Next: Feature N+1
```

### Error Recovery
- If dev server crashes: restart with `yarn dev`
- If a feature hits unexpected complexity: take the time to solve it properly (no rushing, no skipping)
- If tests fail: fix the failure before proceeding (never commit broken tests)
- If context seems compressed: read `.planning/PROGRESS.md` and this plan file to re-orient

### Quality Gates (applied to every commit)
- Pre-commit: lint-staged (ESLint fix + Stylelint fix + Prettier)
- Pre-commit: `yarn test` (to be added as safety hook)
- Post-commit: verify TypeScript compilation via dev server
- Code patterns: follow existing codebase conventions (hooks, SCSS modules, Redux Toolkit)
- No new dependencies unless absolutely necessary
- `code-simplifier` agent after each feature
- `code-reviewer` agent after each feature
