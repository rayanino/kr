---
title: "Taxonomy Engine Deep Build — From Shallow Trees to Encyclopedic Knowledge Structure"
type: feat
status: active
date: 2026-04-07
---

# Taxonomy Engine Deep Build

## Overview

The taxonomy engine is 75% built (148 tests, all deterministic infrastructure working) but faces a fundamental gap: the current science trees (~150-200 leaves per science) are far too shallow for the owner's vision. The owner wants **maximum granulation** — topics broken down to content-type level (definition → school → opinion), with proof/rule/example separation, and confidence flags on every placement. This plan charts the full path from current state to a production-ready taxonomy engine with deep encyclopedic trees.

## Problem Frame

The owner's study method requires opening a specific topic leaf and seeing what all his books say about that *exact* sub-topic. Current trees have leaves like `المفعول_به` (the direct object) — but the owner expects to navigate deeper: `المفعول_به → تعريف → اصطلاحي → الجمهور`. The current engine code can handle any tree depth, but:
1. The trees themselves need to be rebuilt much deeper
2. The LLM placement prompts need to navigate deeper structures
3. The placement needs to classify both TOPIC and CONTENT TYPE
4. Confidence flags need to be prominent, not just metadata

**Source of truth:** Owner's raw feedback in `chatgpt_f1_collection/source_artifacts/f1_owner_original_notes_2026_04_03.txt` and `chatgpt_d3_collection/source_artifacts/d3_owner_raw_reaction_2026_04_07.txt` (on `excerpting-foundations-hardening-20260404` branch). These contain detailed granulation preferences, the rule/proof/attribution tree pattern, leaf pollution concerns, and the "safe space" concept.

## Scope Boundaries

**In scope (this plan):**
- Deep tree architecture design with content-type layers
- Aqidah pilot deep tree (priority #1 per owner)
- LLM placement adapter (Session 2 work — the missing 25%)
- Multi-stage prompts for deep trees
- Confidence flagging system
- Gold baseline generation
- Owner calibration questionnaire
- Scaling patterns to other sciences

**Out of scope:**
- Tree evolution during placement (v1 = static trees)
- Coverage analytics / gap detection (Stage 2)
- Cross-science link management (Stage 2)
- Synthesis engine work (engine 7)
- UI/display layer (separate workstream)
- Owner-facing study interface

## Key Context

### Owner's Granulation Vision (from raw feedback)

The owner showed this tree pattern repeatedly:
```
topic → definition → linguistic → [excerpts]
                   → technical → jumhur (majority) → [excerpts]
                               → hanabila (school) → [excerpts]
      → proofs → from_quran → [excerpts]
               → from_hadith → hadith_anas → [excerpts]
      → examples → [excerpts]
      → conditions → [excerpts]
      → scholarly_opinions → [excerpts]
```

Key principles from his feedback:
- "Anything that can accept a heading, no matter how granulated" = a valid leaf
- Granulation should be "at the highest encyclopedic level"
- Clear separation between rules (الحكم) and proofs (الأدلة)
- School-specific opinions as branches under technical definitions
- Leaf pollution warning: not every brief mention deserves its own leaf entry
- "Once I start studying, my ONLY worry should be MEMORIZING"

### Owner's Placement Preferences

- **Flags over hiding:** Placement should introduce visible confidence flags so owner knows if he should double-check
- **Safe space = flagged space:** Not a permanent residence, but a review queue — "should almost never happen because we aim to make the engine extremely accurate"
- **Aqidah is priority #1:** Build and test with aqidah first
- **Depth varies by topic:** Go as deep as possible where it makes sense; standard patterns (definition, proofs, examples) appear in most topics

### Current Engine State

| Component | Status | Notes |
|-----------|--------|-------|
| Tree loading | DONE | Handles arbitrary depth already |
| Placement routing | DONE | Teaching/editorial/always-staged thresholds |
| Validation | DONE | Leaf existence + byte-identical Arabic check |
| File output | DONE | Placed/staged/unplaced/pending with D-023 |
| Diagnostics | DONE | Batch stats, 4 warning conditions |
| **LLM placement** | **STUB** | **Raises NotImplementedError — Session 2 work** |
| Gold baseline | INVALID | References v1.0 tree paths |
| Tests | 148 pass | Zero LLM tests (deferred to Session 2) |

### Current Tree State

| Science | Version | Leaves | K2 Status | Deep Tree |
|---------|---------|--------|-----------|-----------|
| Nahw | v2.0 | 194 | VALIDATED | Not started |
| Sarf | v1.0 | 226 | Phase 3 pending | Not started |
| Aqidah | v0.2 | 30 | Phase 2-3 pending (130-leaf draft exists) | Not started |
| Balagha | v1.0 | 335 | Phase 1 partial | Not started |
| Imlaa | v1.0 | 105 | Phase 1 in progress | Not started |

## Key Technical Decisions

### D1: Deep trees as YAML, not a separate metadata layer

**Decision:** Content-type sub-branches (definition, proofs, examples, etc.) live IN the tree YAML as regular nodes, not as a separate classification layer.

**Rationale:** The `tree_loader.py` already handles arbitrary depth via recursive `TreeNode` processing. Putting content types in the tree means the owner's browsing experience matches the placement algorithm — he navigates the same structure the engine places into. A separate layer would create a dual-system (tree for topics, metadata for content types) that complicates placement prompts and browsing.

**Implication:** Trees grow from ~150-200 leaves to ~400-800 leaves per major science. The 200-leaf threshold for Stage 1 means ALL deep trees will use hierarchical search, which is correct (more precision needed for deeper trees).

### D2: Standard content-type scaffold with flexible depth

**Decision:** Define a standard set of content-type branches (تعريف/أدلة/أمثلة/أقوال/شروط) but only instantiate them where the corpus evidence warrants it. No empty placeholder branches.

**Rationale:** The owner said "go as deep as possible, as long as it makes sense." Pre-building empty branches wastes tree space and creates false navigation expectations. Instead, during K2 synthesis, researchers identify which content types appear for each topic based on corpus evidence, and only those branches are created.

### D3: Multi-stage placement for deep trees

**Decision:** Add a Stage 1.5 (topic-level selection) between Stage 1 (branch selection) and Stage 2 (leaf ranking) for trees with >500 leaves.

**Rationale:** With deep trees, Stage 2 receives too many leaf candidates (50+ per branch). Stage 1.5 narrows to the specific topic within the branch, then Stage 2 ranks content-type leaves within that topic. This keeps each LLM call focused on a manageable set of candidates.

**Thresholds:**
- ≤200 leaves: Skip Stage 1, all leaves to Stage 2 (current behavior)
- 201-500 leaves: Stage 1 (branches) → Stage 2 (leaves) (current design)
- >500 leaves: Stage 1 (branches) → Stage 1.5 (topics within branch) → Stage 2 (content-type leaves)

### D4: Content-type routing uses excerpting's primary_function

**Decision:** The excerpting engine's `primary_function` classification (definition, rule_statement, evidence_hadith, opinion_statement, etc.) maps to the content-type level of the deep tree. The taxonomy engine uses this as a strong signal for content-type sub-branch selection.

**Rationale:** The excerpting engine already classifies each excerpt's function. This is the SAME information needed to route to content-type sub-branches. Rather than having the taxonomy LLM re-classify content type from scratch, we use the excerpting engine's classification as a prior and let the taxonomy LLM refine it in the context of the specific tree structure.

### D5: Confidence flags as first-class output

**Decision:** Add `needs_owner_review: bool` and `review_flags: list[str]` to `PlacementAdditions`. Flags include: `low_confidence`, `tie_detected`, `content_type_uncertain`, `cross_topic_candidate`, `leaf_pollution_risk`.

**Rationale:** The owner explicitly said: "TAXONOMY PLACEMENT CAN INTRODUCE FLAGS, SO THAT WHEN I OPEN AN EXCERPT I KNOW HOW CERTAIN ITS PLACEMENT IS AND IF I SHOULD DOUBLECHECK SOMETHING." This is beyond the current `placement_confidence` float — it's a set of human-readable signals.

### D6: Aqidah as pilot science, nahw as validation science

**Decision:** Build the first deep tree for aqidah (owner's priority), then validate the pattern works on nahw (already validated v2.0 topic tree, most complete corpus data).

**Rationale:** Aqidah is the owner's study priority AND has the smallest current tree (30 leaves), making it the fastest to iterate on. Nahw is the most mature in terms of K2 validation and corpus data, making it the best validation target.

## Open Questions

### Resolved During Planning

- **Q: Should content types be tree nodes or metadata?** → Tree nodes (D1). The tree_loader already handles it.
- **Q: Empty branches for content types not yet encountered?** → No (D2). Only create branches with corpus evidence.
- **Q: How to handle very deep trees in prompts?** → Multi-stage placement (D3).
- **Q: Safe space = permanent or temporary?** → Temporary flagged space (owner answer). Uses existing `staged` route + enriched flags (D5).

### Deferred to Implementation

- **Exact content-type branch IDs and titles** — Will be determined during aqidah pilot tree build based on what patterns emerge from corpus analysis.
- **Stage 1.5 prompt design** — Depends on seeing the actual deep tree structure and testing prompt effectiveness.
- **Leaf pollution detection** — The owner flagged this (LP-001 through LP-004 in D3 collection) but the threshold is "not yet fully settled from one case." Will calibrate during testing.
- **Multi-model consensus for deep-tree placement** — D-041 requires multi-model for content decisions. Currently deferred to Stage 2. May need earlier if single-model accuracy on content-type routing is insufficient.

## Implementation Units

### PHASE A: Foundation (This Session)

- [ ] **Unit A1: Extract and Archive Owner Feedback Data**

**Goal:** Copy the owner's raw taxonomy-relevant feedback from the excerpting branch into the taxonomy engine's reference area, making it accessible without branch-switching.

**Requirements:** Owner's feedback is the source of truth for granulation preferences, content-type patterns, leaf pollution rules, and safe-space design. It currently only exists on `excerpting-foundations-hardening-20260404`.

**Dependencies:** None

**Files:**
- Create: `engines/taxonomy/reference/owner_feedback/` directory
- Create: `engines/taxonomy/reference/owner_feedback/f1_granulation_preferences.md` (synthesized from F1 raw notes)
- Create: `engines/taxonomy/reference/owner_feedback/d3_content_type_patterns.md` (synthesized from D3 collection)
- Create: `engines/taxonomy/reference/owner_feedback/leaf_pollution_rules.md` (synthesized from D3 LP-001 through LP-004)
- Create: `engines/taxonomy/reference/owner_feedback/safe_space_and_flags.md` (synthesized from owner Q&A + D3)

**Approach:**
- Read raw files from `excerpting-foundations-hardening-20260404` branch via `git show`
- Synthesize the taxonomy-relevant content into focused reference documents
- Include direct quotes from the owner (these are golden data)
- Cross-reference with F-collection entries (HD-001 through HD-004, SB-001 through SB-004, SH-001 through SH-004, LP-001 through LP-004)

**Patterns to follow:** The excerpting engine's `chatgpt_xx_collection` format — structured, traceable, with owner_relation tags.

**Test scenarios:**
- Happy path: All 4 reference documents created with accurate owner quotes
- Verification: Each document has source citation back to the original file on the excerpting branch

**Verification:** Documents exist, contain direct owner quotes, and are cross-referenced to source files.

---

- [ ] **Unit A2: Deep Tree Architecture Specification**

**Goal:** Define the formal specification for deep taxonomy trees with content-type layers, including the standard content-type scaffold, naming conventions, and structural rules.

**Requirements:** The deep tree format must be loadable by the existing `tree_loader.py` (backward compatible), follow TAXONOMY_TREE_PROTOCOL quality gates, and implement the owner's granulation vision.

**Dependencies:** Unit A1 (owner feedback reference docs)

**Files:**
- Create: `engines/taxonomy/reference/DEEP_TREE_SPEC.md`
- Modify: `engines/taxonomy/SPEC.md` (add §4.A.2.1 — Multi-stage placement for deep trees)

**Approach:**
- Define standard content-type branch types: تعريف (definition), أدلة (proofs), أمثلة (examples), أقوال_العلماء (scholarly opinions), شروط (conditions), أحكام (rulings), إسنادات (attributions)
- Define when each type is instantiated (corpus evidence rules)
- Define naming conventions for content-type branch IDs (e.g., `{topic_id}_taarif`, `{topic_id}_adillah`)
- Define structural rules: content-type branches are ALWAYS children of topic nodes, never siblings
- Define the safe-space pattern: `__general` node under each L1 branch for uncertain placements
- Define the Stage 1.5 algorithm for trees >500 leaves
- Address leaf pollution: define significance threshold for leaf-worthiness

**Coworker validation (MANDATORY):**
- Codex CLI: Structural consistency of the proposed format
- Gemini CLI: Arabic scholarly accuracy of content-type categories and naming
- ChatGPT DR: Feasibility of the multi-stage placement with deep trees
- Claude DR: Scholarly completeness — are any common content types missing?

**Test scenarios:**
- Happy path: DEEP_TREE_SPEC.md passes review by all 4 coworkers
- Edge case: Content-type categories cover all `primary_function` values from the excerpting engine
- Edge case: Proposed naming conventions don't collide with existing topic IDs

**Verification:** DEEP_TREE_SPEC.md exists, is reviewed by coworkers, and is internally consistent with SPEC.md and TAXONOMY_TREE_PROTOCOL.md.

---

- [ ] **Unit A3: Update Contracts for Deep Trees**

**Goal:** Add confidence flags (`needs_owner_review`, `review_flags`) and Stage 1.5 response model to `contracts_core.py`.

**Dependencies:** Unit A2 (deep tree spec)

**Files:**
- Modify: `engines/taxonomy/contracts_core.py`
- Test: `engines/taxonomy/tests/test_routing.py` (new flag tests)

**Approach:**
- Add `needs_owner_review: bool` to `PlacementAdditions`
- Add `review_flags: list[str]` to `PlacementAdditions` with enum values: `low_confidence`, `tie_detected`, `content_type_uncertain`, `cross_topic_candidate`, `leaf_pollution_risk`
- Add `TopicSelection` response model for Stage 1.5:
  ```
  class TopicSelection(BaseModel):
      selected_topics: list[str]  # 1-5 topic node IDs within the branch
      content_type_hint: str | None  # Optional hint from excerpt's primary_function
  ```
- Keep backward compatibility: `needs_owner_review` defaults to `False`, `review_flags` defaults to `[]`

**Patterns to follow:** Existing `BranchSelection` and `PlacementRanking` models in `contracts_core.py`.

**Test scenarios:**
- Happy path: PlacementAdditions with new fields serializes correctly
- Edge case: Empty review_flags list doesn't break existing writers
- Edge case: Old-format excerpts (without new fields) still load

**Verification:** pyright passes, existing 148 tests still pass, new flag fields appear in placed excerpt JSON.

---

### PHASE B: Aqidah Pilot Deep Tree

- [ ] **Unit B1: Aqidah Deep Tree — Content-Type Expansion**

**Goal:** Take the existing 130-leaf aqidah architect draft and expand it with content-type sub-branches to create the first deep taxonomy tree.

**Dependencies:** Unit A2 (deep tree spec)

**Files:**
- Modify: `library/sciences/aqidah/tree.yaml` (replace v0.2 with deep v2.0)
- Modify: `library/sciences/taxonomy_registry.yaml` (update aqidah entry)
- Create: `library/sciences/aqidah/tree_history/aqidah_v0_2.yaml` (archive current)
- Test: `engines/taxonomy/tests/test_tree_loader.py` (update aqidah assertions)

**Approach:**
- Start from the 130-leaf architect draft (in `reference/research/architect_draft_aqidah_tree.yaml`)
- For each topic leaf in the draft, analyze corpus evidence to determine which content-type sub-branches are warranted
- Apply the standard scaffold from DEEP_TREE_SPEC.md: at minimum, تعريف for every topic; أدلة and أقوال where corpus shows proofs/opinions
- Add `__general` safe-space nodes under each L1 branch
- Run all 14 quality gates from TAXONOMY_TREE_PROTOCOL.md
- Target: 300-500 leaves (130 topics × 2-4 content-type branches each)

**Coworker validation (MANDATORY):**
- Gemini CLI: Arabic scholarly accuracy + content-type assignments
- Codex CLI: Structural integrity (14 mechanical gates)
- Fresh Claude: Cold-read audit (Phase 3 of K2 process)

**Test scenarios:**
- Happy path: Deep aqidah tree loads in tree_loader, all quality gates pass
- Edge case: Safe-space `__general` nodes are valid leaves (double-underscore convention)
- Edge case: Content-type branches have unique IDs across the entire tree

**Verification:** Tree loads successfully, tree_loader tests pass, 14 quality gates all PASS, at least 2 coworkers confirm scholarly accuracy.

---

- [ ] **Unit B2: Update Test Infrastructure for Deep Trees**

**Goal:** Update test fixtures and assertions to work with the deep aqidah tree.

**Dependencies:** Unit B1 (aqidah deep tree installed)

**Files:**
- Modify: `engines/taxonomy/tests/conftest.py` (update aqidah fixtures)
- Modify: `engines/taxonomy/tests/test_tree_loader.py` (update leaf counts, known paths)
- Modify: `engines/taxonomy/tests/test_routing.py` (update tree size thresholds — aqidah now >200 leaves)
- Test: All test files in `engines/taxonomy/tests/`

**Approach:**
- Update aqidah leaf count assertions to match deep tree
- Add test cases for content-type leaf paths (e.g., `al_iman_billah/asma_wa_sifat/.../taarif`)
- Add test cases for safe-space `__general` node routing
- Update Stage 1 skip logic: aqidah was ≤200 (skip Stage 1), now likely >200 (use Stage 1)

**Test scenarios:**
- Happy path: All existing tests pass with updated assertions
- Edge case: Content-type path depth (4-5 levels) doesn't break path construction
- Edge case: `__general` nodes correctly treated as leaves

**Verification:** `python -m pytest engines/taxonomy/tests/ -x -q --tb=short` — all pass, zero regressions.

---

### PHASE C: LLM Placement Engine (Session 2 Completion)

- [ ] **Unit C1: Build LLMPlacementAdapter**

**Goal:** Implement the LLM placement adapter that calls the CLI adapter for Stage 1 and Stage 2 (and Stage 1.5 for deep trees).

**Dependencies:** Unit A3 (updated contracts)

**Files:**
- Create: `engines/taxonomy/src/llm_adapter.py`
- Modify: `engines/taxonomy/src/engine.py` (wire in LLMPlacementAdapter)
- Modify: `engines/taxonomy/src/placer.py` (add Stage 1.5 logic)
- Test: `engines/taxonomy/tests/test_llm_adapter.py`

**Approach:**
- Implement `LLMPlacementAdapter` implementing the `PlacementAdapter` protocol
- `run_stage1()`: Format branch view from tree, call CLI adapter with `BranchSelection` response model
- `run_stage1_5()`: Format topic view within selected branches, call CLI adapter with `TopicSelection` response model (only for trees >500 leaves)
- `run_stage2()`: Format leaf view from candidates, call CLI adapter with `PlacementRanking` response model
- All calls use `anthropic/claude-opus-4`, temperature=0, timeout=600s
- Use `primary_function` as content-type routing hint in Stage 2 prompt
- Compute `needs_owner_review` and `review_flags` from placement result

**Patterns to follow:**
- `shared/llm/cli_adapter.py` — the LLM interface
- `engines/taxonomy/src/placer.py` — existing `StubPlacementAdapter` protocol
- `engines/taxonomy/src/tree_loader.py` — `build_branch_view()` and `build_leaf_view()`

**Test scenarios:**
- Happy path: Mock CLI adapter returns valid BranchSelection → TopicSelection → PlacementRanking, excerpt gets placed
- Edge case: Stage 1 returns `no_match=True` → excerpt goes to unplaced
- Edge case: Stage 1.5 skipped for trees ≤500 leaves
- Edge case: CLI adapter timeout → `TAX_LLM_FAILURE` warning, retry logic
- Error path: CLI adapter returns invalid JSON → graceful error handling
- Integration: Full pipeline with mock adapter produces correct file structure

**Verification:** All new tests pass, existing tests unbroken, pyright clean.

---

- [ ] **Unit C2: Stage 1/2/1.5 Prompt Design**

**Goal:** Design the LLM prompts for each placement stage, optimized for deep trees with content-type routing.

**Dependencies:** Unit C1 (adapter structure), Unit A2 (deep tree spec)

**Files:**
- Create: `engines/taxonomy/src/prompts.py` (prompt templates and formatting)
- Test: `engines/taxonomy/tests/test_prompts.py`

**Approach:**
- Stage 1 prompt: Show L1 branches with L2 topic summaries. Ask LLM to select 1-3 branches.
- Stage 1.5 prompt: Show topics within selected branches (without content-type depth). Ask LLM to select 1-5 topics and optionally hint content type.
- Stage 2 prompt: Show content-type leaves within selected topics. Include `primary_function` as strong signal. Ask LLM to score each leaf 0-1 with reasoning.
- All prompts include Arabic text directly (never transliteration)
- All prompts include domain terminology in Arabic alongside English
- All prompts use temperature=0

**Coworker validation (MANDATORY):**
- Gemini CLI: Arabic prompt quality and scholarly accuracy
- Codex CLI: Prompt structure consistency and response model alignment

**Test scenarios:**
- Happy path: Prompts for each stage format correctly with real tree data
- Edge case: Very long branch views are truncated within token limits
- Edge case: Excerpts with missing `description_arabic` still produce valid prompts
- Edge case: Arabic text in prompts preserves diacritics exactly

**Verification:** Prompt formatting tests pass, prompts reviewed by 2+ coworkers.

---

- [ ] **Unit C3: Gold Baseline Generation for Aqidah Deep Tree**

**Goal:** Create a gold baseline of manually-placed excerpts for the deep aqidah tree to measure placement accuracy.

**Dependencies:** Unit B1 (aqidah deep tree), Unit C1 (LLM adapter working)

**Files:**
- Create: `engines/taxonomy/tests/fixtures/gold_baseline_aqidah.yaml`
- Modify: `engines/taxonomy/tests/test_real_data.py` (add aqidah gold baseline test)

**Approach:**
- Select 15-20 aqidah excerpts with clear topic + content type (from integration test data or real sources)
- Manually assign each excerpt to the correct deep tree leaf (topic + content type)
- Run real LLM placement on these excerpts
- Compare LLM placements against manual assignments
- Record accuracy metrics: exact-leaf match, topic-level match, content-type match, routing correctness
- Target: ≥80% exact-leaf match for gold baseline excerpts

**Coworker validation:**
- Gemini CLI: Verify manual assignments are scholarly correct
- Owner review: Show 5 example placements to the owner — "does this feel right?"

**Test scenarios:**
- Happy path: LLM places ≥80% of gold excerpts at the correct leaf
- Edge case: LLM picks correct topic but wrong content type → acceptable if within 1 level
- Edge case: Tie detection triggers on legitimately ambiguous excerpts

**Verification:** Gold baseline file created, accuracy metrics documented, at least 1 coworker confirms manual assignments.

---

### PHASE D: Owner Calibration

- [ ] **Unit D1: Taxonomy-Specific Owner Questionnaire Design**

**Goal:** Design a questionnaire testing the owner's taxonomy preferences, modeled on the excerpting engine's exhaustive Q&A protocol.

**Dependencies:** Unit C3 (gold baseline — need real placement examples to show owner)

**Files:**
- Create: `engines/taxonomy/questionnaire/QUESTIONNAIRE.md`
- Create: `engines/taxonomy/questionnaire/OWNER_FEEDBACK_GUARDRAIL.md` (adapted from excerpting)
- Create: `engines/taxonomy/questionnaire/CRITICAL_EVALUATION_GUIDE.md`

**Approach:**
- Design questions around taxonomy-specific concerns:
  - Granulation depth preference (show concrete examples from aqidah)
  - Content-type separation (when should definition/proof be separate vs. together?)
  - School-specific branching (when is a school opinion its own branch vs. attribution?)
  - Safe-space handling (what should the "flagged" experience feel like?)
  - Cross-topic excerpts (when an excerpt spans two topics, which one wins?)
  - Leaf pollution threshold (when is a brief mention too insignificant for its own leaf?)
- Use REAL excerpts from aqidah gold baseline as examples
- Cover ALL relevant SPEC rules (cross-reference §4.A.2 through §4.A.6)
- Apply excerpting lessons: multi-genre, multi-era representation; no jargon without definition; frame as owner observations not engineering decisions

**Coworker validation (MANDATORY — all 5):**
- Codex CLI: Questionnaire coverage vs SPEC rules
- Gemini CLI: Arabic scholarly accuracy of questions
- ChatGPT DR: Questionnaire design quality + bias detection
- Claude DR: Missing edge cases + scholarly reasoning gaps
- Gemini DR: Pedagogical alignment + study workflow coverage

**Test scenarios:**
- Happy path: Questionnaire covers all SPEC §4 rules
- Edge case: Questions don't assume the owner knows technical taxonomy terms
- Verification: At least 3 of 5 coworkers confirm questionnaire quality

**Verification:** Questionnaire document exists, all 5 coworkers have reviewed, zero SPEC coverage gaps.

---

- [ ] **Unit D2: Owner Q&A Execution + Synthesis**

**Goal:** Execute the questionnaire with the owner, then synthesize answers using the 9-category protocol from the excerpting engine.

**Dependencies:** Unit D1 (questionnaire designed and validated)

**Files:**
- Create: `engines/taxonomy/questionnaire/responses/` (owner responses)
- Create: `engines/taxonomy/questionnaire/SYNTHESIS_REPORT.md`

**Approach:**
- Present questions to owner via AskUserQuestion (batches of 3-4)
- For each answer: evaluate using 9-category protocol (CONFIRMED / CHALLENGED / CONTRADICTION / INFEASIBLE / LOCAL_PREFERENCE / DEEPER_NEED / MISSING / OVERRIDDEN / PENDING_SOURCE)
- Dispatch all 5 coworkers to independently evaluate owner answers
- Synthesize coworker evaluations into final calibration
- Only CONFIRMED items become SPEC amendments
- Document every decision with: owner answer ID, coworker confirmations, challenge resolution

**Coworker validation (MANDATORY — all 5):** Each answer evaluated independently.

**Test scenarios:**
- Happy path: Owner answers map cleanly to existing SPEC rules
- Edge case: Owner answer contradicts SPEC scholarly invariant → OVERRIDDEN with explanation
- Edge case: Owner answer reveals a DEEPER_NEED that changes tree structure

**Verification:** Synthesis report exists with all answers categorized, coworker evaluations documented.

---

### PHASE E: Scale and Harden

- [ ] **Unit E1: Nahw Deep Tree Expansion**

**Goal:** Expand the validated nahw v2.0 tree (194 leaves) with content-type sub-branches.

**Dependencies:** Unit A2 (deep tree spec), Unit B1 (lessons from aqidah pilot)

**Files:**
- Modify: `library/sciences/nahw/tree.yaml`
- Modify: `library/sciences/taxonomy_registry.yaml`
- Create: `library/sciences/nahw/tree_history/nahw_v2_0.yaml` (archive current)

**Approach:**
- Apply the same content-type expansion pattern proven on aqidah
- Nahw has richer corpus data (302 books, 70001 headings) so content-type assignments will be more data-driven
- Run all 14 quality gates
- Full coworker validation (especially Gemini CLI for Arabic accuracy)

**Verification:** Deep nahw tree loads, quality gates pass, coworkers confirm.

---

- [ ] **Unit E2: Remaining Sciences — Sarf, Balagha, Imlaa**

**Goal:** Complete K2 process AND deep tree expansion for the remaining 3 sciences.

**Dependencies:** Unit E1 (nahw validated), outstanding DR relays (sarf/aqidah blockers from NEXT.md)

**Approach:**
- **Sarf:** Finish Phase 3 cold-read, then expand 152-leaf draft to deep tree
- **Balagha:** Complete Phase 1 (Gemini DR pending), run Phase 2-3, then expand
- **Imlaa:** Complete Phase 1 convergence, run Phase 2-3, then expand
- Each science follows the same pattern: K2 validation → content-type expansion → quality gates → coworker review

**Verification:** All 5 science trees at deep v2.0+ status, all quality gates passing.

---

- [ ] **Unit E3: Full Batch Testing + Hardening**

**Goal:** Run the complete placement engine on real excerpts across all 5 sciences and validate output quality.

**Dependencies:** Unit E2 (all trees ready), Unit C2 (prompts calibrated)

**Approach:**
- Process a sample batch (50-100 excerpts per science) through the engine
- Measure accuracy against gold baselines
- Dispatch all 5 coworkers for placement quality evaluation
- Iterate on prompts based on findings
- Document placement accuracy per science, per content-type, per confidence level
- Final hardening: fix all issues found, re-run, re-evaluate

**Verification:** Batch placement accuracy ≥80% exact-leaf across all sciences, all coworkers confirm quality.

## System-Wide Impact

- **Upstream (excerpting):** No changes needed. Excerpting's `primary_function` feeds directly into content-type routing as a prior signal. `excerpt_topic` feeds into topic-level routing.
- **Downstream (synthesis):** Deeper trees mean more specific leaf paths in placed excerpts. Synthesis engine receives excerpts with paths like `al_iman/taarif/istilahi/jumhur` instead of just `al_iman`. This is more useful, not a breaking change.
- **Tree protocol:** TAXONOMY_TREE_PROTOCOL.md may need updates for content-type depth quality gates (M-6 leaf count range expands for deep trees).
- **Error propagation:** LLM failures in any stage → excerpt goes to unplaced with detailed reason. No silent failures.
- **State lifecycle:** Trees are built once (K2 process), loaded at placement time. No runtime tree modification.
- **Unchanged invariants:** D-023 metadata preservation, T-1 Arabic text fidelity check, existing routing thresholds, existing error codes.

## Risks & Dependencies

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Deep trees too large for LLM prompt context | Medium | High | Stage 1.5 design keeps each prompt focused; token budget analysis during C2 |
| Content-type branch assignments are subjective | High | Medium | Multi-coworker validation at every step; owner calibration in Phase D |
| Aqidah corpus data is thin (30 leaves currently) | Medium | Medium | Use DR sessions for scholarly content-type analysis; owner review |
| Owner's granulation preferences evolve | High | Low | Questionnaire + feedback guardrails allow controlled evolution |
| DR relay blockers (sarf/aqidah) delay tree completion | High | Medium | Start with aqidah pilot (already has architect draft); parallel DR relays |
| Single-model placement accuracy insufficient for deep trees | Medium | High | Monitor accuracy in Phase C3; escalate to multi-model consensus if <70% |

## Execution Sequence

```
PHASE A (Foundation) ──→ PHASE B (Aqidah Pilot) ──→ PHASE C (LLM Engine) ──→ PHASE D (Calibration) ──→ PHASE E (Scale)
     │                        │                           │
     └─ A1→A2→A3              └─ B1→B2                    └─ C1→C2→C3
                                                               │
                                                          (C1 can start
                                                           parallel to B1)
```

**Parallelism:**
- A1 and A2 can start immediately (this session)
- B1 can start as soon as A2 is done
- C1 can start in parallel with B1 (uses mock trees initially)
- D1 requires C3 (needs real placement examples)
- E1-E2 can overlap with D1-D2 (tree building is independent of questionnaire)

## Sources & References

- **Owner feedback (golden data):** `excerpting-foundations-hardening-20260404:engines/excerpting/chatgpt_f1_collection/source_artifacts/f1_owner_original_notes_2026_04_03.txt`
- **Owner feedback (D3):** `excerpting-foundations-hardening-20260404:engines/excerpting/chatgpt_d3_collection/source_artifacts/d3_owner_raw_reaction_2026_04_07.txt`
- **Leaf pollution rules:** `excerpting-foundations-hardening-20260404:engines/excerpting/chatgpt_d3_collection/10_leaf_pollution_and_significance.jsonl`
- **Content-type patterns:** `excerpting-foundations-hardening-20260404:engines/excerpting/chatgpt_d3_collection/05_hypothetical_definition_layers.jsonl`
- **School branching:** `excerpting-foundations-hardening-20260404:engines/excerpting/chatgpt_d3_collection/07_school_specific_branching.jsonl`
- **Taxonomy SPEC:** `engines/taxonomy/SPEC.md`
- **Tree protocol:** `reference/protocols/TAXONOMY_TREE_PROTOCOL.md`
- **Architecture:** `engines/taxonomy/docs/architecture.md`
- **Current contracts:** `engines/taxonomy/contracts_core.py`
- **Excerpting feedback guardrails:** `excerpting-foundations-hardening-20260404:integration_tests/questionnaire/OWNER_FEEDBACK_GUARDRAIL.md`
