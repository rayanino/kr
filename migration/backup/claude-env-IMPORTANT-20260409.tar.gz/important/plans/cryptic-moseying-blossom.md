# Plan: Deep Review + Launch Overnight Autonomous System

## Context

Exhaustive 3-agent audit of the overnight system found **25 issues** including one that would have made the entire system do nothing for 8 hours (permission_mode="plan" = all tasks hang waiting for approval). The system was built quickly and needs hardening before trusted autonomous execution.

**Three work categories:**
1. Fix 15 bugs/gaps in orchestrator + task generator (Part A)
2. Update stale state files: NEXT.md, CLAUDE.md, .gitignore (Part B)
3. Create 16-task manifest and launch with 8+ hours (Part C/D)

---

## Part A: System Fixes (15 fixes, prioritized)

### A1. CRITICAL: `permission_mode="plan"` → All tasks hang forever
**File:** `scripts/overnight_orchestrator.py:79`, `scripts/overnight_task_generator.py:467`
**Bug:** Every task defaults to `permission_mode: "plan"`. Plan mode requires human approval for tool execution. No human is present overnight. **Every task would hang indefinitely.**
**Fix:** Change default to `"bypassPermissions"` in the orchestrator's TaskDef (line 79). Also change in task generator's TaskDef (line 42). For readonly tasks, `--allowedTools` restricts what tools are available even in bypassPermissions mode.

### A2. CRITICAL: Quality gate + pre-flight exclude excerpting tests (149 tests)
**File:** `scripts/overnight_orchestrator.py:288-291, 504-507`
**Bug:** Both test commands only run source + normalization. After overnight code changes, regressions in excerpting go undetected.
**Fix:** Add `"engines/excerpting/tests/"` to both pytest commands.

### A3. CRITICAL: Budget enforcement completely missing
**File:** `scripts/overnight_orchestrator.py`
**Bug:** `state.total_cost_usd` (line 112) is never incremented. `max_cost_usd` (line 743) is never checked. The $50 budget cap is meaningless.
**Fix:**
- Add `cost_usd: float = 0.0` to TaskResult dataclass (line 87)
- In `_execute_cli()`, store parsed cost on result: `result.cost_usd = cost`
- In main loop after execute_task(), add: `state.total_cost_usd += result.cost_usd`
- Before picking next task, add budget check: `if state.total_cost_usd >= max_cost_usd: break`
- Pass `max_cost_usd` into the main loop (it's already a parameter but unused)

### A4. CRITICAL: `.gitignore` incomplete for overnight files
**File:** `.gitignore:10`
**Bug:** Only `overnight/decisions.log` is ignored. When the orchestrator creates `state.json`, `progress.md`, `MORNING_REPORT.md`, they become untracked. After the orchestrator commits them (line 819), subsequent modifications make them `M overnight/state.json` which `git_is_clean()` doesn't filter.
**Fix:** Add to `.gitignore` under the overnight section:
```
overnight/state.json
overnight/progress.md
overnight/MORNING_REPORT.md
overnight/results/
```
Note: `overnight/manifest.json` stays tracked (it's the task definition, version-controlled).

### A5. CRITICAL: `git_is_clean()` filter insufficient
**File:** `scripts/overnight_orchestrator.py:141-147`
**Bug:** Only filters `?? overnight/` (untracked). Doesn't filter `M overnight/` or ` M overnight/` (modified tracked files). Also doesn't filter `.claude/session_state.json`.
**Fix:** Expand the filter:
```python
lines = [
    line for line in result.stdout.strip().split("\n")
    if line.strip()
    and not any(line.strip().lstrip("M ").lstrip("? ").startswith(prefix)
                for prefix in ("overnight/", "results/", ".claude/scheduled_tasks", ".claude/session_state"))
]
```
Or simpler: filter lines containing these path prefixes regardless of git status character.

### A6. State file corruption — non-atomic writes
**File:** `scripts/overnight_orchestrator.py:199, 245, 361`
**Bug:** `Path.write_text()` is not atomic on Windows. Crash mid-write = truncated JSON = all progress lost on restart.
**Fix:** Write to temp file, then rename (atomic on NTFS):
```python
def save_state(state: OvernightState) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(asdict(state), indent=2, ensure_ascii=False)
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.replace(STATE_FILE)
```
Apply same pattern to `write_progress_file()` and `generate_morning_report()`.

### A7. Git rollback: no error checking + doesn't clean untracked files
**File:** `scripts/overnight_orchestrator.py:151-157`
**Bug:** `git reset --hard` errors are swallowed by `capture_output=True`. And `reset --hard` leaves newly created files behind — partial rollback.
**Fix:**
```python
def git_rollback(commit_hash: str) -> None:
    result = subprocess.run(
        ["git", "reset", "--hard", commit_hash],
        capture_output=True, text=True, cwd=str(PROJECT_DIR),
    )
    if result.returncode != 0:
        log_decision(f"ROLLBACK FAILED: {result.stderr[:500]}")
        raise RuntimeError(f"Git rollback failed: {result.stderr[:200]}")
    # Clean untracked files created by the failed task
    subprocess.run(
        ["git", "clean", "-fd", "--exclude=overnight/"],
        capture_output=True, text=True, cwd=str(PROJECT_DIR),
    )
    log_decision(f"ROLLBACK to {commit_hash[:8]}")
```

### A8. `max_turns` not passed to CLI
**File:** `scripts/overnight_orchestrator.py:368-381`
**Bug:** TaskDef has `max_turns` but `_execute_cli()` never adds `--max-turns` to the command.
**Fix:** Add after the `max_budget_usd` block:
```python
if task.max_turns > 0:
    cmd += ["--max-turns", str(task.max_turns)]
```

### A9. Task generator hardcodes source+normalization, ignores excerpting
**File:** `scripts/overnight_task_generator.py:96, 470-473`
**Bug:** `scan_test_health()` only generates coverage tasks for `engine in ("source", "normalization")`. Core regression test only runs source+normalization.
**Fix:**
- Line 96: Change to `if test_count > 0:` (include any engine with tests)
- Lines 470-473: Add `"engines/excerpting/tests/"` to the core test command

### A10. Regex double-escaping in code quality scanner
**File:** `scripts/overnight_task_generator.py:188`
**Bug:** `r"\\\\d"` becomes the literal string `\\d` which grep interprets as "backslash then d", not the regex digit class `\d`. The Arabic-Indic digit safety scan finds nothing.
**Fix:** `r"\\d"` (single escape in raw string = literal `\d` which grep matches in source code)

### A11. Explicit `encoding="utf-8"` on all file writes
**File:** `scripts/overnight_orchestrator.py:199, 245`
**Bug:** Some `write_text()` calls lack explicit encoding. Windows default encoding may not be UTF-8, corrupting Arabic text.
**Fix:** Add `encoding="utf-8"` to every `.write_text()` call: lines 199, 245, and everywhere else. Also add to `.read_text()` calls.

### A12. Use monotonic time for deadline tracking
**File:** `scripts/overnight_orchestrator.py:803, 840`
**Bug:** Deadline uses `datetime.now(timezone.utc)`. If laptop sleeps or NTP adjusts clock, the deadline becomes inaccurate.
**Fix:** Track elapsed time with `time.monotonic()`:
```python
start_monotonic = time.monotonic()
max_seconds = hours * 3600
# In loop:
elapsed = time.monotonic() - start_monotonic
if elapsed >= max_seconds:
    break
```
Keep the UTC deadline for display/logging but use monotonic for control flow.

### A13. Manifest validation: duplicate IDs + unknown fields
**File:** `scripts/overnight_orchestrator.py:606-615`
**Bug:** Duplicate task IDs are silently overwritten. Unknown JSON fields are silently dropped (could mask typos like `permisison_mode`).
**Fix:** In `load_manifest()`:
```python
# Check for unknown fields
known = set(TaskDef.__dataclass_fields__)
for item in items:
    unknown = set(item.keys()) - known
    if unknown:
        raise ValueError(f"Unknown fields in task {item.get('task_id', '?')}: {unknown}")
# Check for duplicate IDs
ids = [t.task_id for t in tasks]
dupes = [x for x in ids if ids.count(x) > 1]
if dupes:
    raise ValueError(f"Duplicate task IDs: {set(dupes)}")
```

### A14. Explicit commit author for overnight
**File:** `scripts/overnight_orchestrator.py:175-178`
**Bug:** Uses system git config author. Overnight commits should be distinguishable.
**Fix:** Add `--author` flag:
```python
["git", "commit", "-m", message, "--author", "KR Overnight <overnight@kr.local>"]
```

### A15. Safety prompt: add OpenRouter directive
**File:** `scripts/overnight_orchestrator.py:41-57`
**Bug:** Safety prompt doesn't mention OpenRouter-only constraint.
**Fix:** Add to OVERNIGHT_SAFETY_PROMPT:
```
- ALL LLM calls within the pipeline go through OpenRouter ONLY
- Use OPENROUTER_API_KEY — never direct Anthropic or OpenAI endpoints
```

### Deferred issues (acceptable risk for tonight)

These 10 issues have low probability or acceptable fallback behavior:
- Zombie subprocesses on timeout (Python/Windows limitation; processes die when terminal closes)
- Environment variable passthrough (task agents are constrained by tool allowlist)
- Codex CLI unavailability (gracefully caught, L5 is optional)
- Progress file race condition (tasks read once at startup)
- UTF-8 replacement in scanner output (low probability on modern Windows)
- Session state conflict (mitigated by --no-session-persistence)
- rolled_back dependency semantics (conservative: allow dependents to proceed)
- Quality gate timeout awareness (soft deadline is acceptable)
- Empty manifest edge case (manual manifest tonight, not auto-generated)
- `git push` protection (safety prompt + no push in task prompts; we'll add git hook later)

---

## Part B: State File Updates

### B1. Rewrite `NEXT.md` → Phase 3.1 Session 3 directive
Current NEXT.md describes Phase 2 (done). Rewrite with:
- Position: Phase 2 ACCEPTED, 149 tests, HEAD at latest commit
- Target: Phase 3.1 deterministic fields (9 functions in `phase3_deterministic.py`)
- Read first table: SPEC §7.1 (lines 1397-1518), §6.2 (lines 1261-1290), contracts.py
- Per-function specs from SPEC
- Verification criteria

### B2. Update `engines/excerpting/CLAUDE.md`
Update "Current State" to reflect Phase 1+2 completion (149 tests, 2,970 lines).

### B3. Update `.gitignore`
Add overnight state files (see A4).

### B4. Update `scripts/start_overnight.sh`
- `--hours 7.5` → `--hours 8.5` (8h productive + 30min buffer)
- `--max-cost-usd 25.0` → `--max-cost-usd 50.0`

---

## Part C: 16-Task Manifest

### Wave 1: Validation (0-30min) — Priority 1-2
| # | task_id | Mode | Budget | Timeout | Purpose |
|---|---------|------|--------|---------|---------|
| 1 | `val-test-regression` | readonly | $0.50 | 15min | Full test suite: 566+503+149 = ~1,218 tests |
| 2 | `val-contracts` | readonly | $2.00 | 10min | D-023 metadata + cross-engine contracts |

### Wave 2: Quality Analysis (30min-2h) — Priority 3-4
| # | task_id | Mode | Budget | Timeout | Purpose |
|---|---------|------|--------|---------|---------|
| 3 | `cq-excerpting` | readonly | $2.00 | 15min | Code quality: excerpting src/ |
| 4 | `cq-all` | readonly | $2.00 | 15min | Code quality: source + normalization |
| 5 | `test-cov-excerpting` | readonly | $3.00 | 25min | SPEC §4-§5 to test coverage map |
| 6 | `test-cov-source` | readonly | $2.00 | 20min | Source SPEC to test coverage map |
| 7 | `test-cov-normalization` | readonly | $2.00 | 20min | Normalization SPEC to test coverage map |

### Wave 3: Phase 3.1 Implementation (2-5h) — Priority 5
| # | task_id | Mode | Budget | Timeout | Purpose |
|---|---------|------|--------|---------|---------|
| 8 | `impl-phase3-det` | **modifying** | $10.00 | 75min | 9 F-DET functions + build_deterministic_excerpts + ≥30 tests |
| 9 | `impl-phase3-edge` | **modifying** | $6.00 | 45min | Edge cases: multi-layer, split, Arabic fixtures |
| 10 | `pyright-phase3` | readonly | $2.00 | 10min | Type-check all Phase 3 files |

### Wave 4: Hardening (5-7h) — Priority 6
| # | task_id | Mode | Budget | Timeout | Purpose |
|---|---------|------|--------|---------|---------|
| 11 | `harden-phase1` | **modifying** | $5.00 | 30min | Phase 1 edge case tests |
| 12 | `harden-phase2` | **modifying** | $5.00 | 30min | Phase 2 edge case tests |
| 13 | `audit-spec` | readonly | $2.00 | 20min | SPEC quality audit |
| 14 | `audit-invariants` | readonly | $3.00 | 20min | 29 invariants → test mapping |

### Wave 5: Research + Final (7-8h) — Priority 7-8
| # | task_id | Mode | Budget | Timeout | Purpose |
|---|---------|------|--------|---------|---------|
| 15 | `res-enrichment` | readonly | $3.00 | 25min | Phase 3.2/3.3 research |
| 16 | `val-test-final` | readonly | $0.50 | 15min | Final regression test |

**Total budget: $50 cap. All tasks use permission_mode=bypassPermissions.**
**Modifying tasks (8,9,11,12) trigger full quality gate (L1-L4) + rollback on failure.**

Task 8 prompt will include: read SPEC §7.1, implement each F-DET function per algorithm, write tests, run pyright + pytest, ensure 149 existing tests still pass. Self-contained for fresh-context agent.

---

## Part D: Execution Steps

1. Apply 15 fixes to `overnight_orchestrator.py` (A1-A8, A11-A15)
2. Apply 3 fixes to `overnight_task_generator.py` (A9, A10, A13)
3. Update `start_overnight.sh` (B4)
4. Update `.gitignore` (B3/A4)
5. Rewrite `NEXT.md` (B1)
6. Update `engines/excerpting/CLAUDE.md` (B2)
7. Write `overnight/manifest.json` (Part C)
8. Run pyright on modified scripts: `python -m pyright scripts/overnight_orchestrator.py`
9. Dry-run: `python scripts/overnight_orchestrator.py --manifest overnight/manifest.json --dry-run`
10. Commit everything:
    ```
    chore: harden overnight system — fix 15 bugs, add 16-task manifest for Session 3
    ```
11. Launch: `bash scripts/start_overnight.sh overnight/manifest.json`

---

## Part E: Verification

**Pre-launch checks:**
- `git status` → clean (all committed)
- `python -c "import json; json.load(open('overnight/manifest.json'))"` → valid JSON
- Dry-run shows 16 tasks in correct dependency order
- All permission_modes are `bypassPermissions` (grep to confirm)
- Quality gate pytest command includes `engines/excerpting/tests/`
- `.gitignore` includes overnight state files

**Morning checks:**
- `overnight/MORNING_REPORT.md` exists
- `git log --oneline -20` shows `overnight:` prefixed commits
- `python -m pytest engines/excerpting/tests/ -v --tb=short` → >180 tests
- `grep "raise NotImplementedError" engines/excerpting/src/phase3_deterministic.py` → empty (stubs filled)
- No files in `library/sources/frozen/` modified (L2 safety)
