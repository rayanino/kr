# Pre-Flight Hardening: Fixes 3-4 + Enhancements A-B

**Date:** 2026-03-28
**Context:** Fixes 1-2 already committed (7d455f7f). These 4 changes complete pre-flight hardening before the full integration run.
**Mode:** Architect-specified — exact code provided, execute directly.

---

## Fix 3: Log Truncation — `scripts/run_integration_test.py`

**Why:** Dense chunks produce 40K+ chars. Current truncation (500 request, 2000 response) loses debugging data.

| Edit | Line | Old | New |
|------|------|-----|-----|
| Request content | 101 | `[:500]` | `[:2000]` |
| Response content | 129 | `[:2000]` | `[:50000]` |

---

## Fix 4: ENRICH_MAX_TOKENS Scaling — `engines/excerpting/src/phase3_enrichment.py`

**Why:** Fixed 16384 budget. ibn_aqil_v3 (1987 words, 28 TUs) used 14863 tokens. 23 chunks >2500 words will overflow → IncompleteOutputException.

### Steps
1. Add `_compute_enrich_max_tokens(word_count)` helper after imports (before ENRICH_SYSTEM_PROMPT, ~line 41)
2. In `enrich_chunk()` line 234: replace `max_tokens=config.ENRICH_MAX_TOKENS` with `max_tokens=_compute_enrich_max_tokens(chunk.word_count)`
3. Update SPEC.md line 2056: change ENRICH_MAX_TOKENS row from fixed 16384 to dynamic description

---

## Enhancement A: Decontextualization Rules — `engines/excerpting/src/phase2_group.py`

**Why:** 3 scholarly patterns not covered by existing 4 DP bullets: verdict phrases, qualifications, Q&A pairs.

Insert 3 new bullets after line 65 (last existing bullet), before line 67 (SELF-CONTAINMENT section).

---

## Enhancement B: Epithet Resolution — `engines/excerpting/src/phase3_enrichment.py`

**Why:** "best guess" instruction causes wrong attributions. High-frequency epithets need explicit resolution rules.

### Steps
1. Line 92: Replace "set confidence < 0.5 and provide your best guess" → conservative null-with-low-confidence instruction
2. After line 91: Insert epithet resolution table (شيخ الإسلام, الحافظ, القاضي, الشيخان, متفق عليه, collective refs) + CONSERVATISM RULE

---

## Verification

```bash
python -m pytest engines/excerpting/tests/ -x -q          # all pass (baseline 704)
grep -c 'source_school' scripts/run_full_integration.py    # 5 (fix 1 still in place)
grep -c '_compute_enrich_max_tokens' engines/excerpting/src/phase3_enrichment.py  # 2
grep -c '50000' scripts/run_integration_test.py            # 1
grep -c 'شيخ الإسلام' engines/excerpting/src/phase3_enrichment.py  # 1
grep -c 'CONSERVATISM' engines/excerpting/src/phase3_enrichment.py  # 1
grep -c 'best guess' engines/excerpting/src/phase3_enrichment.py    # 0
```

Commit: `fix(excerpting): pre-flight hardening — ENRICH_MAX_TOKENS scaling, log truncation, DP rules, epithet guidance`
Then push.
