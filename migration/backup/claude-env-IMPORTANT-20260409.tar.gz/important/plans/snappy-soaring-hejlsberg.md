# Plan: Integrate recursive-improve into KR Agent Architecture

## Context

KR's pipeline is heavily agent-driven — 24 Claude Code agents, CLI LLM adapter (subprocess-based), multi-model consensus, and a planned Factory v2 with 6 operating modes and agent teams (2-16 agents). The excerpting engine's Phase 2 roadmap specifically calls for configuring agent teams for verification.

**recursive-improve** (https://github.com/kayba-ai/recursive-improve) captures LLM call traces, analyzes failure patterns, proposes improvements, and benchmarks results. The user asks: is it useful for KR? If so, set it up, fine-tune it, and ensure it's always used when applicable.

### Verdict: YES — With Gated Integration

recursive-improve is genuinely valuable for KR, but requires careful adaptation:
- **It can't work out-of-the-box** — `ri.patch()` monkey-patches Python SDK clients, but KR's CLI adapter invokes subprocesses (`claude -p`, `codex exec`, `gemini -p`)
- **It must respect human gates** — KR's principle: "Human gates are not optional." No autonomous content prompt changes
- **It fills a real gap** — KR has result persistence but no systematic trace analysis or improvement benchmarking across runs

---

## Architecture Decisions

### A-1: Trace Bridge, Not Monkey-Patching
`ri.patch()` wraps `openai.Completions.create` and `anthropic.Messages.create`. KR never calls these — it spawns subprocesses. Build a **trace bridge** (`shared/llm/ri_trace_bridge.py`) that hooks into the CLI adapter's existing event system and writes ri-compatible trace JSON.

### A-2: Hybrid Capture (Two LLM Paths)
KR has two LLM call paths:
1. **CLI Adapter** (subprocess) → trace bridge captures via hooks
2. **Instructor/OpenRouter** (Python SDK, used by consensus module + excerpting enrichment) → `ri.patch()` captures natively

Both feed into the same `ri.session()` context manager.

### A-3: Gated Improvements — ri Proposes, Human Approves
ri's improvement proposals (`eval/action_plan.md`) route through KR's human gate system as gate type `ri_improvement_proposal`. ri NEVER auto-applies fixes. The `/ratchet` autonomous loop is restricted to non-content prompts only (JSON formatting, schema directives).

### A-4: Domain-Specific Metrics
ri's built-in detectors (loop, give-up, error) are generic. Add KR-specific detectors:
- Consensus disagreement rate
- Arabic encoding error rate
- JSON retry rate (CLI adapter retries)
- Human gate trigger rate
- Attribution conflict rate

### A-5: /ratchet Restrictions
`/ratchet` is NEVER used for:
- Content classification prompts (genre, author, science scope, school)
- Code modifications
- Arabic text handling changes

ONLY used for: JSON formatting directives, error recovery instructions, schema compliance prompts.

---

## Implementation Phases

### Phase 1: Install + Trace Bridge (foundation)

**Step 1.1** — Install recursive-improve
```bash
uv add "recursive-improve @ git+https://github.com/kayba-ai/recursive-improve.git"
cd C:/Users/Rayane/Desktop/kr && recursive-improve init
```

**Step 1.2** — Create trace bridge: `shared/llm/ri_trace_bridge.py` (~150 lines)
- `TraceBridge` class with `on_kwargs()`, `on_response()`, `on_error()` callbacks
- Translates `CLIResponse` → ri normalized message format
- `attach(adapter, session)` function wires bridge into `CLIInstructorAdapter`

Key mapping:
```
CLIResponse.choices[0].message.content → ri message.content
CLIResponse.model → ri message.model
CLIResponse.backend → ri message.provider (prefixed "cli:")
CLIResponse.usage → ri message.usage dict
```

**Step 1.3** — Tests: `shared/llm/tests/test_ri_trace_bridge.py` (~100 lines)
- Hook attachment
- CLIResponse → ri message translation
- Arabic content preservation (UTF-8, `ensure_ascii=False`)
- Error trace recording

**Critical files to modify:**
- `shared/llm/cli_adapter.py` — read-only reference (hook system at hooks dict)
- `shared/llm/__init__.py` — export trace bridge

### Phase 2: Pipeline Integration

**Step 2.1** — Wire into excerpting pipeline: `engines/excerpting/src/pipeline.py`
```python
import recursive_improve as ri
from shared.llm.ri_trace_bridge import TraceBridge, attach

ri.patch()  # captures Instructor/OpenRouter calls natively
with ri.session("eval/traces/excerpting") as run:
    bridge = TraceBridge(run)
    attach(adapter, run)  # captures CLI adapter calls
    # ... existing pipeline ...
    run.finish(output=summary, success=not had_errors)
```

**Step 2.2** — Wire into `scripts/run_pipeline.py`
- Add `--traces` CLI flag (default: `eval/traces/{engine}/{timestamp}/`)
- Pass traces_dir to engine entry points

**Step 2.3** — Wire into `scripts/run_integration_test.py`
- Same pattern, traces capture during integration tests

### Phase 3: KR-Specific Evaluation

**Step 3.1** — Create `eval/compute_baselines.py` (~250 lines)
KR-domain detectors:
- `detect_consensus_disagreement` — scan for model pairs on same input, count disagreements
- `detect_arabic_encoding_errors` — regex for corruption patterns (isolated diacritics, mojibake)
- `detect_json_retry_rate` — count "PREVIOUS ATTEMPT PRODUCED INVALID JSON" in user prompts
- `detect_low_confidence_fields` — parse structured output for confidence < threshold
- `detect_gate_trigger_rate` — count human gate creations

**Step 3.2** — Create `eval/program.md` (ratchet config)
```markdown
## Agent Run Command
python scripts/run_pipeline.py --fixture tests/fixtures/01_nahw_simple --traces eval/traces

## Metrics
- clean_success_rate: maximize (weight: 2.0)
- json_retry_rate: minimize (weight: 1.5)
- consensus_disagreement_rate: minimize (weight: 1.0)
- arabic_encoding_error_rate: minimize (weight: 3.0)

## Stopping Conditions
- max_iterations: 5
- plateau_patience: 2
```

### Phase 4: Human Gate Integration

**Step 4.1** — Add `ri_improvement_proposal` gate type to `shared/human_gate/src/human_gate.py`
- New trigger variant for ri's action plan proposals
- Routes through existing gate resolution flow

**Step 4.2** — Create `scripts/ri_review.py` (~100 lines)
- Reads `eval/action_plan.md`
- Creates human gate checkpoint per proposed fix
- Approved fixes → git branch `ri/improve-{timestamp}`
- Rejected fixes → logged to `eval/stage6_decision.md`

### Phase 5: Enforcement (Always Used When Applicable)

**Step 5.1** — Rule file: `.claude/rules/ri-trace-collection.md`
```
- Every pipeline run making LLM calls MUST capture traces via recursive-improve.
- Default traces dir: eval/traces/{engine}/{date}/
- After any trace-producing run, note: "Traces at {path}. Run recursive-improve eval."
```

**Step 5.2** — Skill installation
- Copy ri's SKILL.md to `.claude/skills/recursive-improve/SKILL.md`
- Modify Stage 7 to route through KR human gates instead of direct branch creation

**Step 5.3** — Overnight integration
- Add ri eval task as `bookend: true` in overnight manifests
- Runs analysis only (Stages 0-5), writes action plan for morning review
- NEVER runs fix implementation (Stage 7) autonomously

**Step 5.4** — Update session discipline rule
- After LLM pipeline sessions: report trace count, location, whether eval was run

---

## Scope Boundaries (What NOT to Change)

- **No modifications to existing result persistence** — `tests/results/source_engine/` stays as-is; ri traces are a separate layer in `eval/traces/`
- **No modifications to consensus module** — ri captures consensus calls via `ri.patch()` natively
- **No modifications to Decision Playbook** — ri's CANDIDATE_PATTERNs feed existing Playbook review, not a separate system
- **No changes to CLI adapter core** — trace bridge uses existing hook system, no modifications needed

---

## Verification Plan

1. **Trace bridge unit tests** — verify CLIResponse → ri message translation, Arabic preservation
2. **Integration smoke test** — run excerpting pipeline with `--traces`, verify trace files written
3. **Metrics baseline** — `recursive-improve benchmark --label "kr-baseline"` on captured traces
4. **Dashboard check** — `recursive-improve dashboard` renders KR traces correctly
5. **Human gate flow** — run `recursive-improve eval`, verify proposals appear as human gates
6. **Ratchet safety** — verify `/ratchet` only touches non-content prompts (manual inspection)
7. **Arabic safety** — verify Arabic text in traces is intact (no encoding issues, no truncation)

---

## Risk Assessment

| Risk | Severity | Mitigation |
|------|----------|------------|
| ri modifies content prompts autonomously | CRITICAL | `/ratchet` restricted; all proposals through human gate |
| `ri.patch()` conflicts with CLI adapter | LOW | Hybrid approach: bridge for CLI, patch for SDK calls |
| Trace files grow unbounded | MEDIUM | Archive traces >30 days in overnight cleanup |
| Windows path handling | MEDIUM | `pathlib.Path` throughout; test on Windows 11 |
| ri dependency instability | LOW | Pin version; ri has minimal dependencies |

---

## Files Created/Modified Summary

| File | Action | Lines |
|------|--------|-------|
| `shared/llm/ri_trace_bridge.py` | CREATE | ~150 |
| `shared/llm/tests/test_ri_trace_bridge.py` | CREATE | ~100 |
| `eval/compute_baselines.py` | CREATE | ~250 |
| `eval/program.md` | CREATE | ~40 |
| `scripts/ri_review.py` | CREATE | ~100 |
| `.claude/rules/ri-trace-collection.md` | CREATE | ~10 |
| `.claude/skills/recursive-improve/SKILL.md` | COPY+MODIFY | ~varies |
| `engines/excerpting/src/pipeline.py` | MODIFY | +20 |
| `scripts/run_pipeline.py` | MODIFY | +10 |
| `scripts/run_integration_test.py` | MODIFY | +10 |
| `shared/human_gate/src/human_gate.py` | MODIFY | +15 |
| `overnight/sprint_manifest.json` | MODIFY | +entry |
