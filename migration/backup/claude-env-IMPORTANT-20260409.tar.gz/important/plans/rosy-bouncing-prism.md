# Plan: Fix PHASE_C_ALL_VERDICTS.json Audit Findings

## Context

Critical audit of the 76-verdict JSON using 3 parallel agents + automated field-by-field verification against ALL LLM response files, result.json, and consensus.json. The automated audit checked every field of all 76 verdicts. Found **1 data error + 1 coverage gap**.

## Audit Results

### Automated verification (76 verdicts, all fields checked against source data files)
- **75/76 verdicts: ALL fields correct** (author_conf, genre_conf, genre, is_multi_layer, ml_disagreement, consensus_agreed, trust_tier, trust_score, death_date, models)
- **1 error**: Book name `شرح العقيدة الطحاوية - ط الأوقاف السعودية` missing suffix `- بتعليقات أحمد شاكر` (doesn't match disk directory)

### Coverage gap
- **أمالي المحاملي رواية ابن الصلت**: In manifest (73 books), has pipeline data (gate_abort), but never evaluated in any session. NEXT.md says "73 unique books" but only 72 were evaluated.

### False alarms from agent audits (verified as non-issues)
- Death_date "missing" — agent checked wrong field path; data IS at `parsed.author_identification.death_date_hijri`
- Science_scope "omission" for البداية — JSON correctly uses result.json (CA's `['tarikh']`), not Opus's broader `['tarikh', 'sirah']`
- Trust_score "precision" (0.455 vs 0.45499...) — floating point equivalence

## Fixes

### Fix 1: Directory name (in `scripts/build_phase_c_verdicts.py`)
S6 Book 14 entry: change book name from
`"شرح العقيدة الطحاوية - ط الأوقاف السعودية"`
to
`"شرح العقيدة الطحاوية - ط الأوقاف السعودية - بتعليقات أحمد شاكر"`

### Fix 2: Add `_coverage_notes` to JSON
Document in the output JSON:
- أمالي المحاملي processed but never evaluated (the 73rd book)
- 4 books evaluated twice (not NEXT.md's 3): مجموع الفتاوى, الأربعون النووية, شرح الطحاوية ط الرسالة, حاشية ابن عابدين
- unique_books_evaluated = 72, pipeline_books_total = 73

### Fix 3: Correct NEXT.md counts
Update "73 unique books" → "72 unique books evaluated" and note the coverage gap and 4th duplicate.

### Fix 4: Regenerate JSON and re-verify
Re-run `scripts/build_phase_c_verdicts.py` after edits. Then re-run the automated audit expecting 0 errors.

## Verification
1. Re-run automated audit: 0 errors expected
2. Manifest cross-check: only أمالي as documented gap
3. 76 verdicts, 59V/17P unchanged
4. Commit
