# Evaluation: rohitg00/pro-workflow for KR Project

## Context

The owner discovered [rohitg00/pro-workflow](https://github.com/rohitg00/pro-workflow) (v3.2.0, 1,600 stars, 2 contributors) and asks whether it can be safely incorporated into KR without loss of potential. This plan documents the deep technical evaluation.

---

## What pro-workflow Is

A Claude Code plugin providing **generic JS/TS development workflow automation**:
- 29 Node.js hook scripts across 24 Claude Code lifecycle events
- 8 generic agents (planner, reviewer, scout, orchestrator, debugger, etc.)
- 21 slash commands (/develop, /commit, /wrap-up, /learn-rule, etc.)
- 24 SKILL.md portable instruction modules
- SQLite + FTS5 persistent memory for cross-session self-correction ([LEARN] blocks)
- LLM gates (Haiku-powered) for commit validation and secret detection
- Compact guard, drift detector, permission tuner, cost tracker
- SkillKit: translation layer claiming 32+ AI tool compatibility

## What KR Already Has (inventory)

| Category | KR count | pro-workflow count | KR advantage |
|---|---|---|---|
| Domain skills | 15 (Islamic scholarly, Arabic, consensus) | 24 (generic coding) | KR skills encode irreplaceable domain knowledge |
| Custom commands | 23 (/commit, /quality-gate, /arabic-audit, etc.) | 21 (/develop, /commit, /wrap-up, etc.) | KR commands are pipeline-specific |
| Specialized agents | 23 (spec-auditor, verifier, arabic-reviewer, etc.) | 8 (planner, reviewer, scout, etc.) | KR agents implement multi-model consensus |
| Governance rules | 20 (Arabic text, metadata flow, coworker dispatch) | ~10 (.mdc rules) | KR rules encode scholarly constraints |
| Hooks | 5 Python (Arabic safety, quality gate, session start) | 29 Node.js (lifecycle, LLM gates) | KR hooks are Python-native, domain-aware |
| Memory system | 83 structured memories in MEMORY.md + agent-memory/ | SQLite FTS5 generic store | KR memory is domain-categorized |
| Installed plugins | superpowers, compound-engineering, GSD (30+ cmds), pr-review-toolkit, feature-dev, commit-commands, prompt-architect | (is itself a plugin) | KR already has ~100+ plugin commands |

**Total KR infrastructure: ~180+ components across 6 layers. Pro-workflow adds ~90 components, almost all of which overlap with existing capabilities.**

## Verdict: REJECT Full Adoption

### Three Fundamental Conflicts

**1. Language/ecosystem mismatch**
- Pro-workflow: 29 Node.js scripts, requires `npm install`, `tsc` build, `dist/` directory
- KR: Pure Python project. Zero Node.js dependencies. Adding npm to an all-Python scholarly pipeline introduces a foreign runtime dependency for workflow tooling only

**2. Domain blindness**
- Pro-workflow has ZERO Arabic text awareness. All quality gate patterns are Latin/ASCII-centric (`console.log`, `api_key=`, etc.)
- KR's entire hook system exists to protect Arabic scholarly text integrity (diacritics, taa marbuta, isnad chains, Quranic citations)
- Installing pro-workflow's hooks would bypass KR's Arabic safety checks or create ordering conflicts between Python and Node.js hook chains

**3. Generic vs. domain-specific memory**
- Pro-workflow's SQLite stores generic coding corrections ("don't use forEach", "add error handling")
- KR's memory stores Islamic scholarly conventions, multi-model consensus decisions, pipeline architecture, Arabic text rules
- Mixing them dilutes domain-specific memory with generic noise, making session-start context loading less effective

### Additional Risks

- **Zero test suite** — pro-workflow has no automated tests. For a tool that hooks into every git commit and file write, this is a reliability risk
- **Single maintainer** — 2 contributors total, 0 open issues (likely disabled tracker), 0 dependents
- **Hook conflicts** — KR has `.codex/hooks/pre_tool_use_policy.py` (Arabic safety, budget enforcement). Pro-workflow's 24 hook events would either duplicate, conflict, or bypass these
- **Compact guard limits** — pro-workflow restricts context restore to 5 files / 50K tokens. KR's SPEC documents can be 20K+ tokens each; `/smart-compact` already handles this better
- **Plugin overlap** — KR already has superpowers (brainstorming, TDD, debugging, verification), compound-engineering (ce-brainstorm, ce-plan, ce-review, ce-work, git-commit, git-commit-push-pr), GSD (30+ project management commands). Pro-workflow's /develop, /commit, /wrap-up are strictly weaker versions of these

## What IS Worth Extracting (Concepts Only, Not Code)

Three ideas from pro-workflow that KR doesn't have and could benefit from:

### 1. Drift Detector (concept)
**What:** A hook that monitors whether current work is diverging from the stated session intent.
**Why valuable for KR:** Overnight Codex sessions sometimes drift from NEXT.md objectives. A Python hook in `.codex/hooks/` that compares current git diff topics against NEXT.md's stated goals could catch drift early.
**Implementation:** Port the concept as a Python script in `.codex/hooks/drift_detector.py`, reading NEXT.md at session start and comparing against accumulated changes. NOT the Node.js version.

### 2. Deslop Concept (command)
**What:** A pre-commit review pass that identifies and removes AI-generated code patterns (unnecessary abstractions, over-commenting, defensive coding for impossible cases).
**Why valuable for KR:** KR's pipeline has been built through many AI sessions. A `/deslop` command targeting Python-specific AI slop (bare excepts masked as "error handling", unnecessary `try/except` around infallible operations, redundant type annotations, over-generic utility functions) would improve maintainability.
**Implementation:** Create `.claude/commands/deslop.md` as a Python-focused code cleanup command. NOT the JS-centric version.

### 3. Adaptive Quality Gate Frequency (concept)
**What:** Adjusting checkpoint frequency based on historical correction rates (sessions with many corrections get tighter gates).
**Why valuable for KR:** Currently KR's quality gate runs at fixed intervals. Adapting based on session error history would reduce overhead on clean sessions and increase scrutiny on error-prone ones.
**Implementation:** Add a correction counter to `.codex/hooks/stop_quality_gate.py` that tracks per-session fix count and adjusts gate frequency.

## What pro-workflow Does That KR Already Does Better

| pro-workflow feature | KR equivalent | Why KR's is better |
|---|---|---|
| /commit (quality-gated) | /commit + commit-commands:commit + compound-engineering:git-commit | KR has 3 commit systems with Arabic-safe validation |
| /develop (4-phase) | ENGINE_PROTOCOL.md + HARDENING_SESSION_PROTOCOL | KR's protocol is scholarly-pipeline-specific |
| SKILL.md format | .claude/skills/kr-*/SKILL.md (15 skills) | Identical format; KR independently converged on it |
| Compact guard | /smart-compact + context-management.md | KR preserves SPEC rules, Arabic constraints, D-023 semantics |
| Session memory | MEMORY.md (83 entries) + agent-memory/ | Domain-categorized, cross-conversation |
| LLM commit gate | pre_tool_use_policy.py + stop_quality_gate.py | Python-native, budget-enforcing, Arabic-aware |
| Agent specialization | 23 agents (spec-auditors, verifiers, arabic-reviewer) | Domain-specific scholarly verification |
| Code review | /quality-gate + ce:review + code-reviewer agent | Multi-model consensus, coworker dispatch |
| Project planning | GSD (30+ commands) + ultraplan + ce:plan | Full project lifecycle management |
| Debugging | superpowers:systematic-debugging + build-fix | Structured with evidence requirements |

## Alternatives Considered

1. **Keep current setup (recommended)** — KR's 180+ component infrastructure is purpose-built. No generic tool adds value that isn't already covered or domain-inappropriate.

2. **Cherry-pick 3 concepts** — Extract drift-detector, deslop, and adaptive gate frequency as KR-native Python implementations. Zero dependency on pro-workflow code.

3. **Full installation** — REJECTED. Would add 29 Node.js scripts, npm build dependency, and generic hooks that conflict with KR's Arabic-aware Python hooks. Loss of potential is guaranteed, not prevented.

## Recommendation

**Option 2: Cherry-pick 3 concepts, implement natively.** This captures the 5% of pro-workflow that adds genuine value to KR while avoiding the 95% that would conflict, overlap, or dilute existing infrastructure.

Priority order:
1. Drift detector hook (most impactful for overnight Codex sessions)
2. Deslop command (most impactful for code quality)
3. Adaptive gate frequency (nice-to-have optimization)

All three should be implemented as Python/.md files within KR's existing infrastructure. No pro-workflow code is copied or installed.

## Verification

- Confirm pro-workflow assessment by checking its README and hooks.json (done by researcher agent)
- Confirm KR infrastructure counts: 15 skills, 23 commands, 23 agents, 20 rules, 5 hooks (verified via Glob)
- Confirm no existing drift detection in KR hooks (verified: `.codex/hooks/` has session_start, pre_tool_use_policy, stop_quality_gate, hook_utils, dispatch — no drift detection)
- Confirm no existing deslop equivalent in KR commands (verified: `.claude/commands/` has no deslop or code-cleanup command)
