# Plan: SPEC Sync + Full Integration Batch Script

## Context

The excerpting engine's SPEC.md has 8 stale values from two recent changes:
1. **MAX_TOKENS threshold** was lowered from 2000 to 1500 words (commit `24783dda`) but SPEC.md wasn't updated
2. **Model configuration** was changed from `gpt-4.1` → `gpt-5.4` and `command-a-03-2025` → `mistral-large-2411` (commit in session S328) but SPEC.md wasn't updated

Additionally, a batch integration script is needed to run all 5 packages sequentially for full-corpus LLM testing.

**Test baseline note:** User specified "595 passed, 2 skipped" but commit `1f79dba4` (boundary-exhaustive hardening) added 16 tests, bringing the count to ~613. Will report exact count during verification.

---

## Part 1: SPEC.md Sync (8 replacements + 1 note)

**File:** `engines/excerpting/SPEC.md`

### Threshold replacements (§5.5.1, lines 1163-1164):
1. Line 1163: `word_count <= 2000` → `word_count <= 1500`
2. Line 1164: `word_count > 2000` → `word_count > 1500`

### Model replacements (4 × gpt-4.1 → gpt-5.4):
3. Line 1777: `openai/gpt-4.1` → `openai/gpt-5.4` (verification model narrative)
4. Line 1829: `openai/gpt-4.1` → `openai/gpt-5.4` (verification params table)
5. Line 2055: `openai/gpt-4.1` → `openai/gpt-5.4` (Phase 3 params table)
6. Line 2388: `openai/gpt-4.1` → `openai/gpt-5.4` (evaluation methodology)

### Model replacements (2 × command-a → mistral-large):
7. Line 1845: `cohere/command-a-03-2025` → `mistralai/mistral-large-2411` (escalation prose)
8. Line 2057: `cohere/command-a-03-2025` → `mistralai/mistral-large-2411` (Phase 3 params table)

### Empirical note (after §5.5.1 scaling rule, ~line 1165):
Add after the scaling rule bullets:
> Threshold empirically lowered from 2000 to 1500 (2026-03-28): ibn_aqil_v3 حروف الجر chunk (1987 words, 15 layers) exceeded 8192 tokens on classification output.

### DO NOT TOUCH:
- Line 2035: `OVERSIZED_DIVISION_WORDS` range `2000–10000` — this is a config range, not a threshold comparison

### Verification:
- `grep -c "gpt-4.1" engines/excerpting/SPEC.md` → must return 0
- `grep -c "command-a-03-2025" engines/excerpting/SPEC.md` → must return 0
- `grep -c "word_count <= 2000\|word_count > 2000" engines/excerpting/SPEC.md` → must return 0

---

## Part 2: Batch Integration Script

**File:** `scripts/run_full_integration.py` (NEW)

### Design

Subprocess-based runner that invokes `scripts/run_integration_test.py` for each of 5 packages sequentially.

### Key details from exploration:
- **Package paths:** `experiments/format_diversity_test/packages/{name}/`
- **Existing CLI:** `--package-path`, `--output-dir`, `--source-metadata` (JSON string)
- **Output structure:** Per-package subdirectory with `run_metadata.json`, `timing.json`, `excerpts.jsonl`
- **API key:** `OPENROUTER_API_KEY` env var (validated by run_integration_test.py)

### Package configuration (hardcoded, 5 entries):

| Package | source-metadata |
|---------|----------------|
| ibn_aqil_v1 | `{"author_name":"ابن عقيل","work_title":"شرح ابن عقيل على ألفية ابن مالك","science":"نحو","school":null}` |
| ibn_aqil_v3 | same as v1 |
| taysir | `{"author_name":"عبد الله البسام","work_title":"تيسير العلام شرح عمدة الأحكام","science":"فقه","school":"حنبلي"}` |
| ext_39_masala | `{"author_name":null,"work_title":null,"science":null,"school":null}` |
| ext_46_qa | `{"author_name":null,"work_title":null,"science":"أصول النحو","school":null}` |

### Script structure:
```
argparse: --output-dir (default: integration_tests/full_run_{YYYYMMDD}/)
validate OPENROUTER_API_KEY exists
for each package:
    print progress header
    build subprocess command (no --max-chunks)
    run subprocess, capture stdout/stderr
    if crash: log error, record in results, continue
    else: parse run_metadata.json + timing.json + count excerpts.jsonl lines
    print per-book summary
print final summary table
write SUMMARY.json to output_dir
```

### SUMMARY.json schema:
```json
{
  "timestamp": "ISO-8601",
  "output_dir": "path",
  "packages": {
    "ibn_aqil_v1": {
      "status": "success|error",
      "excerpt_count": N,
      "error_count": N,
      "errors": [],
      "time_seconds": N.N,
      "cost_estimate": N.N
    }
  },
  "totals": {
    "packages_run": 5,
    "packages_succeeded": N,
    "packages_failed": N,
    "total_excerpts": N,
    "total_errors": N,
    "total_time_seconds": N.N,
    "total_cost_estimate": N.N
  }
}
```

### Patterns to follow (from existing scripts):
- `from __future__ import annotations`
- Type hints on all functions
- `pathlib.Path` for all paths
- `logging.getLogger(__name__)`
- `datetime.datetime.now(datetime.timezone.utc).isoformat()` for timestamps
- `subprocess.run()` with `capture_output=True`
- Read `run_metadata.json` for error_count, `timing.json` for phase timings
- Count `excerpts.jsonl` lines for excerpt count
- Cost from summing `raw_llm_responses/*.json` usage.cost fields

---

## Part 3: Verification

1. Run `python -m pytest engines/excerpting/tests/ -q --tb=short` — report exact pass/skip/fail count
2. Run grep verification for Part 1 (3 grep commands, all must return 0)
3. Do NOT run the batch integration script

---

## Execution Order

1. Read SPEC.md at the 8 target locations (confirm exact strings)
2. Make all 8 replacements + add empirical note
3. Run grep verification
4. Write `scripts/run_full_integration.py`
5. Run pyright on the new script
6. Run pytest on excerpting tests
7. Commit: `docs(excerpting): sync SPEC.md stale model + threshold values` + `feat(excerpting): add full integration batch runner script`
8. Push to remote

---

## Files Modified
- `engines/excerpting/SPEC.md` — 8 value replacements + 1 note addition
- `scripts/run_full_integration.py` — NEW file (batch runner)
