# KR Overnight Autonomous System v2 — Definitive Implementation Plan

## Context

**The pattern**: By day, Claude Chat (architect) gives structured directives. By night, Claude Code works autonomously for 7-8 hours — auditing, testing, validating, researching, hardening — bringing the project to the next level. This overnight system is the engine that transforms directive into reality.

**The v1 system** (CronCreate + task queue, March 22-23) proved the concept with 10/10 tasks completed but has fundamental limits: context degradation over hours, no quality gates between tasks, no error recovery, no multi-model verification.

**The v2 system** is built on 3 pillars:
1. **Claude Agent SDK** for programmatic Claude Code execution with fresh context per task
2. **Codex CLI** (`codex exec --full-auto`) for independent verification (the user has a subscription)
3. **The KR ecosystem** — 17 agents, 8 skills, 15 commands, 35+ quality scripts already built

---

## Research Findings — Tool Landscape

### Tools We're Integrating

| Tool | Role | Why |
|------|------|-----|
| **Claude Agent SDK** | Primary execution engine | Anthropic's official Python library. Session persistence, tool hooks, subagent dispatch. `pip install claude-agent-sdk` |
| **Claude Code CLI** (`claude -p`) | Simple tasks + agent dispatch | `--agent spec-auditor-a`, `--permission-mode plan`, `--max-budget-usd`. Inherits settings.json hooks. |
| **Codex CLI** (`codex exec`) | Independent code verification | Headless batch mode with `--full-auto`, `--json`, session resume. Python structural analysis, type checking, code review — tasks where Arabic domain knowledge isn't needed. |
| **Codex MCP** (tuannvm/codex-mcp-server) | In-session cross-model verification | Claude can call Codex via MCP tool for independent review within the same session. D-041 multi-model consensus. |
| **PAL MCP** (optional) | Multi-model consensus debates | `consensus({question, models, rounds})` tool for disputed decisions across Claude + GPT + Gemini. |

### Tools We Evaluated From User's Sources

| Tool | Stars | Verdict | Reason |
|------|-------|---------|--------|
| **ruflo** (Claude Flow) | 22.8k | **WATCH** | Native Claude Code MCP, SQLite WAL crash recovery, Windows confirmed. But rapid version cycling (v3.5.x) suggests instability. Evaluate after v4 stabilizes. Could replace custom orchestrator later. |
| **CodeMachine-CLI** | 2.4k | **WATCH** | Purpose-built to orchestrate Claude Code headless for hours. BETA (v0.8.0). TypeScript wrapper adds fragility. Revisit when stable. |
| **hive** | 9.8k | **NO** | Claude support via LiteLLM but no documented persistence for multi-hour runs. |
| **edict** | 12.1k | **NO** | 76 commits — viral hype, not production depth. Built on "OpenClaw" framework (this IS what "OpenClaw" is). |
| **SuperAGI** | 17.3k | **NO** | Stale since June 2024. |
| **agenticSeek** | 25.6k | **NO** | No Claude support at all. Local models only. |
| **pentagi** | 12.4k | **NO** | Security/pentest domain. |
| **yao** | 7.5k | **NO** | Go binary, alpha stage. |
| **ShortGPT** | 7.2k | **NO** | Video content tool — irrelevant. |

### Additional Discoveries

| Tool | What It Does | Potential |
|------|-------------|-----------|
| **metaswarm** (dsifry) | 9-phase workflow orchestrating Claude + Codex + Gemini with adversarial review gates | Pattern reference for our quality gate design |
| **claude_code_bridge** | Split-pane Claude + Codex simultaneous terminal | Interactive pairing, not overnight. But the daemon pattern is useful. |
| **PAL MCP** (BeehiveInnovations) | 15+ tools including `consensus`, `codereview`, `clink` (spawn CLIs as subagents) | Strong candidate for multi-model verification |

### Anthropic's Official Harness Pattern

From "Effective Harnesses for Long-Running Agents" (engineering blog):

> **Initializer agent**: Creates progress file + initial commit + structured task list.
> **Coding agent** (each session): Reads progress + git log before starting. Works one task. Commits + updates progress before ending.
> **Key insight**: Agents share state only through artifacts — progress files + git history = institutional memory.

This is our architecture. Each invocation reads `overnight/progress.md`, works one task, commits, updates progress.

---

## Architecture Overview

```
┌──────────────────────────────────────────────────────────────────┐
│  overnight_orchestrator.py                                        │
│                                                                    │
│  ┌─────────────┐ ┌─────────────┐ ┌──────────────────────────┐   │
│  │ Task         │ │ Scheduler   │ │ State + Progress         │   │
│  │ Generator    │ │ (priority   │ │ (state.json +            │   │
│  │ (8 scanners) │ │  + deps +   │ │  progress.md)            │   │
│  │              │ │  time guard)│ │                          │   │
│  └──────┬──────┘ └──────┬──────┘ └────────────┬─────────────┘   │
│         │               │                      │                  │
│  ┌──────┴───────────────┴──────────────────────┴──────────────┐  │
│  │                    EXECUTION ENGINE                         │  │
│  │                                                             │  │
│  │  Mode A: Claude Agent SDK (ClaudeSDKClient)                 │  │
│  │    → Complex tasks, full programmatic control               │  │
│  │    → Session persistence, PreToolUse hooks                  │  │
│  │                                                             │  │
│  │  Mode B: claude -p --agent <name>                           │  │
│  │    → Agent dispatch (spec-auditor-a, test-engineer, etc.)   │  │
│  │    → Inherits settings.json hooks automatically             │  │
│  │                                                             │  │
│  │  Mode C: codex exec --full-auto                             │  │
│  │    → Independent verification of Claude's work              │  │
│  │    → Code review, type analysis, structural checks          │  │
│  │    → NEVER for Arabic text or domain decisions              │  │
│  └─────────────────────────────────────────────────────────────┘  │
│         │                                                         │
│  ┌──────┴──────────────────────────────────────────────────────┐  │
│  │                    QUALITY GATE                              │  │
│  │  L1: Test suite (pytest)           → ROLLBACK on fail       │  │
│  │  L2: Git state (no frozen/delete)  → ROLLBACK on fail       │  │
│  │  L3: Compliance (pre_review_checks) → ROLLBACK on error     │  │
│  │  L4: Pyright type check            → Log only               │  │
│  │  L5: Codex independent review      → Flag discrepancies     │  │
│  └─────────────────────────────────────────────────────────────┘  │
│         │                                                         │
│  ┌──────┴──────┐  ┌──────────────┐  ┌────────────────────────┐  │
│  │ Git Commit / │  │ Circuit      │  │ Morning Report         │  │
│  │ Rollback     │  │ Breaker      │  │ (MORNING_REPORT.md)    │  │
│  └─────────────┘  └──────────────┘  └────────────────────────┘  │
└──────────────────────────────────────────────────────────────────┘
```

**Three execution modes** ensure the right tool for each task:
- **Claude SDK/CLI** for anything requiring Arabic understanding, SPEC interpretation, domain knowledge, or KR agent dispatch
- **Codex exec** for independent code-structural verification where Arabic domain knowledge is not needed
- **Codex MCP** (from within a Claude session) for inline multi-model verification (D-041 consensus)

---

## Components

### Component 1: Orchestrator — `scripts/overnight_orchestrator.py` (~800 lines)

The core. Manages the full overnight lifecycle.

```python
from __future__ import annotations
import subprocess, json, time, signal, os
from pathlib import Path
from dataclasses import dataclass, field
from datetime import datetime, timedelta

# Try Agent SDK, fall back to CLI-only mode
try:
    from claude_agent_sdk import ClaudeSDKClient
    HAS_SDK = True
except ImportError:
    HAS_SDK = False

PROJECT_DIR = Path("C:/Users/Rayane/Desktop/kr")

@dataclass
class TaskDef:
    task_id: str
    name: str
    category: str           # validation|test|spec|doc|code_quality|research|integration|verification
    prompt: str
    safety_level: str       # readonly|additive|modifying
    execution_mode: str     # sdk|cli|codex
    agent: str | None       # KR agent name for cli mode (e.g., "spec-auditor-a")
    model: str              # sonnet|opus for Claude, gpt-5-codex-mini for Codex
    max_budget_usd: float
    timeout_minutes: int
    allowed_tools: list[str]
    permission_mode: str    # plan|bypassPermissions
    depends_on: list[str]
    priority: int
    max_turns: int = 30
    codex_flags: list[str] = field(default_factory=list)  # extra codex exec flags

@dataclass
class TaskResult:
    task_id: str
    status: str             # success|failed|timeout|rolled_back|skipped
    start_time: str
    end_time: str
    duration_s: float
    output_summary: str
    commit_hash: str | None
    gate_result: dict | None
    error: str | None
    model_used: str
```

**Core execution loop:**

```python
def run_overnight(hours: float = 7.5, max_cost_usd: float = 25.0):
    # Pre-flight
    preflight_checks()  # clean git, tests pass, disk space, claude CLI available, codex CLI available

    state = init_state(hours)
    manifest = generate_or_load_manifest()
    write_progress_file(state, manifest)  # Anthropic harness pattern
    git_commit("overnight: initialize overnight session", ["overnight/"])

    # Graceful shutdown on Ctrl+C
    signal.signal(signal.SIGINT, lambda *_: graceful_shutdown(state))

    while within_deadline(state) and not circuit_breaker(state):
        task = pick_next_ready(manifest, state)
        if not task:
            break

        # Time guard: skip if task can't finish before deadline
        if not can_finish_before_deadline(task, state):
            state.skip(task.task_id, "insufficient time remaining")
            continue

        pre_snapshot = git_head()
        result = execute_task(task)

        # Quality gate (modification tasks + L5 Codex verification)
        if result.status == "success":
            if task.safety_level != "readonly":
                gate = run_quality_gate(task, result)
                if not gate["passed"]:
                    git_rollback(pre_snapshot)
                    result.status = "rolled_back"
                    result.gate_result = gate

            # L5: Optional Codex cross-verification for additive/modifying tasks
            if task.execution_mode != "codex" and task.safety_level != "readonly":
                codex_review = run_codex_verification(task, result)
                if codex_review.get("discrepancies"):
                    log_decision(f"Codex flagged discrepancies in {task.task_id}", codex_review)

        state.record(task.task_id, result)
        write_progress_file(state, manifest)
        save_state(state)

    generate_morning_report(state)
```

**Three execution backends:**

```python
def execute_task(task: TaskDef) -> TaskResult:
    if task.execution_mode == "sdk" and HAS_SDK:
        return execute_via_sdk(task)
    elif task.execution_mode == "codex":
        return execute_via_codex(task)
    else:
        return execute_via_cli(task)

def execute_via_sdk(task: TaskDef) -> TaskResult:
    """Claude Agent SDK — full programmatic control, session persistence."""
    client = ClaudeSDKClient(
        cwd=str(PROJECT_DIR),
        allowed_tools=task.allowed_tools,
        permission_mode=task.permission_mode,
        model=task.model,
        max_budget_usd=task.max_budget_usd,
        append_system_prompt=OVERNIGHT_SAFETY_PROMPT,
    )
    result = client.query(prompt=task.prompt, max_turns=task.max_turns)
    return TaskResult(status="success", output_summary=result.text[:2000], ...)

def execute_via_cli(task: TaskDef) -> TaskResult:
    """Claude Code CLI — agent dispatch, inherits hooks."""
    cmd = ["claude", "-p", task.prompt, "--output-format", "json",
           "--model", task.model, "--max-budget-usd", str(task.max_budget_usd),
           "--permission-mode", task.permission_mode, "--no-session-persistence",
           "--append-system-prompt", OVERNIGHT_SAFETY_PROMPT]
    if task.agent:
        cmd += ["--agent", task.agent]
    if task.allowed_tools:
        cmd += ["--allowedTools", ",".join(task.allowed_tools)]
    env = {**os.environ, "KR_OVERNIGHT": "1", "PYTHONIOENCODING": "utf-8"}
    result = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=task.timeout_minutes * 60, cwd=str(PROJECT_DIR), env=env)
    return parse_cli_result(result)

def execute_via_codex(task: TaskDef) -> TaskResult:
    """Codex CLI — independent verification. NEVER for Arabic content."""
    cmd = ["codex", "exec", "--full-auto", "--json",
           "--output-last-message", f"overnight/results/{task.task_id}/codex_output.md",
           *task.codex_flags, task.prompt]
    env = {**os.environ, "PYTHONIOENCODING": "utf-8"}
    result = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=task.timeout_minutes * 60, cwd=str(PROJECT_DIR), env=env)
    return parse_codex_result(result)

def run_codex_verification(task: TaskDef, claude_result: TaskResult) -> dict:
    """L5: Independent Codex review of Claude's work (D-041 multi-model verification)."""
    review_prompt = f"""Review the following changes made by another AI agent.
    Focus on: code structure, type safety, Pydantic patterns, test completeness.
    Do NOT evaluate Arabic text content or domain-specific decisions.
    Task: {task.name}
    Files modified: check git diff HEAD~1"""
    cmd = ["codex", "exec", "--full-auto", "--output-last-message",
           f"overnight/results/{task.task_id}/codex_review.md", review_prompt]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300,
                           cwd=str(PROJECT_DIR))
    return {"review": result.stdout, "discrepancies": parse_codex_findings(result)}
```

**Safety prompt (appended to every Claude task):**

```
OVERNIGHT AUTONOMOUS MODE — KR Pipeline Project.
You are executing a single task in the overnight autonomous system.

ABSOLUTE RULES:
- NEVER modify files in library/sources/*/frozen/
- NEVER modify primary_text content in any pipeline output
- NEVER delete any file or directory
- NEVER run git push
- NEVER modify .claude/settings.json
- There is no human present — do not ask questions
- Commit with message prefix "overnight: "
- Write summary to overnight/results/{TASK_ID}/summary.md

Read overnight/progress.md for context on what's been done tonight.
Read the active engine's CLAUDE.md for current state.
Follow all rules in CLAUDE.md and .claude/rules/*.
```

### Component 2: Task Generator — `scripts/overnight_task_generator.py` (~500 lines)

8 scanners + manifest writer. Discovers beneficial work by inspecting repo state.

| Scanner | Inputs | Output Tasks | Execution Mode |
|---------|--------|-------------|----------------|
| **Test Health** | `pytest --co -q`, coverage analysis | Gap-filling tests, adversarial tests | Claude CLI (`--agent test-engineer`) |
| **SPEC Quality** | `check_spec_quality.py` per engine | SPEC audits, example generation | Claude CLI (`--agent spec-auditor-a/b`) |
| **Code Quality** | Grep for `\d`, bare except, missing types | Fix Arabic-Indic digits, add type hints | Claude CLI (opus) |
| **Corpus Integrity** | Sweep age, integrity results | Re-validate corpus, check calibration | Claude SDK (sonnet) |
| **Contract Boundaries** | `verify_metadata_flow.py` | Verify D-023, cross-engine alignment | Claude CLI (`--agent boundary-validator`) |
| **Known Limitations** | `KNOWN_LIMITATIONS.md` freshness | Re-calibrate thresholds | Claude SDK (sonnet) |
| **Documentation** | Git log vs doc references | Update stale docs | Claude CLI (sonnet) |
| **Research** | NEXT.md upcoming engine | Technology surveys | Claude CLI (`--agent deep-researcher`) |

**Additionally: Codex verification tasks**
After every Claude additive/modifying task, the generator auto-appends a Codex verification task:

```python
def add_codex_verification(claude_task: TaskDef) -> TaskDef:
    return TaskDef(
        task_id=f"{claude_task.task_id}-verify",
        name=f"Codex review: {claude_task.name}",
        category="verification",
        prompt=f"Review the code changes from task '{claude_task.name}'. "
               f"Check: type safety, Pydantic patterns, test completeness, "
               f"error handling. Do NOT evaluate Arabic text or domain logic.",
        execution_mode="codex",
        safety_level="readonly",
        model="gpt-5-codex-mini",  # cheaper model for verification
        depends_on=[claude_task.task_id],
        priority=claude_task.priority,  # same priority, but after dependency
        timeout_minutes=10,
        max_budget_usd=0.50,
        codex_flags=["--full-auto"],
        ...
    )
```

**Priority system:**

```
P1 (critical)  — Test regression check (gates everything)
P2 (high)      — Corpus integrity validation
P3 (high)      — Cross-engine contract checks
P4 (standard)  — Test coverage improvement + Codex verification
P5 (standard)  — SPEC quality audits (using spec-auditor-a/b agents)
P6 (standard)  — Code quality fixes + Codex verification
P7 (low)       — Documentation updates
P8 (low)       — Research for upcoming engines
```

### Component 3: Quality Gate — 5 Levels

| Level | Check | Tool | Failure = |
|-------|-------|------|-----------|
| **L1** | Test suite passes | `pytest engines/*/tests/ -x -q` | ROLLBACK |
| **L2** | No frozen source / deletion changes | `git diff --name-status` | ROLLBACK |
| **L3** | Compliance | `pre_review_checks.py` on modified files | ROLLBACK on errors |
| **L4** | Type safety | `pyright` on modified Python files | Log only |
| **L5** | Cross-model verification | `codex exec --full-auto "review..."` | Flag discrepancies |

**L5 is the new addition** — every modification task gets an independent Codex review. Discrepancies are logged in `overnight/decisions.log` for morning review, but don't trigger automatic rollback (Claude has domain authority, Codex has structural authority).

### Component 4: State + Progress (Anthropic Harness Pattern)

Two files, two purposes:

**`overnight/state.json`** — Machine-readable, for orchestrator recovery:
```json
{
  "run_id": "2026-03-25_overnight",
  "started_at": "2026-03-25T00:00:00Z",
  "deadline": "2026-03-25T07:30:00Z",
  "status": "running",
  "git_start_hash": "06db7fd",
  "consecutive_failures": 0,
  "total_cost_usd": 0.00,
  "codex_cost_note": "Codex costs billed to OpenAI subscription, tracked separately",
  "results": {}
}
```

**`overnight/progress.md`** — Human-readable, read by each Claude session:
```markdown
# Overnight Progress — 2026-03-25

## What's Been Done
- [x] val-001: Test regression (1,069 pass, 0 fail) — 3 min
- [x] val-002: Corpus integrity (7,475/7,475 clean) — 48 min
- [x] test-001: Added 8 adversarial tests for ADV-023–030 — 22 min
- [x] test-001-verify: Codex review (no discrepancies) — 3 min

## In Progress
- [ ] spec-001: SPEC quality audit (excerpting §4-§5)

## Remaining
- [ ] cq-001: Code quality scan (normalization)
- [ ] cq-001-verify: Codex review of code quality fixes
```

### Component 5: Morning Report — `overnight/MORNING_REPORT.md`

```markdown
# Overnight Report — 2026-03-25

## Summary
- Duration: 7h 12m | Tasks: 14/16 + 8 Codex verifications
- Commits: 13 (abc1234..def5678) | Tests: 1,082 (+13)
- Claude cost: $1.40 | Codex cost: ~$0.80 (subscription)
- Status: CLEAN | Cross-model discrepancies: 1

## Completed Tasks
### Validation (3 tasks)
- [x] Test regression: 1,069 pass, 0 fail (3 min, sonnet)
- [x] Corpus integrity: 7,475/7,475 clean (48 min, sonnet)
- [x] Cross-engine contracts: aligned (2 min, boundary-validator)

### Test Hardening (4 tasks + 2 verifications)
- [x] Adversarial tests for ADV-023–030 (22 min, test-engineer opus)
  - Codex review: CLEAN — no structural issues
- [x] Coverage gap: normalization §4.A 85% → 92% (18 min, test-engineer opus)
  - Codex review: CLEAN

### SPEC Quality (2 tasks)
- [x] Excerpting §4 audit: 3 ambiguous rules found (20 min, spec-auditor-a)
- [x] Excerpting §5 audit: 1 hollow example (15 min, spec-auditor-b)

## Cross-Model Discrepancies (YOUR REVIEW NEEDED)
1. **cq-001-verify**: Codex flagged that `validate_excerpt_offset()` returns
   `None` on invalid input instead of raising. Claude chose this intentionally
   per SPEC §8.2 "soft validation for non-critical fields."
   → Codex's structural concern is valid. Owner should confirm SPEC intent.
   → See: overnight/results/cq-001-verify/codex_review.md

## Issues Found
1. L-005 calibration drift: documented 1.8%, measured 2.3%
2. Excerpting SPEC §5.2: 3 rules use "as appropriate"

## Autonomous Decisions Made
- Used sonnet for all readonly tasks (cost optimization)
- Skipped res-002: exceeded time budget
- Codex verification skipped for readonly tasks (no changes to verify)

## Suggested Next Overnight Tasks
1. Write tests for 6 uncovered ADV cases
2. Fix Arabic-Indic digit regex (3 instances in normalization)
3. Resolve SPEC §5.2 ambiguity (needs architect input)
```

---

## Task Categories, Agents, and Execution Modes

### Leveraging the Full KR Agent Ecosystem

| Task Type | KR Agent | Execution | Model | Why This Agent |
|-----------|----------|-----------|-------|---------------|
| SPEC pattern audit (1-4) | `spec-auditor-a` | CLI | opus | Trained for hollow examples, circular defs, hand-waving |
| SPEC pattern audit (5-7) | `spec-auditor-b` | CLI | opus | Trained for untestable rules, missing error paths |
| SPEC integrity gate | `integrity-auditor` | CLI | opus | 8-lens audit, blocks build |
| Test writing | `test-engineer` | CLI | opus | Writes pytest from SPEC §4 behavioral rules |
| Code review | `code-reviewer` | CLI | opus | SPEC fidelity, Arabic safety, D-023 |
| Build drift detection | `build-prober` | CLI | opus | Catches deviations from SPEC |
| Contract validation | `boundary-validator` | CLI | sonnet | Cross-engine boundary checks |
| Corpus integrity | `library-integrity-checker` | CLI | sonnet | Referential integrity, schema conformance |
| Research | `deep-researcher` | CLI | sonnet | Technology surveys, library evaluation |
| Adversarial testing | `spec-adversary` | CLI | opus | 51 adversarial cases (T-1–T-7) |
| Finding comparison | `audit-comparator` | CLI | opus | Diff across audit rounds |
| Independent verification | — | Codex | gpt-5-codex-mini | Code structure, types, patterns |

### Safety Classification

| Safety Level | Permission Mode | Execution Modes | Quality Gate |
|-------------|----------------|-----------------|-------------|
| **readonly** | `plan` | Claude CLI/SDK | None needed |
| **additive** | `bypassPermissions` | Claude CLI/SDK + Codex verify | L1-L5 |
| **modifying** | `bypassPermissions` | Claude CLI/SDK + Codex verify | L1-L5 |

### What NEVER Runs Overnight
- Engine source code in `engines/*/src/` (requires architect direction)
- SPEC.md modifications (requires design review)
- contracts.py structural changes (architect task)
- Gold baseline changes (requires owner verification)
- Any Arabic text content decisions routed to Codex

---

## Safety Framework — 6 Layers of Defense

```
Layer 1: Tool Restrictions (allowed_tools per task)
   └─ Readonly tasks physically cannot modify files

Layer 2: Permission Mode (per task)
   └─ "plan" for analysis, "bypassPermissions" for writes

Layer 3: Settings.json Hooks (inherited by claude -p)
   └─ circuit-breaker (3 failures → stop)
   └─ cost-guard (budget check before API calls)
   └─ no-ask-human (KR_OVERNIGHT=1 → block questions)
   └─ pre-commit check, Arabic safety, auto-test, pyright, boundary-check

Layer 4: Orchestrator Quality Gate (post-task)
   └─ L1: Test suite | L2: Git state | L3: Compliance | L4: Pyright

Layer 5: Codex Cross-Verification (D-041 multi-model)
   └─ Independent structural review of Claude's changes
   └─ Discrepancies flagged for morning review

Layer 6: Git Rollback (last resort)
   └─ git reset --hard to pre-task snapshot
   └─ Logged in decisions.log
```

---

## Implementation Steps

### Step 1: Install Dependencies

```bash
pip install claude-agent-sdk    # Anthropic's official Agent SDK
pip install nssm_exe            # Windows service wrapper (optional, for crash recovery)
# Codex CLI already installed (user confirmed)
# Codex MCP already installed (user confirmed)
```

Verify Codex: `codex --version && codex exec --help`

### Step 2: Core Orchestrator — `scripts/overnight_orchestrator.py` (~800 lines)

Implement:
- Pre-flight checks (clean git, tests pass, disk space, claude + codex CLIs available)
- Three execution backends (SDK, CLI, Codex)
- Quality gate (5 levels including Codex L5)
- State manager (JSON + progress.md harness file)
- Git operations (snapshot, commit with "overnight: " prefix, rollback)
- Morning report generator
- Crash recovery (read state.json, reconcile with git log, resume)
- Signal handling (SIGINT → graceful shutdown with partial report)
- Budget tracking (Claude via --max-budget-usd, Codex tracked separately)
- Circuit breaker (3 consecutive failures → stop)
- Time guard (don't start tasks that can't finish before deadline)

**Reuses existing infrastructure:**
- `scripts/session_quality_gate.py` — quality gate patterns
- `.claude/hooks/*` — safety hooks (inherited by `claude -p` automatically)
- `scripts/check_spec_quality.py` — SPEC scanner input
- `scripts/verify_metadata_flow.py` — contract scanner input
- `scripts/pre_review_checks.py` — code quality scanner

### Step 3: Task Generator — `scripts/overnight_task_generator.py` (~500 lines)

Implement:
- 8 scanners (test health, SPEC quality, code quality, corpus integrity, contracts, limitations, docs, research)
- Auto-append Codex verification tasks for additive/modifying Claude tasks
- Manifest writer (JSON with priority, dependencies, execution mode)
- Priority system (P1-P8) with dependency DAG
- Task-to-agent mapping (which KR agent handles each task type)

### Step 4: Launch Infrastructure

**`scripts/start_overnight.sh`:**
```bash
#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
export KR_OVERNIGHT=1
export PYTHONIOENCODING=utf-8

# Pre-flight
[ -n "$(git status --porcelain)" ] && echo "ERROR: Uncommitted changes" && exit 1

# Generate or use provided manifest
MANIFEST="${1:-}"
[ -z "$MANIFEST" ] && python scripts/overnight_task_generator.py --output overnight/manifest.json && MANIFEST="overnight/manifest.json"

echo "Starting KR overnight session: $MANIFEST"
python scripts/overnight_orchestrator.py --manifest "$MANIFEST" --hours 7.5 --max-cost-usd 25.0
echo "Done. See overnight/MORNING_REPORT.md"
```

**Optional: Windows Task Scheduler (fire-and-forget):**
```bash
schtasks /create /tn "KR-Overnight" /tr "bash C:\Users\Rayane\Desktop\kr\scripts\start_overnight.sh" /sc DAILY /st 23:00
```

**Optional: NSSM service (auto-restart on crash):**
```bash
nssm install KR-Overnight python.exe C:\Users\Rayane\Desktop\kr\scripts\overnight_orchestrator.py --hours 7.5
nssm set KR-Overnight AppDirectory C:\Users\Rayane\Desktop\kr
nssm set KR-Overnight AppEnvironmentExtra KR_OVERNIGHT=1 PYTHONIOENCODING=utf-8
```

### Step 5: Directory Structure

```
overnight/                       # All overnight artifacts
  state.json                     # Machine-readable run state (orchestrator recovery)
  progress.md                    # Human-readable progress (Anthropic harness pattern)
  manifest.json                  # Task list for this run
  decisions.log                  # Append-only autonomous decision log
  MORNING_REPORT.md              # Post-run summary for owner
  results/                       # Per-task output directories
    val-001/summary.md           # Claude task output
    test-001/summary.md          # Claude task output
    test-001-verify/             # Codex verification
      codex_output.md
      codex_review.md
    ...
```

### Step 6: Codex MCP Verification Skill (optional enhancement)

Create `.claude/skills/codex-verify/SKILL.md` so Claude sessions can invoke Codex review inline:

```markdown
---
name: codex-verify
description: Independent code review via Codex MCP
---
When you've completed a code modification task, invoke the Codex MCP `review`
tool to get an independent structural review. Compare findings with your own
assessment. Log any discrepancies to overnight/decisions.log.

IMPORTANT: Codex has NO Arabic text understanding. Only ask Codex to review:
- Python code structure and patterns
- Pydantic model definitions
- Type safety and error handling
- Test completeness and patterns
NEVER ask Codex about Arabic text content, diacritics, or scholarly domain logic.
```

### Step 7: Testing the System

1. **Dry run**: `--dry-run` generates manifest, prints execution plan
2. **Single Claude task**: `--task val-001` (test regression, readonly)
3. **Single Codex task**: `--task test-001-verify` (Codex review, readonly)
4. **Claude + Codex pair**: Run additive task + its verification
5. **Rollback test**: Intentional quality gate failure → verify git reset
6. **Recovery test**: Kill mid-task → restart → verify resume
7. **Budget test**: `--max-cost-usd 0.01` → verify early stop
8. **30-minute run**: `--hours 0.5` with 3-5 tasks
9. **First overnight**: 7.5h with owner checking first hour

---

## Critical Files Summary

| File | Action | Lines | Purpose |
|------|--------|-------|---------|
| `scripts/overnight_orchestrator.py` | **CREATE** | ~800 | Core: 3 execution backends, quality gate, state, reporting |
| `scripts/overnight_task_generator.py` | **CREATE** | ~500 | 8 scanners + Codex verification auto-append + manifest |
| `scripts/start_overnight.sh` | **CREATE** | ~25 | Launch script with pre-flight checks |
| `overnight/` directory | **CREATE** | — | State, progress, results, reports |
| `.claude/skills/codex-verify/SKILL.md` | **CREATE** | ~20 | Codex MCP verification skill for inline use |
| `.claude/settings.json` | **NO CHANGE** | — | Hooks already configured |
| `.claude/hooks/*` | **NO CHANGE** | — | Safety hooks already wired |
| `.claude/agents/*` | **NO CHANGE** | — | 17 agents already defined and usable via --agent |
| `scripts/session_quality_gate.py` | **REUSE** | — | Quality gate pattern |
| `scripts/check_spec_quality.py` | **REUSE** | — | SPEC scanner input |
| `scripts/verify_metadata_flow.py` | **REUSE** | — | Contract scanner input |
| `scripts/pre_review_checks.py` | **REUSE** | — | Code quality scanner |

---

## The Vision

```
11:00 PM  Owner runs: bash scripts/start_overnight.sh
          Orchestrator initializes, generates 15-20 tasks

11:05 PM  P1: Test regression check (sonnet, 3 min)
          → 1,069 tests pass. Gate open.

11:10 PM  P2: Corpus integrity validation (sonnet, 48 min)
          → 7,475 books verified clean.

12:00 AM  P3: Cross-engine contracts (boundary-validator, 5 min)
          → Source→Normalization boundary aligned.

12:10 AM  P4: Adversarial test generation (test-engineer opus, 25 min)
          → 8 new tests for ADV-023 through ADV-030
12:35 AM  P4-verify: Codex reviews new tests (gpt-5-codex-mini, 5 min)
          → Clean. No structural issues.

12:40 AM  P4: Coverage gaps (test-engineer opus, 20 min)
          → Normalization §4.A coverage 85% → 92%
1:00 AM   P4-verify: Codex reviews coverage tests (5 min)
          → Clean.

1:05 AM   P5: SPEC audit excerpting §4 (spec-auditor-a, 20 min)
          → 3 ambiguous rules found, documented.
1:25 AM   P5: SPEC audit excerpting §5 (spec-auditor-b, 15 min)
          → 1 hollow example found, documented.

1:40 AM   P6: Code quality scan (opus, 20 min)
          → Fixed 3 Arabic-Indic digit regex. Type hints added to 7 functions.
2:00 AM   P6-verify: Codex structural review (5 min)
          → 1 discrepancy: validate_excerpt_offset() returns None vs raise.
          → Logged for morning review.

2:05 AM   P7: Documentation freshness (sonnet, 15 min)
          → Updated KNOWN_LIMITATIONS.md L-005 calibration.

2:20 AM   P8: Technology survey — Arabic sentence boundaries (deep-researcher, 20 min)
          → Survey report written to overnight/results/res-001/survey.md

2:40 AM   Additional: Integrity auditor dry-run on excerpting SPEC (20 min)
          → 2 MUST-FIX findings documented for architect review.

...       [continues through remaining tasks]

6:30 AM   Time guard: insufficient time for remaining tasks. Graceful stop.
          Morning report generated.

7:00 AM   Owner wakes up. Reads overnight/MORNING_REPORT.md.
          13 commits. 1,082 tests (+13). 1 cross-model discrepancy to review.
          Project is measurably better than 8 hours ago.
```
