# Source Engine Deep Review — Round 2: Fix Verification & Remaining Issues

## Context

Round 1 applied 8 bug fixes (BUG-2 through BUG-10). Round 2 is a critical self-review
of those fixes plus a final sweep for anything missed. Three verification agents
independently reviewed all changes and the full engine.

---

## Bugs Found in Round 2

### CRITICAL — Introduced by BUG-3 fix (must fix immediately)

**NEW-BUG-1: Missing gate handler for `consistency_author_science` in engine.py**
- File: `engines/source/src/engine.py:604-635`
- BUG-3 changed check 5c severity from "warning" to "gate"
- But engine.py's gate loop (lines 609-629) only handles 3 check types:
  `confidence_threshold`, `multi_layer_empty_layers`, `consistency_hashiyah_no_layers`
- There is NO handler for `consistency_author_science`
- Result: when 5c triggers a gate, the loop creates NO checkpoint, then raises the error
- The owner never sees a reviewable checkpoint for author-science mismatches
- **The wrapper function already exists**: `gate_author_science_mismatch()` in
  `engines/source/src/human_gate.py:121-137` — it just isn't imported or called
- **Fix**:
  1. Add `gate_author_science_mismatch` to the import (engine.py:54-58)
  2. Add handler in gate loop (after line 629):
     ```python
     elif gate_error.check == "consistency_author_science":
         author_id = data_for_validation.get("author", {}).get("canonical_id", "")
         known = list(registries.get("scholars", {}).get(author_id, {}).get("school_affiliations", {}).keys())
         source_sci = data_for_validation.get("science_scope", [])
         gate_author_science_mismatch(source_id, known, source_sci, gate_error.message)
     ```

### HIGH — Pre-existing issues found during sweep

**NEW-BUG-2: Logger `_append()` crashes on I/O errors**
- File: `engines/source/src/logger.py:111-114`
- `_append()` has no try/except. Any I/O error (disk full, permissions) propagates up.
- In engine.py, this would be caught by `except Exception` (line 664) and wrapped as
  INTERNAL_ERROR — so it doesn't crash the process, but it ABORTS the current source
  acquisition for a logging failure, which is wrong.
- **Fix**: Wrap `_append` body in try/except OSError, log to stderr, never crash.

**NEW-BUG-3: Genre synonyms JSON crash at module import**
- File: `engines/source/src/metadata_inference.py:53-56`
- `json.loads()` at module level with no try/except for JSONDecodeError
- Malformed `library/config/genre_synonyms.json` crashes the entire module import
- **Fix**: Wrap in try/except, default to empty dict with warning.

### LOW — Code quality

**NEW-BUG-4: `import uuid` inside function body**
- File: `engines/source/src/text_utils.py:171`
- Should be at module level (line 10-11 area)
- Not a bug, but violates conventions. Python caches imports, so no runtime cost, but messy.
- **Fix**: Move to module-level import.

### False Positives from Round 2 agents

- **"Check 6c not implemented"** — FALSE. It IS implemented at validation.py:356-372.
- **"Logger batch alert division by zero"** — FALSE. Guarded by `if self._batch_source_count > 0`.
- **"Config doesn't validate library_root"** — TRUE but very low risk. The engine creates
  directories as needed with `mkdir(parents=True, exist_ok=True)`.

---

## Execution Plan

### Step 1: Fix NEW-BUG-1 (critical — our change broke this)
1. Add `gate_author_science_mismatch` to engine.py imports (line 54-58)
2. Add handler in gate loop (after line 629)

### Step 2: Fix NEW-BUG-2 (logger crash protection)
3. Wrap `_append()` in try/except OSError in logger.py

### Step 3: Fix NEW-BUG-3 (genre synonyms)
4. Wrap genre synonyms loading in try/except in metadata_inference.py

### Step 4: Fix NEW-BUG-4 (import placement)
5. Move `import uuid` to module level in text_utils.py

### Step 5: Run tests
6. `python -m pytest engines/source/tests/ shared/*/tests/ -v --tb=short`
7. Verify 0 failures

---

## Files to Modify

| File | Change |
|------|--------|
| `engines/source/src/engine.py:54-58,629` | Import + handler for author-science gate |
| `engines/source/src/logger.py:111-114` | try/except around _append I/O |
| `engines/source/src/metadata_inference.py:53-56` | try/except around genre synonyms |
| `engines/source/src/text_utils.py:10,171` | Move import uuid to module level |
