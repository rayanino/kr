# Adversarial Review of Cross-Audit Synthesis Plan

## Findings (ordered by severity)

---

### FINDING 1 -- CRITICAL: Codex changes are uncommitted, making PR#14 incomplete as stated

**Severity: CRITICAL**

The plan says "Merge PR#14 to main" as the single best next move. But the current branch has 12 files of uncommitted changes from Codex's audit session (CF-001 through CF-003 resolutions: deletion of SUPERVISED_PROVING_RUN.md, rewrites of TOOLING_AND_RESEARCH, HUMAN_OPERATING_PLAYBOOK, IMMEDIATE_NEXT_ACTIONS, etc.). These changes exist only as unstaged diffs on disk.

If you merge PR#14 right now, you merge the Claude commits but NOT the Codex corrections. That means CF-001 (historical runtime protocol still in active docs) and CF-002 (runtime framing in docs) and CF-003 (generic next-move phrasing) all survive the merge unresolved.

The plan does not acknowledge this gap. Its "DO NOW step 1" is incomplete as specified.

**What should change:** Step 1 must be: commit Codex's pending changes first, push the branch, THEN merge PR#14. This is a prerequisite, not an optional sub-step.

---

### FINDING 2 -- HIGH: The plan missed a shared finding across all three audits

**Severity: HIGH**

All three audits independently flagged the same thing: the quarantine custody model is fragile because it points to a local Windows desktop path (`C:\Users\Rayane\Desktop\IsIdeas_quarantine\`).

- Claude audit: created the quarantine at that path but did not flag the fragility.
- Codex audit: accepted the quarantine as-is without questioning durability.
- ChatGPT audit: explicitly flagged this as finding #8 ("custody model is weak... machine-specific, non-portable, and hard to review later").

The synthesis plan puts "Move quarantine custody to durable reference" as DO LATER item 5, rated MEDIUM. But this is the one concrete finding where all three audits converge on a real structural weakness (even if Claude and Codex converged implicitly by not solving it). A finding that survives three independent reviews without resolution deserves higher priority than MEDIUM-later.

More importantly: `workflows/QUARANTINE_PROTOCOL.md` hardcodes that local path in its procedure steps. That means every future quarantine operation will replicate the fragility. The protocol itself is the vector, not just the current entries.

**What should change:** Promote this to DO NOW or at minimum early DO LATER with an explicit note that QUARANTINE_PROTOCOL.md itself must be updated, not just QUARANTINED_BUILDS.md.

---

### FINDING 3 -- HIGH: "Owner-approval requirement" (DO NOW #2) has no enforcement mechanism and the plan does not specify one

**Severity: HIGH**

The plan says: "Add owner-approval requirement for scope-critical mutations." ChatGPT's recommendation 3 was explicit: require owner approval for frontier promotion, handoff promotion, and scope-boundary changes. The plan adopts this but does not say HOW.

The only destination mentioned is "add to EMPLOYEE_PROTOCOLS" (step 2 of next 3 steps). But EMPLOYEE_PROTOCOLS is an advisory document that AI agents read. Adding more advisory language to an advisory document is exactly the pattern that failed with the original "no implementations" rule -- it was written, and it was ignored.

ChatGPT's original finding said: "The current anti-self-ratification language is good but insufficient." The plan's response is to add more of the same kind of language. That is not responsive to the criticism.

Unless this becomes a GitHub branch protection rule (require owner review on PRs) or a CODEOWNERS file, it is advisory text protecting against the failure of advisory text.

**What should change:** The plan should specify that the enforcement mechanism is a GitHub-level control (branch protection requiring owner review, or CODEOWNERS), not just more markdown prose. If the owner chooses prose-only, the plan should explicitly acknowledge this is a weaker-than-recommended tradeoff.

---

### FINDING 4 -- MEDIUM: The "lifecycle vocabulary" fix (DO NOW #3) is over-ranked relative to impact

**Severity: MEDIUM (the finding is real; the ranking is wrong)**

Renaming "Priority" to "Lane" in IDEA_REGISTRY is a legitimate cleanup. But it is ranked as DO NOW #3, ahead of items like the external forbidden-file gate, quarantine durability, handoff-freeze rule, and sourcing the I-002 curriculum.

This is a column rename in a 4-row markdown table. It prevents "portfolio confusion and sloppy promotion logic" in ChatGPT's words, but the table currently has 4 ideas and one human reader. The confusion risk is theoretical at current scale. Meanwhile, the external forbidden-file gate directly prevents the recurrence of the single most dangerous failure mode the entire audit series was triggered by.

**What should change:** Demote vocabulary fix to early DO LATER. Promote external forbidden-file gate to DO NOW #3 (or at least acknowledge that it was demoted from ChatGPT's explicit #2 recommendation, and explain why).

---

### FINDING 5 -- MEDIUM: The REJECT for "ban in-repo dashboards" is correct in conclusion but wrong in reasoning

**Severity: MEDIUM**

The plan rejects ChatGPT recommendation 7 ("ban in-repo dashboards permanently") as "redundant with FACTORY_SCOPE_BOUNDARY." That conclusion is defensible, but the reasoning is slightly off.

FACTORY_SCOPE_BOUNDARY bans application source code file types. A dashboard built as a set of markdown files with embedded HTML or SVG -- which is technically possible -- would not violate FACTORY_SCOPE_BOUNDARY's forbidden-file-type list. The boundary's "test" question ("Is this documentation, governance, or a handoff artifact?") would catch it, but that test is advisory, not mechanical.

The real reason the explicit dashboard ban is redundant is that ADR-011 already records the root-cause analysis of why the dashboard was dangerous and why it was removed. A future session would have to contradict ADR-011, which is a stronger barrier than a standalone rule.

This is not a plan-breaking issue, but the reasoning should be tightened. If someone later argues "this markdown dashboard does not violate FACTORY_SCOPE_BOUNDARY," the rebuttal is ADR-011, not the file-type list.

---

### FINDING 6 -- MEDIUM: The plan does not address the untracked audit files

**Severity: MEDIUM**

Git status shows three untracked files in `audits/`:
- `audits/2026-03-31-chatgpt-pr14-scope-audit.md`
- `audits/2026-03-31-codex-factory-hardening-verification.md`
- `audits/README.md`

These are the actual audit artifacts that the entire synthesis is built on. They are not tracked by git and not part of PR#14. If someone runs `git clean -fd`, all three disappear.

The plan says "merge PR#14" but does not mention that the audit files themselves need to be committed first. The Claude audit was committed (commit `7468249`), but the Codex and ChatGPT audits are not.

**What should change:** Add an explicit pre-merge step: commit all three audit artifacts and the Codex pending changes before merging.

---

### FINDING 7 -- LOW: The REJECT for "process-infrastructure pruning rules" deserves a lighter touch

**Severity: LOW**

The plan rejects ChatGPT finding #9 (process-infrastructure drift) as "meta-governance fighting bureaucracy with bureaucracy." That is a good instinct, but ChatGPT's concern was not entirely unfounded. The branch added: bottleneck map, critique registry, integrity board, tooling/research, handoff queue, repo health, task queue, and cadences as new governance surfaces. That is 8 new tracking files on top of an already large governance layer.

A full pruning/expiry rule system would indeed be over-engineered. But a single line in OPERATING_CADENCES or the operating loop -- something like "if a governance surface has not been meaningfully updated in 3 cycles, flag it for removal review" -- would cost almost nothing and directly address the concern without creating new bureaucracy.

The complete rejection forecloses a cheap safeguard.

**What should change:** Instead of hard REJECT, make it a soft REJECT with a note: consider adding a one-line staleness check to the existing operating loop rather than creating a separate governance document.

---

## Items the plan gets right

1. **PR#14 merge as the single best next move** -- correct. The branch-vs-main split is the highest-risk state the repo is in right now. Every other improvement is reversible while this split persists.

2. **REJECT of in-repo automated guard** -- correct. This is the most important reject in the plan. Reintroducing a toolchain to guard against toolchain reintroduction is self-defeating. The plan correctly inherits the CF-004 tradeoff reasoning from both Claude and Codex.

3. **Sourcing a published curriculum for I-002 as DO LATER** -- correct ranking. All three audits agree this is the right next substantive move for the factory, but it is a research task that cannot be rushed and does not block the governance corrections.

4. **Handoff-freeze rule as DO LATER** -- correct. The risk is real but low at current scale (1 item in handoff queue). Worth adding but not urgent.

---

## Verdict: what should change in the plan

| # | Change | Why |
|---|---|---|
| 1 | Add pre-merge step: commit Codex's 12 pending file changes and the 3 untracked audit files BEFORE merging PR#14 | Without this, the merge is incomplete and two of three audits are not preserved |
| 2 | Specify that owner-approval is a GitHub-level control, not just EMPLOYEE_PROTOCOLS prose | Advisory text protecting against failure of advisory text is not responsive to the criticism |
| 3 | Promote quarantine custody durability from MEDIUM-later to HIGH-early, and note that QUARANTINE_PROTOCOL.md itself must be updated | Three-audit convergent finding; the protocol hardcodes the fragility |
| 4 | Swap DO NOW #3 (vocabulary fix) with DO LATER #4 (external forbidden-file gate) | Column rename in a 4-row table is less urgent than mechanical drift prevention |
| 5 | Tighten the dashboard-ban rejection reasoning to cite ADR-011 as the primary barrier, not FACTORY_SCOPE_BOUNDARY | The file-type list alone does not cover all dashboard forms |
| 6 | Soften the process-infrastructure rejection to allow a one-line staleness check in the operating loop | Cheap safeguard, not a new governance document |

Everything else in the plan should stay as-is.
