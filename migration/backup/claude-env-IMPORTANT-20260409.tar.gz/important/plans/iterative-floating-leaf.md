# Plan: Gemini DR Report (#5 FINAL) + Complete 5-Coworker Synthesis

## Context

Gemini DR is the final coworker report (5/5). It's a 176-line scholarly document with 21 academic citations providing a complete classical Islamic curriculum framework for the digital library. This is the most architecturally disruptive of all 5 reports — it introduces new sciences, proposes architectural masking layers, and provides a month-by-month data collection calendar grounded in Islamic pedagogy literature.

## Gemini DR Deep Analysis

### Most Critical Finding: الفقه على المذاهب الأربعة is Pedagogically Dangerous

Gemini DR argues (backed by academic citations) that the owner's priority book — a comparative fiqh text covering all 4 schools — is a "catastrophic pedagogical failure" for a beginner with "minimum Islamic knowledge." Classical pedagogy mandates single-madhab mastery (taqlid) BEFORE comparative study (khilaf).

**Proposed solution:** A "masking layer" that:
1. Forces the student to designate a primary madhab
2. Extracts ONLY that madhab's rulings from the text
3. Algorithmically suppresses the other 3 schools
4. Gradually unlocks comparative layers after verified baseline mastery

This is a MAJOR architectural finding that the other 4 coworkers missed or only partially addressed.

### 5 Genuinely Unique Findings (not in any other coworker)

1. **Basran terminology default for nahw** — The system must default to Basran grammatical nomenclature and implement a synonym-mapping layer for Kufan variants. Exposing a beginner to both simultaneously violates tadarruj.

2. **Mantiq (logic) as new required science** — Classical logic is a NON-NEGOTIABLE prerequisite for Usul al-Fiqh and advanced Aqidah. The current 18-science list does NOT include mantiq. A foundational mantiq taxonomy tree must be built.

3. **Fiqh masking layer** — Per-madhab filtering of comparative texts, not just tagging. This is an architectural feature the pipeline currently lacks.

4. **Month-by-month collection calendar:**
   - April: Imla + Sarf (finalize morphological taxonomy)
   - May: Nahw + Balagha (test FP-12/FP-3, lock nahw_v2_0, FP-15 for balagha)
   - June: Fiqh + Mantiq (single-madhab masking, populate logic tree)
   - July 1: Usul + Aqidah (system links advanced theory to foundations)

5. **Fiqh-before-Usul as structural dependency** — Not just a preference but a pedagogical REQUIREMENT. The student needs practical rulings before abstract theory. The fiqh taxonomy must be populated BEFORE usul texts are ingested.

### Verification Against Codebase (from earlier exploration)

| Claim | Verdict | Evidence |
|-------|---------|----------|
| nahw_v2_0 has 183 leaves | CONFIRMED | taxonomy_registry.yaml |
| aqidah_v0_2 exists | CONFIRMED | taxonomy_registry.yaml |
| SCIENCE.md files are placeholders | CONFIRMED | "Status: Placeholder — full Level 3 documentation to be written during Phase 2" |
| user_model has FSRS/curriculum | CONFIRMED | shared/user_model/SPEC.md §4.A.3, §4.A.5 |
| FP-3, FP-12, FP-14, FP-15, FP-16 exist | CONFIRMED | SPEC.md §1.1b |
| Mantiq not in current sciences | CONFIRMED | taxonomy_registry.yaml: nahw, sarf, balagha, imlaa, aqidah only |
| No per-madhab filtering in excerpting | CONFIRMED | Phase 2b uses one-size-fits-all grouping |

### Cross-Reference: Gemini DR → Other 4 Coworkers

| Gemini DR Finding | Other Coworkers | Gemini DR Unique Value |
|-------------------|----------------|----------------------|
| Basran terminology | — | UNIQUE — no coworker addressed grammar school terminology |
| Fiqh masking | Gemini CLI (madhhab target), Codex DT-06 | EXTENDS into architectural masking layer with progressive unlock |
| Mantiq prerequisite | — | UNIQUE — discovers a missing science |
| Monthly calendar | — | UNIQUE — operationalizes tadarruj into a schedule |
| Fiqh before Usul | Gemini CLI (munazarah mode) | EXTENDS with academic grounding |
| Mulazamah constraint | Gemini CLI (FP-14/16) | Confirms with teacher-replacement framing |
| 'Ard through FSRS | Gemini CLI (active recall) | Validates user_model design |
| Study-ready architecture | All 4 | Extends with 4 specific architectural requirements |
| Flag budget protection | DR18 EXC-D-010, ChatGPT DR | Confirms with student safety framing |

## Impact on Preliminary Synthesis

### Additions to Layer 1 (User Model + Pedagogical Mode)

- **NEW: Primary madhab designation** (IMMEDIATE — blocks fiqh processing)
- **NEW: Grammar school terminology default** (Basran, with Kufan synonym layer)
- **NEW: Mantiq added to science inventory** (science #19)

### Additions to Layer 2 (Quality Policies)

- **NEW: Fiqh masking layer policy** — suppress/unlock comparative rulings
- **REFINED: Science sequencing enforced** — imla→sarf→nahw→balagha→fiqh→usul→aqidah

### Additions to Layer 3 (Engine Decisions)

- **NEW: Synonym-mapping layer for Kufan nahw variants** (normalization or taxonomy)
- **REFINED: Tree finalization order** now has pedagogical grounding (not arbitrary)

### No changes to Layer 4 (Calibration)

Gemini DR agrees with others: FP-18 calibration and excerpt judgment collection are summer work.

## Execution Plan

### Step 1: Save Gemini DR report (5 min)
- Copy from Downloads to `engines/excerpting/reference/dr_reviews/GEMINI_DR_madrasa_curriculum_framework.md`
- Write verification + cross-reference to `engines/excerpting/reference/dr_reviews/GEMINI_DR_verification_crossref.md`

### Step 2: Update synthesis tracker (2 min)
- Mark Gemini DR as received — ALL 5 coworkers now complete

### Step 3: Finalize 5-coworker synthesis (15 min)
- Update `PRELIMINARY_SYNTHESIS_4_OF_5.md` → rename to `FINAL_SYNTHESIS_5_OF_5.md`
- Add Gemini DR findings: masking layer, mantiq, Basran default, monthly calendar
- Remove "PRELIMINARY" status
- Add the owner-facing question about his fiqh book

### Step 4: Update memory + NEXT.md (5 min)
- Create memory entry
- Update NEXT.md to reflect all 5 complete

### Step 5: Commit and push (1 min)

### Step 6: Present findings to owner
- The masking layer recommendation needs owner reaction
- The mantiq prerequisite is a curriculum-level decision
- These are questions the owner CAN answer (non-technical, study-focused)

### Files to Create/Modify
- `engines/excerpting/reference/dr_reviews/GEMINI_DR_madrasa_curriculum_framework.md` (create)
- `engines/excerpting/reference/dr_reviews/GEMINI_DR_verification_crossref.md` (create)
- `engines/excerpting/reference/dr_reviews/FINAL_SYNTHESIS_5_OF_5.md` (create from preliminary)
- `engines/excerpting/reference/dr_reviews/COWORKER_SYNTHESIS_TRACKER.md` (edit)
- `memory/gemini_dr_madrasa_curriculum.md` (create)
- `memory/MEMORY.md` (edit)
- `NEXT.md` (edit)
