# Plan: Separate Resources from Ideas

## Context

`reference/RESOURCE_INBOX.md` was just created from the user's `sources.md` but it mixes two fundamentally different things:
- **Resources** — external links (repos, tools, services) with a clear lifecycle: found → evaluated → adopted/rejected via `technology-survey` skill → cataloged in `RESOURCES.md`
- **Ideas** — the user's own design thoughts and feature concepts for the project, which have a different lifecycle: captured → explored → formalized into a SPEC section

The user wants these separated, with ideas organized intelligently per-engine.

## Changes

### 1. Edit `reference/RESOURCE_INBOX.md`
Remove the "Normalization Engine Design Ideas" section (lines 81-86). This file becomes purely external resources.

### 2. Create `reference/IDEAS.md`
A single structured file mirroring the pipeline, where the user captures design ideas.

**Why one file, not per-engine files:**
- Only 2 ideas exist right now — 7+ files would be over-engineered
- Cross-engine ideas (e.g., "pipeline should handle X") need a home
- One file is easy to scan holistically and quick to add to
- If it grows past ~200 lines, split later

**Structure:**
```
# Project Ideas

Brief header explaining purpose and lifecycle.

## General / Cross-Engine
(pipeline-wide, tooling, workflow, architecture)

## Source Engine
## Normalization Engine
  → seed with the 2 existing ideas (multi-language, source format hunting)
## Passaging Engine
## Atomization Engine
## Excerpting Engine
## Taxonomy Engine
## Synthesis Engine
## Scholar Interface
```

**Per-idea format:** Title + 1-3 sentences. Optional `(§N.N)` cross-ref to VISION.md. No bureaucracy — adding an idea takes 10 seconds.

## Files
- **Edit:** `reference/RESOURCE_INBOX.md` — remove lines 81-86 (ideas section)
- **Create:** `reference/IDEAS.md` — structured by engine with 2 normalization ideas seeded

## Verification
- `RESOURCE_INBOX.md` contains zero ideas (only external links)
- `IDEAS.md` contains the 2 normalization ideas under the correct engine
- Both files have clear headers explaining their purpose and how to use them
