# Code Review: SPEC_ADVERSARY_NORMALIZATION.md — Fix Groups J1 through J9

**File reviewed:** `C:\Users\Rayane\Desktop\kr\reference\SPEC_ADVERSARY_NORMALIZATION.md`
**Base SHA:** 80d6221
**Head SHA:** 35bb0bc
**Reviewer:** Senior Code Reviewer (Claude Opus 4.6)

---

## Executive Summary

The implementation is **CORRECT and COMPLETE**. All 9 fix groups (J1-J9) from NEXT.md have been faithfully implemented. Word-for-word comparison reveals no content deviations. Placement, numbering, category tags, summary table, and header counts are all accurate. There are zero critical or important issues. I have two minor suggestions for future consideration only.

---

## 1. CONTENT ACCURACY (Word-for-Word Comparison)

### J1: ADV-022 Replacement -- PASS

**Requirement:** Replace the weak ADV-022 ("Python str.strip() removing diacritics at string edges") with "Custom whitespace cleanup removing trailing diacritics".

**Verification:** The old ADV-022 content (which explicitly admitted "its own input doesn't trigger the trap") has been fully removed. The new ADV-022 at lines 448-466 matches the NEXT.md J1 specification word for word:
- Title: `### ADV-022 arabic_trap -- Custom whitespace cleanup removing trailing diacritics` -- matches
- SPEC rule citation: `"Preserve all diacritics exactly." (S4.A.8) + "Leading/trailing line whitespace trimmed" (S4.A.8)` -- matches
- Python code block with `re.sub(r'[^\w\s]+$', '', text)` -- matches
- Correct/wrong behavior descriptions -- match
- "Why it matters" with T-1 reference -- matches
- Detection assertion about byte-level equality and U+0650 -- matches

**Verdict:** Exact match. No deviations.

### J2: ADV-023 Fix -- PASS

**Requirement:** Replace the unsourced "~30%" statistic in ADV-023's "Why it matters" section.

**Verification:** Line 483 now reads:
> Shamela exports sometimes mix digit forms within the same source. Missing Arabic-Indic markers means an unknown but potentially significant fraction of footnote references could be orphaned -- the actual frequency needs corpus measurement.

This matches the NEXT.md J2 specification exactly. The old text "~30% of footnote references could be orphaned" has been correctly replaced.

**Verdict:** Exact match. No deviations.

### J3: ADV-025 Fix -- PASS

**Requirement:** Update three sections of ADV-025: "Correct behavior", "Wrong behavior", and "Detection" to reflect the SPEC gap at exactly 70% and the K1 fix.

**Verification at lines 548-550:**
- "Correct behavior" references the SPEC gap, the K1 fix, and the new threshold `>=70%` pass / `<70%` flag -- matches
- "Wrong behavior" has three lettered failure modes (a), (b), (c) -- matches
- "Detection" asserts pass at 70.0%, flag at 69.9%, pass at 70.1% -- matches
- The "Why it matters" section was correctly REMOVED (it was not specified in J3's replacement text)

**Verdict:** Exact match. No deviations.

### J4: ADV-043 and ADV-044 (T-3 Cases) -- PASS

**Requirement:** Add 2 new cases under a new section header `## S4.B.2 -- Structural Format Auto-Detection (T-3 defense)`. Place them after the S4.B section heading, before ADV-035.

**Verification:**
- Section header at line 707: `## S4.B.2 -- Structural Format Auto-Detection (T-3 defense)` -- matches
- ADV-043 at lines 709-716: Q&A format detection at exactly 30% threshold, boundary_value category -- all content matches word for word
- ADV-044 at lines 720-727: Commentary markers and Q&A markers co-occurring, multi_signal_conflict category -- all content matches word for word
- Placement: ADV-043 and ADV-044 appear at lines 707-729, followed by `## S4.B -- Transformative Capabilities` at line 731 and ADV-035 at line 735 -- correct placement before ADV-035

**Verdict:** Exact match. No deviations.

### J5: ADV-045, ADV-046, ADV-047, ADV-048 (Critical Error Codes) -- PASS

**Requirement:** Add 4 new cases placed in specific SPEC sections.

**ADV-045** (lines 433-444): After ADV-021 in S4.A.8 section.
- Title: `silent_corruption -- Diacritics drift from Python JSON serializer (NORM_DIACRITICS_DRIFT)` -- matches
- SPEC rule cites S5 check 8 with the exact diacritics range and count -- matches
- All content fields match word for word
- Placement: immediately after ADV-021 (line 417), before ADV-022 (line 448) -- correct per spec ("After ADV-021")

**ADV-046** (lines 302-309): After ADV-015 in S4.A.5 section.
- Title: `silent_corruption -- Layer fingerprint inversion (NORM_LAYER_FINGERPRINT_INVERSION)` -- matches
- SPEC rule cites S4.B.9 with exact threshold values -- matches
- All content fields match word for word
- Placement: immediately after ADV-015 (line 285), before S4.A.6 section header (line 313) -- correct per spec ("After ADV-015")

**ADV-047** (lines 655-666): After ADV-032 in S7 section.
- Title: `format_edge_case -- Atomic write failure and recovery (NORM_WRITE_FAILED / NORM_WRITE_RECOVERY)` -- matches
- All content fields including the three simulated directory states match word for word
- Placement: immediately after ADV-032 (line 643), before S3 section header (line 681) -- correct per spec ("After ADV-032")

**ADV-048** (lines 670-677): After ADV-047, still in S7 section.
- Title: `format_edge_case -- Windows-1256 encoded Shamela export (NORM_ENCODING_ERROR)` -- matches
- All content fields match word for word
- Placement: immediately after ADV-047 -- correct (spec says "After ADV-032" for both 047 and 048, and 048 follows 047)

**Verdict:** All four cases are exact matches with correct placement.

### J6: ADV-049, ADV-050, ADV-051 (Section Minimum Cases) -- PASS

**Requirement:** Add 3 new cases to reach 3-case minimum in S4.A.7 and S4.A.9.

**ADV-049** (lines 398-411): After ADV-020 in S4.A.7 section.
- Title: `boundary_value -- Page number integer overflow from corrupt Shamela HTML` -- matches
- HTML code block with the large page number -- matches
- All content fields match word for word
- Placement: immediately after ADV-020 (line 382), before S4.A.8 section header (line 415) -- correct per spec ("After ADV-020")

**ADV-050** (lines 505-515): After ADV-024 in S4.A.9 section.
- Title: `arabic_trap -- Hadith citation with non-standard introduction` -- matches
- Arabic hadith text with isnad chain -- matches
- All content fields match word for word
- Placement: immediately after ADV-024 (line 490), before ADV-051 -- correct per spec ("After ADV-024")

**ADV-051** (lines 519-533): After ADV-050 in S4.A.9 section.
- Title: `format_edge_case -- Table of contents page detection` -- matches
- Arabic TOC content with leader dots -- matches
- All content fields match word for word
- Placement: immediately after ADV-050, still in S4.A.9 section -- correct

**Verdict:** All three cases are exact matches with correct placement.

### J7: Deferred Annotation for S4.B Cases -- PASS

**Requirement:** Add a blockquote before ADV-035.

**Verification at line 733:**
> **NOTE:** S4.B test cases (ADV-035 through ADV-042) target transformative capabilities that are deferred from core build. Implement these tests when the corresponding S4.B capabilities are built. They are included here for completeness and to guide future build sessions.

This matches the NEXT.md J7 specification word for word.

**Verdict:** Exact match. No deviations.

### J8: Coverage Gap Documentation -- PASS

**Requirement:** Add coverage gap note after header metadata.

**Verification at line 11:**
> **Coverage gaps (deferred normalizers):** Sections S4.A.3 (PDF text normalizer), S4.A.4 (scanned PDF/image normalizer), S4.A.4a-S4.A.4d (EPUB, Word, plain text, owner content normalizers) are marked [NOT YET IMPLEMENTED] in the SPEC. No adversarial cases are provided for these sections. Write adversarial cases when each normalizer is implemented.

This matches the NEXT.md J8 specification word for word.

**Verdict:** Exact match. No deviations.

### J9: Summary Table and Header Counts -- PASS

**Requirement:** Replace the Summary by Threat table and update header counts.

**Summary table verification (lines 848-856):**
- T-1 row: ADV-006, ADV-007, ADV-021, ADV-022, ADV-039, ADV-045, ADV-048 -- matches spec
- T-2 row: ADV-011, ADV-012, ADV-013, ADV-014, ADV-015, ADV-046 -- matches spec
- T-3 row (new): ADV-043, ADV-044 -- matches spec
- T-4 row: ADV-001, ADV-002, ADV-017, ADV-019 -- matches spec
- T-5 row: ADV-010, ADV-030 -- matches spec
- T-6 row: ADV-033, ADV-034, ADV-035 -- matches spec
- T-7 row: ADV-018, ADV-020 -- matches spec

**Header counts verification (line 7):**
- Claimed: `boundary_value: 10, arabic_trap: 10, silent_corruption: 15, format_edge_case: 11, multi_signal_conflict: 5`
- Actual (from grep on ADV headers only):
  - boundary_value: 10 -- MATCHES
  - arabic_trap: 10 -- MATCHES
  - silent_corruption: 15 -- MATCHES
  - format_edge_case: 11 -- MATCHES
  - multi_signal_conflict: 5 -- MATCHES
- Total: 10 + 10 + 15 + 11 + 5 = 51 -- MATCHES header claim of 51

**Verdict:** Exact match. No deviations.

---

## 2. PLACEMENT Verification

All new cases are inserted at their correct positions:

| Case | Spec says "after" | Actual position | Correct? |
|------|-------------------|-----------------|----------|
| ADV-043 | Before ADV-035, under new S4.B.2 header | Line 709, before S4.B at line 731 | YES |
| ADV-044 | Same section as ADV-043 | Line 720, after ADV-043 | YES |
| ADV-045 | After ADV-021 | Line 433, after ADV-021 at line 417 | YES |
| ADV-046 | After ADV-015 | Line 302, after ADV-015 at line 285 | YES |
| ADV-047 | After ADV-032 | Line 655, after ADV-032 at line 643 | YES |
| ADV-048 | After ADV-032 (with ADV-047) | Line 670, after ADV-047 | YES |
| ADV-049 | After ADV-020 | Line 398, after ADV-020 at line 382 | YES |
| ADV-050 | After ADV-024 | Line 505, after ADV-024 at line 490 | YES |
| ADV-051 | After ADV-050 in S4.A.9 | Line 519, after ADV-050 | YES |

---

## 3. NUMBERING Verification

All 51 ADV numbers from 001 to 051 are present with no gaps. Extracted and sorted:
```
1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38,
39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51
```

Numbers are NOT in numerical order in the file (they are grouped by SPEC section, as expected). This is correct per the review requirements: "they don't need to be in numerical ORDER in the file (they're grouped by SPEC section), but all 51 numbers must exist."

---

## 4. CATEGORY TAGS Verification

| New Case | Expected Category | Actual Category | Correct? |
|----------|-------------------|-----------------|----------|
| ADV-043 | boundary_value | boundary_value | YES |
| ADV-044 | multi_signal_conflict | multi_signal_conflict | YES |
| ADV-045 | silent_corruption | silent_corruption | YES |
| ADV-046 | silent_corruption | silent_corruption | YES |
| ADV-047 | format_edge_case | format_edge_case | YES |
| ADV-048 | format_edge_case | format_edge_case | YES |
| ADV-049 | boundary_value | boundary_value | YES |
| ADV-050 | arabic_trap | arabic_trap | YES |
| ADV-051 | format_edge_case | format_edge_case | YES |
| ADV-022 (replaced) | arabic_trap | arabic_trap | YES |

---

## 5. SUMMARY TABLE Verification

The Summary by Threat table correctly includes ALL new cases:
- ADV-045 and ADV-048 added to T-1 (Silent Text Corruption) row
- ADV-046 added to T-2 (Attribution Error) row
- T-3 (Taxonomic Misplacement) row added with ADV-043, ADV-044
- T-4 through T-7 rows unchanged and correct

**Note on completeness:** ADV-047 (atomic write), ADV-049 (page number overflow), ADV-050 (hadith citation), and ADV-051 (TOC detection) are NOT listed in the summary table. This is consistent with the NEXT.md specification -- the J9 table in NEXT.md also does not include these cases. These cases do not map cleanly to the T-1 through T-7 threat categories (they are operational edge cases rather than knowledge corruption threats), so their omission from the threat summary is defensible.

---

## 6. HEADER COUNTS Verification

| Category | Header Claim | Actual Count (grep on ADV headers) | Match? |
|----------|-------------|-------------------------------------|--------|
| boundary_value | 10 | 10 | YES |
| arabic_trap | 10 | 10 | YES |
| silent_corruption | 15 | 15 | YES |
| format_edge_case | 11 | 11 | YES |
| multi_signal_conflict | 5 | 5 | YES |
| **Total** | **51** | **51** | **YES** |

**Important note on counting methodology:** The earlier grep without restricting to ADV headers showed higher counts (11, 11, 16, 12, 6) because category tags also appear in the body text of some cases (e.g., in "Why it matters" sections). The correct count restricts to `### ADV-` header lines only, which gives the matching counts shown above.

---

## Issues Found

### Critical Issues: NONE

### Important Issues: NONE

### Suggestions (nice to have, not blocking):

**S1. ADV-025 SPEC rule quote is now stale.** Line 541 still reads: `**SPEC rule:** "Character distribution must be plausible for Arabic text: >70% Arabic characters..."` -- The `>70%` in the SPEC rule quote is the OLD text (before K1 fix). The "Correct behavior" section explains the fix was applied, but the SPEC rule quote itself still shows the pre-fix wording. This is arguably intentional (quoting the original SPEC text to show what was wrong), but could cause confusion. NEXT.md J3 only specified changes to three sections (correct behavior, wrong behavior, detection) and did NOT specify changing the SPEC rule quote, so the implementation follows the spec. No action needed unless the team wants to update the quote to match the post-K1 SPEC text.

**S2. Four ADV cases absent from Summary by Threat table.** ADV-047, ADV-049, ADV-050, and ADV-051 do not appear in the Summary by Threat table. As noted in section 5, this matches the NEXT.md specification exactly. However, for future catalog maintenance, it may be worth adding these under appropriate threats (ADV-049 could go under T-4 Context Loss since an overflow crash loses the page's content; ADV-050 under T-2 Attribution Error since misidentifying hadith text is an attribution issue; ADV-051 under T-3 since phantom TOC divisions are a structural misclassification). This is purely a suggestion for future sessions.

---

## Overall Verdict: PASS

All 9 fix groups (J1-J9) are implemented correctly, completely, and faithfully to the NEXT.md specification. The implementation shows careful attention to:
- Exact wording preservation from the spec
- Correct placement within the document structure
- Consistent formatting with existing entries
- Accurate header counts and summary table updates
- Complete ADV number sequence with no gaps

No changes are required.
