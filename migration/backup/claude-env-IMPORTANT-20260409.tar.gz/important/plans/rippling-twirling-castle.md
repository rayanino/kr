# ECC Pattern Integration Plan for KR

## Context

The [everything-claude-code](https://github.com/affaan-m/everything-claude-code) (ECC) repo is a performance optimization system for AI agent harnesses, built through 10 months of daily usage. It provides 21+ agents, 57+ commands, 100+ skills, 20+ hooks, and comprehensive workflow patterns across multiple languages and frameworks.

**KR already has a highly customized Claude Code infrastructure:** 15 agents, 6 hooks, 8 rules, 12 commands, 8 domain-specific skills. Most of ECC's offerings are irrelevant (wrong language, wrong domain). The value lies in **6 patterns** that address real gaps in KR's workflow — not in bulk adoption.

**Approach:** Pattern adoption, not plugin installation. Each ECC pattern is reimplemented to fit KR's conventions (Python, type hints, pathlib, SPEC-driven, Arabic-safe). No ECC code is copied directly.

---

## Gap Analysis

| Capability | KR Status | ECC Pattern | Value |
|-----------|-----------|-------------|-------|
| Session exit state | **Missing** — no Stop hooks, state lost on exit | Stop hook auto-saves state | **HIGH** |
| .claude/ config integrity | **Missing** — orphaned `run-tests-async.sh` already found | `/harness-audit` validates config | **HIGH** |
| Debug print detection | **Missing** — `pre_review_checks.py` checks logging but not print() | PostToolUse print() warning | **MEDIUM** |
| On-demand quality check | **Partial** — hooks auto-run but no manual comprehensive scan | `/quality-gate` on-demand command | **MEDIUM** |
| Agent orchestration | **Missing** — agents dispatched manually one-by-one | `/orchestrate` chains agents | **MEDIUM** |
| Agent output format | **Inconsistent** — each agent defines its own output shape | Structured handoff envelope | **MEDIUM** |
| Build error diagnosis | **Missing** — pyright/pytest fail but no structured diagnosis | Error analysis script | **LOW** |

---

## What NOT to Adopt (and Why)

| ECC Pattern | Why Skip |
|-------------|---------|
| **Model routing** | KR assigns specific models per agent for quality guarantees. Cost optimization contradicts CLAUDE.md: "Never optimize for saving costs" |
| **Generic TDD agent** | KR's philosophy is "test the SPEC, not the implementation" — generic TDD produces implementation-driven tests |
| **Continuous learning hooks** | Auto-extracted patterns risk encoding lucky outcomes as rules. KR uses deliberate feedback files in `memory/feedback_*.md` |
| **Session token/cost tracking** | Claude Code usage cost is not actionable. KR tracks API call costs (COST_LOG.json), not session tokens |
| **Language-specific agents** (Go, Swift, PHP, TypeScript) | KR is Python-only |
| **Frontend/backend skills** | KR has no UI — pipeline is backend-only |
| **Generic code review agent** | Would dilute KR's SPEC-fidelity, Arabic-safety, D-023 focused review |
| **ECC as a plugin** | Massive bloat (57 commands, 100 skills). Conflicts with KR's domain-specific hooks and rules |
| **ECC security scanning** | KR is a personal tool, not a production SaaS. Agent configs don't face adversarial inputs |

---

## Improvements to Implement

### E-1. Session Stop Hook — State Persistence
**Priority:** P1 (highest) | **Effort:** Small | **Pattern source:** ECC Stop hooks

**Problem:** When a session ends (context limit, user leaves, crash), all in-flight state vanishes. `/catchup` rebuilds from git + NEXT.md, but misses: which files were being worked on, last test status, active SPEC section, uncommitted changes context. `/smart-compact` saves to Serena memory, but only when manually invoked and depends on Serena MCP being available.

**Solution:** `scripts/session_stop.py` — auto-runs on session exit, writes `.claude/session_state.json`.

Captures:
- Active engine (derived from recent git diffs)
- Files modified this session (git diff --name-only)
- Last test result summary (pass/fail count from most recent pytest)
- Uncommitted changes summary (git diff --stat)
- Current NEXT.md first 15 lines
- Timestamp

**Integration:**
- Register as Stop hook in `settings.json`
- Update `/catchup` to read `.claude/session_state.json` as first step
- `/smart-compact` can delegate to this script instead of manual Serena write

**Risk:** Claude Code may not support Stop hooks. If not, fall back to a PreToolUse(`Bash(git commit*)`) hook that saves state before commits, or a manual `/save-state` command.

**Files:**
- NEW: `scripts/session_stop.py` (~60 lines)
- MODIFY: `.claude/settings.json` (add Stop hook section)
- MODIFY: `.claude/commands/catchup.md` (add session_state.json read at step 0)

---

### E-2. Harness Self-Audit
**Priority:** P1 | **Effort:** Medium | **Pattern source:** ECC `/harness-audit`

**Problem:** KR's `.claude/` has grown to 15 agents, 6 hooks, 12 commands, 8 rules, 8 skills. Already found: `run-tests-async.sh` exists but is not registered in `settings.json` (orphaned). As the directory grows, configuration drift is inevitable.

**Solution:** `scripts/audit_claude_config.py` — validates all `.claude/` files for internal consistency.

Checks:
1. **Hook paths:** Every `"command"` in `settings.json` hooks resolves to an existing file. Every `.sh` in `.claude/hooks/` is referenced in `settings.json`.
2. **Agent frontmatter:** Every `.md` in `.claude/agents/` has required fields (name, description, tools, model). Model field uses valid short names (opus/sonnet/haiku).
3. **Command scripts:** Commands referencing `python3 scripts/...` point to existing scripts.
4. **Rule freshness:** Every `.md` in `.claude/rules/` is non-empty and path references resolve.
5. **Skill structure:** Every skill dir has a `SKILL.md`.
6. **Orphan detection:** Files in `.claude/hooks/`, `.claude/agents/`, `.claude/commands/` that are not referenced anywhere.

**Files:**
- NEW: `scripts/audit_claude_config.py` (~150 lines)
- NEW: `.claude/commands/harness-audit.md`

---

### E-3. Debug Print Detection
**Priority:** P2 | **Effort:** Small | **Pattern source:** ECC console.log hook

**Problem:** KR engine source uses `logging.getLogger(__name__)` consistently. But leftover `print()` statements are a realistic risk as 5 more engines get built. `pre_review_checks.py` checks for logging presence but not for rogue prints.

**Solution:** Add `print()` detection to two existing files (no new hooks — KR already has 6 PostToolUse hooks).

**Files:**
- MODIFY: `.claude/hooks/pre-commit-check.sh` (add check 7: advisory print() detection in staged src files)
- MODIFY: `scripts/pre_review_checks.py` (add `check_debug_prints()` function)

---

### E-4. On-Demand Quality Gate Command
**Priority:** P2 | **Effort:** Small | **Pattern source:** ECC `/quality-gate`

**Problem:** KR's quality checks run as hooks (every write) or at commit time. There's no way to run a comprehensive, on-demand check at any session checkpoint. Hooks are noisy; the quality gate is intentional.

**Solution:** `/quality-gate <engine>` command that runs ALL validation scripts and produces a summary.

Runs in sequence:
1. `pytest engines/<n>/tests/ -v --tb=short`
2. `pyright` on all src files
3. `validate_spec_values.py`
4. `pre_review_checks.py` (all src files)
5. `check_pydantic_fields.py` (contracts.py)
6. `verify_metadata_flow.py`
7. `update_build_metrics.py`

Distinct from `session_quality_gate.py` (commit-readiness) and `pre_review_checks.py` (review-readiness). This is a comprehensive session-checkpoint tool.

**Files:**
- NEW: `.claude/commands/quality-gate.md`

---

### E-5. Agent Orchestration Command
**Priority:** P3 | **Effort:** Medium | **Pattern source:** ECC `/orchestrate`

**Problem:** KR has specialized agents (code-reviewer, build-prober, triage-analyst, verifier-a/b, consolidator) but dispatches them individually. The user must remember the sequence, copy outputs, ensure nothing is missed.

**Solution:** `/orchestrate <chain> <engine>` command with two predefined chains.

**Chain A: `post-build`** (after a build session)
```
code-reviewer → build-prober → combined report
```

**Chain B: `verify`** (for evaluation phases)
```
triage-analyst → verifier-a + verifier-b (parallel) → consolidator → final verdicts
```

Each agent produces output in the structured handoff format (E-6). The command template specifies what context to pass between agents.

**Files:**
- NEW: `.claude/commands/orchestrate.md`

---

### E-6. Structured Agent Handoff Format
**Priority:** P3 | **Effort:** Small | **Pattern source:** ECC handoff documents

**Problem:** KR agents produce ad-hoc outputs. The code-reviewer has a defined format (SPEC Fidelity, Issues, Good Patterns), but build-prober, triage-analyst, and consolidator each define their own. Cross-agent handoffs lack a common envelope.

**Solution:** Define a standard envelope in `reference/protocols/AGENT_HANDOFF_FORMAT.md`.

Envelope fields:
```
## [Agent Name] Report — [Engine] [Context]
**Date:** [ISO 8601]
**Agent:** [filename]
**Scope:** [files/data reviewed]
### Summary
  HIGH: [count] — [one-line each]
  MEDIUM: [count]
  LOW: [count]
### Findings
  [Agent-specific detail — existing formats preserved]
### Downstream Context
  For next agent: [what they need to know]
  Unresolved: [open questions]
  Files to re-examine: [paths]
```

Update agent definitions to require this envelope around their existing output formats.

**Files:**
- NEW: `reference/protocols/AGENT_HANDOFF_FORMAT.md`
- MODIFY: `.claude/agents/code-reviewer.md` (add envelope requirement)
- MODIFY: `.claude/agents/build-prober.md` (add envelope requirement)

---

### E-7. Test Failure Diagnoser
**Priority:** P4 (lowest) | **Effort:** Small | **Pattern source:** ECC build-error-resolver

**Problem:** When pytest/pyright fails, diagnosis is manual. The error output often lacks context about which SPEC section is involved or which recent changes might be responsible.

**Solution:** `scripts/diagnose_failure.py` — given pytest output, produces structured diagnosis.

Output includes:
- Failing test name and file
- The assertion that failed
- SPEC section referenced in test docstring (if any)
- Related recent git changes (files near failing test's imports)
- Suggested investigation order

Does NOT auto-fix — that would violate KR's Rule 12 ("every action thoroughly thought-out").

**Files:**
- NEW: `scripts/diagnose_failure.py` (~100 lines)

---

## Implementation Order

| Phase | Items | Effort | Dependencies |
|-------|-------|--------|-------------|
| **Phase 1** | E-1 (Stop hook), E-3 (debug prints) | ~1 hour | None |
| **Phase 2** | E-2 (harness audit), E-4 (quality gate) | ~2 hours | None |
| **Phase 3** | E-6 (handoff format), E-5 (orchestrate) | ~2 hours | E-6 before E-5 |
| **Phase 4** | E-7 (failure diagnoser) | ~1 hour | None |

**Total: ~6 hours across 4 phases.** Phases 1-2 are independent and could run in the same session. Phase 3 requires reading existing agent definitions. Phase 4 is standalone.

---

## File Inventory

### New files (8)
| File | Lines | Purpose |
|------|-------|---------|
| `scripts/session_stop.py` | ~60 | Stop hook: auto-save session state |
| `scripts/audit_claude_config.py` | ~150 | Validate .claude/ configuration consistency |
| `scripts/diagnose_failure.py` | ~100 | Structured test failure diagnosis |
| `.claude/commands/harness-audit.md` | ~10 | Command wrapper for audit script |
| `.claude/commands/quality-gate.md` | ~30 | On-demand comprehensive quality check |
| `.claude/commands/orchestrate.md` | ~40 | Agent chaining with handoff documents |
| `reference/protocols/AGENT_HANDOFF_FORMAT.md` | ~40 | Standard agent output envelope |

### Modified files (6)
| File | Change |
|------|--------|
| `.claude/settings.json` | Add Stop hook section |
| `.claude/commands/catchup.md` | Read session_state.json at step 0 |
| `.claude/hooks/pre-commit-check.sh` | Add check 7: print() detection |
| `scripts/pre_review_checks.py` | Add `check_debug_prints()` |
| `.claude/agents/code-reviewer.md` | Add handoff envelope requirement |
| `.claude/agents/build-prober.md` | Add handoff envelope requirement |

---

## Verification

After implementation:
1. **E-1:** Start a session, make changes, exit. Start new session, run `/catchup` — verify session_state.json is read and context is restored.
2. **E-2:** Run `/harness-audit` — verify it catches the orphaned `run-tests-async.sh` and any other issues.
3. **E-3:** Add a `print("debug")` to an engine src file, commit — verify pre-commit warns.
4. **E-4:** Run `/quality-gate normalization` — verify all 7 checks run and produce a summary.
5. **E-5:** Run `/orchestrate post-build normalization` — verify code-reviewer → build-prober chain executes.
6. **E-7:** Intentionally break a test, run `python scripts/diagnose_failure.py` — verify structured output.
