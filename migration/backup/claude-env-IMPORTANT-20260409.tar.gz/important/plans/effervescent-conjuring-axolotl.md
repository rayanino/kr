# Plan: Maximize Claude Code Environment from everything-claude-code

## Context

The KR project processes Islamic scholarly Arabic text through a 7-engine pipeline where **every error propagates into the owner's knowledge**. The Claude Code environment already has strong foundations (9 hook scripts, 18 agents, 15 commands, 9 skills, 8 rules). After thorough analysis of [affaan-m/everything-claude-code](https://github.com/affaan-m/everything-claude-code) (ECC) — an Anthropic hackathon-winning plugin system — we identified improvements in three categories:

1. **New additions** from ECC patterns (16 items)
2. **Improvements to existing components** informed by ECC's more rigorous approaches (15 items)
3. **Future-proofing** for the upcoming web UI phase (3 items)

---

## PART A: New Additions from ECC

### Phase 1: Security Hardening

#### 1A. Configuration File Protection Hook (NEW)
**Why:** The entire safety net (Arabic checks, D-023, circuit breaker) lives in `settings.json`. An accidental edit silently disables all protections.

**Create:** `.claude/hooks/config-protection.sh` (~25 lines)
- Read stdin JSON, extract target file path from `$CLAUDE_TOOL_FILE_PATH`
- Block if path matches `.claude/settings` or `.claude/hooks/`
- Escape hatch: `KR_CONFIG_EDIT=1` env var

**Modify:** `.claude/settings.json` — add PreToolUse entry for `Write|Edit|MultiEdit` matcher

#### 1B. Secret Detection in Pre-Commit
**Why:** KR uses OpenRouter, Anthropic, OpenAI API keys. Deny list has `Read(.env)` but nothing prevents embedding a key in Python source.

**Modify:** `.claude/hooks/pre-commit-check.sh` — add BLOCKING check #8:
- Scan staged `.py` files for patterns: `sk-ant-`, `sk-or-`, `sk-[a-zA-Z0-9]{20,}`, `API_KEY\s*=\s*["']`
- Bypass: `# safe:` comment (matches existing pattern)

#### 1C. Git Hook Bypass Protection
**Why:** `--no-verify` skips ALL pre-commit checks including Arabic safety and frozen source protection.

**Modify:** `.claude/settings.json` line 66 — extend the destructive command regex to also match `--no-verify`

### Phase 2: Hook Architecture — New Hooks

#### 2A. Ruff Auto-Fix PostToolUse Hook (NEW)
**Why:** `Bash(ruff *)` is in the allow list (line 48) but never wired. Ruff catches unused imports, wildcard imports (dangerous — naming collisions between engines can shadow functions), and anti-patterns that black doesn't address.

**Modify:** `.claude/settings.json` — extend the black hook (lines 122-131) to run `ruff check --fix --quiet` before black

**Modify:** `pyproject.toml` — add `[tool.ruff]` section:
```toml
[tool.ruff]
line-length = 88
target-version = "py312"

[tool.ruff.lint]
select = ["F", "E", "W", "I", "UP", "B", "SIM"]
ignore = ["E501"]

[tool.ruff.lint.per-file-ignores]
"tests/**" = ["B011"]
```

#### 2B. Enhanced Stop Hook — Cost + Learning + Print Detection (NEW)
**Why:** After compaction, no way to know session cost, circuit breaker issues, or leftover debug prints.

**Modify:** `scripts/session_stop.py` — add to state dict:
- `cost_summary`: parse `COST_LOG.json`, compute total/remaining budget
- `circuit_breaker_triggers`: last 5 entries from `.claude/circuit_breaker.log`
- `print_warnings`: scan modified engine/shared `.py` files for bare `print()` statements
- `test_baseline`: capture current test count from last pytest run

#### 2C. Enhanced Startup Hook — Budget Display (NEW)
**Why:** Budget remaining should be visible immediately on session start, not only after `/catchup`.

**Modify:** `.claude/settings.json` startup hook — append budget status display after git status

### Phase 3: New Rules

#### 3A. Input Sanitization Rule (NEW)
**Why:** KR ingests external Arabic text from Shamela HTML, PDFs. Hidden Unicode (zero-width spaces, BOM, bidi overrides) can corrupt scholarly text without triggering existing Arabic safety checks.

**Create:** `.claude/rules/input-sanitization.md` (glob: `engines/*/src/*, shared/*/src/*`)
- List dangerous invisible characters with Unicode codepoints
- EXCEPTIONS: U+200D valid in Arabic ligatures, U+200C valid in Persian
- UTF-8 validation at file read boundary
- Never trust external metadata without cross-validation
- Log sanitization actions for audit trail

#### 3B. Context Management Rule (NEW)
**Why:** Formalizing token awareness survives compaction recovery. Currently only in session-discipline.md as brief mention.

**Create:** `.claude/rules/context-management.md` (glob: all files)
- Use /smart-compact at ~60% context proactively
- Post-compaction re-read list (engine CLAUDE.md, SPEC section, NEXT.md)
- MCP limit: <=5 enabled servers
- Prefer Bash CLI over MCP for simple operations
- Subagent best practice: pass objective context, max 3 retrieval iterations
- Note key findings from large tool results in response text (survives compaction)

#### 3C. Commit Message Format Rule (NEW)
**Why:** Consistent commits help /catchup parse history and make `git log --grep` effective.

**Create:** `.claude/rules/commit-format.md` (glob: all files)
- Conventional format: `type(scope): description`
- Valid types: feat, fix, refactor, test, docs, chore, perf
- KR-specific types: handoff, review, protocol
- Scope = engine name or shared module
- 72-char first line max
- Include SPEC reference when applicable

### Phase 4: New Commands

#### 4A. /build-fix Command (NEW)
**Why:** Semantic-level iterative error resolution with a hard 3-cycle limit. Complements circuit breaker (command-pattern level) with task-awareness.

**Create:** `.claude/commands/build-fix.md`
- Accept failing test/command as argument
- Run → analyze → fix → verify cycle, MAX 3 iterations
- Each cycle must try a DIFFERENT approach
- After 3 failures: stop, report, escalate

#### 4B. /tdd Command (NEW)
**Why:** Enforces Red-Green-Refactor aligned with "test the SPEC, not implementation" philosophy.

**Create:** `.claude/commands/tdd.md`
- Accept `<engine> <spec-section>` arguments
- RED: write failing tests from SPEC rules using real Arabic fixtures
- GREEN: minimal implementation to pass
- REFACTOR: clean up, run full quality gate

### Phase 5: New Agent

#### 5A. Quick-Check Agent — Haiku-Based (NEW)
**Why:** Fills gap between RAPID_MODE (no checks) and full hook chain (200s timeout). Fast model-assisted sanity check.

**Create:** `.claude/agents/quick-check.md`
- Model: haiku
- Tools: Read, Bash, Grep, Glob
- Scope: pyright, pytest (engine tests), Arabic safety, imports
- Returns one-paragraph pass/fail
- Does NOT check SPEC fidelity (that's code-reviewer)

---

## PART B: Improvements to Existing Components

### Phase 6: Enhance Existing Agents

#### 6A. code-reviewer Agent — Add Confidence Threshold + Complexity Metrics
**Why:** ECC's python-reviewer uses >80% confidence threshold (only report findings you're confident about) and checks function complexity (50-line max, 5-param max). These catch real issues KR's reviewer doesn't currently flag.

**Modify:** `.claude/agents/code-reviewer.md`

Add to **Code Quality** checklist:
```markdown
- [ ] No function exceeds 50 lines (excluding docstring/comments). Split if larger.
- [ ] No function has more than 5 parameters. Use a Pydantic model or dataclass for complex signatures.
- [ ] No single file exceeds 500 lines. Consider splitting into modules.
- [ ] Cyclomatic complexity is manageable — no function has more than 10 branches.
```

Add to **Rules** section:
```markdown
- Confidence threshold: only report findings you are >80% confident about.
  If unsure whether something is a bug vs. intentional, note it as
  "UNCERTAIN — verify with builder" rather than filing as HIGH.
- Performance awareness: flag O(n^2) or worse algorithms on collections
  that could grow (e.g., processing all chunks in a book). Mark as LOW severity.
```

#### 6B. test-engineer Agent — Add Edge Case Checklist + Coverage Targets
**Why:** ECC's TDD guide has a comprehensive edge case list (null, empty, boundary, invalid types, race conditions, large datasets) and mandates 80%+ coverage (100% for critical paths). Currently the test-engineer lists some edge cases but not systematically.

**Modify:** `.claude/agents/test-engineer.md`

Add after existing Principles section:
```markdown
## Mandatory Edge Cases (per function)

Every tested function must have cases for:
- **Empty/null input**: empty string, empty list, None where Optional
- **Boundary values**: exactly at threshold, threshold ± 1
- **Single-element**: single-character atom, single-page chunk, one join_point
- **Maximum size**: input at or near configured limits (MAX_CHUNK_SIZE, etc.)
- **Mixed content**: Arabic + Latin, diacritics + plain, RTL + LTR
- **Diacritics-only**: text that is entirely tashkeel with no base letters
- **Invalid types**: wrong type passed (str where int expected) → verify error raised
- **Unicode edge cases**: combining characters, presentation forms, surrogates

## Coverage Targets

- 80% minimum line coverage per engine module
- 100% coverage for: metadata pass-through functions, Arabic text operations,
  error code paths, consensus logic
- Every error code in contracts.py must have at least one test that triggers it
```

#### 6C. spec-adversary Agent — Add Security Adversarial Category
**Why:** ECC's security guide identifies prompt injection via crafted input as a primary threat. KR processes external Arabic text that could contain adversarial patterns designed to mislead LLM-based classification in Phase 2/3.

**Modify:** `.claude/agents/spec-adversary.md`

Add Category 6:
```markdown
### Category 6: Input Injection / LLM Manipulation
Inputs crafted to manipulate LLM-based classification or consensus.

**Pattern:** Arabic text containing embedded instructions, misleading metadata,
or content designed to trick genre/author classification into wrong outputs.
Examples:
- Book with colophon containing a different author's name (T-2 attribution)
- Text where commentary mimics main text style (layer detection confusion)
- Metadata in source HTML that contradicts actual content (metadata poisoning)
- Arabic text structured to look like a different genre (genre confusion)
```

#### 6D. build-prober Agent — Add Performance + Test Flakiness Detection
**Why:** ECC's code review includes performance awareness and flaky test detection as standard categories.

**Modify:** `.claude/agents/build-prober.md`

Add to Step 4 (Classify Findings):
```markdown
- **PERFORMANCE**: Code introduces O(n^2) or worse complexity on data that scales
  with book size (pages, chunks, join_points). This becomes critical when processing
  large books (1000+ pages).
  - Example: Nested loop iterating all chunks × all pages inside compute_page_range.

- **FLAKY_TEST**: A new test that depends on timing, ordering, or external state
  that may vary between runs.
  - Example: Test that asserts on dictionary ordering without sorted().
  - Example: Test with hardcoded datetime that will fail after a date passes.
```

### Phase 7: Enhance Existing Hooks

#### 7A. pyright-check.sh — Add Scope Filter + RAPID_MODE
**Why:** Currently runs pyright on ANY `.py` file including experiments/ and one-off scripts. Wastes 10-15s per irrelevant edit. auto-test.sh already has RAPID_MODE but pyright doesn't.

**Modify:** `.claude/hooks/pyright-check.sh` — add at top:
```bash
if [ -n "$CLAUDE_RAPID_MODE" ]; then exit 0; fi
# Only check engine/shared/scripts source files
if ! echo "$FILE" | grep -qE '(engines|shared)/[^/]+/(src|tests)/.*\.py$|scripts/.*\.py$'; then
  exit 0
fi
```

#### 7B. arabic-safety-check.sh — Add Invisible Unicode Detection
**Why:** Current checks focus on `.lower()/.upper()/.strip()/.replace()` and regex patterns. Doesn't detect invisible Unicode characters (zero-width spaces, BOM, bidi overrides) that can silently corrupt Arabic scholarly text.

**Modify:** `.claude/hooks/arabic-safety-check.sh` — add check #8:
```bash
# 8. Invisible Unicode detection (WARNING)
INVISIBLE=$(grep -Pn '[\x{200B}\x{200E}\x{200F}\x{202A}-\x{202E}\x{2060}\x{FEFF}]' "$FILE" 2>/dev/null | grep -v '# safe:')
if [ -n "$INVISIBLE" ]; then
    echo "  WARNING: $FILE contains invisible Unicode characters that may corrupt Arabic text"
    echo "  Found: zero-width spaces, bidi overrides, or BOM markers"
    echo "$INVISIBLE" | head -3
fi
```
Note: If `grep -P` not available on Windows, use Python fallback:
```bash
python3 -c "
import sys
with open(sys.argv[1], encoding='utf-8', errors='ignore') as f:
    for i, line in enumerate(f, 1):
        for c in line:
            if ord(c) in (0x200B, 0x200E, 0x200F, 0xFEFF, 0x2060) or 0x202A <= ord(c) <= 0x202E:
                if '# safe:' not in line:
                    print(f'  {sys.argv[1]}:{i}: invisible U+{ord(c):04X} found')
                    break
" "$FILE" 2>/dev/null
```

#### 7C. pre-commit-check.sh — Add Function Length + TODO Count Advisories
**Why:** ECC's python-reviewer enforces 50-line function max. Long functions in KR are the highest-risk code for silent bugs because they're hardest to review.

**Modify:** `.claude/hooks/pre-commit-check.sh` — add advisory checks #9 and #10:
```bash
# 9. Advisory: Long function detection (>50 lines)
if [ -n "$MODIFIED_PY" ]; then
    for pyfile in $MODIFIED_PY; do
        LONG_FUNCS=$(python3 -c "
import ast, sys
with open(sys.argv[1]) as f:
    tree = ast.parse(f.read())
for node in ast.walk(tree):
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        length = node.end_lineno - node.lineno + 1
        if length > 50:
            print(f'  {sys.argv[1]}:{node.lineno}: {node.name}() is {length} lines (>50)')
" "$pyfile" 2>/dev/null)
        if [ -n "$LONG_FUNCS" ]; then
            echo "  WARNING: Long functions detected (consider splitting):"
            echo "$LONG_FUNCS"
        fi
    done
fi

# 10. Advisory: TODO/FIXME/HACK count in modified files
if [ -n "$MODIFIED_PY" ]; then
    TODO_COUNT=0
    for pyfile in $MODIFIED_PY; do
        COUNT=$(grep -cE '\b(TODO|FIXME|HACK|XXX)\b' "$pyfile" 2>/dev/null || echo 0)
        TODO_COUNT=$((TODO_COUNT + COUNT))
    done
    if [ $TODO_COUNT -gt 0 ]; then
        echo "  INFO: $TODO_COUNT TODO/FIXME/HACK markers in modified files"
    fi
fi
```

#### 7D. Enhanced Compact Recovery Hook — Session State Display
**Why:** After compaction, you don't know if tests were passing/failing or if the circuit breaker fired.

**Modify:** `.claude/settings.json` compact hook — append session state display:
```bash
echo '' && echo '--- session state ---'
if [ -f .claude/session_state.json ]; then
  python3 -c "
import json
s=json.load(open('.claude/session_state.json'))
if s.get('cost_summary'): print(f\"Budget: EUR {s['cost_summary']['total_eur']}/{s['cost_summary']['budget_eur']}\")
if s.get('circuit_breaker_triggers'): print(f\"Circuit breaker: {len(s['circuit_breaker_triggers'])} recent triggers\")
if s.get('print_warnings'): print(f\"Print warnings: {len(s['print_warnings'])} leftover print() statements\")
" 2>/dev/null
fi
```

### Phase 8: Enhance Existing Rules

#### 8A. python-code.md — Add Complexity Limits + Docstring + Mutable Defaults
**Why:** ECC's python-reviewer enforces function limits that catch real bugs. Mutable default arguments (`def f(x=[])`) are a classic Python trap.

**Modify:** `.claude/rules/python-code.md` — append:
```markdown
- Functions should not exceed 50 lines (excluding docstrings). If longer, split into helpers.
- Functions should not have more than 5 parameters. Use a Pydantic model or dataclass for complex signatures.
- No mutable default arguments (`def f(x=[])`, `def f(d={})`). Use `None` + conditional assignment.
- Public functions in engine src/ must have a one-line docstring at minimum.
- Prefer `logging.getLogger(__name__)` over `print()` in all non-test code.
```

#### 8B. testing.md — Add Coverage Targets + Flaky Test Protocol + Table-Driven Patterns
**Why:** ECC mandates 80%+ coverage with 100% for critical paths. Table-driven (parametrize) patterns from ECC's Go/Python reviewers improve test ergonomics.

**Modify:** `.claude/rules/testing.md` — append:
```markdown
- Target 80% line coverage per engine module. 100% for: Arabic text operations,
  metadata pass-through (D-023), error code paths, consensus voting logic.
- Use `@pytest.mark.parametrize` for table-driven tests when a rule applies
  to multiple inputs (e.g., different Arabic formats, different page counts).
- Flaky test protocol: if a test fails intermittently, mark with
  `@pytest.mark.flaky(reason="...")` and file a fix ticket. Never delete flaky tests.
- Integration tests that depend on external services (LLM APIs) go in a separate
  `test_llm_inference.py` with `@pytest.mark.skipif` for offline runs.
- After any test failure, check if the failure is the test's fault or the code's
  fault BEFORE modifying the test. Tests that guard SPEC rules must not be weakened.
```

#### 8C. quality-workflow.md — Add Severity Classification + Pre-Merge Checklist
**Why:** ECC uses structured severity levels (CRITICAL blocks, HIGH blocks, MEDIUM warns). Currently KR workflow rules are binary — this adds nuance.

**Modify:** `.claude/rules/quality-workflow.md` — append:
```markdown
- Findings severity classification:
  - CRITICAL (blocks everything): security vulnerabilities, data corruption,
    Arabic text damage, silent metadata loss, frozen source modification
  - HIGH (blocks commit): wrong behavior vs SPEC, missing error handling,
    test failures, type errors
  - MEDIUM (advisory warning): style issues, missing tests for non-critical paths,
    long functions, missing docstrings
  - LOW (informational): performance suggestions, refactoring opportunities
- Pre-merge checklist (before any commit touching engine src/):
  [ ] pyright passes on modified files
  [ ] engine tests pass (pytest -x -q)
  [ ] no Arabic safety violations (hook output clean)
  [ ] no leftover print() statements
  [ ] D-023 metadata preserved (if contracts.py touched)
  [ ] commit message follows conventional format
```

### Phase 9: Enhance Existing Commands

#### 9A. /quality-gate — Add Complexity + Coverage Analysis
**Why:** Current quality gate checks tests, pyright, SPEC values, pydantic fields, metadata flow. Missing: function complexity and test coverage ratio.

**Modify:** `.claude/commands/quality-gate.md` — add checks #8 and #9:
```markdown
8. **Function complexity:** Scan engine src/ for functions >50 lines and >5 parameters:
   `python3 -c "import ast; ..." engines/$ARGUMENTS/src/*.py`
9. **Test coverage ratio:** Count SPEC §4 rules vs test functions:
   `grep -c '§4\.' engines/$ARGUMENTS/SPEC.md` vs `grep -c 'def test_' engines/$ARGUMENTS/tests/*.py`
```

Update summary table to include:
```
  Complexity:      PASS | WARN (N functions >50 lines)
  Coverage ratio:  PASS (N tests / M rules = X%) | WARN (<80%)
```

#### 9B. /catchup — Add Circuit Breaker + Print Warnings + Budget %
**Why:** /catchup reads session_state.json but doesn't display the new fields (cost, CB triggers, print warnings). Make them visible.

**Modify:** `.claude/commands/catchup.md` — add step 10:
```markdown
10. From session_state.json, also report:
    - Budget: EUR X/Y (Z% used)
    - Circuit breaker triggers: N recent (show last one if any)
    - Print warnings: N leftover print() statements in engine src/
    - Session cost delta since last session (if available)
```

#### 9C. /commit — Add Conventional Commit Validation
**Why:** The command already instructs Haiku to use conventional commits, but there's no validation.

**Modify:** `.claude/commands/commit.md` — add validation step:
```markdown
Before creating commits, validate each commit message against:
- Pattern: `^(feat|fix|refactor|docs|test|chore|perf|handoff|review|protocol)\([a-z/_-]+\): .+`
- First line max 72 characters
- If message doesn't match, rewrite it before committing
- Include test count when relevant: `(NNN pass, N skip)`
```

#### 9D. /smart-compact — Add Cost + CB History Save
**Why:** Cost and circuit breaker data should be captured before compaction wipes context.

**Modify:** `.claude/commands/smart-compact.md` — add to step 1:
```markdown
   - Session cost (from COST_LOG.json if available)
   - Circuit breaker triggers this session
   - Print warnings in modified files
```

---

## PART C: Future-Proofing for Web UI

### Phase 10: UI/Frontend Preparation

#### 10A. E2E Testing Patterns Rule (NEW — dormant until UI phase)
**Why:** KR will have a web UI. Encoding best practices NOW means the UI phase starts with correct patterns instead of learning them under pressure.

**Create:** `.claude/rules/e2e-testing.md` (glob: `ui/**/*.ts, ui/**/*.tsx, frontend/**/*`)
```markdown
- Use Playwright for E2E testing. Prefer semantic selectors:
  `[data-testid="scholar-card"]` > CSS class > XPath
- Page Object Model: one class per page/component with methods for actions.
- Never use `page.waitForTimeout()` (flaky). Use `page.waitForSelector()` or
  `expect(locator).toBeVisible()`.
- Test Arabic text rendering: verify RTL layout, diacritic display,
  ligature rendering (lam-alef لا must render as single glyph).
- Test bidirectional text: mixed Arabic/Latin in same field must not break layout.
- Accessibility: every interactive element needs `aria-label` or visible label.
  Test with screen reader simulation for Arabic content.
- Mark E2E tests with `@pytest.mark.e2e` (or equivalent) for separate CI runs.
- E2E tests must be idempotent — each test creates and cleans up its own data.
```

#### 10B. Frontend Development Rule (NEW — dormant until UI phase)
**Why:** When the UI phase begins, having component patterns and Arabic rendering rules ready prevents rework.

**Create:** `.claude/rules/frontend-development.md` (glob: `ui/**/*.ts, ui/**/*.tsx, frontend/**/*`)
```markdown
- TypeScript strict mode for all UI code. No `any` types.
- Components: functional components with hooks. No class components.
- Arabic text display: always set `dir="rtl"` and `lang="ar"` on Arabic content containers.
- Font stack for Arabic: Amiri (scholarly), Noto Naskh Arabic (fallback), system serif.
- Never truncate Arabic text with CSS `text-overflow: ellipsis` without testing
  that truncation doesn't split a word mid-letter or drop diacritics.
- Search inputs: normalize Arabic search queries (strip tatweel ـ, normalize hamza variants)
  but NEVER normalize display text.
- Keyboard navigation: support both LTR and RTL keyboard shortcuts.
- Color contrast: WCAG AA minimum (4.5:1) — critical for displaying diacritics
  which are small and low-contrast by nature.
- Scholar names: always display in Arabic script as primary, transliteration secondary.
- Component testing: React Testing Library or equivalent.
  Test by behavior (`getByRole`, `getByText`) not implementation.
```

#### 10C. /ui-test Command Template (NEW — dormant until UI phase)
**Why:** Ready-made command for when Playwright tests exist.

**Create:** `.claude/commands/ui-test.md`
```markdown
---
description: "Run E2E UI tests. Usage: /ui-test [component|full]. Dormant until UI phase."
allowed-tools: ["Bash"]
---
Run Playwright E2E tests for the KR scholarly library interface.

If $ARGUMENTS is a component name:
  `npx playwright test --grep "$ARGUMENTS" --reporter=html`

If $ARGUMENTS is "full" or empty:
  `npx playwright test --reporter=html`

After tests complete:
1. Report pass/fail count
2. For failures: show screenshot path and error message
3. Check Arabic rendering: grep test output for RTL/bidi issues
4. Open HTML report: `npx playwright show-report`

NOTE: This command is dormant until the UI phase begins. If no Playwright
config exists, report "UI tests not yet configured" and exit.
```

---

## Summary: 34 Changes Total

### New Additions (16)
| # | Area | Change | File |
|---|------|--------|------|
| 1A | Security | Config file protection hook | NEW hook + settings.json |
| 1B | Security | Secret detection in pre-commit | pre-commit-check.sh |
| 1C | Security | Git --no-verify block | settings.json |
| 2A | Hooks | Ruff auto-fix integration | settings.json + pyproject.toml |
| 2B | Hooks | Stop hook: cost + learning + prints | session_stop.py |
| 2C | Hooks | Startup: budget display | settings.json |
| 3A | Rules | Input sanitization | NEW rule |
| 3B | Rules | Context management | NEW rule |
| 3C | Rules | Commit message format | NEW rule |
| 4A | Commands | /build-fix | NEW command |
| 4B | Commands | /tdd | NEW command |
| 5A | Agents | quick-check (Haiku) | NEW agent |

### Existing Component Improvements (15)
| # | Area | Change | File |
|---|------|--------|------|
| 6A | Agent | code-reviewer: confidence + complexity | code-reviewer.md |
| 6B | Agent | test-engineer: edge cases + coverage | test-engineer.md |
| 6C | Agent | spec-adversary: security category | spec-adversary.md |
| 6D | Agent | build-prober: perf + flakiness | build-prober.md |
| 7A | Hook | pyright: scope + RAPID_MODE | pyright-check.sh |
| 7B | Hook | arabic-safety: invisible Unicode | arabic-safety-check.sh |
| 7C | Hook | pre-commit: function length + TODOs | pre-commit-check.sh |
| 7D | Hook | compact recovery: session state | settings.json |
| 8A | Rule | python-code: complexity limits | python-code.md |
| 8B | Rule | testing: coverage + flaky protocol | testing.md |
| 8C | Rule | quality-workflow: severity levels | quality-workflow.md |
| 9A | Cmd | /quality-gate: complexity + coverage | quality-gate.md |
| 9B | Cmd | /catchup: CB + prints + budget% | catchup.md |
| 9C | Cmd | /commit: conventional validation | commit.md |
| 9D | Cmd | /smart-compact: cost + CB save | smart-compact.md |

### Future-Proofing (3)
| # | Area | Change | File |
|---|------|--------|------|
| 10A | Rule | E2E testing patterns | NEW rule (dormant) |
| 10B | Rule | Frontend development | NEW rule (dormant) |
| 10C | Cmd | /ui-test template | NEW command (dormant) |

## Files Modified (existing) — 14 files

| File | Changes |
|------|---------|
| `.claude/settings.json` | 1A, 1C, 2A, 2C, 7D |
| `.claude/hooks/pre-commit-check.sh` | 1B, 7C |
| `.claude/hooks/pyright-check.sh` | 7A |
| `.claude/hooks/arabic-safety-check.sh` | 7B |
| `scripts/session_stop.py` | 2B |
| `pyproject.toml` | 2A |
| `.claude/agents/code-reviewer.md` | 6A |
| `.claude/agents/test-engineer.md` | 6B |
| `.claude/agents/spec-adversary.md` | 6C |
| `.claude/agents/build-prober.md` | 6D |
| `.claude/rules/python-code.md` | 8A |
| `.claude/rules/testing.md` | 8B |
| `.claude/rules/quality-workflow.md` | 8C |
| `.claude/commands/quality-gate.md` | 9A |
| `.claude/commands/catchup.md` | 9B |
| `.claude/commands/commit.md` | 9C |
| `.claude/commands/smart-compact.md` | 9D |

## Files Created (new) — 10 files

| File | Purpose |
|------|---------|
| `.claude/hooks/config-protection.sh` | Protect settings/hooks from accidental edits |
| `.claude/rules/input-sanitization.md` | External text safety |
| `.claude/rules/context-management.md` | Token/MCP awareness |
| `.claude/rules/commit-format.md` | Conventional commits |
| `.claude/rules/e2e-testing.md` | E2E patterns (dormant) |
| `.claude/rules/frontend-development.md` | UI patterns (dormant) |
| `.claude/commands/build-fix.md` | Iterative error resolution |
| `.claude/commands/tdd.md` | Test-driven development |
| `.claude/commands/ui-test.md` | E2E test runner (dormant) |
| `.claude/agents/quick-check.md` | Fast Haiku-based validator |

## Implementation Order

**Group 1 — Security + Hooks (highest impact, modify core infra):**
1A, 1B, 1C, 2A, 2B, 2C, 7A, 7B, 7C, 7D

**Group 2 — Rules (no code execution risk, purely guidance):**
3A, 3B, 3C, 8A, 8B, 8C, 10A, 10B

**Group 3 — Agent improvements (update prompts, no runtime risk):**
6A, 6B, 6C, 6D

**Group 4 — Commands (opt-in, low risk):**
4A, 4B, 9A, 9B, 9C, 9D, 10C

**Group 5 — New agent:**
5A

## Verification

After full implementation:
1. `python -m pytest engines/excerpting/tests/ -v --tb=short` — baseline ≥588 pass
2. Edit a `.py` file → verify ruff + black + pyright + auto-test all fire
3. Edit a file in `experiments/` → verify pyright SKIPS it (scope fix)
4. `git commit --no-verify` attempt → verify blocked
5. Write to `.claude/settings.json` → verify config-protection blocks
6. `python3 scripts/session_stop.py` → verify cost_summary, cb_triggers, print_warnings
7. New session start → verify budget display in startup hook
8. `/build-fix "pytest engines/excerpting/tests/test_dummy -x"` → verify command works
9. `/tdd excerpting "§4.A.3"` → verify TDD workflow fires
10. Existing hooks still work identically for normal edit-test cycles
11. All 15 commands still function correctly

## What We're NOT Adopting (and why)

| ECC Feature | Why Skip |
|-------------|----------|
| TypeScript/Go/Rust/Java/Kotlin/PHP/Swift reviewers | KR is Python-only. Would add 7 unused agent files. |
| tmux auto-start hook | Windows incompatible (NTFS, no tmux) |
| Identity separation / agent accounts | Single-developer project — pure overhead |
| Governance capture hooks | No audit compliance requirement |
| ECC's 125 generic skills | KR's 9 domain-specific skills are more valuable. Generic skills would dilute context. |
| Database reviewer agent | KR uses file-based persistence, not PostgreSQL/RDS |
| Extra env toggles (STRICT/LINT mode) | RAPID_MODE + OVERNIGHT are sufficient. More toggles = combinatorial complexity. |
| Memory management narrowing | Already scoped to single JSONL file |
| Generic model routing rule | Already well-calibrated per-agent (code-reviewer: opus, test-engineer: sonnet, commit: haiku) |
| Commitlint npm package | Overkill — advisory regex in pre-commit hook achieves same goal without npm dependency |
