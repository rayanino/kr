# Plan: Fix Division Tree Preamble Gaps (Phase 1 Blocker)

## Context

ALL 5 experimental packages fail Phase 1 validation (EX-V-001) because parent division nodes have content units not covered by any child. This is the standard Arabic scholarly text pattern: a chapter starts with introductory text before its sub-sections. Units 2-29% of each package are silently lost. No LLM integration testing can proceed until this is fixed.

The NEXT.md plan is **architect-specified with exact code** — line numbers, algorithm, imports, and test specs are all pre-defined. This plan's value is the pre-implementation risk analysis the user requested.

---

## Pre-Implementation Risk Analysis

### VERIFIED SAFE (13 checks passed)

| # | Check | Result |
|---|-------|--------|
| 1 | **Line numbers match** | All 5 function defs match NEXT.md exactly: `find_leaf_divisions:180`, `should_skip_division:209`, `validate_phase1:1132`, `_build_parent_map:1281`, `run_phase1:1338` |
| 2 | **Import additions** | `DivisionType` (L467), `HeadingDetectionMethod` (L51), `HeadingConfidence` (L42) all exist as `str, Enum` in normalization contracts. NOT currently imported in phase1_assembly.py. |
| 3 | **DivisionType.MUQADDIMAH** | Exists at L478, value = `"مقدمة"` |
| 4 | **No div_id validators** | `div_id` is plain `str` field — no regex, no prefix check. Synthetic IDs (`_pre`, `_gap_N`, `_post`) pass freely. |
| 5 | **model_copy pattern** | Already used at L1556 in same file. Pydantic v2 confirmed. |
| 6 | **No test file collision** | `test_phase1_preamble.py` does not exist anywhere. |
| 7 | **No function name collision** | `_complete_division_tree` appears only in NEXT.md. |
| 8 | **Package data present** | All 5 dirs have `manifest.json` + `content.jsonl`. |
| 9 | **Conftest factory compatible** | `_make_division_node(**overrides)` supports all needed fields. |
| 10 | **Import pattern clear** | Tests use `from engines.excerpting.tests.conftest import ...` and `from engines.excerpting.src.phase1_assembly import ...` |
| 11 | **DivisionNode has no @model_validator** | No validators that could reject synthetic nodes. |
| 12 | **Optional[DivisionType]** | `division_type=None` is valid for inter-child/trailing gaps. |
| 13 | **run_phase1 modification points** | All 4 code blocks (L1362, L1435, L1438, L1568) match NEXT.md's "Replace" sections character-for-character. |

### BASELINE DRIFT (minor, non-blocking)

| Issue | Detail | Impact |
|-------|--------|--------|
| **Test count** | NEXT.md says "570 tests (2 skipped)". Actual: **572 passed, 0 skipped**. The 2 previously-skipped tests now pass. | Verification step expects "572 + N" not "570 + N". No code impact. |

### EDGE CASES IN ALGORITHM (all handled correctly)

| Edge Case | Algorithm Behavior | Covered by Test |
|-----------|-------------------|-----------------|
| No children (`children=[]`) | Treated as leaf, returned as-is | Test 12 |
| Children fully cover parent range | No synthetics added | Test 2 |
| Flat tree (all leaves) | No-op, all returned unchanged | Test 3 |
| Same-page siblings (same `start_unit_index`) | `sorted()` is stable; inter-child gap check produces negative range → no synthetic | Not explicitly tested, but mathematically safe |
| Nested preamble gaps (grandparent + parent) | Recursive call handles children first, then parent | Test 6 |
| Preamble units all TOC/blank | `should_skip_division` or `assemble_text` handles correctly — empty text → division skipped | Implicit in existing skip logic |
| Tiny preamble (< 50 words) | Merge step groups by parent; synthetic preamble may merge with first sibling | Correct behavior, not a bug |

### ZERO ISSUES FOUND

After thorough analysis of contracts, validators, test helpers, package data, and algorithm edge cases: **the NEXT.md plan is implementable as written with no modifications needed.**

The architect did a thorough job — the plan accounts for:
- Backward compatibility (optional `completed_tree` parameter)
- Immutability (model_copy, not mutation)
- All gap types (preamble, inter-child, trailing) despite only preamble being empirically observed
- Correct heading_level assignment (sibling level, not parent level)
- Semantic correctness (MUQADDIMAH type for preambles)

---

## Implementation Steps

Execute NEXT.md Parts A-E exactly as specified. The architect's code is copy-pasteable with verified line numbers.

### Step 1: Add imports (Part A prerequisite)
- **File:** `engines/excerpting/src/phase1_assembly.py` lines 37-49
- Add `DivisionType`, `HeadingDetectionMethod`, `HeadingConfidence` to existing normalization import block

### Step 2: Implement `_complete_division_tree()` (Part A)
- **File:** `engines/excerpting/src/phase1_assembly.py`
- **Insert after:** line 206 (end of `find_leaf_divisions`), **before:** line 209 (`should_skip_division`)
- Copy algorithm from NEXT.md exactly

### Step 3: Wire into `run_phase1()` (Part B)
- **File:** `engines/excerpting/src/phase1_assembly.py`
- 4 changes at lines 1362, 1435, 1438, 1568
- All modification points verified character-for-character

### Step 4: Update `validate_phase1()` signature (Part C)
- **File:** `engines/excerpting/src/phase1_assembly.py`
- Add optional `completed_tree` parameter (L1132)
- Update leaf finding to use completed tree (L1154)

### Step 5: Write tests (Part D)
- **New file:** `engines/excerpting/tests/test_phase1_preamble.py`
- 12 tests: 9 unit tests for `_complete_division_tree` + 2 integration tests on real packages + 1 edge case

### Step 6: Add SPEC errata note (Part E)
- **File:** `engines/excerpting/SPEC.md` around line 635
- One paragraph documenting the tree completion behavior

### Step 7: Verification
1. `python -m pytest engines/excerpting/tests/ -q --tb=short` → 572 + 12 = **584 tests**, 0 failed
2. `grep -n 'def _complete_division_tree'` → function exists
3. `grep 'completed_tree'` → 5+ occurrences
4. Integration script on all 5 packages → all PASS
5. Mock integration test → completes without error
6. No existing tests broken

## Key Files

| File | Action |
|------|--------|
| `engines/excerpting/src/phase1_assembly.py` | Edit (imports + new function + 4 wiring changes + signature update) |
| `engines/excerpting/tests/test_phase1_preamble.py` | Create (12 tests) |
| `engines/excerpting/SPEC.md` | Edit (1 paragraph addition) |
| `engines/normalization/contracts.py` | Read-only (verify enums) |
| `engines/excerpting/tests/conftest.py` | Read-only (use existing factories) |
| `experiments/format_diversity_test/packages/*/` | Read-only (integration test data) |
