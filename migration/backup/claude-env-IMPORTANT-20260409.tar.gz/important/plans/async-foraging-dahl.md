# Plan: Diagnose & Fix CLI Backend Integration Test Failure

## Context

The CLI adapter (`--backend cli`) smoke test produces **0 excerpts across all 5 packages** despite reporting "success". The OAuth token is **VALID** (7.7h remaining). This is NOT a token expiry issue — something else prevents the CLI subprocess calls from executing or returning results.

**Key evidence:**
- 3 request files per package (adapter retry hook fires 3x) but 0 response AND 0 error files
- Phase 2a timing: 0.009s per package — impossibly fast for even one subprocess call (~85ms minimum)
- `run_metadata.json` shows `error_count: 0` — errors are silently swallowed
- `SUMMARY.json` says `status: "success"` for all packages — misleading

## Root Cause Analysis

Two bugs compound:

**Bug A — Unknown subprocess failure mode:** The adapter fires the `completion:kwargs` hook (3 request files) but never fires `completion:response` or `completion:error`. The 0.009s timing means subprocess.run() either never executes or fails before spawning the process. Possible causes:
1. `subprocess.run(check=True)` raises `CalledProcessError` but the error hook write fails silently
2. `_extract_claude_result()` raises `CLIBackendError` which ISN'T caught by the adapter's retry loop (only catches `CalledProcessError`, `TimeoutExpired`, `json.JSONDecodeError`, `ValidationError`)
3. A Windows-specific subprocess issue (encoding, shell, PATH)

**Bug B — Silent failure:** `phase2_classify.py:454` catches ALL exceptions via `except Exception`, logs a warning, excludes the chunk, and returns empty results. The integration test reports "success" when 0/N chunks succeed.

## Plan

### Step 1: Diagnostic (find the actual error)

Run a minimal isolated test of the CLI adapter — outside the full pipeline — to see the exact exception:

```python
python3 -c "
import logging, json
logging.basicConfig(level=logging.DEBUG)
from shared.llm.cli_adapter import CLIInstructorAdapter, CLIBackendError
from pydantic import BaseModel

class Test(BaseModel):
    answer: str

adapter = CLIInstructorAdapter()
try:
    result = adapter.chat.completions.create(
        model='anthropic/claude-opus-4.6',
        response_model=Test,
        messages=[
            {'role': 'system', 'content': 'Return JSON: {\"answer\": \"hello\"}'},
            {'role': 'user', 'content': 'Say hello'},
        ],
        max_retries=0,
    )
    print(f'SUCCESS: {result}')
except Exception as e:
    print(f'FAILED: {type(e).__name__}: {e}')
"
```

This will reveal the exact exception type and message. All subsequent steps depend on this output.

### Step 2: Fix the adapter's exception handling gap

**File:** `shared/llm/cli_adapter.py` (create method, ~line 400-530)

The retry loop catches 4 specific exception types but NOT `CLIBackendError`. If `_extract_claude_result()` raises CLIBackendError (envelope with `is_error=true` but exit code 0), it bypasses all retry logic.

**Fix:** Add a catch for `CLIBackendError` in the retry loop, treating it like `CalledProcessError`:

```python
except CLIBackendError as e:
    last_error = e
    logger.warning(
        "Attempt %d/%d: CLI backend error: %s",
        attempt + 1, max_retries + 1, e,
    )
    if attempt < max_retries:
        time.sleep(2**attempt)
    else:
        adapter._fire_hooks("completion:error", e)
        raise
```

Place this AFTER the `CalledProcessError` handler (line ~530) and BEFORE the end of the try/except chain.

### Step 3: Fix based on Step 1 diagnostic results

**If auth error** (token rejected despite being valid):
- Check if credentials.json token needs URL-encoding or escaping for the ANTHROPIC_API_KEY env var
- Test with `KR_ANTHROPIC_TOKEN` env var set explicitly
- Check if Windows subprocess env handling differs

**If subprocess not found / PATH issue:**
- Use full path from `shutil.which("claude")` in the subprocess command instead of bare `"claude"`

**If encoding error** (Windows cp1252 vs UTF-8 in subprocess):
- Add `errors="replace"` to subprocess.run encoding parameter
- Or force UTF-8 via `PYTHONIOENCODING=utf-8` in the subprocess env

### Step 4: Test and verify

```bash
# 1. Isolated adapter test (Step 1 diagnostic — must succeed first)
python3 -c "..." # Same as Step 1 but expecting SUCCESS

# 2. Unit tests (must stay at 43 pass)
python -m pytest shared/llm/tests/test_cli_adapter.py -v --tb=short

# 3. CLI smoke test (THE actual test)
python scripts/run_full_integration.py --backend cli \
  --output-dir integration_tests/smoke_cli_fix_20260329 --max-chunks 1
# Expect: 5/5 packages, >0 excerpts, $0.00 cost

# 4. Full suite regression
python -m pytest engines/excerpting/tests/ -q --tb=short
```

## Files to modify

| File | Change |
|------|--------|
| `shared/llm/cli_adapter.py` | Add CLIBackendError catch in retry loop + fix from Step 1 diagnostic |
| `shared/llm/tests/test_cli_adapter.py` | Add test for CLIBackendError retry |

## Key constraint

**Do NOT modify** any files outside `shared/llm/` — per NEXT.md scope restriction. The phase2 silent failure is a separate issue to track.
