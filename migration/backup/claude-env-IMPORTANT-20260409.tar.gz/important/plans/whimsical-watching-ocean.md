# Plan: Pre-Close Deep Review — 3 Fixes + 1 Memory

## Context

Ultra-think analysis before session close found 2 genuine gaps that the 3-reviewer audit missed, plus 1 piece of project knowledge worth persisting.

## Finding 1: FLAG+PLAUSIBLE gap in consolidator comparison table

The consolidator's verdict comparison table covers 14 of 16 non-ESCALATE verdict pairs. Two are missing:
- FLAG + PLAUSIBLE (one verifier found a problem, the other is uncertain)
- PLAUSIBLE + FLAG (symmetric)

This is a **pre-existing gap** (the original table never had it), but adding UNVERIFIABLE made it more visible because the table now looks exhaustive. During Probe 3, if a consolidator encounters FLAG+PLAUSIBLE with no matching row, it has to guess — exactly the kind of silent failure KR is designed to prevent.

**Classification:** SOFT_DISAGREEMENT — one says "maybe wrong" (FLAG) and the other says "uncertain" (PLAUSIBLE). This isn't as urgent as HARD_DISAGREEMENT (where one says "correct" and the other says "wrong"), but it still requires investigation.

**Fix:** Add 2 rows to consolidator.md comparison table:
```
| FLAG | PLAUSIBLE | **SOFT_DISAGREEMENT** — investigate |
| PLAUSIBLE | FLAG | **SOFT_DISAGREEMENT** — investigate |
```

Also add matching rows to `reference/AGENT_ARCHITECTURE.md` if it has the same table (it doesn't — the architecture only has the quality gate table, not the comparison table. So only consolidator.md needs updating.)

## Finding 2: ADV-025 SPEC rule quote is stale

ADV-025 line 541 still quotes `>70%` but K1 changed the SPEC to `≥70%`. The "Correct behavior" section explains the change, but the SPEC rule quote itself is now wrong.

**Fix:** Update the SPEC rule quote from `>70%` to `≥70%`.

## Finding 3: model: field constraint — save as memory

The discovery that agent frontmatter `model:` field accepts only short names (`opus`, `sonnet`) — not full API model IDs — is project-specific knowledge that prevents future mistakes. No memory currently captures this.

**Fix:** Create `feedback_model_field_format.md` in memory directory.

## Execution

### Step 1: Consolidator comparison table (2 rows)
File: `.claude/agents/consolidator.md`
Insert after the UNVERIFIABLE+FLAG row (line ~43), before Step 2:
```
| FLAG | PLAUSIBLE | **SOFT_DISAGREEMENT** — investigate |
| PLAUSIBLE | FLAG | **SOFT_DISAGREEMENT** — investigate |
```

### Step 2: ADV-025 SPEC rule quote
File: `reference/SPEC_ADVERSARY_NORMALIZATION.md`
Change line ~541: `>70%` → `≥70%` in the SPEC rule quote only.

### Step 3: Model field memory
Create `feedback_model_field_format.md`.

### Step 4: Update MEMORY.md index

### Step 5: Commit + push

## Verification
```bash
# Consolidator now has 18 non-ESCALATE rows (16 pairs + 2 ESCALATE wildcards)
grep -c "|" .claude/agents/consolidator.md  # Should increase by 2

# ADV-025 quote updated
grep "≥70%" reference/SPEC_ADVERSARY_NORMALIZATION.md | head -2  # Should show 2 lines (SPEC rule quote + another)

# Memory file exists
ls -la ~/.claude/projects/C--Users-Rayane-Desktop-kr/memory/feedback_model_field_format.md
```
