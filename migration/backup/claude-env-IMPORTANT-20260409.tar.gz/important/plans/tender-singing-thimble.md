# Plan: Execute 9 Architect-Specified Fixes for Excerpting Phase 3

## Context

Architect review (commit `4a7f71e9`) + CC adversarial audit found 9 bugs in `phase3_consensus.py` and `phase3_enrichment.py`. NEXT.md provides exact fix code, exact line numbers, and exact test specifications. This is an architect-directive execution — no design decisions needed.

**Baseline:** 437 passed, 2 skipped, 0 failed
**Target:** ≥465 passed (437 + ≥28 new), 0 failed
**Constraint:** Do NOT modify `contracts.py`. Do NOT modify existing tests. Only ADD new tests.

## Files to Modify

| File | Fixes |
|------|-------|
| `engines/excerpting/src/phase3_consensus.py` | 1, 3a, 3b, 4, 5, 6, 7, 8, 9 |
| `engines/excerpting/src/phase3_enrichment.py` | 2, 4 |
| `engines/excerpting/tests/test_phase3_consensus.py` | +16 new tests |
| `engines/excerpting/tests/test_phase3_enrichment.py` | +5 new tests |

## Execution Order

### Step 1: Fix 1 — Attribution majority winner NOT applied [CRITICAL]
**File:** `phase3_consensus.py` lines 337-347
**Change:** When `majority != enrichment_val`, update `primary_author_layer` via `model_copy(update={"author_id": majority, "rule_applied": "LA-3_consensus"})`. Currently only records the decision but doesn't apply it.
**Tests (4):** `test_majority_different_from_enrichment_applied`, `test_majority_same_as_enrichment_unchanged`, `test_all_3_disagree_keeps_enrichment`, `test_majority_sets_consensus_rule`

### Step 2: Fix 2 — PARTIAL context_hint None → I-ER-4 crash [HIGH]
**File:** `phase3_enrichment.py` lines 279-282
**Change:** Add fallback chain: LLM hint → `self_containment_notes` → generic Arabic string `"يحتاج سياقاً إضافياً لفهم المحتوى"`
**Tests (3):** `test_apply_partial_with_none_hint_uses_notes_fallback`, `test_apply_partial_with_none_hint_no_notes_uses_generic`, `test_apply_partial_roundtrip_after_enrichment`

### Step 3: Fix 3 — EX-G-003 over-triggers [MEDIUM]
**File:** `phase3_consensus.py`
- **3a** line 290: Change `vi.alternative != excerpt.school` → `vi.alternative != source_school`
- **3b** lines 575-585: Add verifier-agrees-with-source check before triggering EX-G-003
**Tests (4):** `test_ex_g_003_not_triggered_when_verifier_agrees_with_source`, `test_ex_g_003_triggered_when_source_conflicts_with_both`, `test_check_gate_triggers_ex_g_003_respects_verifier`, `test_check_gate_triggers_ex_g_003_both_conflict`

### Step 4: Fix 4 — Chunk matching startswith false-match [MEDIUM]
**Files:** `phase3_enrichment.py` lines 370-380, `phase3_consensus.py` lines 640-648
**Change:** Replace `startswith` loop with exact dict lookup + split_id fallback pattern
**Tests (2):** `test_split_chunk_matched_correctly`, `test_split_chunk_consensus_matched_correctly`

### Step 5: Fix 5 — Verification item mapping ignores item_index [MEDIUM-HIGH]
**File:** `phase3_consensus.py` lines 714-726
**Change:** Replace positional `iter()/next()` with `vi_by_index` dict keyed by `item_index`
**Tests (2):** `test_verification_items_matched_by_index_not_position`, `test_missing_verification_item_logged`

### Step 6: Fix 6 — _parse_self_containment substring order [LOW-MEDIUM]
**File:** `phase3_consensus.py` lines 490-498
**Change:** Try exact match first, then on substring match pick most conservative (DEPENDENT < PARTIAL < FULL)
**Tests (3):** `test_parse_ambiguous_picks_most_conservative`, `test_parse_exact_match_preferred`, `test_parse_both_in_text`

### Step 7: Fix 7 — Gate entry missing assessments [MEDIUM]
**File:** `phase3_consensus.py` lines 595-619
**Change:** Add `assessments` list built from `consensus_metadata.decisions` to the gate entry dict
**Tests (2):** `test_gate_entry_contains_assessments`, `test_gate_entry_assessments_contain_all_models`

### Step 8: Fix 8 — consensus_metadata ordering [MEDIUM]
**File:** `phase3_consensus.py` lines 226-234
**Change:** Move `consensus_metadata` assignment BEFORE `_repair_context_hint` call. Remove duplicate `ConsensusRecord` at line 234.
**Tests (1):** `test_repair_context_hint_reads_consensus_metadata`

### Step 9: Fix 9 — Phantom "unknown" voter [LOW-MEDIUM]
**File:** `phase3_consensus.py` line 330 + lines 422-430
**Change:** Replace `vi.alternative or "unknown"` with `vi.alternative` (None). Add `_find_majority_flexible()` that filters None votes. Update `ConsensusDecision.verifier_value` to use `verifier_val or "abstained"` for display.
**Tests (2):** `test_verifier_no_alternative_does_not_block_majority`, `test_verifier_no_alternative_with_different_escalation`

## Post-Fix Verification

1. `python -m pytest engines/excerpting/tests/ -v --tb=short` → ≥465 passed, 0 failed
2. All 437 existing tests still pass
3. Fix 1 acid test: `test_majority_different_from_enrichment_applied` → `author_id == "sch_b"`
4. Fix 2 acid test: `test_apply_partial_roundtrip_after_enrichment` → `model_validate` no raise
5. `grep -n "startswith" phase3_enrichment.py phase3_consensus.py` → 0 in chunk matching sections
6. Pyright on both modified source files
7. Commit all changes, push to origin
