# Plan: Mermaid Visual Representations for KR Pipeline Engines

## Context

The KR pipeline has 7 conceptual engines, but the excerpting engine **absorbs** passaging (as Phase 1) and atomization (as Phase 2) in the actual implementation. The user wants Mermaid diagrams to visualize the engine architecture. These diagrams will go in `docs/architecture/` as a new `pipeline_diagrams.md` file — a single document with all diagrams rendered inline via Mermaid code blocks.

## What to create

**One file:** `docs/architecture/pipeline_diagrams.md` containing 4 Mermaid diagrams:

### Diagram 1: Full Pipeline Overview
A left-to-right flowchart showing all 7 engines, the normalization boundary, and Phase 1/Phase 2 grouping. Highlights which engines are built vs. in-progress vs. not-started.

```
Source → Normalization ─── BOUNDARY ─── [Passaging] → [Atomization] → Excerpting → Taxonomy → Synthesis
         Phase 1                              Phase 2 (source-agnostic)
```

Key details:
- Normalization boundary clearly marked as a subgraph divider
- Passaging/Atomization shown as absorbed into Excerpting (dashed borders)
- Build status indicated by color: green=complete, yellow=in-progress, gray=not-started

### Diagram 2: Data Flow Between Engines
Shows the concrete data types/artifacts that flow between each engine:

- Source → Normalization: `frozen files` + `SourceMetadata`
- Normalization → Excerpting: `NormalizedPackage` (manifest.json + content.jsonl)
- Excerpting → Taxonomy: `ExcerptRecord` stream (excerpts.jsonl)
- Taxonomy → Synthesis: `PlacedExcerpt` files (.json per excerpt)
- Synthesis → Library: `Entry` files

### Diagram 3: Excerpting Engine Internal Phases
The most complex engine — 3-phase internal pipeline:

```
NormalizedPackage
  → Phase 1 (deterministic): walk division tree → assemble text → merge/split → rebase layers
  → Phase 2 (LLM): classify segments (16 types) → group into teaching units
  → Phase 3 (enrichment): deterministic fields → LLM enrichment → consensus verification → validation
  → ExcerptRecords
```

### Diagram 4: Source Engine Internal Flow
Shows the intake → metadata extraction → LLM inference → consensus → freezing → registration flow.

## Changelog mechanism

The diagrams file will include a **Changelog** section at the bottom — a reverse-chronological table of diagram updates. Each entry has:
- **Date** (YYYY-MM-DD)
- **Ref** — a short tag like `CHG-001` for easy referencing in commits/conversations
- **What changed** — 1-line summary (e.g., "Taxonomy: Session 1 complete, 119 tests → status yellow→green")

Example:
```
| Ref | Date | Change |
|-----|------|--------|
| CHG-001 | 2026-04-07 | Initial creation — all 4 diagrams from current state |
```

**When to update:** Any commit that changes an engine's build status, adds/removes a phase, modifies contracts between engines, or changes the pipeline architecture should include a corresponding update to this file with a new CHG entry. The diagrams themselves get updated inline (colors, labels, nodes), and the changelog records what changed and why.

## Files to create/modify

| File | Action |
|------|--------|
| `docs/architecture/pipeline_diagrams.md` | CREATE — all 4 Mermaid diagrams + explanatory text + changelog table |

## Key architectural facts to represent accurately

1. **Normalization boundary**: Phase 1 (source-format-specific) vs Phase 2 (source-agnostic). If a new source type is added, ONLY Phase 1 engines change.
2. **Absorption**: Excerpting absorbs Passaging (Phase 1) and Atomization (Phase 2). The 7-engine conceptual model maps to 5 actual engines.
3. **D-023**: Metadata flows forward through the entire pipeline, never deleted.
4. **D-041**: Multi-model consensus for content decisions (shown in excerpting Phase 3).
5. **Build status**: Source (complete, 758 tests), Normalization (complete, 420 tests), Excerpting (complete + hardening, 917+ tests), Taxonomy (Session 1 done, 119 tests), Synthesis (SPEC only, no code).

## Verification

- Render the Mermaid diagrams in a Markdown preview to confirm syntax is valid
- Cross-check data types against actual `contracts.py` files
- Ensure the normalization boundary and absorption are clearly represented
