# Mypy Fixes — EXECUTION COMPLETE + CRITICAL REVIEW

## Status: ALL DONE

- 17 edits across 9 files applied and verified
- mypy: **Success: no issues found in 39 source files**
- pytest source engine: **511 passed in 4.10s**
- pytest shared components: **71 passed in 0.95s**
- mypy shared files: **Success: no issues found in 3 source files**

## Handoff Doc Gaps (2 issues found and fixed)

The handoff document (`reference/CLAUDE_CODE_MYPY_FIXES.md`) had two gaps:

### Gap 1: Fix 3 — `elif` alone was insufficient

**Handoff said:** Change `if` to `elif` on line 468 of `scholar_authority.py` to make branches mutually exclusive.

**Reality:** The `merged` variable is inside a `for` loop (line 449). Across iterations, mypy tracks `merged` as `list` from the first branch, then sees `dict` assignment in the `elif` branch of the next iteration. `elif` solves within-iteration exclusivity but not cross-iteration type narrowing.

**Additional fix applied:** Renamed `merged` to `merged_dict` in the dict branch (lines 469-471). This gives each branch its own variable, eliminating the cross-iteration type conflict.

**Behavioral impact:** Zero. `merged_dict` is used only within lines 469-471 and doesn't leak outside.

### Gap 2: Fix 7 — missed downstream consumer `build_needs_review`

**Handoff said:** Widen `apply_confidence_caps` return from `dict[str, float]` to `dict[str, float | None]`. Checked downstream: `engine.py` reads via bare `dict` — no issue.

**Reality:** `build_needs_review(confidence, extracted)` at `metadata_inference.py:611` is another consumer. Its parameter was `confidence_scores: dict[str, float]` — now incompatible.

**Additional fix applied:** Widened `build_needs_review` parameter to `dict[str, float | None]`.

**Behavioral impact:** Zero. The function already handles None at line 380: `if score is not None and score < threshold`. Its own docstring (line 367) already documents: "None confidence values... are skipped." The annotation was simply wrong before.

## Behavioral Analysis of All Fixes

| Fix | Type | Behavioral Change? |
|-----|------|-------------------|
| 1 (config.py return type) | Annotation only | None |
| 2 (validation.py variable type) | Annotation only | None |
| 3 (scholar_authority.py elif + rename) | Logic equivalent | None — list/dict mutually exclusive |
| 4 (consensus.py BaseException) | **Real fix** | Catches KeyboardInterrupt/SystemExit from gather — prevents potential crash |
| 5 (consensus.py assert) | Runtime assertion | Documents invariant; raises AssertionError instead of AttributeError on violation |
| 6 (scholar_registry.py type:ignore) | Suppression | None |
| 7 (metadata_inference.py return type) | Annotation truthfulness | None — function already returned None |
| 7b (metadata_inference.py param type) | Annotation truthfulness | None — function already handled None |
| 8 (metadata_inference.py type:ignore) | Suppression | None |
| 9 (engine.py field_name default) | **Real fix** | Prevents TypeError crash when gate_error.field is None |
| Pydantic suppressions (x6) | Suppression | None |

**Fixes with real behavioral impact:** Only Fix 4 and Fix 9 change runtime behavior, and both are strictly improvements (crash prevention).

## Risk Assessment

1. **Fix 5 assert with `-O` flag:** If Python runs with `-O`, asserts are stripped. But the code already relied on the None checks above; the assert adds safety, doesn't remove any.

2. **Fix 9 `or "unknown"`:** If `gate_error.field` is empty string `""`, it defaults to `"unknown"`. This is acceptable — empty string field names are bugs in validation code, not legitimate values.

3. **Fix 3 `elif`:** A value can never be both list and dict. The `elif` is logically identical to `if` for all possible inputs.

4. **Fix 4 `BaseException`:** `asyncio.gather(return_exceptions=True)` puts exceptions in the result list rather than raising them. Wrapping `BaseException` subtypes as failed `ModelResponse` is correct behavior.

## What to Do Next

Per `NEXT.md` and `PRE_BATCH_EXECUTION_PROTOCOL.md`: the owner should say "continue" in Claude Chat to trigger **Step 2 (Subtask 2A)** — verify Claude Code's mypy work. Update NEXT.md accordingly.
