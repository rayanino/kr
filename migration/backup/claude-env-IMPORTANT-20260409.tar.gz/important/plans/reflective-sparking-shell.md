# Claude Code Configuration Inventory — KR Project

**Generated:** 2026-03-26T22:15Z
**Branch:** master (HEAD: `c4544f89`)
**Purpose:** Ground-truth inventory for Claude Chat architect

---

## 1. .claude/settings.json

```json
{
  "$schema": "https://json.schemastore.org/claude-code-settings.json",
  "permissions": {
    "allow": [
      "Read", "Write", "Edit", "MultiEdit", "Glob", "Grep", "LS", "Task",
      "WebFetch", "WebSearch", "TodoWrite",
      "Bash(python *)", "Bash(python3 *)", "Bash(pip install *)", "Bash(pip3 install *)",
      "Bash(cd *)", "Bash(cat *)", "Bash(ls *)", "Bash(grep *)", "Bash(find *)",
      "Bash(wc *)", "Bash(head *)", "Bash(tail *)", "Bash(mkdir *)", "Bash(cp *)",
      "Bash(mv *)", "Bash(rm *)", "Bash(touch *)", "Bash(chmod *)", "Bash(git *)",
      "Bash(tree *)", "Bash(sed *)", "Bash(awk *)", "Bash(sort *)", "Bash(diff *)",
      "Bash(echo *)", "Bash(jq *)", "Bash(curl *)", "Bash(make *)",
      "Bash(sha256sum *)", "Bash(md5sum *)", "Bash(pytest *)", "Bash(black *)",
      "Bash(ruff *)", "Bash(npx *)", "Bash(node *)"
    ],
    "deny": [
      "Bash(rm -rf /)", "Bash(sudo rm:*)", "Read(.env)"
    ],
    "defaultMode": "acceptEdits"
  },
  "hooks": { "...see Section 5 below..." },
  "enabledPlugins": {
    "oberskills@rtd": true
  }
}
```

**User-level settings (~/.claude/settings.json):**
- `model`: `opus[1m]`
- `defaultMode`: `bypassPermissions`
- `alwaysThinkingEnabled`: true
- `fastMode`: false
- `autoDreamEnabled`: true
- `skipDangerousModePermissionPrompt`: true
- `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS`: "1"

**User-level plugins (21 total):**
pyright-lsp, gopls-lsp, commit-commands, pr-review-toolkit, qodo-skills, coderabbit, feature-dev, playground, serena, skill-creator, claude-md-management, claude-mem, firecrawl, oberskills, superpowers, code-simplifier, ralph-loop, explanatory-output-style, context7, claude-lens, gsd (via hooks)

---

## 2. .claude/agents/ — 21 active + 3 archived

| # | File | Description | Model | Tools | Actually Used? |
|---|------|-------------|-------|-------|---------------|
| 1 | `arabic-reviewer.md` | Arabic text safety + scholarly convention review | sonnet | Read, Bash, Glob, Grep | **NEW (Session 2)** — never tested |
| 2 | `audit-comparator.md` | Merges dual-auditor (A+B) defect inventories | opus | Read, Grep, Glob, Bash | **UNTESTED** — designed for SPEC audits, never dispatched |
| 3 | `boundary-validator.md` | Pipeline boundary contract checks (D-023) | sonnet | Read, Bash, Glob, Grep | **UNTESTED** — designed for post-build, never dispatched |
| 4 | `build-prober.md` | Session diff vs SPEC drift detection | opus | Read, Bash, Glob, Grep | **USED** — dispatched in normalization build sessions |
| 5 | `code-reviewer.md` | Implementation code review against SPEC | opus | Read, Bash, Glob, Grep | **HEAVILY USED** — 10+ dispatches, multiple BLOCKED/ACCEPT verdicts in git |
| 6 | `consolidator.md` | Verifier A+B verdict consolidation with self-review | opus | Read, Bash, WebSearch, WebFetch, Glob, Grep | **USED** — source engine Phase C/D/E evaluation |
| 7 | `deep-researcher.md` | 8+ web searches per SPEC defect, Arabic-specific | opus | Bash, WebSearch, WebFetch, Read, Grep, Glob | **USED** — SPEC audits, technology surveys |
| 8 | `evaluation-prep.md` | Pre-flight checks for Phase C/D/E runs | sonnet | Read, Bash, Glob, Grep | **NEW (Session 2)** — never tested |
| 9 | `integrity-auditor.md` | SPEC integrity checklist (MUST-FIX / SHOULD-FIX) | opus | Read, Grep, Glob, Bash | **USED** — dispatched during SPEC finalization |
| 10 | `library-integrity-checker.md` | Library data referential integrity | sonnet | Bash, Read, Glob, Grep | **UNTESTED** — no library population yet |
| 11 | `quick-check.md` | Fast smoke-check (type errors, test pass, Arabic) | haiku | Read, Bash, Grep, Glob | **NEW (Session 2)** — never tested |
| 12 | `regression-detector.md` | Test regression detection between git refs | haiku | Read, Bash, Glob, Grep | **NEW (Session 2)** — never tested |
| 13 | `spec-adversary.md` | Adversarial test case generation from SPEC | opus | Read, Grep, Glob, Bash | **USED** — excerpting adversarial catalog |
| 14 | `spec-auditor-a.md` | Silent failure patterns 1-4 audit | opus | Read, Grep, Glob, Bash | **USED** — multiple SPEC audits |
| 15 | `spec-auditor-b.md` | Silent failure patterns 5-7 + T1-T7 audit | opus | Read, Grep, Glob, Bash | **USED** — multiple SPEC audits |
| 16 | `spec-writer.md` | Writes/refines SPEC sections with precision | opus | Read, Grep, Glob, Bash, WebSearch | **USED** — SPEC writing throughout |
| 17 | `test-engineer.md` | KR test specialist, pytest from SPEC rules | sonnet | Read, Write, Edit, Bash, Glob, Grep | **USED** — dispatched for test suite writing |
| 18 | `triage-analyst.md` | Pre-verification risk tier assignment (EUR 0 cost) | sonnet | Read, Bash, Glob, Grep | **USED** — source engine Phase C triage |
| 19 | `verdict-adversary.md` | Re-probes VERIFIED items to disprove them | opus | Read, Bash, WebSearch, WebFetch, Grep, Glob | **USED** — source engine evaluation |
| 20 | `verifier-a.md` | Playbook-guided verification | opus | Read, Bash, WebSearch, WebFetch, Grep, Glob | **USED** — source engine Phase C/D/E |
| 21 | `verifier-b.md` | First-principles verification (NO Playbook) | opus | Read, Bash, WebSearch, WebFetch, Grep, Glob | **USED** — source engine Phase C/D/E |

**Archived (3):**
| File | Description | Why Archived |
|------|-------------|-------------|
| `researcher.md` | General research agent | Superseded by deep-researcher |
| `result-analyst.md` | Test result aggregation | Source engine specific, may revive |
| `scholarly-verifier.md` | Scholarly claim verification | Folded into verifier-a/b |

**Usage summary:** 12 of 21 active agents have been used in real sessions. 5 are new from Session 2 (never tested). 4 are designed for future phases (library, boundary, audit-comparator, evaluation-prep).

---

## 3. .claude/commands/ — 24 commands

| # | Command | Description | Tested? |
|---|---------|-------------|---------|
| 1 | `/arabic-audit` | Arabic text safety audit on changed files | **NEW (S2)** — untested |
| 2 | `/build-fix` | Iterative error resolution (max 3 cycles) | **USED** — during build sessions |
| 3 | `/catchup` | Reload WIP context after /clear or session start | **USED** — regularly used |
| 4 | `/challenge` | Three Challenges against current work | **USED** — used in reviews |
| 5 | `/check-spec` | SPEC consistency review | **USED** |
| 6 | `/commit` | Review changes + conventional commits | **USED** — regularly |
| 7 | `/cost-report` | API cost breakdown by model/phase/date | **NEW (S2)** — untested |
| 8 | `/design-review` | Structured design review | **USED** |
| 9 | `/eval-dashboard` | Evaluation phase dashboard | **NEW (S2)** — untested |
| 10 | `/harness-audit` | .claude/ config internal consistency check | **USED** — config drift detection |
| 11 | `/orchestrate` | Chain agents with structured handoffs | **USED** — post-build, verify chains |
| 12 | `/phase-status` | Current phase progress dashboard | **USED** — during source engine eval |
| 13 | `/quality-gate` | Comprehensive engine quality check | **USED** |
| 14 | `/read-vision` | Extract VISION.md sections without full read | **USED** |
| 15 | `/regression-check` | Test comparison between git refs | **NEW (S2)** — untested |
| 16 | `/research` | Deep research with web + Context7 + Tavily | **USED** |
| 17 | `/session-report` | Plan vs deliverables comparison | **USED** |
| 18 | `/smart-compact` | Context-preserving compaction | **USED** — regularly |
| 19 | `/tdd` | Test-driven development cycle for SPEC rule | **USED** |
| 20 | `/trace-pipeline` | Data consistency trace through pipeline | **USED** |
| 21 | `/ui-test` | E2E UI tests — **DORMANT until UI phase** | **DORMANT** |
| 22 | `/verify-boundaries` | Pipeline boundary data flow validation | **USED** |

**Usage summary:** 15 of 24 commands have been used. 4 are new from Session 2. 1 is dormant (UI). 4 have no description frontmatter (challenge, check-spec, design-review, read-vision) — they still work but lack metadata.

---

## 4. .claude/rules/ — 16 rules

| # | File | Topic | Active? |
|---|------|-------|---------|
| 1 | `arabic-scholarly-conventions.md` | Bismillah, colophon, honorifics, transmission, madhab signals | **ACTIVE** — loaded every session |
| 2 | `commit-format.md` | Conventional commit format for KR | **ACTIVE** |
| 3 | `context-management.md` | MCP limits, /smart-compact at 60%, subagent context | **ACTIVE** |
| 4 | `e2e-testing.md` | Playwright, RTL, accessibility | **DORMANT** — UI phase only |
| 5 | `frontend-development.md` | TypeScript, React, Arabic RTL display | **DORMANT** — UI phase only |
| 6 | `input-sanitization.md` | External text validation, invisible Unicode | **ACTIVE** |
| 7 | `llm-call-optimization.md` | Temperature, Arabic prompting, token mgmt, caching, cost | **ACTIVE** — critical for current work |
| 8 | `python-code.md` | Type hints, Pydantic, Arabic string safety, function limits | **ACTIVE** |
| 9 | `quality-workflow.md` | Pyright → pytest → code-reviewer → pre-merge checklist | **ACTIVE** |
| 10 | `regex-arabic-digits.md` | \d matches Arabic-Indic digits — use [0-9] | **ACTIVE** |
| 11 | `result-preservation.md` | Every API call persists, COST_LOG.json, manifests | **ACTIVE** |
| 12 | `session-discipline.md` | One engine/session, re-read after compaction | **ACTIVE** |
| 13 | `shared-concept-changes.md` | Grep ALL consumers when modifying shared concepts | **ACTIVE** |
| 14 | `spec-writing.md` | Arabic examples, VISION cross-refs, open questions | **ACTIVE** |
| 15 | `testing.md` | Real Arabic fixtures, SPEC-driven tests, coverage targets | **ACTIVE** |

**Note:** Rules are auto-loaded into every conversation via CLAUDE.md reference. 13 are actively enforced, 2 are dormant (waiting for UI phase).

---

## 5. .claude/hooks/ — 14 hook scripts

### PreToolUse hooks (7 matchers)

| Matcher | Hook Script | What It Does | Working? |
|---------|-------------|-------------|----------|
| `Write\|Edit\|MultiEdit` | `config-protection.sh` | Blocks edits to `.claude/settings.json`, `.env`, and critical config files | **WORKING** — tested during Session 1 |
| `Bash` | inline jq command | Blocks `rm -rf /`, force-push to main, `--no-verify` bypass | **WORKING** — passive safety net |
| `Bash(git push*)` | inline pytest command | Runs full test suite before any push — blocks on failure | **WORKING** — tested on push attempts |
| `Bash(git commit*)` | `pre-commit-check.sh` | Pre-commit validation (ruff, print() detection, Arabic safety) | **WORKING** — fires on every commit |
| `Bash` | `circuit-breaker.sh` | Detects repeated failures, blocks after threshold | **WORKING** — state tracked in session_state.json |
| `Bash` | `cost-guard.sh` | Checks KR_BUDGET_LIMIT before API calls | **WORKING** — budget enforcement |
| `AskUserQuestion` | `no-ask-human.sh` | Blocks AskUserQuestion when running autonomously | **WORKING** — critical for overnight runs |

### PostToolUse hooks (8 matchers)

| Matcher | Hook Script | What It Does | Working? |
|---------|-------------|-------------|----------|
| `Write\|Edit\|MultiEdit` | `ruff-format.sh` | Auto-format Python files with ruff | **WORKING** |
| `Write\|Edit\|MultiEdit` | inline SPEC/code check | Reminds about SPEC quality check and D-023 | **WORKING** — advisory only |
| `Write\|Edit\|MultiEdit` | `arabic-safety-check.sh` | Detects Arabic text processing antipatterns (.lower(), \d in Arabic context) | **WORKING** — 5613 bytes of patterns |
| `Write\|Edit\|MultiEdit` | inline auto-stage | Auto-stages modified files to git + writes changes.log | **UNKNOWN** — changes.log not found (may be gitignored or never fired) |
| `Write\|Edit\|MultiEdit` | `pyright-check.sh` | Type-checks modified Python files | **WORKING** |
| `Write\|Edit\|MultiEdit` | `auto-test.sh` | Runs engine tests on modified Python files | **WORKING** |
| `Write\|Edit\|MultiEdit` | `boundary-check.sh` | Validates pipeline contract boundaries after contracts.py changes | **WORKING** |
| `Write\|Edit\|MultiEdit` | `diacritic-preservation.sh` | Checks Arabic diacritic byte preservation | **WORKING** — Session 1 addition |
| `Write\|Edit\|MultiEdit` | `spec-coverage-check.sh` | Checks SPEC coverage after test changes | **WORKING** |

### SessionStart hooks (2)

| Matcher | What It Does | Working? |
|---------|-------------|----------|
| `compact` | Post-compaction recovery: NEXT.md + active engine + invariants + budget | **WORKING** |
| `startup\|resume` | Session start: git status, recent commits, NEXT.md head, budget | **WORKING** — fires at start of this session |

### Stop hooks (1)

| What It Does | Working? |
|-------------|----------|
| Runs `scripts/session_stop.py` — saves session state | **WORKING** — writes session_state.json |

### User-level hooks (GSD plugin)

| Event | Hook | Working? |
|-------|------|----------|
| `SessionStart` | `gsd-check-update.js` | **WORKING** — GSD update checker |
| `PostToolUse` | `gsd-context-monitor.js` | **WORKING** — GSD context tracking |

**Summary:** 14 project hooks + 2 user-level hooks. All appear functional except the auto-stage hook (changes.log artifact missing — may just be gitignored).

---

## 6. .claude/skills/ — 14 skill directories

| # | Skill | SKILL.md Size | Topic | Used? |
|---|-------|--------------|-------|-------|
| 1 | `arabic-text/` | 5,687 bytes | Arabic text processing rules, encoding, diacritics | **ACTIVE** — referenced in rules, used by hooks |
| 2 | `arabic-text-quality/` | 8,472 bytes | OCR corruption, encoding artifacts, diacritic quality grading | **NEW (S1)** — referenced but not directly invoked |
| 3 | `codex-verify/` | 1,369 bytes | D-041 multi-model verification via Codex MCP | **UNTESTED** — Codex MCP not configured |
| 4 | `consensus-pattern/` | 6,713 bytes | D-041 LiteLLM + Instructor implementation pattern | **USED** — guided Phase 2/3 implementation |
| 5 | `domain-glossary/` | 20,365 bytes | Islamic scholarly terminology → KR data models | **USED** — reference during SPEC writing |
| 6 | `evaluation-methodology/` | 10,816 bytes | Phase C/D/E evaluation protocol with errata | **USED** — source engine evaluation |
| 7 | `islamic-sciences-classification/` | 18,021 bytes | How each Islamic science structures texts | **NEW (S1)** — not yet directly invoked in sessions |
| 8 | `knowledge-safety/` | 6,477 bytes | 7-threat model audit for knowledge integrity | **NEW (S1)** — loaded but not directly invoked |
| 9 | `quranic-text-handling/` | 17,368 bytes | Quran detection, preservation, cross-referencing | **NEW (S1)** — loaded but not directly invoked |
| 10 | `scholarly-attribution/` | 10,466 bytes | Author identification, disambiguation, verification | **NEW (S1)** — loaded but not directly invoked |
| 11 | `scholarly-design/` | 6,364 bytes | Challenge KR design for scholarly value | **USED** — design reviews |
| 12 | `spec-examples/` | 3,992 bytes | Generate concrete Arabic input/output examples | **USED** — SPEC writing |
| 13 | `technology-survey/` | 4,081 bytes | Survey tools/libraries before custom code | **USED** — multiple surveys |

**Note:** Skills 7-10 were added in Session 1 environment overhaul. They encode deep domain knowledge (Islamic sciences classification, Quranic text handling, scholarly attribution) but have not been directly invoked in a build session yet. They will be most relevant during the excerpting LLM evaluation (Phase C) when the agent needs to evaluate attribution accuracy and Quranic citation correctness.

---

## 7. MCP Servers — 3 configured

| Server | Command | Purpose | Working? |
|--------|---------|---------|----------|
| `context7` | `npx -y @upstash/context7-mcp@latest` | Library documentation lookup (Pydantic, Instructor, etc.) | **WORKING** — used in research |
| `tavily` | `npx -y tavily-mcp@latest` | Web search, extraction, research | **WORKING** — used in evaluation |
| `memory` | `npx -y @modelcontextprotocol/server-memory` | Persistent knowledge graph (kr-engine.jsonl) | **WORKING** — cross-session state |

**Plugin MCP servers** (from user-level plugins): `serena` (code intelligence), `context7` (duplicate of project-level), `tavily` (duplicate).

---

## 8. Scheduled Tasks

**None configured.** No cron, triggers, or remote agents set up.

There is a `scripts/session_stop.py` that fires on the `Stop` hook event to save session state, but it's reactive (not scheduled).

---

## 9. Environment

| Component | Version |
|-----------|---------|
| **Python** | 3.13.12 |
| **Node.js** | 24.14.0 |
| **Claude Code** | 2.1.84 |
| **OS** | Windows 11 Home 10.0.26200 (MINGW64/Git Bash) |
| **Model** | Opus 4.6 (1M context) |
| **instructor** | 1.14.5 |
| **openai** (SDK) | 2.26.0 |
| **pydantic** | 2.12.5 |
| **litellm** | 1.82.0 |
| **pytest** | 8.4.2 |
| **pyright** | 1.1.408 |
| **ruff** | 0.15.7 |
| **black** | 26.3.0 |

**API Keys (presence only, not values):**
- `OPENROUTER_API_KEY` — required for LLM calls (checked by run_integration_test.py)
- `TAVILY_API_KEY` — required for Tavily MCP
- `KR_BUDGET_LIMIT` — optional, defaults to 100 EUR

---

## 10. What Works Well

**Proven in real sessions (with git evidence):**

1. **Code reviewer agent (opus)** — The most valuable agent. 10+ review dispatches with clear BLOCKED/ACCEPT verdicts. Multi-pass review catches real bugs (e.g., F-4: attribution majority not applied).

2. **Dual-auditor SPEC review** — `spec-auditor-a` + `spec-auditor-b` in parallel produce comprehensive defect inventories. Different silent failure pattern focus means genuine independence.

3. **Pre-commit hook chain** — `pre-commit-check.sh` + `ruff-format.sh` + `pyright-check.sh` + `arabic-safety-check.sh` catches issues before they reach git. The Arabic safety hook is particularly valuable — 5.6KB of patterns.

4. **Session lifecycle hooks** — `startup` hook prints context immediately. `compact` hook restores critical invariants. `Stop` hook saves state. Together they make session transitions smooth.

5. **Cost guard + budget tracking** — `cost-guard.sh` hook + `COST_LOG.json` + budget in `session_state.json`. Source engine evaluation stayed within budget (EUR 36.70/100).

6. **Verifier A/B pattern** — Playbook-guided (A) vs first-principles (B) verification genuinely catches different errors. The consolidator resolves disagreements. Proven across source engine Phases C/D/E.

7. **`/catchup` command** — Essential for session recovery. Reads git state + NEXT.md + session_state.json in one pass.

8. **`/smart-compact` command** — Preserves critical context (SPEC rules, Arabic constraints, D-023) during compaction. Better than bare `/compact`.

---

## 11. What's Broken or Unused

### Known Issues

1. **Auto-stage hook** — The PostToolUse hook that auto-stages files and writes `changes.log` produces no `changes.log` file. Either it silently fails (Windows path issue?), the log is gitignored, or it never fires. **LOW RISK** — manual staging works fine.

2. **codex-verify skill** — References Codex MCP which is NOT configured as an MCP server. Cannot function without it. **DEAD CODE** until Codex MCP is set up.

3. **4 commands missing description frontmatter** — `/challenge`, `/check-spec`, `/design-review`, `/read-vision` work but have no `description:` line, which means they won't appear properly in tool inventories.

### Never Tested (Session 2 additions)

4. **arabic-reviewer agent** (sonnet) — Defined but never dispatched. No git evidence of use.
5. **evaluation-prep agent** (sonnet) — Defined but never dispatched.
6. **quick-check agent** (haiku) — Defined but never dispatched.
7. **regression-detector agent** (haiku) — Defined but never dispatched.
8. **`/arabic-audit` command** — Defined but never run.
9. **`/cost-report` command** — Defined but never run.
10. **`/eval-dashboard` command** — Defined but never run.
11. **`/regression-check` command** — Defined but never run.

### Designed for Future Phases

12. **boundary-validator agent** — For post-engine-build boundary checks. Will be relevant when building taxonomy engine.
13. **library-integrity-checker agent** — For library population phase. No library data yet.
14. **audit-comparator agent** — For dual-audit consolidation. Has been superseded by the consolidator for evaluation work; may be relevant for future SPEC audits.
15. **`/ui-test` command** — Explicitly dormant until UI phase.
16. **e2e-testing.md rule** — Dormant until UI phase.
17. **frontend-development.md rule** — Dormant until UI phase.

### Domain Skills (Loaded but Not Invoked)

18. **islamic-sciences-classification skill** (18KB) — Loaded but never directly invoked in a build session. Will be critical during excerpting evaluation.
19. **knowledge-safety skill** (6.5KB) — Loaded but never directly invoked. Should be used during LLM output review.
20. **quranic-text-handling skill** (17KB) — Loaded but never directly invoked. Relevant when processing hadith-heavy and tafsir texts.
21. **scholarly-attribution skill** (10.5KB) — Loaded but never directly invoked. Critical for evaluating author attribution in excerpting output.

### Plugin Overlap Concern

22. **21 user-level plugins** is aggressive. Several overlap (context7 project-level + plugin, tavily project-level + plugin). The `context-management.md` rule says "keep MCP servers <= 5" but plugins may add more behind the scenes. Potential context waste.

---

## 12. Summary Statistics

| Category | Count | Tested | Untested/New | Dormant |
|----------|-------|--------|-------------|---------|
| **Agents** | 21 active + 3 archived | 12 | 5 (Session 2) | 4 (future) |
| **Commands** | 24 | 15 | 4 (Session 2) | 1 (UI) |
| **Hooks** | 14 project + 2 user | 13 | 1 (auto-stage?) | 0 |
| **Skills** | 14 | 7 | 4 (Session 1 domain) | 1 (codex-verify) |
| **Rules** | 16 | 13 | 0 | 2 (UI) |
| **MCP Servers** | 3 project + plugins | 3 | 0 | 0 |

**Total configuration surface:** 21 agents, 24 commands, 16 hooks, 14 skills, 16 rules, 3 MCP servers = **94 configuration items.**

**Tested in real sessions:** ~63 items (67%)
**Untested/new:** ~18 items (19%)
**Dormant/future:** ~13 items (14%)
