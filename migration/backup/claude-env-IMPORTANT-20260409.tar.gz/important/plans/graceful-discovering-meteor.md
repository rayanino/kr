# Phase 3 Deterministic Metadata Assembly — Implementation Plan

## Context

Session 3 implements the 10 deterministic functions in `phase3_deterministic.py` (SPEC §7.1, §6.2). These compute ExcerptRecord fields from data alone — no LLM. Phase 2 output (ClassifiedSegments + TeachingUnits) feeds in; partial ExcerptRecords come out. Session 4 fills the LLM-enriched fields.

**Baseline:** 147 tests passing, 2 skipped. Target: ≥177 tests, 0 failed.

---

## Critical Decision: PARTIAL Self-Containment

**Problem:** ExcerptRecord has a `model_validator` (contracts.py:534-566) enforcing I-ER-4 at construction time. For PARTIAL units, it requires `context_hint != None` UNLESS `"llm_enrichment_failed"` is in `review_flags`. NEXT.md says to set `context_hint=None, review_flags=[]` — this will raise `ValueError` for any PARTIAL TeachingUnit.

**Resolution (user-approved):** Set `review_flags=["llm_enrichment_failed"]` for both PARTIAL and DEPENDENT units. FULL units get `review_flags=[]`.

- **PARTIAL:** Flag is required by the model_validator (I-ER-4 rejects context_hint=None without it)
- **DEPENDENT:** Flag is NOT required by validator (DEPENDENT check doesn't inspect review_flags), but set for semantic consistency — LLM enrichment hasn't run yet for any non-FULL unit
- **FULL:** No flag needed, validator passes with context_hint=None + review_flags=[]
- Session 4 will: on LLM success → set context_hint, remove flag. On failure → keep flag (correct state)
- Document as L-XXX in KNOWN_LIMITATIONS.md

---

## Step 0: Fix contracts.py Docstring (line 461-464)

**File:** `engines/excerpting/contracts.py`

The `primary_text` field description says `' '.join(assembled_text.split()[start_word:end_word+1])` — the split-and-rejoin approach. SPEC §7.1 F-DET-2 explicitly requires substring extraction to preserve `\n\n` paragraph breaks.

Change to: `"Extracted from assembled_text via character-offset substring (F-DET-2). Preserves internal whitespace including paragraph breaks."`

This qualifies as a documentation bug per NEXT.md line 33.

---

## Step 1: Rewrite Stub Signatures + Imports

**File:** `engines/excerpting/src/phase3_deterministic.py`

The existing stubs have significantly wrong signatures. 7 of 10 functions need signature changes:

| # | Function | Key Change |
|---|----------|------------|
| 3 | `compute_layer_attribution` | Replace `layer_map, layer_split_points` → `assembly_metadata: AssemblyMetadata` |
| 4 | `compute_content_types` | Replace `list[tuple]` → `segments: list[ClassifiedSegment], unit_segment_indices: list[int]` |
| 5 | **Rename** `detect_quran_verses → detect_evidence_refs` | Return `list[EvidenceRef]` not `bool` |
| 6 | `compute_page_range` | Replace `start_word, end_word` → `join_points, char_start, char_end` |
| 8 | `filter_relevant_footnotes` | Add `assembled_text, char_start, char_end` params |
| 9 | **Rename** `compute_segment_indices → compute_quoted_scholars` | Completely different function |
| 10 | `build_deterministic_excerpts` | Replace `chunks, grouped, classified, manifest, config` → `chunk, units, segments` |

**Import changes:**
- **Add:** `EvidenceRef`, `ScholarAttribution`, `AssemblyMetadata`, `ClassifiedSegment` from contracts; `Footnote`, `LayerType`, `PhysicalPage` from normalization contracts; `_build_token_char_map` from `phase2_classify`
- **Remove:** `ExcerptingConfig`, `NormalizedManifest`, `LayerMapEntry` (unused in new signatures)

---

## Step 2: Shared Helpers

### 2a: `_word_to_char_range(assembled_text, start_word, end_word) → tuple[int, int]`

Wraps `_build_token_char_map` from phase2_classify.py (lines 105-123). Returns `(char_start, char_end)` with **exclusive end** — `assembled_text[char_start:char_end]` gives the substring.

Critical: `_build_token_char_map` returns spans with exclusive ends. So `char_start = spans[start_word][0]`, `char_end = spans[end_word][1]`. Do NOT add +1.

Used by: F2, F3, F6 (indirectly via orchestrator), F8 (indirectly), F10.

### 2b: `_compute_layer_coverages(text_layers, char_start, char_end, layer_split_points) → list[tuple[TextLayerSegment, float]]`

Shared by Function 3 and Function 9. Does two things:
1. **Merge layers at split points (DD-S3-7):** Consecutive segments with identical `(layer_type, author_canonical_id)` where `first.end in set(layer_split_points)` → merge into one virtual segment. Handle chains (A-B-C all mergeable).
2. **Compute overlap:** `overlap = max(0, min(layer_end, char_end) - max(layer_start, char_start))`, coverage = `overlap / (char_end - char_start)`. Return only segments with coverage > 0.

### 2c: `_LAYER_LEVEL` constant

```python
_LAYER_LEVEL: dict[LayerType, int] = {
    LayerType.UNCERTAIN: 0,
    LayerType.MATN: 1,
    LayerType.SHARH: 2,
    LayerType.HASHIYAH: 3,
    LayerType.TAHQIQ_NOTE: 4,
}
```

Ordering per NEXT.md: `TAHQIQ_NOTE > HASHIYAH > SHARH > MATN > UNCERTAIN`. Used by F3 for LA-2 (outermost wins).

---

## Step 3: Functions 1-10

### F1: `compute_excerpt_id` — trivial
`return f"exc_{source_id}_{div_id}_{chunk_index}_{unit_index}"`

### F2: `extract_primary_text` — substring extraction
```
char_start, char_end = _word_to_char_range(assembled_text, start_word, end_word)
return assembled_text[char_start:char_end]
```
Preserves `\n\n` paragraph breaks. NOT split-and-rejoin.

### F3: `compute_layer_attribution` — most complex function
1. Convert words → chars via `_word_to_char_range`
2. Call `_compute_layer_coverages` (includes split-point merging)
3. Apply rules **in order** (LA-4 → LA-1 → LA-2 → LA-3):
   - **LA-4:** Any layer 100% → that layer
   - **LA-1:** Any layer ≥80% → that layer
   - **LA-2:** Exactly 2 layers, neither ≥80% → outermost (max `_LAYER_LEVEL`)
   - **LA-3:** 3+ layers, none ≥80% → log EX-M-001, use highest-coverage layer
4. Return `AuthorAttribution(layer_id=layer.layer_type.value, author_id=layer.author_canonical_id or "unknown", coverage_pct=coverage, rule_applied="LA-N")`

**Important ordering note:** LA-2 catches ALL 2-layer cases (regardless of dominant coverage). LA-3 only fires for 3+ layers. The "dominant <60%" condition in LA-3 is from the SPEC but is redundant given NEXT.md's ordering — by the time we reach LA-3, we already know it's 3+ layers.

### F4: `compute_content_types` — deduplication
Filter `segments` by `unit_segment_indices`, collect unique `scholarly_function` values. Return as `list[ScholarlyFunction]`.

### F5: `detect_evidence_refs` — pattern matching (DD-S3-8: NO word boundaries)
Three evidence types, ALL using **plain `str.find()` substring matching**:

| Type | Markers | Return fields |
|------|---------|---------------|
| Quran (EV-1) | `﴿...﴾` regex (U+FD3F...U+FD3E), strip delimiters from snippet | `type="quran", text_snippet=<between delimiters, stripped>` |
| Hadith (EV-2) | `رواه`, `أخرجه`, `في الصحيحين`, `متفق عليه`, `في صحيح`, `في سنن` | `type="hadith", text_snippet=<50 chars around>, marker_text=<pattern>` |
| Ijma (EV-3) | `أجمعوا`, `إجماع`, `لا خلاف`, `اتفق العلماء`, `بالاتفاق` | `type="ijma", text_snippet=<50 chars around>, marker_text=<pattern>` |

Snippet clamping: `primary_text[max(0, pos-25):min(len(primary_text), pos+len(marker)+25)]`

Dedup by `(position, marker)` — same marker at different positions = separate refs.

### F6: `compute_page_range` — join point navigation
1. If `not physical_pages`: return `None`
2. **Single-page fast path (96.8% of cases):** If `not join_points`, all units overlap the single page. Extract `page_number_int` from `physical_pages[0]`. If None → return `None`. Else return `PageRange(volume=physical_pages[0].volume, start_page=page_number_int, end_page=page_number_int)`.
3. **Multi-page path:** Build page char ranges from `join_points` (N pages → N-1 join points):
   - Page 0: `[0, join_points[0].char_offset_in_assembled)`
   - Page i: `[join_points[i-1].char_offset, join_points[i].char_offset)`
   - Page N-1: `[join_points[-1].char_offset, ∞)`
4. Find pages overlapping `[char_start, char_end)`
5. Collect `page_number_int` (skip None). If all None → return `None`
6. Return `PageRange(volume=first_page.volume, start_page=min, end_page=max)`

### F7: `compute_word_offsets` — trivial passthrough
`return (start_word, end_word)`

### F8: `filter_relevant_footnotes` — marker search
For each footnote: search `assembled_text` for `⌜{ref_marker}⌝` (U+231C, U+231D). If found within `[char_start, char_end)` → include. If not found anywhere → log warning (orphan).

### F9: `compute_quoted_scholars` — non-primary layers
1. Call `_compute_layer_coverages` (same merging as F3)
2. Filter layers with coverage > 0 that are NOT the primary layer (`layer.layer_type.value != primary_layer.layer_id`)
3. Role: MATN in a non-MATN primary unit → `"classification_frame"`. Otherwise → `"quoted_opinion"`
4. Return `ScholarAttribution(mention_text="[structural: {layer_type}]", resolved_name=author_canonical_id, role=role, confidence=1.0, source="layer_overlap")`

### F10: `build_deterministic_excerpts(chunk, units, segments)` — orchestrator
Per-chunk function (caller iterates over chunks). For each TeachingUnit:
1. Compute `chunk_index` from `chunk.split_info.chunk_index` (or 0)
2. Compute `char_start, char_end` via `_word_to_char_range`
3. Call F1-F9 with appropriate args
4. Compute review_flags based on self-containment level:
   ```python
   review_flags: list[str] = []
   if unit.self_containment in (SelfContainmentLevel.PARTIAL, SelfContainmentLevel.DEPENDENT):
       review_flags = ["llm_enrichment_failed"]
   ```
5. Construct `ExcerptRecord` with all 33 fields:

**Deterministic (F1-F9):** excerpt_id, primary_text, primary_author_layer, content_types, evidence_refs, physical_pages, start_word/end_word, footnotes_relevant, quoted_scholars

**Chunk passthrough:** source_id, div_id, div_path

**Unit passthrough (8 fields):** unit_index, segment_indices, text_snippet, primary_function, secondary_functions, description_arabic, self_containment, self_containment_notes

**Computed:** chunk_index

**LLM defaults (10 fields):** excerpt_topic=[], school=None (DD-S3-1 explicit), school_confidence=None, attribution_confidence=None (DD-S3-6), takhrij_data=None, terminology_variants=[], cross_references=[], context_hint=None, consensus_metadata=None

**Flags:** gate_flags=[], review_flags (FULL→[], PARTIAL/DEPENDENT→["llm_enrichment_failed"])

---

## Step 4: Conftest Additions

**File:** `engines/excerpting/tests/conftest.py`

### `_make_multi_layer_chunk(**overrides) → AssembledChunk`
MATN + SHARH layers with real Arabic text. ~20 words, MATN covering first ~40%, SHARH covering ~60%. Both layers have `author_canonical_id` set. Used by F3/F9 attribution tests.

### `_make_chunk_with_footnotes(**overrides) → AssembledChunk`
Arabic text with embedded `⌜1⌝` and `⌜2⌝` markers at known positions. Two `Footnote` objects with matching `ref_marker`. Used by F8 footnote filtering tests.

---

## Step 5: Tests (≥30)

**File:** `engines/excerpting/tests/test_phase3_deterministic.py` (NEW)

| Category | Tests | Key assertions |
|----------|-------|----------------|
| **F-DET-1** excerpt_id | 3 | Format string, split chunk (index>0), unsplit (index=0) |
| **F-DET-2** primary_text | 3 | `\n\n` preserved (critical), single-word, full-range |
| **F-DET-3** attribution | 6 | LA-4 (100%), LA-1 (≥80%), LA-2 (2 layers outermost wins), LA-2 (2 layers even with dominant<60% — NOT LA-3), LA-3 (3 layers + EX-M-001), split-point merging |
| **F-DET-4** content_types | 3 | Single, dedup, multiple |
| **F-DET-5** evidence | 5 | Quran ﴿﴾, hadith marker, ijma marker, prefixed forms (الإجماع/وأخرجه/فرواه), snippet clamping |
| **F-DET-6** page_range | 3 | Single page (no join_points), multi-page span, empty→None |
| **F-DET-7** word_offsets | 1 | Passthrough returns (start_word, end_word) unchanged |
| **F-DET-8** footnotes | 3 | Relevant included, irrelevant excluded, orphan warning (caplog) |
| **F-DET-9** quoted_scholars | 3 | Non-primary detected, primary excluded, role computation |
| **Orchestrator** | 5 | Happy path, multi-unit, school=None explicit, PARTIAL→review_flag set, passthrough fields correct |
| **Total** | **≥35** | |

---

## Verification Checklist

| # | Check | Command | Expected |
|---|-------|---------|----------|
| 1 | No stubs remain | `grep -r "raise NotImplementedError" engines/excerpting/src/phase3_deterministic.py` | Empty |
| 2 | Phase 3 tests pass | `python -m pytest engines/excerpting/tests/test_phase3_deterministic.py -v --tb=short` | ≥30 passed |
| 3 | All tests pass | `python -m pytest engines/excerpting/tests/ -v --tb=short` | ≥177 passed, 0 failed |
| 4 | Type check | `python -m pyright engines/excerpting/src/phase3_deterministic.py` | 0 errors |
| 5 | Test count | `grep -c "def test_" engines/excerpting/tests/test_phase3_deterministic.py` | ≥30 |
| 6 | LA rules covered | `grep -c "LA-" engines/excerpting/tests/test_phase3_deterministic.py` | ≥4 |
| 7 | No LLM imports | `grep -r "import anthropic" engines/excerpting/src/` | Empty |
| 8 | `\n\n` test exists | Verify test_primary_text_preserves_paragraph_breaks passes | Pass |
| 9 | DD-S3-8 compliance | Prefixed form tests pass (الإجماع, وأخرجه, فرواه) | All detected |

---

## Files Modified

| File | Action |
|------|--------|
| `engines/excerpting/src/phase3_deterministic.py` | Rewrite: new signatures, 2 helpers, 10 function implementations |
| `engines/excerpting/contracts.py` | Fix: docstring line 461-464 |
| `engines/excerpting/tests/conftest.py` | Add: 2 factory helpers |
| `engines/excerpting/tests/test_phase3_deterministic.py` | Create: ≥35 tests |
| `reference/SPEC_ERRATA.md` | Add: SPEC-NOTE-8 (F-DET-5 word boundaries → substring), SPEC-NOTE-9 (F-DET-9 author_name_arabic → author_canonical_id) |

## Key Reuse

| What | Where | Why |
|------|-------|-----|
| `_build_token_char_map` | `phase2_classify.py:105-123` | Word→char conversion (DD-S3-2: do NOT duplicate) |
| `_make_assembled_chunk` | `conftest.py:61` | Base factory for chunk construction |
| `_make_teaching_unit` | `conftest.py:119` | Base factory for unit construction |
| `_make_classified_segment` | `conftest.py:105` | Base factory for segment construction |
| `ExcerptingErrorCodes.EX_M_001` | `contracts.py:700` | The ONLY error code emitted by F3 (LA-3) |
