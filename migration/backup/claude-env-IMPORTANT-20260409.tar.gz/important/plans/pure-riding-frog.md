# Audit: Silent Usage Waste in Claude Code Setup

## Finding 1: Dormant Rules Still Loading (~850 tokens/turn) — DEFINITE WASTE

**What:** Claude Code loads rules from ALL subdirectories of `.claude/rules/`, including `dormant/`.
Four files you moved to `dormant/` to deactivate are still injected into every conversation.

| File | Words | Issue |
|------|-------|-------|
| `dormant/e2e-testing.md` | 139 | No E2E/frontend work happening |
| `dormant/frontend-development.md` | 180 | No frontend work happening |
| `dormant/result-preservation.md` | 89 | Content already in `llm-call-optimization.md` |
| `dormant/session-discipline.md` | 209 | Content already in `context-management.md` |

**Evidence:** All four appear in the system-reminder at conversation start (visible in this session's
initial context). The last two are semantic duplicates — e.g., both `session-discipline.md` and
`context-management.md` contain "One engine per session" (grep confirmed).

**Fix:** Move the four files to `reference/dormant-rules/` (outside `.claude/rules/` entirely).
Claude Code only scans `.claude/rules/**/*.md`.

---

## Finding 2: Triple Context7 MCP (~260 tokens/turn) — DEFINITE WASTE

**What:** Three independent Context7 instances all providing identical functionality:

| Instance | Source | Tools | Can Remove? |
|----------|--------|-------|-------------|
| `claude.ai Context7` | Platform built-in | query-docs, resolve-library-id | No (platform) |
| `context7` | `.mcp.json` local | query-docs, resolve-library-id | **Yes** |
| `plugin:context7:context7` | Plugin | query-docs, resolve-library-id | **Yes** |

All three inject the IDENTICAL instruction block into the system prompt ("Use this server to fetch
current documentation whenever the user asks about a library..."). That instruction appears THREE
times in your system-reminder. Two copies are pure waste.

Each instance also adds 2 tools to the deferred tools list = 4 duplicate tool entries.

**Fix:** Remove `context7` entry from `.mcp.json`. For the plugin instance, check if it comes from
`oberskills@rtd` or another plugin and disable that Context7 component.

---

## Finding 3: Double Tavily MCP (~100 tokens/turn) — DEFINITE WASTE

**What:** Two Tavily instances providing identical 5 tools each:

| Instance | Source | Can Remove? |
|----------|--------|-------------|
| `claude.ai tavily` | Platform built-in | No |
| `tavily` | `.mcp.json` local | **Yes** |

The local one was likely added before the platform version became available. The platform Tavily
(`claude.ai tavily`) is listed in `claudeAiMcpEverConnected` — confirmed working.

**Fix:** Remove `tavily` entry from `.mcp.json`. The platform version handles everything.

Note: The local config has `TAVILY_API_KEY` env var. The platform version uses Anthropic's
built-in Tavily integration (no API key needed). Same functionality, zero config.

---

## Finding 4: Memory MCP — Never Used (9 tools → ~120 tokens/turn) — DEFINITE WASTE

**What:** The `.mcp.json` defines a `memory` MCP (knowledge graph) targeting
`~/.claude-memory/kr-engine.jsonl`. **That file does not exist. The directory does not exist.**

The MCP was configured but has literally never been used. Meanwhile, KR uses a completely
separate file-based memory system at `~/.claude/projects/*/memory/`.

9 deferred tools (add_observations, create_entities, create_relations, delete_entities,
delete_observations, delete_relations, open_nodes, read_graph, search_nodes) load every
session for zero benefit.

**Fix:** Remove `memory` entry from `.mcp.json`.

---

## Finding 5: Serena Plugin — NEEDS CONFIRMATION (~800 tokens/turn)

**What:** The Serena plugin adds ~25 tools to the deferred list and ~500 words of instructions
to the system prompt. Serena provides semantic code analysis (find_symbol, get_symbols_overview,
replace_symbol_body, etc.).

**Question:** Do you use Serena for KR development? If not, disabling it saves ~800 tokens/turn.
If you do use it, it's not waste.

---

## Summary

| Finding | Tokens/turn | Status | Fix |
|---------|-------------|--------|-----|
| Dormant rules loading | ~850 | Definite waste | Move out of `.claude/rules/` |
| Triple Context7 | ~260 | Definite waste | Remove from `.mcp.json` + plugin |
| Double Tavily | ~100 | Definite waste | Remove from `.mcp.json` |
| Unused Memory MCP | ~120 | Definite waste | Remove from `.mcp.json` |
| Serena plugin | ~800 | Needs confirmation | Disable if unused |

**Total definite waste: ~1,330 tokens/turn**
**Total if Serena unused: ~2,130 tokens/turn**

Over a 50-turn conversation, that's 66,500–106,500 tokens of silent waste.
At cached Opus pricing ($1.875/MTok): ~$0.12–$0.20 per conversation.
At uncached pricing ($15/MTok): ~$1.00–$1.60 per conversation.

The real cost isn't just dollars — it's cache prefix bloat. These 1,330+ tokens occupy
the cache prefix, reducing effective cache hit rates on actual content.

---

## What This Audit Did NOT Flag

These consume tokens but provide real value — NOT waste:

- Active rules (arabic-scholarly-conventions, llm-call-optimization, etc.) — essential domain guidance
- Skills list (~100 skills) — invocable functionality, most are KR-relevant
- Hooks output — budget tracking, quality gates, Arabic safety checks
- MEMORY.md — cross-session context
- Sequential-thinking MCP — referenced in quality-workflow rules, actually used
- Scholar Gateway MCP — unique platform tool for scholarly research
- Superpowers framework — provides brainstorming, TDD, debugging workflows

---

## Implementation

After approval, the fix touches exactly two locations:

1. **Move 4 files** from `.claude/rules/dormant/` to `reference/dormant-rules/`
2. **Edit `.mcp.json`** to remove `context7`, `tavily`, and `memory` entries

No code changes. No functional changes. Pure waste elimination.
