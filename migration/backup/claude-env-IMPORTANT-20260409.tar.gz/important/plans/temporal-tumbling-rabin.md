# Plan: Foundation Integrity Audit + Structural Guardrails

## Context

A phantom "1500-word prompt cap" was discovered during Session 9. The cap was never formally decided — it emerged from an informal note ("1484/1500") that was progressively treated as a hard constraint across sessions. This drove a quality-losing 45% compression of the GROUP prompt (reverted after Gemini found 2 gaps). The owner challenged the engineering judgment and demands a thorough investigation to ensure no other unfounded constraints exist.

**Root cause:** A number appeared in a document → it was treated as a constraint without tracing its origin → an entire DR was commissioned to solve a non-problem → quality was lost.

**Pattern to prevent:** Informal numbers becoming hard constraints without formal decision, empirical calibration, or documented rationale.

## Audit Results (3-coworker investigation)

### Source 1: Explore Agent — Constraint Inventory (COMPLETE)
- **38 numeric thresholds** identified across SPEC + code
- **7 HIGH risk** (quality-impacting, undocumented):
  1. `>4000 word MAX_TOKENS` — explicitly marked "untested" in code comment
  2. `GROUP_MAX_TOKENS = 16384` — static, no rationale (CLASSIFY/ENRICH are dynamic)
  3. `VERIFY_MAX_TOKENS = 8192` — smaller than GROUP/ENRICH, no documented reason
  4. `unit_text[:1500]` in consensus — verifier sees only first 1500 chars, late evidence invisible
  5. `text_snippet` 80-char validation — known Unicode issue (DR-29)
  6. `excerpt_topic` 1-3 keywords — arbitrary cardinality, no corpus analysis
  7. PARTIAL/DEPENDENT boundary — explicitly uncalibrated, deferred to 30-book probe
- **15 MEDIUM risk** (single-source calibration or unclear basis)
- **16 LOW risk** (empirically calibrated or deterministic)
- **No other phantom constraints** found

### Source 2: Codex CLI — FP Doctrine vs Code (PENDING)
- Cross-checking FP-1..FP-22 against code implementation for contradictions

### Source 3: Gemini CLI — Arabic Scholarly Constraints (PENDING)
- Auditing all Arabic-specific lists for completeness

## Fixes (by priority)

### Tier 1: Fix Now (quality-impacting, clear action)

**Fix 1: Remove 1500-char truncation in consensus verification**
- File: `engines/excerpting/src/phase3_consensus.py:136,155,173`
- Problem: `excerpt.primary_text[:1500]` — verifier model sees only first 1500 characters. If critical evidence for attribution or school assignment appears later, the verifier can't see it.
- Fix: Send full `primary_text` to verifier. The verification model (Claude Opus 4.6) handles 200K context — 1500 chars is an arbitrary truncation that could cause wrong verifications on long passages.
- Risk if unfixed: Silent verification failures on long teaching units where late content matters.

**Fix 2: Make GROUP_MAX_TOKENS dynamic (match CLASSIFY/ENRICH pattern)**
- File: `engines/excerpting/contracts.py:810`
- Problem: GROUP_MAX_TOKENS is static 16384 while CLASSIFY and ENRICH scale dynamically based on word count. No documented rationale for the difference.
- Fix: Add `_compute_group_max_tokens(word_count)` function matching the CLASSIFY/ENRICH pattern (8192 for ≤1500 words, 16384 for 1501-4000, 32768 for >4000).
- Risk if unfixed: Potential output truncation on large chunks.

**Fix 3: Add `CONSTRAINT_REGISTRY.md` — every threshold must be traceable**
- File: New file at `engines/excerpting/reference/CONSTRAINT_REGISTRY.md`
- Purpose: Every numeric threshold in the engine gets an entry: value, location, origin (who decided, when, based on what data), calibration status (CALIBRATED/UNCALIBRATED/DEFERRED), and next calibration point.
- This is the structural guardrail against future phantom constraints.

### Tier 2: Fix Before 30-Book Probe (needs calibration data)

- `>4000 word MAX_TOKENS` — test with actual large chunks
- PARTIAL/DEPENDENT boundary calibration — adversarial examples needed
- `excerpt_topic` 1-3 cardinality — corpus analysis needed
- `text_snippet` 80-char Unicode issue — redesign snippet validation

### Tier 3: Track as Known Limitations

- Forgiving retention 15%/30-word thresholds — reasonable heuristics, monitor during probe
- Sub-20-word item grouping — monitor during probe
- 10% spot-check rate — review after probe results
- 60% LA-3 uncertainty threshold — review with LA calibration data

## Structural Guardrails (prevent recurrence)

### Guardrail 1: CONSTRAINT_REGISTRY.md
Every numeric threshold in code or SPEC must have an entry. New thresholds without a registry entry trigger a pre-commit warning.

### Guardrail 2: Pre-commit hook for magic numbers
A hook that scans for new numeric literals in engine source code and checks they have either:
- A reference to CONSTRAINT_REGISTRY.md
- A comment citing empirical data
- A config parameter in ExcerptingConfig (not hardcoded)

### Guardrail 3: "Origin trace" rule
Add to `.claude/rules/`: "Before treating any number as a constraint, trace its origin. Who decided it? When? Based on what data? If the answer is 'it appeared in a document' without a formal decision, it is NOT a constraint — it is an observation that needs validation."

## DR Deployment

- **DR28** (already prepared, relay in progress): Prompt architecture research — long-term alternative to word-count-based prompt management
- **DR29** (to prepare): Constraint validation — send the HIGH/MEDIUM audit findings to ChatGPT DR for independent assessment of which thresholds need immediate attention vs. deferred calibration

## Verification

1. After Fix 1: Run `python -m pytest engines/excerpting/tests/test_phase3_consensus.py -v` — verify no truncation
2. After Fix 2: Run `python -m pytest engines/excerpting/tests/test_phase2_group.py -v` — verify dynamic tokens
3. After Fix 3: Verify registry covers all 38 identified thresholds
4. Run full suite: `python -m pytest engines/excerpting/tests/ -q` — 917+ pass, 0 fail

## Files to Modify

- `engines/excerpting/src/phase3_consensus.py` — remove [:1500] truncation (Fix 1)
- `engines/excerpting/contracts.py` — add dynamic GROUP_MAX_TOKENS (Fix 2)  
- `engines/excerpting/src/phase2_group.py` — use dynamic tokens from config (Fix 2)
- `engines/excerpting/reference/CONSTRAINT_REGISTRY.md` — new file (Fix 3)
- `.claude/rules/constraint-origin-trace.md` — new rule (Guardrail 3)
- `engines/excerpting/reference/dr_reviews/DR29_constraint_validation_brief.md` — new DR brief

## Pending Coworker Results

Plan will be updated when Codex CLI (doctrine audit) and Gemini CLI (Arabic audit) complete. Their findings may add more fixes.
