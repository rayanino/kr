# Plan: KR Environment Overhaul — Session Intelligence + Coworker Orchestra

## Context

The KR project has a mature Claude Code environment (17 hooks, 26 agents, 14 skills, 12 rules, 22 commands) but suffers from **orchestration debt** — the individual pieces are strong, but connections between them have gaps that compound session-over-session. Three coworkers (Claude Code, Codex CLI, Gemini CLI) exist but work in silos with fragmented state, no shared decision trail, and manual session continuity.

**Coworker consultation:** Both Codex (GPT-5.4) and Gemini (Pro 3.1) were consulted and independently recommended Approach A (git-native protocol), rejected background daemons, and provided 13 combined hardening proposals that are incorporated below.

**Six gaps addressed:** (1) fragmented cost tracking, (2) manual post-compaction recovery, (3) invisible hook health, (4) prose-only session continuity, (5) shallow Gemini integration, (6) siloed coworker decisions.

---

## Architecture

```
.kr/
├── CHARTER.md              (existing — human-authoritative, unchanged)
├── ACTIVE.md               (existing — human-authoritative, unchanged)
├── HANDOFF.md              (existing — human-authoritative, unchanged)
├── DECISIONS.md            (existing — human-authoritative, unchanged)
│
├── runtime/                (NEW — machine state layer)
│   ├── session_context.json      # Current session objectives, prereqs, cost summary
│   ├── coworkers/
│   │   ├── claude.json           # Per-worker lease (task, branch, sha, heartbeat, scope)
│   │   ├── codex.json
│   │   └── gemini.json
│   ├── events.jsonl              # Operational events (append-only)
│   ├── cost_events.jsonl         # Spend tracking per agent/model (append-only)
│   └── reviews/
│       └── <review-id>/
│           ├── packet.json       # Normalized: commit_sha, diff_base, files, prompt_hash
│           └── result.json       # Verdict, findings, cost, model, timestamp
│
├── schemas/                (NEW — JSON Schema validation)
│   ├── session_context.schema.json
│   ├── coworker_lease.schema.json
│   ├── event.schema.json
│   ├── cost_event.schema.json
│   └── review_packet.schema.json
│
└── scripts/                (NEW — atomic operations)
    ├── kr_state.py               # Single entry point for all .kr/runtime/ writes
    ├── kr_validate.py            # Schema validator (called by hooks)
    ├── kr_resume.py              # Unified resume builder (derives context from all sources)
    ├── kr_cost.py                # Cost aggregator (reads cost_events.jsonl → summary)
    └── kr_fanout.py              # One-shot parallel dispatch (not daemon)
```

**Design principle (from Codex):** Human-authoritative files (CHARTER, ACTIVE, HANDOFF, DECISIONS) remain untouched. Machine state lives under `runtime/` to avoid authority fork. Strategic decisions still get promoted to `DECISIONS.md` manually.

---

## Component 1: Shared State Layer

### 1.1 Per-Worker Leases (`.kr/runtime/coworkers/<name>.json`)

Each coworker writes its own lease file — no shared state file, no last-writer-wins risk.

```json
{
  "agent": "claude",
  "task_id": "excerpting-v2-rerun",
  "mode": "active",
  "branch": "master",
  "head_sha": "59d00a76",
  "heartbeat_at": "2026-04-01T12:00:00Z",
  "lease_expires_at": "2026-04-01T14:00:00Z",
  "write_scope": ["engines/excerpting/", "NEXT.md"],
  "session_start": "2026-04-01T10:30:00Z"
}
```

**Write rule:** Each coworker only writes its own file. Read all three to see who's doing what.

### 1.2 Session Context (`.kr/runtime/session_context.json`)

Written by the active coworker at session start/end. Schema-validated.

```json
{
  "version": 1,
  "active_engine": "excerpting",
  "objectives": [
    {"id": "obj-1", "description": "Run v2 re-run with hardened prompts", "status": "pending",
     "prerequisites": ["DR-1 committed", "DR-3 committed", "model defaults fixed"]}
  ],
  "cost_summary": {
    "total_eur": 36.7,
    "budget_eur": 100.0,
    "remaining_eur": 63.3,
    "source": "cost_events.jsonl"
  },
  "compaction_checkpoint": {
    "fragile_files": ["engines/excerpting/SPEC.md", "engines/excerpting/CLAUDE.md", "NEXT.md"],
    "critical_invariants": ["D-023", "D-041", "arabic-safety"],
    "last_checkpoint_at": "2026-04-01T11:45:00Z"
  }
}
```

### 1.3 Event Streams (`.kr/runtime/events.jsonl` + `cost_events.jsonl`)

Split streams per Codex's recommendation. All writes go through `kr_state.py`.

**events.jsonl** — operational events:
```jsonl
{"ts":"2026-04-01T10:30:00Z","agent":"claude","event":"session_start","detail":{"engine":"excerpting"}}
{"ts":"2026-04-01T11:00:00Z","agent":"claude","event":"review_dispatched","detail":{"to":"codex","review_id":"rev-001"}}
{"ts":"2026-04-01T11:15:00Z","agent":"codex","event":"review_completed","detail":{"review_id":"rev-001","verdict":"pass"}}
```

**cost_events.jsonl** — per-call spend (Gemini's per-entry cost fields):
```jsonl
{"ts":"2026-04-01T11:02:00Z","agent":"claude","model":"claude-opus-4-6","input_tokens":4200,"output_tokens":1800,"cost_eur":0.12,"phase":"excerpting-enrichment"}
```

### 1.4 Review Artifacts (`.kr/runtime/reviews/<id>/`)

Normalized review packets per Codex's recommendation — pinned sha, diff_base, file list, prompt hash.

**Files to create/modify:**
- `NEW .kr/schemas/*.schema.json` — 5 JSON Schema files
- `NEW .kr/scripts/kr_state.py` — atomic write/append with schema validation
- `NEW .kr/scripts/kr_validate.py` — standalone validator for hooks
- `NEW .kr/scripts/kr_cost.py` — cost aggregator

---

## Component 2: Coworker Dispatch System

### 2.1 Review Dispatch Commands

Three new Claude Code commands in `.claude/commands/`:

**`/review-with-codex`**
- Generates normalized review packet (commit_sha, diff from merge-base, file list, prompt)
- Writes packet to `.kr/runtime/reviews/<id>/packet.json`
- Calls `codex exec -s read-only` with the packet content
- Captures output to `.kr/runtime/reviews/<id>/result.json`
- Logs event to `events.jsonl`

**`/review-with-gemini`**
- Same normalized packet
- Calls `gemini -p` with `-y` flag
- Same artifact capture

**`/consensus-3way`**
- Per Gemini's recommendation: deterministic, temp=0, fail loudly on mismatch
- Sends identical prompt to all three CLI tools
- Programmatic diff of structured outputs
- If outputs disagree: exit 1 + surface disagreement (never auto-resolve)
- If outputs agree: log agreement + confidence

### 2.2 One-Shot Fanout Script

`scripts/kr_fanout.py` — launches Codex and Gemini in parallel for a single review, collects results, exits. Not a daemon.

**Files to create/modify:**
- `NEW .claude/commands/review-with-codex.md`
- `NEW .claude/commands/review-with-gemini.md`
- `NEW .claude/commands/consensus-3way.md`
- `NEW .kr/scripts/kr_fanout.py`

---

## Component 3: Session Intelligence Engine

### 3.1 Lifecycle Hooks (modify existing)

**SessionStart** — enhance existing hook:
- Read `.kr/runtime/session_context.json`
- Validate prerequisites (check each one against repo state)
- Load cost state from `cost_events.jsonl`
- Update coworker lease (`claude.json`)
- Report: "Session objectives: X, Y, Z. Prerequisites: all met / missing: A"

**UserPromptSubmit** — enhance existing `prompt-context.sh`:
- Add coworker state summary (who else is active)
- Add cost warning at 80% and 90% thresholds (Gemini's recommendation)

**PreCompact** — enhance existing `pre-compact-checkpoint.sh`:
- Serialize to `session_context.json` (structured, not just advisory echo)
- Record fragile files list and critical invariants
- Write compaction checkpoint timestamp

**PostCompact** — enhance existing `post-compact-recovery.sh`:
- Read `session_context.json` compaction checkpoint
- Verify each fragile file is still readable
- Re-inject critical invariants as structured reminders
- Validate cost state wasn't lost

**Stop** — enhance existing hooks:
- Generate structured session report
- Update `session_context.json` with final state
- Write next objectives (machine-readable NEXT.md section)
- Release coworker lease

### 3.2 Resume Builder

`kr_resume.py` — unified context reconstruction. Called at session start or after compaction. Derives context from:
- `.kr/ACTIVE.md` (frontier)
- `.kr/HANDOFF.md` (handoff notes)
- `.kr/runtime/session_context.json` (machine state)
- `git status` + `git log` (current state)
- `.kr/runtime/coworkers/*.json` (who's active)
- `.kr/runtime/cost_events.jsonl` (budget)

**Files to create/modify:**
- `MODIFY .claude/hooks/prompt-context.sh` — add coworker state + cost warnings
- `MODIFY .claude/hooks/pre-compact-checkpoint.sh` — serialize to session_context.json
- `MODIFY .claude/hooks/post-compact-recovery.sh` — verify from session_context.json
- `NEW .kr/scripts/kr_resume.py`

---

## Component 4: Hook Health Dashboard

### 4.1 `/hook-health` Command

New command that checks (per Codex: actual wiring and recency, not just file presence):

1. **Wiring check**: Parse `.claude/settings.json` hooks → verify each referenced script exists and is executable
2. **Recency check**: Last execution timestamp for each hook (from events.jsonl)
3. **Failure check**: Any hook errors in current session
4. **Cost status**: Current spend vs budget with 80%/90% warnings
5. **Circuit breaker**: Current state and trigger history
6. **WSL sync**: Whether WSL clone matches Windows checkout (if applicable)
7. **Coworker status**: Who's active, lease state

Output: colored terminal table with status indicators.

**Files to create/modify:**
- `NEW .claude/commands/hook-health.md`
- `NEW scripts/kr_hook_health.py`

---

## Component 5: Gemini Control Plane Enhancement

### 5.1 Minimal Gemini Control Plane

Mirror the essential `.codex/` structure for Gemini:

```
.gemini/
├── settings.json          (existing — keep)
├── hooks.json             (NEW — mirror .codex/hooks.json structure)
└── hooks/
    └── session_start.py   (NEW — loads KR context for Gemini sessions)
```

This ensures Gemini sessions get the same context injection that Codex sessions get.

**Files to create/modify:**
- `NEW .gemini/hooks.json`
- `NEW .gemini/hooks/session_start.py`
- `MODIFY GEMINI.md` — add reference to .kr/runtime/ for shared state

---

## Implementation Order

| Step | Component | Files | Dependencies |
|------|-----------|-------|-------------|
| 1 | JSON Schemas | 5 schema files in `.kr/schemas/` | None |
| 2 | State writer (`kr_state.py`) | 1 script | Schemas |
| 3 | Validator (`kr_validate.py`) | 1 script | Schemas |
| 4 | Cost aggregator (`kr_cost.py`) | 1 script | Schemas |
| 5 | Resume builder (`kr_resume.py`) | 1 script | State writer |
| 6 | Session lifecycle hooks | 4 modified hooks | State writer, resume builder |
| 7 | Hook health command + script | 1 command + 1 script | State writer |
| 8 | Review dispatch commands | 3 commands + kr_fanout.py | State writer, schemas |
| 9 | Gemini control plane | 2 new files + 1 modified | None (independent) |
| 10 | Integration test | 1 test script | All above |

Steps 1-3 can be parallelized. Steps 8 and 9 are independent of each other.

---

## Verification

1. **Schema validation**: Run `kr_validate.py` on all `.kr/runtime/` files — all must pass
2. **Lease isolation**: Simulate two coworkers writing leases — no conflicts
3. **Cost unification**: `kr_cost.py` reads `cost_events.jsonl` → matches expected totals
4. **Resume reconstruction**: `kr_resume.py` produces correct context from current repo state
5. **Hook health**: `/hook-health` shows all 17 hooks wired and recent
6. **Review dispatch**: `/review-with-codex` generates packet, calls codex, captures result
7. **Consensus**: `/consensus-3way` sends to all three, reports agreement/disagreement
8. **Compaction cycle**: Trigger compaction → verify session_context.json preserved → verify post-compact recovery restores state
9. **Cost warnings**: Spend 81% of budget → verify 80% warning fires in prompt-context

---

## What This Does NOT Include

- No new servers, databases, or external tools
- No background daemons (one-shot scripts only)
- No changes to engine code or pipeline logic
- No changes to existing .kr/ human-authoritative files (CHARTER, ACTIVE, etc.)
- No Paperclip or RTK integration
- No UI dashboard (terminal commands only)
