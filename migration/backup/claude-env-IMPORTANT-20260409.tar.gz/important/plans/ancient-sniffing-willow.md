# Architect-directed surgical fixes (3 edits)

## Context
Post-review fixes from architect. Exact code provided — execute directly per feedback_architect_directive.

## Fix 1: phase2_classify.py:421–423
Set `error_feedback = None` for ValidationError (schema errors are structural, not content feedback).

## Fix 2: phase2_group.py:324–326
Same change — `error_feedback = None` for ValidationError.

## Fix 3: phase2_group.py:205–207
Wrap segment index lookup in try/except IndexError → raise ValueError with clear V-P2-14 message.

## Verification
`python -m pytest engines/excerpting/tests/ -v --tb=short` → 147 passed, 2 skipped, 0 failed.
