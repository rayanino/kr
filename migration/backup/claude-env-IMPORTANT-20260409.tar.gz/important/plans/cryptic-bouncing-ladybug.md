# Plan: Format Diversity Experiment (4 Deliverables)

## Context

The Architecture C experiment validated LLM teaching-unit extraction on 10 prose divisions (all <=1040 words). Two critical gaps remain untested before writing the excerpting engine SPEC:
1. **Non-prose formats** — verse-commentary text (Ibn Aqil's sharh on Alfiyyah)
2. **Longer divisions** — 2000-4000 word prose (Taysir al-Ilam fiqh sharh)

This experiment fills both gaps by running the same LLM extraction (Approaches A & B) on 10-14 new divisions. Cost: ~3-5 EUR. The architect evaluates results in a separate session to decide if verse-commentary needs preprocessing before the SPEC.

---

## Deliverable 1: Normalize Fixtures (`produce_packages.py`)

**Adapt:** `experiments/architecture_test/produce_packages.py`
**Write to:** `experiments/format_diversity_test/produce_packages.py`
**Output:** `experiments/format_diversity_test/packages/{fixture_name}/manifest.json + content.jsonl`

### Changes from original

| Aspect | Original | New |
|--------|----------|-----|
| Fixture list | 5 fixtures from `tests/fixtures/shamela_real/` | 5 fixtures from mixed locations (see table) |
| Output root | `experiments/architecture_test/packages/` | `experiments/format_diversity_test/packages/` |
| Stats | CU count, leaf division count | + median division word count |
| Error handling | None (all succeed or crash) | PRIMARY=fatal, OPTIONAL=log+skip |

### Fixture configuration

```python
FIXTURES = [
    # PRIMARY — must succeed
    {"name": "ibn_aqil_v1", "path": "experiments/format_diversity_test/fixtures/ibn_aqil/001.htm",
     "is_multi_layer": True, "priority": "PRIMARY"},
    {"name": "ibn_aqil_v3", "path": "experiments/format_diversity_test/fixtures/ibn_aqil/003.htm",
     "is_multi_layer": True, "priority": "PRIMARY"},
    {"name": "taysir", "path": "experiments/format_diversity_test/fixtures/taysir_al_ilam/book.htm",
     "is_multi_layer": False, "priority": "PRIMARY"},
    # OPTIONAL — skip on failure or <5 leaf divisions
    {"name": "ext_39_masala", "path": "tests/fixtures/shamela_extended/ext_39/book.htm",
     "is_multi_layer": False, "priority": "OPTIONAL"},
    {"name": "ext_46_qa", "path": "tests/fixtures/shamela_extended/ext_46/book.htm",
     "is_multi_layer": False, "priority": "OPTIONAL"},
]
```

### Key reuse
- `normalize_source()` from `engines.normalization.src.dispatcher`
- `_make_source_metadata()` from `engines.normalization.tests.conftest`
- `count_leaf_divisions()` from original (copy verbatim)

### Implementation notes
- Paths are relative to PROJECT_ROOT; each fixture has a different base path
- `_make_source_metadata(is_multi_layer=True)` for ibn_aqil fixtures
- Add `arabic_word_count()` helper (same as in extract_divisions.py) for median word count calc
- Print table: fixture | CU count | leaf divisions | median div words

---

## Deliverable 2: Extract Divisions (`extract_divisions.py`)

**Adapt:** `experiments/architecture_test/extract_divisions.py`
**Write to:** `experiments/format_diversity_test/extract_divisions.py`
**Output:** `experiments/format_diversity_test/divisions/{fixture_name}/div_{index}.json`
**Report:** `experiments/format_diversity_test/EXTRACTION_REPORT.md`

### Changes from original

| Aspect | Original | New |
|--------|----------|-----|
| Word range | 300-2000 for all | Per-fixture (see table) |
| Target count | 2 per fixture | Per-fixture (2-4) |
| Alignment (L-003) | Strict only (15/100) | Strict + relaxation for ibn_aqil (30/200 if >80% rejected) |
| Context | 3 content units before/after | 200 words before/after |
| Selection | Closest to 700w | Per-fixture criteria |
| Verse detection | None | ibn_aqil: verify verse-commentary interleaving |
| Special markers | None | ext_39: require >=2 masala; ext_46: require >=2 QA markers |
| Output report | None | EXTRACTION_REPORT.md |

### Per-fixture selection criteria

| Fixture | Count | Word range | Special |
|---------|-------|------------|---------|
| ibn_aqil_v1 | 2-3 | 300-2000w | Must contain verse lines (<=20 Arabic words surrounded by prose, or "قال ابن مالك" markers) |
| ibn_aqil_v3 | 2-3 | 300-2000w | Same verse-commentary criteria |
| taysir | 3-4 | 2000-4000w | Standard L-003 strict. Select from different kitab sections |
| ext_39_masala | 1-2 | 300-2000w | >=2 "مسألة" markers in assembled text |
| ext_46_qa | 1-2 | 300-2000w | >=2 QA markers (سؤال/فأجاب/سُئل) |

### Key functions to reuse (copy + adapt)
- `load_package()` — change PACKAGES_DIR path
- `find_leaf_divisions()` — reuse verbatim
- `assemble_text()` + `BC_JOIN_MAP` — reuse verbatim
- `rebase_text_layers()` — reuse verbatim
- `aggregate_content_flags()` — reuse verbatim
- `strip_arabic_noise()` — reuse verbatim
- `arabic_word_count()` — reuse verbatim
- `write_division_json()` — change DIVISIONS_DIR path

### New functions needed
- `has_verse_commentary(text: str) -> bool` — detect verse-commentary interleaving (short lines <=20 words surrounded by longer prose, or markers like "قال ابن مالك")
- `has_masala_markers(text: str, min_count: int) -> bool` — count "مسألة" occurrences
- `has_qa_markers(text: str, min_count: int) -> bool` — count سؤال/فأجاب/سُئل
- `select_divisions_for_fixture()` — fixture-specific selection logic (replaces the original `select_divisions()`)
- `extract_word_context(units, index, direction, word_limit)` — extract 200 words before/after
- `generate_extraction_report()` — writes EXTRACTION_REPORT.md

### L-003 relaxation logic
```python
# For ibn_aqil fixtures:
# 1. Try strict: first 15 stripped chars in first 100 stripped chars
# 2. Count rejection rate
# 3. If >80% rejected, relax to: first 30 in first 200
# 4. Note in extraction report which mode was used
```

---

## Deliverable 3: Run LLM Tests (`run_tests.py`)

**Adapt:** `experiments/architecture_test/run_tests.py`
**Write to:** `experiments/format_diversity_test/run_tests.py`
**Output:** `experiments/format_diversity_test/results/{fixture_name}/div_{index}_{approach}.json`
**Report:** `experiments/format_diversity_test/results/RUN_SUMMARY.md`

### Changes from original

| Aspect | Original | New |
|--------|----------|-----|
| Approaches | A, B, C | A, B only (no C) |
| Paths | `experiments/architecture_test/divisions/` + `results/` | `experiments/format_diversity_test/divisions/` + `results/` |
| C eligibility | should_run_c() logic | Removed entirely |

### What to copy verbatim (DO NOT MODIFY)
- All Pydantic schemas: `TeachingUnit`, `ExtractionResult`, `ClassifiedSegment`, `ClassificationResult`
- All system prompts: `APPROACH_A_SYSTEM`, `APPROACH_B_CLASSIFY_SYSTEM`, `APPROACH_B_GROUP_SYSTEM`
- `FUNCTION_ENUM` literal type
- `get_client()` — OpenRouter setup (base_url, Mode.JSON, env var)
- `call_llm()` — API call wrapper
- `run_approach_a()` — single-call extraction
- `run_approach_b()` — two-call classify+group
- `save_result()` / `save_error()` — result persistence

### What to change
- Remove `APPROACH_C_GROUP_SYSTEM`, `run_approach_c()`, `should_run_c()`
- Update `DIVISIONS_DIR` and `RESULTS_DIR` paths
- In `main()`: remove Approach C block, update summary format
- API config stays same: `MODEL = "anthropic/claude-opus-4.6"`, `TEMPERATURE = 0`

---

## Deliverable 4: Evaluation Workbook (`generate_workbook.py`)

**Adapt:** `experiments/architecture_test/generate_workbook.py`
**Write to:** `experiments/format_diversity_test/generate_workbook.py`
**Output:** `experiments/format_diversity_test/EVALUATION_WORKBOOK.md`

### Changes from original

| Aspect | Original | New |
|--------|----------|-----|
| Approach C section | Present | Removed |
| Comparison notes | A vs B vs C | A vs B only |
| Paths | architecture_test dirs | format_diversity_test dirs |
| Header | "Architecture C — Evaluation Workbook" | "Format Diversity — Evaluation Workbook" |

### What to copy verbatim
- `load_all_divisions()` (change path)
- `load_result()` (change path)
- `format_teaching_units_table()` (verbatim)

### What to change
- Remove Approach C loading + display
- Update comparison notes to A vs B only
- Update paths: DIVISIONS_DIR, RESULTS_DIR, OUTPUT_PATH

---

## Execution Order

1. **Write `produce_packages.py`** → run it → verify 3+ PRIMARY fixtures normalized with >5 leaf divisions each
2. **Write `extract_divisions.py`** → run it → verify 10-14 divisions extracted, ibn_aqil has verse content, taysir has 2000-4000w
3. **Write `run_tests.py`** → run it → verify all divisions tested (A+B), zero errors
4. **Write `generate_workbook.py`** → run it → verify full Arabic text, no truncation

Each deliverable is written, run, and verified before moving to the next.

---

## Critical Files

| File | Role |
|------|------|
| `experiments/architecture_test/produce_packages.py` | Template for D1 |
| `experiments/architecture_test/extract_divisions.py` | Template for D2 |
| `experiments/architecture_test/run_tests.py` | Template for D3 (prompts/schemas copied verbatim) |
| `experiments/architecture_test/generate_workbook.py` | Template for D4 |
| `engines/normalization/src/dispatcher.py:32` | `normalize_source()` entry point |
| `engines/normalization/tests/conftest.py:59` | `_make_source_metadata()` factory |
| `engines/normalization/contracts.py` | NormalizedPackage, ContentUnit, DivisionNode models |
| `experiments/format_diversity_test/fixtures/ibn_aqil/001.htm` | Primary fixture (verse-commentary) |
| `experiments/format_diversity_test/fixtures/ibn_aqil/003.htm` | Primary fixture (verse-commentary) |
| `experiments/format_diversity_test/fixtures/taysir_al_ilam/book.htm` | Primary fixture (longer prose) |
| `tests/fixtures/shamela_extended/ext_39/book.htm` | Optional fixture (masala) |
| `tests/fixtures/shamela_extended/ext_46/book.htm` | Optional fixture (QA) |

---

## Verification Checklist

- [ ] >=3 PRIMARY fixtures normalized with >5 leaf divisions each
- [ ] 10-14 divisions extracted (minimum 8 from PRIMARY)
- [ ] Ibn Aqil divisions contain visible verse-commentary content
- [ ] Taysir divisions are in 2000-4000w range
- [ ] LLM tests run on every division (A+B), zero errors
- [ ] Workbook has full Arabic text (not truncated)
- [ ] RUN_SUMMARY.md has zero errors
- [ ] EXTRACTION_REPORT.md documents all decisions
- [ ] No modifications to normalization engine code
- [ ] No modifications to experiments/architecture_test/ files
- [ ] Same prompts, schemas, model as original

---

## Do NOT Do (from NEXT.md)

- Do NOT modify normalization engine code
- Do NOT modify `experiments/architecture_test/` files
- Do NOT create gold reference files
- Do NOT run Approach C
- Do NOT modify LLM prompts or schemas
- Do NOT use any API other than OpenRouter
- Do NOT normalize ext_49
- Do NOT spend >5 min debugging OPTIONAL fixture normalization failures
