# Plan: val-contracts Cross-Boundary Defect Fixes (A3, A2, A1)

## Context

The Codex `val-contracts` review found three HIGH-severity cross-boundary defects where adjacent engines disagree on contract shapes. The adjudication log confirms no coworker contradictions were raised (both CLI reviewers were degraded). The packet orders fixes as A3 → A2 → A1, which is correct: text integrity first, then boundary acceptance, then contract documentation.

**Source:** `docs/codex/reviews/2026-04-01-val-contracts-claude-packet.md`

## A3: TEXT_INTEGRITY — Remove ZWNJ stripping from excerpting writer

**Problem:** `writer.py:77-86` strips all runs of 2+ consecutive ZWNJ (U+200C) from `primary_text` during serialization, violating the contract at `contracts.py:471` ("Never modified after extraction") and the normalization SPEC §4.A.7 which preserves double-ZWNJ as structural heading markers in 9.5% of Shamela corpus. The BUG-003 comment mischaracterizes preserved source data as "normalization artifacts."

**Decision:** The stripping is a contract violation. Remove it.

### Steps

**1. Delete ZWNJ stripping from `engines/excerpting/src/writer.py`**
- Delete line 27: `_DOUBLE_ZWNJ_RE = re.compile(r"\u200c{2,}")`
- Delete line 26: the `# BUG-003:` comment above it
- Delete lines 77-86: the entire `if "\u200c\u200c" in pt:` block
- Delete `import re` from line 2 (only user of `re` in this file)

**2. Rewrite tests in `engines/excerpting/tests/test_writer.py`**
- Rename `TestDoubleZwnjStripping` → `TestZwnjPreservation`
- `test_double_zwnj_preserved` (was `_stripped`): Assert `"\u200c\u200c" in data["primary_text"]` and `data["primary_text"].startswith("\u200c\u200c")` — invert the old assertion
- `test_triple_zwnj_preserved` (was `_stripped`): Assert `data["primary_text"] == "text\u200c\u200c\u200cmore"` — the old assertion was `"textmore"`
- Keep `test_single_zwnj_preserved` and `test_no_zwnj_unchanged` as-is (already correct)
- Add `test_primary_text_byte_identical_through_writer`: Create a record with mixed Arabic, single/double/triple ZWNJ, diacritics. Assert `output["primary_text"] == original` byte-for-byte. This is the regression gate.

**3. Verify**
```bash
python -m pyright engines/excerpting/src/writer.py
python -m pytest engines/excerpting/tests/test_writer.py -x -v
```

**Files:** `engines/excerpting/src/writer.py`, `engines/excerpting/tests/test_writer.py`

---

## A2: EXCERPTING→TAXONOMY — Accept empty topics when llm_enrichment_failed

**Problem:** Excerpting allows `excerpt_topic=[]` when `"llm_enrichment_failed" in review_flags` (contracts.py:516-519, phase3_validation.py:114-124). Taxonomy unconditionally rejects all empty topic lists (engine.py:230-237), ignoring `review_flags`. The flag IS present in the data but invisible to taxonomy's validation.

**Critical detail:** The `_REQUIRED_FIELDS` tuple at engine.py:46 includes `"excerpt_topic"`. The check at line 221 (`not excerpt.get(f)`) catches `[]` as falsy, so excerpts are rejected at line 221 *before* reaching the dedicated topic check at line 230. Both must be fixed.

**Decision:** Taxonomy must respect the `llm_enrichment_failed` flag. Placement depends on primary_text and primary_function, not topics.

### Steps

**1. Remove `"excerpt_topic"` from `_REQUIRED_FIELDS` in `engines/taxonomy/src/engine.py:46`**
```python
# Before
_REQUIRED_FIELDS = ("excerpt_id", "source_id", "primary_text", "excerpt_topic")
# After
_REQUIRED_FIELDS = ("excerpt_id", "source_id", "primary_text")
```
Add comment: `# NOTE: excerpt_topic validated separately — see _process_excerpt line ~230`

**2. Update the dedicated check at engine.py:230-237**
```python
# Before
topics = excerpt.get("excerpt_topic")
if not isinstance(topics, list) or len(topics) == 0:
    logger.error(...)
    return None

# After
topics = excerpt.get("excerpt_topic")
if not isinstance(topics, list) or len(topics) == 0:
    review_flags = excerpt.get("review_flags", [])
    if "llm_enrichment_failed" in review_flags:
        logger.warning(
            "TAX_EMPTY_TOPIC_FALLBACK: excerpt %s has empty excerpt_topic"
            " but llm_enrichment_failed flag present — proceeding",
            excerpt_id,
        )
    else:
        logger.error(
            "TAX_MISSING_REQUIRED_FIELD: excerpt %s has empty/invalid"
            " excerpt_topic — skipped",
            excerpt_id,
        )
        return None
```

**3. Update tests in `engines/taxonomy/tests/test_engine.py`**
- Rename `test_empty_excerpt_topic_skips` → `test_empty_excerpt_topic_without_flag_skips` (body unchanged — tests rejection when no flag)
- Add `test_empty_excerpt_topic_with_enrichment_failed_accepted`: excerpt with `excerpt_topic=[]` + `review_flags=["llm_enrichment_failed"]` → NOT rejected, reaches a placement route
- Add `test_empty_excerpt_topic_with_unrelated_flag_skips`: excerpt with `excerpt_topic=[]` + `review_flags=["some_other_flag"]` → rejected (only `llm_enrichment_failed` triggers fallback)

**4. Verify**
```bash
python -m pyright engines/taxonomy/src/engine.py
python -m pytest engines/taxonomy/tests/ -x -v
```

**Files:** `engines/taxonomy/src/engine.py`, `engines/taxonomy/tests/test_engine.py`

---

## A1: TAXONOMY→SYNTHESIS — Contract authority unification

**Problem:** Taxonomy has two contract files: `contracts_core.py` (runtime, used by all code) and `contracts.py` (unused, documents deferred fields like `verified_flagged_status`). Synthesis SPEC requires `verified_flagged_status` as mandatory, but neither excerpting nor taxonomy produces it — it belongs to an unimplemented human gate step. Synthesis `tracer.py` is a legacy stub expecting aggregate JSON; taxonomy writes per-excerpt files.

**Decision:** `contracts_core.py` is the sole authoritative runtime contract. `verified_flagged_status` defaults to `"verified"` until the human gate is implemented.

### Steps

**1. Deprecate `PlacedExcerptAdditions` in `engines/taxonomy/contracts.py:156`**
Update docstring to mark as DEPRECATED, point to `contracts_core.py:PlacementAdditions` as the runtime authority.

**2. Document authority in `engines/taxonomy/contracts_core.py:153`**
Update `PlacementAdditions` docstring: note it IS the authoritative runtime contract, reference the deprecated contracts.py model and the synthesis input model.

**3. Add pre-human-gate default to `engines/synthesis/SPEC.md` §2.1 (after line 31)**
Document that absent `verified_flagged_status` defaults to `"verified"` — all excerpts enter the factual layer until the human gate step is implemented.

**4. Document per-excerpt file format in `engines/synthesis/SPEC.md` §2.1 (after line 35)**
Describe the actual taxonomy output: per-excerpt JSON files at `library/sciences/{science_id}/content/{leaf_path}/excerpts/{excerpt_id}.json`, encoding, fields.

**5. Add `TaxonomyPlacedExcerpt` input model to `engines/synthesis/contracts.py`**
New Pydantic model matching the actual runtime output shape: required fields from excerpting (excerpt_id, source_id, primary_text) + taxonomy additions (lifecycle_stage, confirmed_leaf, placement_route) + `verified_flagged_status` with default `"verified"`. Place after the enum definitions, before the existing Input Contract Models section (~line 147).

**6. Verify**
```bash
python -m pyright engines/taxonomy/contracts.py engines/taxonomy/contracts_core.py engines/synthesis/contracts.py
```

**Files:** `engines/taxonomy/contracts.py`, `engines/taxonomy/contracts_core.py`, `engines/synthesis/contracts.py`, `engines/synthesis/SPEC.md`

---

## Verification Plan

After all three fixes:
1. `python -m pytest engines/excerpting/tests/test_writer.py -x -v` — ZWNJ preservation
2. `python -m pytest engines/taxonomy/tests/ -x -v` — empty-topic boundary + full regression
3. `python -m pyright engines/excerpting/src/writer.py engines/taxonomy/src/engine.py engines/synthesis/contracts.py` — type safety
4. `python -m pytest engines/excerpting/tests/ -x -q` — full excerpting regression (958 tests)
5. Verify the taxonomy test fixture's double-ZWNJ (`conftest.py:44`) survives roundtrip through any integration paths

## What is NOT in scope

- **A4 (validation tooling refresh):** Deferred per packet instructions until A1-A3 settle boundary shapes
- **Structural follow-ons (#5 source→normalization enum, #6 D-023 adjacent-schema):** Medium severity, separate work
- **Synthesis tracer.py rewrite:** Legacy stub, will be replaced when synthesis is built
