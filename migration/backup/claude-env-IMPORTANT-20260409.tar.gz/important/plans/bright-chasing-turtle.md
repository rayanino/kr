# Plan: Fix F-1 (stale join_points) + F-2 (lint)

## Context

Excerpting Phase 1 (commit 1ae4a991) was **BLOCKED** by the architect review with 2 findings. Both are surgical fixes — no new features, no SPEC changes. The architect provided exact code for all three parts of F-1. Per the architect-directive feedback rule, execute directly without dispatching code-reviewer.

**Bug (F-1):** `renumber_footnotes()` can change `assembled_text` length (e.g., `⌜1⌝` → `⌜10⌝`), but `join_points` are never updated. `rebase_text_layers()` uses stale offsets → silently wrong layer coordinates.

## Steps

### Step 1: F-1 Part 1 — Add helper function

**File:** `engines/excerpting/src/phase1_assembly.py`
**Location:** After line 142 (end of `_should_insert_space_mid_sentence`), before line 147 (`§4.2` section header)
**Action:** Insert `_adjust_join_points_after_renumber()` — exact code from NEXT.md lines 27-80

Dependencies already satisfied:
- `_FOOTNOTE_MARKER_RE` at line 87
- `JoinPoint` imported at line 31

### Step 2: F-1 Part 2 — Modify run_phase1() step 4 loop

**File:** `engines/excerpting/src/phase1_assembly.py`
**Location:** Lines 1396-1429 (the `for chunk in merged_chunks:` block)
**Action:** Replace entire block with architect-provided code (NEXT.md lines 88-131)

Key changes:
1. Call `_adjust_join_points_after_renumber()` after `renumber_footnotes()`
2. Move `original_join_points[chunk.div_id]` assignment AFTER renumbering (was BEFORE)
3. Set `assembly_metadata.join_points` to `adjusted_jps` in finalized chunk

### Step 3: F-1 Part 3 — Add regression test

**File:** `engines/excerpting/tests/test_phase1_metadata.py`
**Location:** After line 176 (end of file)
**Action:** Append `TestJoinPointAdjustmentAfterRenumber` class — exact code from NEXT.md lines 143-231

### Step 4: F-2 — Fix lint

**Command:** `ruff check --fix engines/excerpting/tests/`
Auto-removes unused imports across test files.

### Step 5: Verification (all 4 commands from NEXT.md)

```bash
# 1. All tests pass (expect 82+ after adding the new test)
python -m pytest engines/excerpting/tests/ -v --tb=short

# 2. Lint clean
ruff check engines/excerpting/src/phase1_assembly.py engines/excerpting/tests/

# 3. Normalization regression
python -m pytest engines/normalization/tests/ --tb=short

# 4. F-1 specific: run the regression test in isolation
python -m pytest engines/excerpting/tests/test_phase1_metadata.py::TestJoinPointAdjustmentAfterRenumber -v --tb=long
```

### Step 6: Commit

Single commit with both fixes. No code-reviewer dispatch (architect re-verifies).

## Do NOT Do

- Modify `contracts.py`
- Modify any existing test
- Change `renumber_footnotes()` signature
- Change any other function behavior
- Run CC self-review

## Critical Files

- `engines/excerpting/src/phase1_assembly.py` — production code (2 edits)
- `engines/excerpting/tests/test_phase1_metadata.py` — test file (1 append)
- `engines/excerpting/tests/*.py` — lint fix targets
