# Plan: Overnight System v3 — Comprehensive Upgrade

## Context

The first overnight run (2026-03-28) proved the system works (171 tests, 1 HIGH bug found+fixed, 7 SPEC issues) but exposed 29 gaps in the infrastructure. This upgrade addresses the critical blockers, adds Gemini CLI as a third reviewer, enforces core quality rules, and switches to Opus for maximum test quality.

The HIGH bug fix from ki-attribution-excerpting was already committed manually (3ad75a65). All 768 tests pass.

## Priority A: Critical Bug Fixes (3 changes)

### A1. Fix `--full-auto` duplication — `scripts/overnight_task_generator.py:764`
```python
# Before:
codex_flags=["--full-auto"],
# After:
codex_flags=[],
```
The orchestrator's `_execute_codex()` already passes `--full-auto`. Duplicate causes all Codex verification tasks to fail.

### A2. Auto-commit guard — `scripts/overnight_orchestrator.py` (after quality gate, ~30 lines)
After the quality gate passes for a modifying task, check if the CLI session actually committed:
```python
if result.status == "success" and task.safety_level != "readonly":
    # Quality gate...
    if not gate["passed"]:
        # rollback...
    else:
        # NEW: check if CLI committed or left changes uncommitted
        current_head = git_head()
        if current_head == pre_snapshot:
            # CLI didn't commit — check for uncommitted changes
            uncommitted = subprocess.run(
                ["git", "status", "--porcelain", "--", "engines/", "shared/"],
                capture_output=True, text=True, cwd=str(PROJECT_DIR),
            ).stdout.strip()
            if uncommitted:
                log_decision(f"AUTO-COMMIT: {task.task_id} left uncommitted changes — committing")
                git_commit(f"overnight: {task.task_id} — auto-commit (CLI missed commit step)")
            # else: readonly task or task made no changes — fine
```

### A3. Fix Codex timeout + prompt passing — `scripts/overnight_orchestrator.py`
- Increase `run_codex_verification()` timeout: 300 → 600
- Pass prompt via temp file instead of CLI argument (avoids Windows arg length issues):
```python
prompt_file = results_dir / "codex_prompt.txt"
prompt_file.write_text(review_prompt, encoding="utf-8")
cmd = [codex_bin, "exec", "--full-auto",
       "--output-last-message", str(output_file),
       f"@{prompt_file}"]  # if codex supports file input, else pass shorter prompt
```

## Priority B: Gemini L6 Integration (new execution backend + verification layer)

### B1. Add `_find_gemini()` helper (~15 lines, next to `_find_codex()`)
Check `shutil.which("gemini")`, then npm global paths. Set `KR_GEMINI_PATH` env var.

### B2. Add `_execute_gemini()` backend (~40 lines)
```python
def _execute_gemini(task: TaskDef, results_dir: Path) -> TaskResult:
    """Execute via Gemini CLI — adversarial review. Uses -y for auto-approval."""
    gemini_bin = os.environ.get("KR_GEMINI_PATH", "gemini")
    output_file = results_dir / "gemini_output.md"
    cmd = [
        gemini_bin, "-p", task.prompt,
        "-o", "text",
        "-y",  # auto-approve (equivalent of --full-auto)
    ]
    # ... subprocess execution, result parsing
```

### B3. Add `run_gemini_adversarial_challenge()` as L6 gate (~40 lines)
After L5 (Codex structural review), run Gemini as adversarial challenger on HIGH+ findings:
```python
def run_gemini_adversarial_challenge(task: TaskDef, codex_review: dict) -> dict:
    """L6: Gemini adversarial challenge of Codex findings (D-H002)."""
    challenge_prompt = f"""A code review by an independent reviewer concluded:
{codex_review.get('review', 'No findings.')}

The code changes were for: {task.name}

Challenge this conclusion:
1. What edge cases could still break this code?
2. What assumptions is the reviewer making?
3. Is the fix addressing the root cause or papering over the symptom?
"""
    # Execute Gemini CLI...
```

### B4. Add `execution_mode: "gemini"` to task routing (line ~495)
```python
if task.execution_mode == "gemini":
    result = _execute_gemini(task, task_results_dir)
elif task.execution_mode == "codex":
    ...
```

## Priority C: Quality Gate Restructuring

### C1. Move commit AFTER all verification gates
Current flow: execute → gate → commit → Codex → (bugs slip through)
New flow: execute → L1-L4 gate → auto-commit guard → Codex L5 → Gemini L6 → commit

The CLI session may or may not commit. The auto-commit guard (A2) ensures changes are staged. But the final "blessed" commit happens AFTER Codex and Gemini approve. If they find issues, rollback to pre_snapshot.

Implementation: restructure the main loop section at lines 1290-1330.

## Priority D: Core Rules (update safety prompt)

Add to `OVERNIGHT_SAFETY_PROMPT` before the findings protocol:

```
CORE QUALITY RULES:
1. Every bug you find MUST be fixed AND regression-tested in the same session.
   Finding without fixing is half the value. The fix must have a test that fails
   without it and passes with it.
2. Every test must test exactly ONE behavior. Name it precisely:
   test_{what}_{condition}_{expected}. No multi-assertion catch-all tests.
3. Reference the EXACT SPEC section for every test: read the SPEC text, quote
   the rule, then write the test. Don't paraphrase SPEC rules from memory.
4. Test QUALITY over QUANTITY. 10 precise boundary tests > 100 shallow smoke tests.
   Every test must catch a real bug or prove a real invariant.
5. When done, self-review your work: re-read every test you wrote and ask
   "Would this test catch the bug if someone introduced it tomorrow?"
6. Count tests BEFORE and AFTER. Report the delta in findings.json.
```

## Priority E: Opus for All Tasks + max_turns increase

Update manifest generation and tonight's manifest:
- All tasks use `"model": "opus"` instead of `"sonnet"`
- Increase `max_turns` default from 25 to 40 for modifying tasks
- Increase `max_budget_usd` to $8 per task (Opus is more expensive but produces better tests)

## Priority F: Enhanced Findings Schema

Update the findings.json template in the safety prompt to include:
```json
{
  "task_status": "success|truncated|failed",
  "session_id": "2026-03-28",
  "bugs_found": [...],
  "tests_added": [...],
  "spec_issues": [...],
  "dead_code": [...],
  "learnings": [...],
  "test_count_before": 0,
  "test_count_after": 0,
  "total_session_cost_usd": 0.0
}
```

Also fix the synthesis task's cost aggregation (BUG 3 from audit — it reported $1.11 instead of the real session total).

## Files Modified (summary)

| File | Changes |
|------|---------|
| `scripts/overnight_orchestrator.py` | A1 fix, A2 auto-commit guard, A3 Codex timeout, B1-B4 Gemini integration, C1 gate restructuring, D core rules in prompt, F findings schema |
| `scripts/overnight_task_generator.py` | A1 --full-auto fix, E default model/turns |
| `overnight/tonight_manifest.json` | E Opus for all, increased budgets/turns |

## Verification

1. `python -c "import scripts.overnight_orchestrator"` — imports clean
2. `python scripts/overnight_task_generator.py --dry-run` — no --full-auto in codex_flags
3. `gemini -p "test" -o text -y` — Gemini CLI responds
4. `python scripts/overnight_orchestrator.py --manifest overnight/tonight_manifest.json --dry-run` — all tasks load
5. `python -m pytest engines/excerpting/tests/ -x -q` — 768 pass
6. Commit, push, launch
