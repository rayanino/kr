# Plan: DR22 Integration — Multi-Layer Text Detection Blueprint

## Context

DR22 (Gemini Deep Research): "Computational Stratigraphy in Classical Arabic Texts" — 351 lines, 58 citations. This is the last of the 6 DR reports dispatched in this session (DR17-DR22). It provides a complete technical blueprint for the hardest unsolved problem in the excerpting engine: detecting and preserving multi-authorial layers (matn/sharh/hashiya/ta'liqa/tahqiq).

**Archive:** `engines/excerpting/reference/dr_reviews/DR22_gemini_multilayer_text_detection.md`

## What DR22 Delivers

### Phase 1: Publisher Conventions (6 publishers profiled)
| Publisher | Matn/Sharh Distinction | Hashiya Placement | Consistency |
|---|---|---|---|
| Dar al-Kutub al-'Ilmiyyah | Bold, ornate brackets | Bottom half, solid line | High |
| Mu'assasat al-Risalah | Distinct font families, spatial isolation | Separate blocks | Very High |
| Dar al-Fikr | ص/ش sigla, inline integration | Framing margins | Medium |
| Dar al-Salam | Brackets, indentation levels | Bottom block, indented | High |
| Umm al-Qura Press | 24pt body / 18pt margins, Naskh font | 18pt margin font | Absolute |
| Al-Azhar Press | Matn isolated + fully vocalized; Sharh unvocalized | Separate from Matn | High |

### Phase 2: Complete Marker Catalog (22 markers with ambiguity ratings)
- **Low ambiguity (9):** قال المصنف, متن, حاشية, أقول, قلت, الراجح عندي, يظهر لي, في الأصل, هكذا في المطبوع
- **Medium ambiguity (4):** قال رحمه الله, ص, ش, ط (Turra)
- **High ambiguity (2):** قوله (requires state-tracking), انظر (positional context needed)
- This catalog extends our current `arabic-scholarly-conventions.md` with ambiguity ratings and disambiguation rules

### Phase 3: Genre-Specific Layer Topologies
| Family | Layer Ratio | Key Challenge | Detection Strategy |
|---|---|---|---|
| Fiqh sharh | 1:10-20 Matn:Sharh | Aggressive qala/aqulu interleaving | State machine + qawluhu tracking |
| Hadith sharh | Variable | Isnad vs commentary confusion | Bab heading → isnad isolation → sharh parse |
| Nahw sharh | Verse:prose | Matn is poetry (nazm) | Metrical detection isolates verses |
| Tafsir | Ayah-anchored | Fixed external structure | String-match against Quranic corpus |
| Qira'at | Bayt-anchored | 1,173-line poem + commentary | Verse as atomic unit |
| Mantiq/Kalam | Dialectical | Hypothetical argument tracking | "fa-in qila / qulna" markers |

### Phase 4: Computational Architecture
- **Hybrid approach:** Rule-based (OpenITI mARkdown, regex, state machines) → ML fallback (AraBERT-CRF sequence labeling) → Dependency graph (indivisible unit enforcement)
- **OpenITI mARkdown:** Lightweight markup for Islamicate texts. Tags: `#~#` for edited text, `#*#` for annotations. passim algorithm for text reuse detection.
- **AraBERT + CRF:** Transformer contextual embeddings distinguish classical Arabic century-by-century. CRF layer enforces sequential state coherence.
- **Cross-domain parallels:** Talmudic layer detection (ML confirms Rashi's insights), Sanskrit sandhi segmentation (GraphCRF + finite-state transducers), Biblical chiasmus detection (neural embeddings for structural heuristics)

### Phase 5: Detection Architecture (Pseudocode)
Complete StratigraphyPipeline class with:
- Publisher/genre profile loading
- Genre-specific fast paths (nazm detection for Nahw, Quranic corpus matching for Tafsir)
- State machine for explicit markers (0.98 confidence)
- ML fallback for ambiguous text (confidence varies)
- Indivisible Unit Dependency Graph (recursive parent traversal for excerpting)
- Metadata schema: segment_id, text_content, layer_type, author_name, author_century, dependency_id, confidence_score

## Implementation Plan

### Step 1: Archive DR22 ✓

### Step 2: Update NEXT.md
Reference DR22 as the technical blueprint for multi-layer handling. This informs Phase 1 assembly (text layer rebasing) and the Tier 2/3 books in the 40-book manifest.

### Step 3: Update arabic-scholarly-conventions.md
Extend the existing marker rules with DR22's ambiguity ratings. Add the publisher-specific profile concept.

### Step 4: Commit + Push

## What This Does NOT Include (Deferred to Implementation Sessions)
- Building the actual StratigraphyPipeline (this is a major implementation effort)
- Training AraBERT-CRF (requires annotated training data from multi-layer books)
- Publisher profile configuration files (requires processing actual Shamela HTML per publisher)
- Integration with existing phase1_assembly.py layer rebasing code

## Verification
- [ ] DR22 archived
- [ ] NEXT.md references DR22
- [ ] Committed and pushed
