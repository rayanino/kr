# Plan: Source Engine Pre-Step-4 Hardening

**Context:** Comprehensive audit of source engine after BUG-01 through BUG-05 fixes. Goal: make the engine bulletproof before 200-book Step 4. Found 0 critical crash bugs, but significant test coverage gaps and 2 code-level improvements needed.

---

## Summary of Findings

**False positive from audit:** P-01 (confidence_scores.genre None crash) is NOT a bug — `genre: float` is required, not Optional, and `_build_confidence_scores` defaults to 0.5.

**Real issues:**
1. **Zero test coverage for check 5f** (tahqiq-note override) — the entire BUG-03 fix is untested
2. **Zero test coverage for death_date_source** determination (BUG-04)
3. **death_date_source is free-form string** — should be constrained
4. **school_affiliations multi-entry behavior untested** (BUG-01 edge case)
5. **BUG-05 new warning path untested** for needs_review semantics

**Pre-existing issues (documented, not fixing now):**
- Check 5d prior_sources not wired (by design, deferred to Phase D)
- Orphaned frozen files on validation failure (major refactor, not this session)
- TOCTOU window in WAL (documented, near-zero probability)

---

## 1. Add tests for check 5f — tahqiq-note override (BUG-03)

**File:** `engines/source/tests/test_validation.py`

Add `TestTahqiqNoteOverride` class after `TestAutoCorrectChain` (after line 287):

**(a)** `test_tahqiq_only_layers_clears_ml` — `is_multi_layer=True`, `text_layers=[{matn}, {tahqiq_note}]` → is_multi_layer set to False, text_layers cleared to []

**(b)** `test_sharh_layer_prevents_override` — `is_multi_layer=True`, `text_layers=[{matn}, {sharh}]` → is_multi_layer stays True (sharh is a real commentary layer)

**(c)** `test_matn_only_still_overrides` — `is_multi_layer=True`, `text_layers=[{matn}]` → is_multi_layer set to False (matn alone is subset of {matn, tahqiq_note})

**(d)** `test_5e_then_5f_chain` — `genre="sharh"`, `is_multi_layer=False`, `text_layers=[{matn}, {tahqiq_note}]` → check 5e sets ML=True, then check 5f overrides back to False. Verify both corrections produce warnings.

---

## 2. Add tests for death_date_source determination (BUG-04)

**File:** `engines/source/tests/test_metadata_inference.py`

Add `TestDeathDateSource` class. These test the determination logic directly without making LLM calls. Need to check if there's a way to test just the determination block...

Actually, death_date_source is set inside `infer_metadata()` after LLM calls. To test it without LLM calls, I need to either:
- Extract the determination logic into a standalone function (better testability)
- Or test it via integration with mocked inference

**Approach:** Extract `_determine_death_date_source(death_date: Optional[int], extracted: dict) -> str` from `infer_metadata()` and test it directly.

**File:** `engines/source/src/metadata_inference.py` (extract function)

Then add 4 test cases:
- `test_absent` — death_date=None → "absent"
- `test_author_raw_text` — death_date=911, author_raw="السيوطي (ت 911هـ)" → "author_raw_text"
- `test_extraction` — death_date=911, author_raw="السيوطي", edition_raw="911هـ" → "extraction"
- `test_inference` — death_date=911, none of the fields contain "911" → "inference"

---

## 3. Constrain death_date_source type

**File:** `engines/source/contracts.py`

Change `death_date_source: Optional[str]` to use a `Literal` type (lighter than a full enum, fits the 4 known values from BUG-04):

```python
from typing import Literal

DeathDateSourceType = Literal["extraction", "author_raw_text", "inference", "absent"]

# In ScholarAuthorityRecord:
death_date_source: Optional[DeathDateSourceType] = Field(None, ...)
```

Update `metadata_inference.py` to use the same type on `MetadataInferenceResult.death_date_source`.

---

## 4. Add test for school_affiliations multi-entry (BUG-01 edge case)

**File:** `engines/source/tests/test_registries.py`

Add test after the existing auto-link test (~line 234):

`test_new_record_stores_full_school_affiliations` — register a new author with `school_affiliations={"fiqh": "شافعي", "usul": "شافعي"}`. Verify the stored record has the full dict, not just `{"primary": "شافعي"}`.

---

## 5. Robustify death_date_source substring matching

**File:** `engines/source/src/metadata_inference.py`

The current `str(death_date) in str(val)` has two minor issues:
- `str(extracted.get(f, ""))` returns `str(None)` = `"None"` when field exists but is None
- Substring match could false-positive on partial number matches

Fix the None handling:
```python
# Before:
if str(death_date) in str(author_raw):
# After:
if author_raw and str(death_date) in str(author_raw):
```

And for the extraction fields loop:
```python
# Before:
elif any(str(death_date) in str(extracted.get(f, "")) for f in (...)):
# After:
elif any(
    (val := extracted.get(f)) is not None and str(death_date) in str(val)
    for f in (...)
):
```

---

## Files Modified

| File | Changes |
|------|---------|
| `engines/source/contracts.py` | `death_date_source` → `Literal[...]` type |
| `engines/source/src/metadata_inference.py` | Extract `_determine_death_date_source()`, fix None handling |
| `engines/source/tests/test_validation.py` | +4 tests: check 5f tahqiq-note override |
| `engines/source/tests/test_metadata_inference.py` | +4 tests: death_date_source determination |
| `engines/source/tests/test_registries.py` | +1 test: school_affiliations multi-entry storage |

---

## Verification

```bash
python -m pytest engines/source/tests/ -v --tb=short && python -m pytest shared/*/tests/ -q
```
