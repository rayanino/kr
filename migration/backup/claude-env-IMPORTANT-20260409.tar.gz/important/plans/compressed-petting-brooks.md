# Weekend Sprint v2: Parallel Exhaustive Autonomous System

## Context

User has 90% remaining on Max 20x plan + 2x weekend bonus (~180M+ tokens available). The 55-task sequential system (v1) would burn ~10-20% at best. Need parallel execution + 3x task count to genuinely exhaust usage.

**User direction:** Focus on work NOT done in day-sessions — extensive bughunting, edge case testing (generate mock cases and run them), exhaustive probing. Day sessions are architect-driven (discuss → relay); overnight should be the exhaustive mechanical work a human wouldn't sit through.

**5-engine pipeline:** Source ✅ → Normalization ✅ → Excerpting ✅ → Taxonomy 🔶 → Synthesis 🔶
Passaging/atomization are STALE. Excerpting src/ is under CLI transformation (don't modify, CAN test contracts/outputs).

---

## Architecture: 4-Worker Parallel System

```
scripts/weekend_parallel.py (coordinator)
├── ReadonlyPool (3 concurrent `claude -p` processes)
│   ├── Worker A ─── analysis/bughunt/research tasks
│   ├── Worker B ─── analysis/bughunt/research tasks
│   └── Worker C ─── analysis/bughunt/research tasks
│   (no git ops, write to overnight/results/{task_id}/ only)
│
├── WriteWorker (1 orchestrator instance, sequential)
│   └── overnight_orchestrator.py --manifest sprint_write.json
│   (creates new test files, scripts — uses L1-L5 gates)
│
├── TaskRouter (splits manifest into readonly vs write queues)
├── ProgressTracker (monitors all 4 workers, prints dashboard)
└── ReportAggregator (combines all results at end)
```

**Why this works:**
- Readonly tasks (sprint_analysis) are isolated — each writes to its own `overnight/results/{task_id}/` directory. No git conflicts. 3 can run simultaneously.
- Write tasks (sprint_test, sprint_script) modify the repo — must be sequential. The existing orchestrator handles this with quality gates.
- 4 workers × ~40 tasks each = ~160 tasks. Each uses 300K-800K tokens → 50-130M tokens total. Much closer to exhausting quota.

---

## What's Already Built (v1)

These are DONE and just need to be kept:
- ✅ `overnight_orchestrator.py` — 3 sprint safety prompts + category routing + excerpting protection
- ✅ `overnight/sprint_manifest.json` — 55 tasks (will be expanded to 150+)
- ✅ `scripts/start_sprint.sh` — launcher (will be updated for parallel mode)

---

## Implementation Steps

### Step 1: Build `scripts/weekend_parallel.py` (~250 lines)

The parallel coordinator. Key components:

```python
class ReadonlyWorker:
    """Runs a single readonly task via claude -p."""
    def execute(task_id, prompt, model, timeout, safety_prompt) -> result

class ReadonlyPool:
    """Manages N concurrent ReadonlyWorkers."""
    def __init__(self, max_workers=3)
    def submit(task) -> future
    def drain() -> list[results]  # wait for all to complete

class ParallelCoordinator:
    """Splits manifest, launches pools, tracks progress."""
    def __init__(self, manifest_path, hours, max_workers)
    def run():
        readonly_tasks, write_tasks = split_manifest()
        # Start write orchestrator as subprocess
        write_proc = launch_write_orchestrator(write_tasks)
        # Run readonly tasks through pool
        pool = ReadonlyPool(max_workers=3)
        for task in readonly_tasks:
            pool.submit(task)
        # Wait for both to complete
        pool.drain()
        write_proc.wait()
        # Aggregate results
        generate_report()
```

Each readonly worker:
1. Creates `overnight/results/{task_id}/` directory
2. Runs `claude -p "{prompt}" --model {model} --dangerously-skip-permissions --append-system-prompt "{safety}" --max-turns {turns} --output-format json`
3. Captures output, writes to results dir
4. Reports success/failure

Write orchestrator: runs the existing `overnight_orchestrator.py` with a write-tasks-only manifest.

### Step 2: Expand Manifest from 55 → 150+ Tasks

**New task categories (focused on what day-sessions DON'T do):**

#### A. Source Engine Bug Hunting (10 tasks, readonly)
Deep code review of each source module looking for:
- Off-by-one errors, None handling gaps, Arabic string safety
- Silent data loss (catch-and-continue patterns)
- Type coercion issues, regex \d bugs

Tasks: `bughunt-source-trust`, `bughunt-source-dedup`, `bughunt-source-freezer`, `bughunt-source-metadata`, `bughunt-source-consensus`, `bughunt-source-validation`, `bughunt-source-config`, `bughunt-source-errors`, `bughunt-source-io`, `bughunt-source-encoding`

#### B. Normalization Engine Bug Hunting (12 tasks, readonly)
Same deep code review approach:

Tasks: `bughunt-norm-shamela`, `bughunt-norm-structure`, `bughunt-norm-layers`, `bughunt-norm-boundary`, `bughunt-norm-content-flags`, `bughunt-norm-writer`, `bughunt-norm-plain-text`, `bughunt-norm-footnotes`, `bughunt-norm-validation`, `bughunt-norm-headings`, `bughunt-norm-dispatch`, `bughunt-norm-errors`

#### C. Excerpting Engine Bug Hunting (8 tasks, readonly)
Can review code but NOT modify. Focus on finding bugs for the day-session to fix:

Tasks: `bughunt-exc-phase1`, `bughunt-exc-phase2-classify`, `bughunt-exc-phase2-group`, `bughunt-exc-phase3-det`, `bughunt-exc-phase3-enrich`, `bughunt-exc-phase3-consensus`, `bughunt-exc-phase3-validation`, `bughunt-exc-writer`

#### D. Arabic Text Edge Case Generation (12 tasks, write — generates test files)
Generate and run edge cases through existing code:

Tasks: `edgecase-hamza-variants`, `edgecase-taa-marbuta`, `edgecase-alef-variations`, `edgecase-shadda-stacking`, `edgecase-tatweel-positions`, `edgecase-mixed-bidi`, `edgecase-arabic-digits`, `edgecase-presentation-forms`, `edgecase-diacritic-combinations`, `edgecase-lam-alef-ligature`, `edgecase-quran-marks`, `edgecase-zero-width-chars`

#### E. Contract Exhaustion Tests (8 tasks, write)
For each Pydantic model: test every field at every boundary, generate valid/invalid instances:

Tasks: `exhaust-source-contracts`, `exhaust-norm-contracts`, `exhaust-exc-contracts`, `exhaust-taxonomy-contracts`, `exhaust-synthesis-contracts`, `exhaust-shared-consensus-contracts`, `exhaust-shared-gate-contracts`, `exhaust-shared-scholar-contracts`

#### F. Existing v1 tasks (55 tasks — already built)
Keep all 55 from the current sprint_manifest.json.

**Total: 55 + 10 + 12 + 8 + 12 + 8 = 105 new tasks → 160 total**

### Step 3: Build Task Generator

**File:** `scripts/generate_sprint_tasks.py`

Reads engine source files and programmatically generates bughunt task prompts. For each source file:
1. Reads the file to get function names and line counts
2. Generates a bughunt prompt: "Review {file} lines {start}-{end}, looking for: [specific bug patterns]"
3. Outputs task JSON

This makes the manifest reproducible and extensible.

### Step 4: Update Launch Script

Modify `scripts/start_sprint.sh` to call `weekend_parallel.py` instead of the orchestrator directly.

### Step 5: Test & Launch

```bash
# Dry run
python scripts/weekend_parallel.py --manifest overnight/sprint_manifest.json --dry-run

# Launch (4 workers, 20 hours)
python scripts/weekend_parallel.py --manifest overnight/sprint_manifest.json --hours 20 --workers 4
```

---

## Task Design: What Makes a Good Bughunt Task

Each bughunt task follows this structure:

```
BUGHUNT — {module_name}

Read {file_path} carefully, line by line. You are looking for REAL BUGS, not style issues.

CHECK FOR THESE BUG PATTERNS:
1. None/null handling: Are there any code paths where a None value would cause
   an AttributeError or TypeError? Check every .attribute access and function call.
2. Arabic string safety: Any use of .lower(), .upper(), .strip() on Arabic text?
   Any regex using \d (matches Arabic-Indic digits) instead of [0-9]?
3. Off-by-one: Any range(), slice, or index operations that might be off by 1?
4. Silent data loss: Any except blocks that catch and continue without logging?
   Any conditional returns that silently drop data?
5. Type coercion: Any int()/float() calls on user-provided strings without validation?
6. File I/O: Any file operations without proper encoding specification?
   Any file writes without atomic write patterns?
7. D-023 violations: Any function that transforms data but drops upstream fields?

For EVERY potential bug found:
- Quote the exact code (file:line)
- Explain why it's a bug
- Describe the trigger condition
- Rate severity: CRITICAL / HIGH / MEDIUM / LOW
- Suggest a fix

Write overnight/results/{task_id}/findings.md with all findings.
Write overnight/results/{task_id}/findings.json: {"bugs_found": N, "critical": N, "high": N}
```

---

## Safety Mechanisms

Same as v1, plus:
- **Worker isolation**: Readonly workers never touch git. Write worker uses existing L1-L5 gates.
- **Process monitoring**: Coordinator checks heartbeat every 60s. Kill stuck processes after timeout.
- **Graceful shutdown**: SIGINT handler stops spawning new tasks, waits for running tasks to complete.
- **Budget tracking**: Track tokens consumed per worker via CLI output parsing.

---

## Critical Files

| File | Action | Purpose |
|------|--------|---------|
| `scripts/weekend_parallel.py` | Create (~250 lines) | Parallel coordinator |
| `scripts/generate_sprint_tasks.py` | Create (~200 lines) | Bughunt task generator |
| `overnight/sprint_manifest.json` | Expand (55 → 160 tasks) | Full task catalog |
| `scripts/start_sprint.sh` | Update | Point to parallel launcher |
| `scripts/overnight_orchestrator.py` | Already modified | Sprint prompts (done) |

---

## Codex Review Fixes (Pre-Launch Hardening)

Codex review found 11 issues. Here's the fix plan for each:

### MUST FIX (blocks launch)

**1. CRITICAL — Rollback destroys untracked files** (`overnight_orchestrator.py:371-384`)
- `git_rollback()` uses `reset --hard` + `clean -fd`, destroying new untracked files
- **Fix:** Commit all sprint files before launching. Then `clean -fd --exclude=overnight/ --exclude=scripts/weekend_* --exclude=scripts/generate_sprint* --exclude=scripts/review_* --exclude=scripts/merge_*`
- **OR:** Modify `git_rollback()` to exclude sprint files from clean

**2. HIGH — Readonly workers have Bash access** (`weekend_parallel.py:183-195`)
- **Fix:** Remove `Bash` from readonly task `allowed_tools` in `generate_sprint_tasks.py:make_task()`. Use `["Read", "Glob", "Grep"]` only. Bughunts and analysis don't need Bash.
- Exception: tasks that run scripts (verify-metadata-flow, verify-regression) need Bash — keep those as sprint_analysis but override tools.

**3. HIGH — No deadline enforcement for readonly pool** (`weekend_parallel.py:398-408`)
- **Fix:** Submit tasks incrementally (batch of `max_workers`), check deadline before each batch. Add `cancel()` on remaining futures when deadline hit.

**4. HIGH — Excerpting write tasks exist** (exhaust-excerpting, test-cross-boundary-n-e)
- **Fix:** Remove `exhaust-excerpting` from manifest. Move `test-cross-boundary-n-e` test file to `tests/` (not `engines/excerpting/tests/`). Add `engines/excerpting/` to L2 protection (not just `engines/excerpting/src/`).

**5. MEDIUM — Edge case test paths conflict with safety prompt** (write to `tests/` root)
- **Fix:** Move all edge case test files from `tests/test_edgecase_*.py` to `engines/source/tests/test_edgecase_*.py` or `shared/tests/test_edgecase_*.py`.

### SHOULD FIX (improves quality)

**6. HIGH — Readonly/write share mutable worktree**
- **Accept risk:** Full worktree isolation is complex. Mitigate by having readonly tasks note "analyzed at commit {hash}" in findings. The write worker changes are small (new test files) — unlikely to affect analysis results.

**7. MEDIUM — Bughunt prompts too broad, excerpting ones contradictory**
- **Fix:** Remove "Suggest a concrete fix" from excerpting bughunt prompts. Add "Read the module's existing tests before reviewing" to all bughunt prompts.

**8. MEDIUM — Contract exhaustion targets wrong files for shared modules**
- **Fix:** Point shared contract tasks at the actual models (imported from `engines/source/contracts.py`), not the service files.

**9. MEDIUM — max_turns not forwarded** (`weekend_parallel.py:183-197`)
- **Fix:** Add `--max-turns` to the claude -p command in `execute_readonly_task()`.

### DEFER (low risk)

**10. LOW — Dashboard doesn't show write progress** — Accept. User can check orchestrator output log.
**11. MEDIUM — python3 vs python on Windows** — Already works via Git Bash. Task prompts use `python -m pytest` which is correct.

---

## CC Review Fixes (3 additional)

**B-1: Cross-queue dependency bug** — 4 validation test tasks depend on `validation-spec-review` (readonly pool) but live in write queue. Write orchestrator never sees readonly completions → tasks orphaned.
- **Fix:** Remove `depends_on` from these 4 tasks in manifest. Set to `[]`.

**B-2: No budget cap on readonly workers** — All readonly tasks have `max_budget_usd: 0`, so no `--max-budget-usd` flag passed. Runaway tasks run unbounded.
- **Fix:** Add `effective_budget = max(task.max_budget_usd, 5.0)` and always pass `--max-budget-usd`.

**B-3: Bookend tasks in parallel pool** — `verify-regression` (bookend) could run pytest while write worker commits. False failures.
- **Fix:** Split bookend tasks out, run sequentially after pool completes.

**CC also recommended:** Start with `--workers 2` to avoid rate limits, increase if no 429s in first hour.

## Review & Verification Status

| Reviewer | Verdict | Findings | Fixes Applied |
|----------|---------|----------|---------------|
| Codex | 11 findings (1 CRITICAL, 5 HIGH) | All addressed | Yes |
| Claude Code | 3 blocking + 8 non-blocking | All 3 blocking fixed | Yes |
| Gemini | "Architecturally sound" | 1 budget logic tweak | Yes |
| Smoke test | 1 real task ran 19min | 150 stale refs found | N/A — verified |

## LIVE ANALYSIS — Sprint at 70 Minutes (2026-03-28 18:03 UTC)

### Performance Metrics

| Metric | Value | Assessment |
|--------|-------|------------|
| Elapsed | 70 min | 6% of 20h budget |
| Tasks completed | 10/104 | 10% (on track) |
| Readonly done | 7/53 (2 timeout) | ~7.8 tasks/hour |
| Write done | 2/51 | ~1.7 tasks/hour |
| Tests added | 31 (all passing) | High quality |
| Bugs found | 19 (1 HIGH) | Finding real bugs |
| Commits | 3 | Clean commit history |
| Write cost | $5.00 | Budget-constrained (now fixed to $15) |

### Throughput Projection
- Readonly: 53 tasks ÷ 7.8/hour = ~6.8 hours (with 3 workers)
- Write: 51 tasks ÷ 1.7/hour = ~30 hours (exceeds 20h deadline)
- **Bottleneck**: Write worker. Only ~34 of 51 write tasks will complete in 20 hours.
- **Mitigation**: Tasks sorted by priority, so highest-value work runs first.

### Quality Assessment

**Bughunt quality: EXCELLENT** — Found a real HIGH-severity bug in excerpting engine:
- BUG-1: Footnotes silently lost in split chunks (`phase1_assembly.py:772,800`)
- BUG-2: Split point selection picks first heading, not nearest to midpoint
- Both with exact line numbers, trigger conditions, impact analysis, and fixes

**Analysis quality: EXCELLENT** — 591-line validation review, 274-line bughunt, 84-line core extraction.

**Test quality: EXCELLENT** — 31 new tests, ALL passing, testing genuine edge cases (hamza variants, taa marbuta, diacritics, honorifics, symmetry).

### Issues Found Live

1. **Timeout calibration off**: 2/9 readonly tasks timed out (22%). `audit-stale-artifacts` had 20m (needed 30m), `contract-sync-audit` had 30m (needed 45m).
2. **Write budget too low**: First task hit $5 cap after 132 turns. Fixed live to $15.
3. **Findings.json schema inconsistent**: Some tasks produce `{"bugs_found": N}`, others produce `{"tests_added": N}`, others produce nested objects. Dashboard counts unreliable.
4. **Write orchestrator state lag**: State file shows 1 result but git has 2 commits.

### What's Working for "Always-On"
- Readonly pool batch scheduling with deadline enforcement
- Bookend task separation
- Safety prompts preventing file modification
- Quality gate catching broken commits
- Real bugs being found autonomously

### What Needs Fixing for "Always-On"

**P0 — Blocks reliability:**
1. Auto-retry for timed-out tasks (with 1.5x timeout increase)
2. Task recycling — when all tasks done, regenerate new work automatically
3. Standardized findings.json schema (enforce with a validator)
4. Graceful handoff — detect day-session activity, pause write worker

**P1 — Important for quality:**
5. Dynamic timeout calibration (track avg duration per category, set timeout at 2x)
6. Git conflict detection before each write task
7. Per-task cost tracking for readonly pool (currently $0 because Max subscription)
8. Cross-session persistence — resume from last state after restart

**P2 — Nice to have:**
9. Slack/email alert when CRITICAL/HIGH bug found
10. Priority re-ranking based on findings (bughunt finds critical → prioritize that module)
11. Learning loop — which bughunt patterns yield real bugs → weight those patterns higher
12. HTML dashboard (richer than terminal)

## Verification

```bash
# 1. Commit all sprint files first (prevents Codex CRITICAL rollback issue)
git add scripts/weekend_parallel.py scripts/generate_sprint_tasks.py scripts/start_sprint.sh scripts/review_sprint_cc.sh scripts/review_sprint_codex.sh scripts/merge_sprint_reviews.sh overnight/sprint_manifest.json
git commit -m "weekend: feat(sprint): parallel autonomous sprint system (104 tasks, 3+1 workers)"

# 2. Verify fixes
PYTHONIOENCODING=utf-8 python scripts/weekend_parallel.py --manifest overnight/sprint_manifest.json --dry-run

# 3. Full launch (start conservative: 2 workers)
bash scripts/start_sprint.sh --workers 2
```
