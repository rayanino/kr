# Plan: KR Working Environment Optimization

## Context

The KR project has a mature, well-designed Claude Code environment (7 skills, 6 agents, 10 commands, 3 hooks, 4 rules). However, after auditing the full setup against the current workflow (Phase C evaluation sessions), three categories of waste emerged:

1. **Dead-weight MCP servers** — ~60 deferred tools from 5 irrelevant MCPs add tool selection noise
2. **Manual workflows** that consume 60-90 min/session (result inventory, scholarly verification, context reload)
3. **Enforcement gaps** — Arabic safety hook warns but doesn't block; result preservation is policy, not rule

External sources audited (AGENTS-COLLECTION with 784 agents, aitmpl.com catalog) contain generic engineering agents. None match KR's specialized domain needs. The value is in structural patterns (multi-agent teams, phase workflows), not in importing generic agents. KR's existing tooling is more specialized and higher quality than anything available externally — the optimization should create KR-specific tools, not import generic ones.

---

## Part 1: REMOVE Dead Weight

### 1a. Document MCP Cleanup for Manual Action

> **Cannot be done from project config** — MCPs are global. Create a reference file the user can follow.

**Create:** `.claude/MCP_CLEANUP.md`

Content: instructions to disable 5 irrelevant MCP servers in global Claude settings:

| MCP | Tools | Why Remove |
|-----|-------|-----------|
| DeepGraph Next.js | 6 | KR is Python, not Next.js |
| DeepGraph React | 6 | KR is Python, not React |
| playwright-server | 25 | Redundant — keep executeautomation-playwright only |
| automatalabs-playwright | 10 | Redundant — keep executeautomation-playwright only |
| chrome-devtools | 25 | Redundant — keep executeautomation-playwright only |
| Exa search | 2 | Redundant with Tavily for scholarly content |

**Impact:** ~74 fewer deferred tools in the selection space.

---

## Part 2: CREATE New Tools (3 agents, 1 skill, 1 command, 1 rule)

### 2a. Agent: `scholarly-verifier` (HIGH PRIORITY)

**File:** `.claude/agents/scholarly-verifier.md`
**Pattern:** Follow `researcher.md` (opus, WebSearch+WebFetch, structured report output)

```yaml
---
name: scholarly-verifier
description: Verifies scholarly claims (author, death date, genre, science, attribution) against external sources. Use during Phase C/D/E evaluation to validate pipeline output.
tools: Bash, WebSearch, WebFetch, Read, Grep, Glob
model: opus
---
```

**Body content (key sections):**

1. **Input:** Book name (Arabic directory name from `tests/results/source_engine/phase_c/`)
2. **Evidence hierarchy** (most to least authoritative):
   - Usul.ai / OpenITI (independent scholarly DB)
   - Shamela.ws book page (primary for this corpus)
   - ketabonline.com, islamport.com (secondary aggregators — same ecosystem, count as 1)
   - Arabic Wikipedia, Marefa.org (encyclopedias)
   - General web (last resort)
3. **Per-book workflow:**
   - Read `result.json` for status, genre, science_scope, is_multi_layer, attribution
   - Read `llm_responses/claude_opus_4_6.json` for author name, death_date_hijri, author_identification_confidence (NOT result.json — always 1.0 due to registry bug, per Errata #4)
   - Read `extraction.json` for shamela_category, author_name_raw, author_death_hijri (distinguish pass-through from inference)
   - If extraction death_date == LLM death_date: mark "pass-through" not real inference
   - Run 2-3 web searches: `"{title}" shamela.ws`, `"{author}" death site:ar.wikipedia.org`, `"{title}" genre`
   - web_fetch 1+ URLs for direct evidence
   - Cross-check shamela_category against pipeline genre
4. **Output format:** Match PHASE_C_SESSION1_REPORT.md verdict structure exactly
5. **Rules:**
   - Search BEFORE verdict (M-1)
   - Check which model file exists per book (command_a.json vs gpt_5_4.json) per Errata #1
   - Read author conf from llm_responses only per Errata #4
   - Filename is `claude_opus_4_6.json` per Errata #2
   - Gate_abort books: read LLM responses directly, not result.json
   - For ML: if layer_type="tahqiq_note" on non-sharh book, FLAG as Opus bias per Errata #9
   - Require 2+ genuinely independent non-Shamela-ecosystem sources for VERIFIED per Errata #8 rule 8

**Why opus:** Domain knowledge needed to judge attribution disputes and genre boundaries.

---

### 2b. Agent: `result-analyst` (HIGH PRIORITY)

**File:** `.claude/agents/result-analyst.md`
**Pattern:** Follow `integrity-checker.md` (sonnet, Read+Bash+Glob+Grep, structured table output)

```yaml
---
name: result-analyst
description: Analyzes Phase C/D/E test results — aggregates status, finds model disagreements, tracks cost, inventories books by evaluation state. Use at session start for orientation.
tools: Read, Bash, Glob, Grep
model: sonnet
---
```

**Body content (4 modes):**

1. **Dashboard mode** (default, no args):
   - Read COST_LOG.json: total spend vs 100 EUR budget
   - Read PHASE_C_MANIFEST.json: success/gate_abort/error counts
   - Count session reports: `PHASE_C_SESSION*_REPORT.md`
   - Count verdicts across reports: grep for `Verdict:`
   - Output compact table

2. **Disagreement mode** (arg: "disagreements"):
   - Read each book's consensus.json where `agreed=false`
   - For agreed=true books: compare field-by-field between both LLM responses
   - Group by disagreement type (name-format vs substantive)

3. **Session prep mode** (arg: "session N"):
   - List books for session N from NEXT.md
   - Per book: read result.json status, consensus.json agreement, sanity_checks.json flags
   - Show pre-identified risks from strategic analysis
   - Suggest evaluation order (disagreements first)

4. **Output:** Always structured tables, never prose.

**Why sonnet:** Data aggregation, no domain reasoning needed. Token-efficient for frequent invocation.

---

### 2c. Skill: `evaluation-methodology` (HIGH PRIORITY)

**File:** `.claude/skills/evaluation-methodology/SKILL.md`

```yaml
---
name: evaluation-methodology
description: Complete Phase C/D/E evaluation protocol with all errata corrections. Use when evaluating any book's pipeline results. Prevents methodology drift across sessions.
---
```

**Body content — distill from these sources into a single authoritative reference:**
- `PHASE_C_EVALUATION_FRAMEWORK.md` (the base protocol)
- `PHASE_C_ERRATA.md` (12 corrections from calibration + Session 1)
- `PHASE_C_SESSION1_STRATEGIC_ANALYSIS.md` (predictions to test)
- `NEXT.md` (session-specific methodology fixes)

**Key sections to include:**

1. **Six methodology rules** (M-1 through M-6):
   - M-1: Search BEFORE verdict, never after, never skip
   - M-2: web_fetch 1+ URL per book for direct evidence
   - M-3: shamela_category cross-check on every verdict
   - M-4: Distinguish death-date pass-through vs inference (extraction.json vs LLM)
   - M-5: Check model source per book (command_a.json vs gpt_5_4.json)
   - M-6: Session-end consistency check as separate pass

2. **File path corrections** (from errata):
   - Opus: `claude_opus_4_6.json` not `opus_4_6.json`
   - Author confidence: llm_responses ONLY, not result.json
   - Skip framework Section 7 entirely (0/73 single-model)

3. **Corrected field source table** (from Errata #5 — exact JSON paths per field per status)

4. **Verdict decision tree:**
   - VERIFIED: 2+ genuinely independent non-ecosystem sources
   - PLAUSIBLE: 1 source confirms OR reasonable but unverifiable
   - FLAG: material discrepancy or no evidence

5. **Anti-patterns:**
   - Circular verification (Shamela ecosystem = 1 source)
   - Confidence inflation (LLM gives 0.99 for everything)
   - Edition confusion (same work, different editions must agree)
   - Tahqiq-as-layer bias (Opus over-extends ML for tahqiq notes)

6. **Gate abort protocol:** Don't skip. Read LLM responses directly. 98% false positive rate from sparse registry.

---

### 2d. Command: `/phase-status` (MEDIUM-HIGH)

**File:** `.claude/commands/phase-status.md`

```yaml
---
description: Instant dashboard of current phase progress — books processed, verdicts, cost, pending work.
allowed-tools: Bash(cat:*), Bash(ls:*), Bash(wc:*), Bash(find:*), Read, Glob, Grep
---
```

**Steps:**
1. Read `tests/results/source_engine/COST_LOG.json` — per-phase cost + total vs 100 EUR
2. Count book directories in `tests/results/source_engine/phase_c/` (minus non-book files)
3. Read `PHASE_C_SUMMARY.json` — success/gate_abort/error
4. List session reports: glob `PHASE_C_SESSION*_REPORT.md`
5. Count verdicts: grep `Verdict:` across all session reports
6. Read first 15 lines of NEXT.md for current session assignment
7. Output compact dashboard:
   ```
   === PHASE C STATUS ===
   Books: 73 processed (22 success, 51 gate_abort)
   Cost: 9.2 / 100.0 EUR (9.2%)
   Sessions: 1/7 complete | 14 verdicts issued
   Current: Session 2 — 8 books
   Risks: [count from NEXT.md pre-identified risks]
   ```

---

### 2e. Rule: `result-preservation.md` (MEDIUM)

**File:** `.claude/rules/result-preservation.md`

```yaml
---
globs: ["scripts/run_phase_*.py", "engines/*/src/**/*.py", "shared/*/src/**/*.py"]
---
```

**Content (6 imperatives):**
- Every LLM API call MUST persist full output to `tests/results/source_engine/{phase}/`. Never discard raw responses.
- Before making an API call, check PHASE_X_MANIFEST.json. If `needs_rerun: false`, SKIP the call.
- Per-book structure: result.json, extraction.json, llm_responses/{model}.json, consensus.json, sanity_checks.json.
- After each phase: produce PHASE_X_SUMMARY.json, PHASE_X_MANIFEST.json, PHASE_X_LESSONS.md.
- Bug fixes: set `needs_rerun: true` ONLY for affected books — never blanket re-run.
- Update COST_LOG.json after every API-calling script run.

---

## Part 3: ENHANCE Existing Tools

### 3a. Arabic Safety Hook — Make Check 1 Blocking

**File:** `.claude/hooks/arabic-safety-check.sh` (modify)
**Pattern:** Reuse existing Check 3 Arabic detection logic for Check 1 blocking.

**Change:** After the existing Check 1 grep finds `.lower()`/`.upper()` without `# safe:`, add Arabic content detection. If the file contains Arabic (U+0600–U+06FF), exit 1 instead of just warning.

**Specific edit** — replace the current Check 1 block (lines 21-25) with:

```bash
# Check 1: .lower()/.upper() — BLOCKING when file contains Arabic text
LOWER_UPPER=$(grep -nE '\.(lower|upper)\(\)' "$FILE" 2>/dev/null | grep -v '#.*noqa' | grep -v '# safe:')
if [ -n "$LOWER_UPPER" ]; then
    HAS_ARABIC=$(python3 -c "import sys; sys.exit(0 if any('\u0600'<=c<='\u06FF' for line in open(sys.argv[1],encoding='utf-8',errors='ignore') for c in line) else 1)" "$FILE" 2>/dev/null && echo "yes" || echo "no")
    if [ "$HAS_ARABIC" = "yes" ]; then
        echo "BLOCKED: .lower()/.upper() in file with Arabic content." >&2
        echo "Arabic has no case — this WILL corrupt data. Add '# safe: reason' to bypass." >&2
        echo "$LOWER_UPPER" >&2
        exit 1
    else
        WARNINGS="${WARNINGS}WARNING: .lower()/.upper() found — verify this only applies to non-Arabic text.\n$(echo "$LOWER_UPPER" | head -3)\n\n"
    fi
fi
```

Checks 2-5 remain warnings (exit 0). Rationale: `.lower()` on Arabic is NEVER correct. The cost of a false block (add `# safe:` comment) is 5 seconds. The cost of missing it is silent data corruption.

---

### 3b. Enhanced `/catchup` Command

**File:** `.claude/commands/catchup.md` (modify)
**Change:** Add 3 steps after existing step 6:

```
7. Read `tests/results/source_engine/COST_LOG.json` — report budget status in one line.
8. If any PHASE_C_SESSION*_REPORT.md files exist, count verdicts issued so far.
9. Read `PHASE_C_ERRATA.md` first 5 lines — remind yourself of the correction titles before starting evaluation work.
```

Also add to allowed-tools: `Bash(wc:*), Bash(find:*)`

---

## Part 4: MCP Integration Notes

### Scholar Gateway MCP
- **Already available** as `mcp__claude_ai_Scholar_Gateway__semanticSearch`
- Searches modern peer-reviewed academic literature, NOT classical Islamic texts
- Useful for: finding modern scholarly analysis of classical texts (authorship disputes, genre debates)
- The `scholarly-verifier` agent should use it as a SECONDARY source alongside web search
- Not a primary source for death dates or basic metadata

### Context7 MCP
- **Already available** as `mcp__context7__resolve-library-id` + `query-docs`
- Useful during implementation sessions for Python library API lookup (pydantic, instructor, pytest)
- The `/research` command should mention Context7 as first step for library-specific questions

---

## Implementation Sequence

**Batch 1 (before Session 2 — highest impact):**
1. `scholarly-verifier` agent (2a)
2. `result-analyst` agent (2b)
3. `evaluation-methodology` skill (2c)

**Batch 2 (before Session 3):**
4. `/phase-status` command (2d)
5. Arabic safety hook upgrade (3a)
6. Enhanced `/catchup` (3b)

**Batch 3 (before Phase D):**
7. `result-preservation` rule (2e)
8. MCP cleanup doc (1a)

---

## Estimated Time Savings

| Tool | Current Cost | After | Savings/Session |
|------|-------------|-------|-----------------|
| scholarly-verifier | 20-30 min manual search/book | 5-8 min delegated | ~20 min (8-book session) |
| result-analyst | 30-45 min manual inventory | 2-3 min dashboard | ~35 min |
| evaluation-methodology | 10-15 min re-reading framework+errata | 0 min (loaded as skill) | ~12 min |
| /phase-status | 15-20 min context assembly | 1 min | ~17 min |
| Arabic hook blocking | Unpredictable (bugs found later) | 0 (blocked at write) | Prevents future debugging |

**Total: ~85 min/session across 6 remaining sessions = ~8.5 hours saved**

---

## Verification Plan

After implementation, verify each component:

1. **scholarly-verifier**: Invoke on a book from Session 1 (e.g., `الأربعون النووية`). Output should match the calibration verdict in PHASE_C_ERRATA.md #12.
2. **result-analyst**: Invoke dashboard mode. Verify counts match PHASE_C_SUMMARY.json. Invoke "session 2" mode — verify book list matches NEXT.md.
3. **evaluation-methodology**: Read the skill file and verify it includes all 12 errata corrections and all 6 methodology rules from NEXT.md.
4. **/phase-status**: Run the command. Verify cost, book count, and verdict count are accurate.
5. **Arabic hook**: Write a test `.py` file in `engines/source/src/` containing `.lower()` and Arabic text. Verify the hook blocks the write.
6. **Enhanced /catchup**: Run `/catchup`. Verify it now shows budget status and errata reminder.
7. **result-preservation rule**: Create a test script in `scripts/`. Verify the rule appears in context.

---

## What Was Explicitly NOT Recommended

- **Generic agents** from AGENTS-COLLECTION (784 agents audited — none match KR's domain)
- **codebase-memory-mcp** (analyzed in prior conversation turn — Serena covers 70% of features)
- **New MCP servers** (none found that address KR's actual bottlenecks)
- **Session orchestration** (KR's manual NEXT.md approach works well for single-engine sessions)
- **Knowledge graph MCP** for scholar data (would need schema unification with existing registries — premature)
- **aitmpl.com templates** (dynamic content; generic engineering templates not domain-relevant)
