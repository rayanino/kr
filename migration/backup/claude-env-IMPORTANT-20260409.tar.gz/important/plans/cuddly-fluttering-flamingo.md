# KR Operating Doctrine: April 9 - July 1, 2026

**Type:** Doctrine-setting review (read-only analysis)
**Scope:** 83-day autonomous operating period
**Fixed facts:** Codex authority starts Apr 9. Owner checks once/day. Claude Code + Gemini CLI Pro 3.1 are peer primary coworkers.

---

## 1. Recommended Operating Model

### The core problem

The Factory Roadmap v2 and Autonomous Quality System describe a sophisticated 6-mode factory (BUILD/HUNT/FIX/EVALUATE/CROSS-ENGINE/BENCHMARK) with Agent Teams, synthetic adversarial data, benchmarks, and a findings lifecycle. **None of it exists.** Zero factory directories. Zero factory scripts. Zero of 10 roadmap sessions completed. The only operational infrastructure is:

- `scripts/overnight_codex_orchestrator.py` (2,750 lines) — shadow mode, worktree branches, backlog-driven
- WSL bootstrap scripts — proven functional
- `AGENTS.md` and `GEMINI.md` — created but untested in production
- Backend proof — phases 1-3 work via CLI, consensus/verification blocked on Claude rate limits

Trying to build the full factory AND use it to operate simultaneously in 83 days is a recipe for fragile foundations. The doctrine must choose between ambition and stability.

### Recommended model: Disciplined Sequential Build

**Not autonomous factory operation. Structured workstream execution with daily checkpoints.**

The system operates in bounded work sessions (1.5h each, 2-3/day), drawing from a prioritized backlog. Each session produces a testable artifact. Quality gates run after every session. A daily report summarizes progress.

**Authority model:**
- **Codex runtime** is the execution environment (WSL clone, task scheduler, orchestrator)
- **Claude Code** is the primary builder (code implementation, test writing, SPEC execution)
- **Gemini CLI Pro 3.1** is the primary challenger (design review, adversarial checks, Arabic scholarly review)
- **Codex CLI (GPT-5.4)** handles code review and excerpting LLM calls
- All three are peers. No single tool's output is trusted alone.

**Work phases (sequential, gated):**

| Phase | Dates | Focus | Gate to advance |
|-------|-------|-------|-----------------|
| **A: Excerpting Close** | Apr 9-20 | v2 re-run, evaluation, owner review packet | Evaluation complete, owner has reviewed |
| **B: Taxonomy Build** | Apr 21 - May 18 | Sessions 2-3 of taxonomy engine | Taxonomy tests passing, owner Arabic review |
| **C: Factory Foundation** | May 19 - Jun 8 | Factory Roadmap sessions 1-3 ONLY | Ops manifest, CI/CD, CLI abstraction working |
| **D: Harden + Hunt** | Jun 9-29 | Regression growth, manual hunt cycles, cross-engine tests | All engines stable, test counts growing |
| **E: Handoff** | Jun 30 - Jul 1 | Status report, tag known-good states, document gaps | Owner has clear picture |

**What this model explicitly does NOT attempt:**
- Factory sessions 4-10 (benchmark, orchestrator modes, dashboard, acceptance test)
- Synthesis engine
- Agent Teams
- Automated hunt cycles with synthetic adversarial data
- Quality maturity tracking

These are deferred to post-July-1 because building them on untested foundations violates the project's own principle: "The system must not build on fragile foundations."

---

## 2. Non-Negotiable Rules

These rules cannot be relaxed, overridden, or temporarily suspended during the autonomous period. They are drawn from CLAUDE.md, GOVERNANCE.md, and the project's design principles, with autonomous-period-specific additions.

### Knowledge integrity (from CLAUDE.md Critical Rules)
1. **Frozen sources are immutable.** Bytes never change after freezing.
2. **Primary text is never modified.** No correction, no cleanup, no normalization.
3. **Every claim is traceable** to source excerpt or explicit analytical tag.
4. **Errors fail loudly.** Never silently drop data, never default on uncertainty.
5. **Multi-model consensus for content decisions.** Never single LLM call for attribution, genre, school, science scope.
6. **Arabic text handling rules are absolute.** No `.lower()`, no `\d` for digits, no arbitrary chunking. Read the arabic-text skill before any Arabic text processing.
7. **D-023 metadata pass-through.** Every function that transforms data passes through ALL upstream metadata fields.

### Autonomous operation rules (new for this period)
8. **No same-run discovery-to-implementation.** If the system discovers a bug or opportunity during a run, it records it in the backlog. It does NOT fix it in the same run. Discovery and implementation are separate sessions. (From runtime-policy.md, reinforced here.)
9. **Protected areas are read-only:**
   - `.claude/` (all contents)
   - `CLAUDE.md` (root and engine-level)
   - `NEXT.md`
   - `reference/archive/VISION.md`
   - `reference/GOVERNANCE.md`
   - `reference/DECISION_PLAYBOOK.md`
   - Any file under `docs/superpowers/`
10. **Cross-provider review on all engine-code changes.** Before any commit touching `engines/*/src/` or `shared/*/src/` or `contracts.py`, at least one non-builder model must review the diff. If Gemini is unavailable, record `reduced_confidence: true` explicitly.
11. **Budget enforcement is non-bypassable.** The cost-guard hook fires before API calls. When it blocks, the system stops that task and moves on. It does not retry, disable the hook, or find workarounds.
12. **Every API call persists its full output.** Raw responses written to disk before any processing. Results are reusable artifacts.
13. **Quality gates must pass before commit.** Pyright on modified files. Pytest on the affected engine. No exceptions.
14. **Owner interruption threshold.** The system ONLY interrupts the owner for:
    - Architectural scope changes (new engine, new contract field, new dependency)
    - Resource needs (subscriptions, auth tokens, access)
    - Domain judgment that would constitute a scholarly decision
    - Stop triggers (see Section 6)
15. **No silent coworker downgrade.** If Claude Code or Gemini CLI is unavailable (quota, auth, crash), the system records this explicitly in the daily report and in the affected task's metadata. It does not proceed as if one coworker is enough.

---

## 3. Cadence and Quota Strategy

### Daily cadence

```
06:00  Task Scheduler triggers first bounded run (1.5h max)
08:00  Second bounded run (if first completed cleanly)
10:00  Third bounded run (optional, skip if quota pressure)
12:00  MORNING_REPORT.md generated and committed
```

All times are approximate. The scheduler respects: (a) no overlapping runs, (b) PID lock prevents concurrent execution, (c) each run completes or times out before the next starts.

### Per-run structure

Each bounded run:
1. Read ACTIVE_AUTHORITY.md (confirm authority is codex)
2. Read backlog, pick highest-priority unblocked task
3. Execute task within approved scope
4. Run quality gates on changed files
5. Commit if gates pass; revert if they fail
6. Update backlog and state.json
7. Generate run summary for inclusion in daily report

### Quota budget

| Resource | Limit | Tracking | Action on exhaustion |
|----------|-------|----------|---------------------|
| Claude Code (Max plan) | ~100 messages/3h (estimate) | Track per-run in state.json | Reduce runs per day |
| Codex CLI (ChatGPT sub) | Rate-limited, varies | Log failures | Defer code review tasks |
| Gemini CLI (free tier) | Heavily rate-limited | Log failures | Defer challenge tasks |
| OpenRouter API (excerpting) | EUR 100 total budget, ~EUR 17 remaining for excerpting | COST_LOG.json + cost-guard hook | STOP API tasks |
| Git operations | Unlimited | N/A | N/A |

### Weekly cadence

| Day | Activity |
|-----|----------|
| Mon-Fri | 2-3 bounded runs, active work |
| Saturday | 1 run: regression check + report generation only |
| Sunday | No runs (allow auth tokens to refresh, reduce rate-limit pressure) |

### Context management

- Fresh session per engine. Never cross-engine work in one session.
- `/smart-compact` at 60% context, not 80%.
- After any compaction: re-read engine CLAUDE.md, active SPEC section, NEXT.md.
- Keep MCP servers to <= 5 active.

---

## 4. Expansion Gate and Maturity Ladder

Each phase (A through E) requires passing its gate before the next phase begins. Gates are binary: PASS or NOT-PASS. There is no "conditional pass" or "proceed with caveats."

### Gate 0: Entry (must pass before Apr 9 cutover)

| Criterion | Metric | Status |
|-----------|--------|--------|
| Shadow stability | 48 consecutive hours without orchestrator error | VERIFY before cutover |
| Test baseline | All engine tests pass, counts recorded | VERIFY |
| Auth preflight | codex: OK, claude: OK, gemini: OK or rate-limited | Partially done (backend-proof-status.md) |
| ACTIVE_AUTHORITY.md updated | active_authority: codex, effective_date: 2026-04-09 | NOT DONE |
| Protected areas enforced | Smoke test: attempt to edit .claude/*, verify rejection | NOT DONE |
| Daily report generation | One successful MORNING_REPORT.md cycle | EXISTS but verify |
| Backlog populated | >= 5 actionable tasks in backlog.json | VERIFY |

### Gate 1: Excerpting Close -> Taxonomy (end of Phase A)

| Criterion | Metric |
|-----------|--------|
| v2 re-run complete | `integration_tests/smoke_api_v2/` populated with valid output |
| v2 evaluation complete | `evaluate_excerpts.py` produces report with no blocking errors |
| Owner has reviewed | Owner message confirming review of >= 3 books' excerpts |
| No test regressions | Excerpting test count >= 915 |
| Budget sufficient for taxonomy | EUR remaining > EUR 10 for taxonomy LLM calls (or taxonomy uses free CLI path) |

### Gate 2: Taxonomy -> Factory Foundation (end of Phase B)

| Criterion | Metric |
|-----------|--------|
| Taxonomy sessions 2-3 complete | LLM infrastructure + gold baseline tests |
| Taxonomy tests passing | Test count >= 200 (118 deterministic + new LLM tests) |
| Cross-engine contract | Excerpting->Taxonomy boundary passes `verify_metadata_flow.py` |
| Owner Arabic review | Owner has reviewed taxonomy output for >= 2 books |
| No regressions | All engine test counts at or above their baseline |

### Gate 3: Factory Foundation -> Harden (end of Phase C)

| Criterion | Metric |
|-----------|--------|
| `ops_manifest.json` exists and validates | Factory Session 1 deliverable |
| CI/CD expanded | Ruff, black, pyright in CI. Pre-commit works. |
| CLI abstraction | `cli_adapter.py` dispatches all 3 CLIs. Health check passes. |
| Gemini dispatch | Orchestrator can invoke Gemini CLI headlessly |
| Integration test | Cross-provider review cycle works end-to-end |

### Gate 4: Harden -> Handoff (end of Phase D)

| Criterion | Metric |
|-----------|--------|
| Regression sweep | Full test suite for all engines passes |
| Test growth | Total tests > 2,300 (baseline ~2,145) |
| No CRITICAL findings open | Any CRITICAL finding found during harden phase is fixed |
| Known-good tags | At least 1 `owner-approved-*` tag per completed engine |

### Maturity ladder (per engine, tracked across phases)

| Level | Name | Criteria |
|-------|------|----------|
| **L0** | Untested | No tests or incomplete test suite |
| **L1** | Tested | All SPEC behavioral rules have >= 1 test. Engine tests pass. |
| **L2** | Hardened | >= 80% line coverage. Cross-engine boundary tests exist. Manual adversarial cases added. |
| **L3** | Evaluated | Owner has reviewed real output. All T-1..T-7 threat types have >= 3 manual test cases. |
| **L4** | Production | Hunt yield < 10%. Zero CRITICAL findings in 30 days. Owner review gate passed. |

**Current levels (estimated):**
- Source: L3 (566 tests, owner reviewed, transition gate passed)
- Normalization: L3 (503 tests, owner reviewed, transition gate passed)
- Excerpting: L1-L2 (915 tests, evaluation in progress, owner has not yet fully reviewed)
- Taxonomy: L0-L1 (118 tests, deterministic only, no LLM tests)
- Synthesis: L0 (not started)

**The system must NOT advance an engine to L4 without the owner's explicit confirmation of their Arabic review.** This is the epistemic safety guarantee (D-F024).

---

## 5. Daily Owner Interaction Contract

### What the owner receives (daily, by 12:00 local time)

**MORNING_REPORT.md** — must be readable in < 3 minutes. Exact format:

```
# Morning Report — [DATE]

## Status: [GREEN | YELLOW | RED]
[One sentence: what the status means]

## Completed
- [Task 1: one line]
- [Task 2: one line]

## Blocked (requires owner)
- [Blocker 1: what's needed, why]

## Next
- [What the system will do next cycle]

## Metrics
- Tests: [total] ([+/-] from yesterday)
- Budget: EUR [remaining] of EUR [total]
- Coworkers: Claude [OK|DOWN], Gemini [OK|DOWN], Codex [OK|DOWN]
- Phase: [A|B|C|D|E] — Gate [X] progress: [fraction]

## Escalations (0)
[Only if present: one-line description + link to artifact]
```

**Status color meanings:**
- **GREEN:** All runs completed, gates passing, no blockers
- **YELLOW:** Minor issue (one coworker down, rate-limited, non-critical test flaky)
- **RED:** Stop trigger fired, or blocker requires owner action before work can continue

### What the owner provides

One message per day, max. Possible responses:
- "Approved" / "Continue" — system proceeds as planned
- "Redirect: [instruction]" — system adjusts priority
- "Stop: [reason]" — system enters HALT mode
- "[Answer to blocker]" — system unblocks specific task
- No response — system continues GREEN/YELLOW items. RED items remain blocked.

### What the owner NEVER needs to provide

- Code review (the system does this cross-provider)
- Test decisions (quality gates are automated)
- Task sequencing (the backlog handles this)
- Commit messages (conventional format is automated)
- Debug guidance (the system diagnoses and fixes)

### Owner absence protocol

If the owner provides no response for 3 consecutive days:
1. The system continues GREEN work only
2. All YELLOW items are paused (not deferred, paused)
3. All RED items remain blocked
4. The system does NOT escalate more aggressively (no spam)
5. On day 5 of silence, the system enters SAFE mode: regression checks only, no new work

---

## 6. Stop / Rollback Triggers

### Immediate STOP (halt all runs, alert owner)

| Trigger | Detection | Action |
|---------|-----------|--------|
| **Arabic text corruption** | Arabic safety hook, diacritic check, encoding validator | Revert all uncommitted changes. Tag last-known-good state. RED report. |
| **Test regression > 5%** | pytest reports >5% previously-passing tests now failing | `git reset --hard` to last commit. Investigate in read-only mode. RED report. |
| **D-023 metadata loss** | `verify_metadata_flow.py` detects dropped fields | Revert the commit. RED report. |
| **Protected area violation** | Any commit modifying protected files | Revert the commit. RED report. |
| **3 consecutive run failures** | Circuit breaker (existing in orchestrator) | HALT mode. RED report. |
| **All coworkers down** | Auth preflight shows 0/3 CLIs responsive | HALT mode. RED report. |
| **Budget exhausted** | cost-guard hook fires | STOP API-calling tasks. Non-API work continues. YELLOW report. |

### Automatic rollback (revert + continue)

| Trigger | Detection | Action |
|---------|-----------|--------|
| **Quality gate failure** | pyright error or pytest failure on committed code | `git revert` the commit. Log. Move to next task. |
| **Merge conflict on master** | git push fails | Stash changes. Alert in next report. Do not force-push. |
| **Single coworker down** | Auth preflight shows 1/3 CLIs failed | Record `reduced_confidence: true`. Continue with available coworkers. YELLOW report. |

### Rollback mechanism

The system maintains rollback capability at two levels:

1. **Per-commit:** Every commit to master can be individually reverted via `git revert`.
2. **Per-phase:** At the start of each phase (A-E), the system creates a tag `phase-start-{A|B|C|D|E}-{date}`. If the phase goes badly, the owner can request: "Roll back to phase start."

**NOTE:** The `owner-approved-*` tag system described in D-F025 does not yet exist. The system should create these tags as part of Gate 0 setup.

---

## 7. July 1 Success Criteria

### Tier 1: Minimum viable (all must pass)

| # | Criterion | Measurable |
|---|-----------|------------|
| 1 | Excerpting v2 evaluation complete | `integration_tests/smoke_api_v2/` exists + evaluation report committed |
| 2 | Taxonomy engine operational | `engines/taxonomy/tests/` has >= 200 passing tests |
| 3 | Zero knowledge integrity incidents | No T-1..T-7 violation committed to master during the period |
| 4 | Zero protected area violations | git log shows no commits modifying protected files by Codex |
| 5 | Test count maintained or grown | Total tests >= 2,145 (current baseline) |
| 6 | Daily reports generated | MORNING_REPORT.md committed for >= 70% of weekdays |
| 7 | Owner interrupted <= 3x/week average | Count of RED reports + blocker messages <= ~36 total |
| 8 | All engines pass their test suites | `pytest engines/*/tests/ -q` exits 0 |

### Tier 2: Target (aim for these)

| # | Criterion | Measurable |
|---|-----------|------------|
| 9 | Factory sessions 1-3 complete | `ops_manifest.json`, CI expanded, CLI abstraction working |
| 10 | Excerpting reaches L2 maturity | >= 80% coverage, boundary tests exist |
| 11 | Total tests > 2,500 | Net addition of ~355 tests across all engines |
| 12 | Known-good tags exist | `git tag` shows `owner-approved-*` for source and normalization |

### Tier 3: Aspirational (celebrate if achieved)

| # | Criterion | Measurable |
|---|-----------|------------|
| 13 | Factory sessions 4-5 complete (benchmark) | Benchmark infrastructure exists, routing table produced |
| 14 | Manual hunt cycles run on excerpting | >= 10 adversarial test cases added manually |
| 15 | Synthesis SPEC design started | `engines/synthesis/SPEC.md` has at least section headers |
| 16 | Taxonomy reaches L2 maturity | Cross-engine boundary tests exist |

### Anti-criteria (any ONE of these means the period FAILED regardless of other metrics)

| # | Anti-criterion |
|---|---------------|
| A1 | Silent knowledge corruption committed to master (any T-1..T-7 violation that was not caught by the system) |
| A2 | Engine code committed without tests |
| A3 | System expanded scope without passing the gate (e.g., started factory work before taxonomy was done) |
| A4 | Protected areas were edited |
| A5 | Owner had to intervene daily (> 5 days/week) for > 2 consecutive weeks |
| A6 | System attempted to auto-approve scholarly/domain decisions |

---

## 8. Biggest Risks in the Current Repo/Doc Set

### RISK 1: Documentation-Reality Gap (CRITICAL)

**The problem:** The AQS, Factory Roadmap v2, and Team Architecture describe a system that does not exist. Zero factory directories exist (`work_queue/`, `policies/`, `findings_db/`, `synthetic_tests/`, `benchmarks/`, `escalation_queue/`, `artifacts/` — all missing). Zero factory scripts exist (`cli_health_check.py`, `cli_dispatch.py`, `synthetic_generator.py`, `factory_scheduler.py` — all missing). None of 10 Factory Roadmap sessions have been started.

**The danger:** The Codex orchestrator might read these documents and attempt to operate as if the infrastructure exists, resulting in silent failures or scope explosion trying to build everything at once.

**Mitigation:** The doctrine's Phase C (Factory Foundation) explicitly limits factory work to sessions 1-3 only, and only after excerpting and taxonomy are done. The AQS and Team Architecture are long-term visions, not current operating documents.

### RISK 2: Claude Subscription Expiry (HIGH)

**The problem:** `ACTIVE_AUTHORITY.md` states: "Primary Claude-backed excerpting calls remain blocked unless an alternative backend is proven." The backend-proof-status.md shows Claude verification is blocked by rate limits. If the Claude Max subscription expires or rate limits tighten, the primary builder (Claude Code) becomes unavailable.

**The danger:** The entire operating model depends on Claude Code as the builder. Without it, only read-only review and Codex/Gemini challenge remain. No code gets written.

**Mitigation:** (a) Monitor Claude auth status in every daily report. (b) If Claude becomes unavailable for >48h, enter SAFE mode (regression checks only). (c) The owner must ensure subscription continuity for the 83-day period. Flag this as a Gate 0 prerequisite.

### RISK 3: Quality Regression Under Automation (HIGH)

**The problem:** The overnight branches show Codex has been creating branches (`overnight-codex-harden-recent-excerpting-*`, `overnight-codex-ki-layer-merge-*`, etc.) but the quality of this work is unverified. At least 12 branches exist. None appear to be merged.

**The danger:** Automated commits accumulate subtle bugs that individually pass quality gates but collectively degrade the codebase. The "boiling frog" problem — each commit is small and seems fine, but the aggregate drifts from the SPEC.

**Mitigation:** (a) Weekly full regression sweep (all engines, all tests). (b) Every 2 weeks, a cross-provider code review of the cumulative diff since the last review. (c) The build-prober agent should run after every build session to check for SPEC drift.

### RISK 4: Scope Ambition Mismatch (HIGH)

**The problem:** The Factory Roadmap v2 describes 14-17 sessions of work. At 1-2 sessions per week (realistic pace with quality gates), that's 7-17 weeks — the entire autonomous period or more. The AQS adds another layer of complexity. Trying to build the factory AND operate engines simultaneously will result in neither being done well.

**The danger:** The system takes on too much, produces half-built infrastructure that's worse than no infrastructure, and the owner returns to a mess.

**Mitigation:** The doctrine explicitly limits factory work to sessions 1-3 (Phase C) and only after engine work is done (Phases A-B). The rest is deferred to post-July.

### RISK 5: Stale Document Authority (MEDIUM)

**The problem:** Multiple documents reference conflicting dates and states:
- `ACTIVE_AUTHORITY.md`: planned_codex_cutover: 2026-04-05 (user says April 9)
- `ACTIVE_AUTHORITY.md`: current_scope references Claude finishing excerpting (Claude may no longer be doing this)
- `.kr/ACTIVE.md`: status says "completed — ready for next frontier" (stale?)
- Shadow runbook: references cutover readiness conditions that may be outdated
- Factory Roadmap timeline: references "Now" as excerpting model research (months ago)

**The danger:** The orchestrator reads one of these stale documents and acts on outdated information.

**Mitigation:** Section 9 of this doctrine specifies exact corrections to each document.

### RISK 6: No Tested Rollback (MEDIUM)

**The problem:** D-F025 specifies `owner-approved-{engine}-{date}` tags for rollback. None exist. The only rollback mechanism is manual `git revert` on individual commits.

**The danger:** If something goes wrong, restoring a known-good state requires forensic investigation of git history rather than a simple tag checkout.

**Mitigation:** Gate 0 (Entry) includes creating initial tags for all completed engines: `owner-approved-source-20260409`, `owner-approved-normalization-20260409`.

### RISK 7: Agent Teams Untested (MEDIUM)

**The problem:** `TEAM_ARCHITECTURE.md` describes sophisticated 3-5 teammate teams for every factory mode. The feature requires `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` (note: "experimental"). It has never been tested in this project.

**The danger:** Building operational processes on an experimental feature that may be unstable, rate-limited, or removed.

**Mitigation:** Do NOT rely on Agent Teams during the autonomous period. Use sequential sessions with cross-provider review instead. If Agent Teams stabilize, they can be adopted in Phase D (Harden) as an experiment.

### RISK 8: Budget Uncertainty (MEDIUM)

**The problem:** The excerpting budget shows ~EUR 17 remaining. Factory work budget is undefined. Taxonomy LLM call budget is undefined. The total EUR 100 budget may need to cover all of these.

**The danger:** Running out of API budget mid-taxonomy or mid-factory, leaving work half-done.

**Mitigation:** (a) Use CLI backend (free) for taxonomy development where possible. (b) Reserve EUR 10 for excerpting final eval. (c) Allocate EUR 5-10 for taxonomy probes. (d) Track daily in reports.

---

## 9. Exact Corrections Needed to Current Control Docs

### ACTIVE_AUTHORITY.md

**Current:**
```
planned_codex_cutover: 2026-04-05
```
**Change to:**
```
planned_codex_cutover: 2026-04-09
autonomous_period_end: 2026-07-01
```

**Current:**
```
current_scope: Claude finishes excerpting and taxonomy while Codex builds the takeover environment.
```
**Change to:**
```
current_scope: Codex operates as primary authority for excerpting evaluation, taxonomy build, and bounded factory infrastructure. Claude Code and Gemini CLI Pro 3.1 are peer primary coworkers.
```

**Add after rollback section:**
```
## Approved Scope for Autonomous Period

Phase A (Apr 9-20): Excerpting v2 re-run + evaluation
Phase B (Apr 21 - May 18): Taxonomy sessions 2-3
Phase C (May 19 - Jun 8): Factory Roadmap sessions 1-3 only
Phase D (Jun 9-29): Regression growth, manual hardening, cross-engine tests
Phase E (Jun 30 - Jul 1): Status report, tag known-good states

Anything outside these phases requires owner approval.
```

**Remove or replace:** The "Sunday Cutover Checklist" — it references conditions that may no longer apply (e.g., "Excerpting and taxonomy are finished or explicitly frozen" — taxonomy isn't finished). Replace with a Gate 0 checklist from this doctrine.

### docs/codex/operating-model.md

**Add new section after "Runtime Policy":**
```
## Autonomous Period Shape (Apr 9 - Jul 1, 2026)

During the autonomous period, Codex operates in `autonomous_codex` mode with these constraints:

### Writable paths
- engines/taxonomy/src/
- engines/taxonomy/tests/
- engines/excerpting/tests/ (test additions only, not src changes without review)
- shared/factory/ (new, for factory infrastructure)
- scripts/ (factory scripts only)
- overnight_codex/
- integration_tests/

### Read-only paths (enforced)
- .claude/ (all contents)
- CLAUDE.md (root and engine-level)
- NEXT.md
- reference/archive/VISION.md
- reference/GOVERNANCE.md
- reference/DECISION_PLAYBOOK.md
- engines/source/ (completed, frozen)
- engines/normalization/ (completed, frozen)

### Decision authority
- Codex may: implement SPEC sections, write tests, fix bugs it discovers (next session, not same session), run evaluations, build factory infrastructure per roadmap
- Codex may NOT: modify SPECs, create new engines, change contracts without cross-provider review, approve scholarly content, modify protected files, expand scope beyond approved phases
```

### docs/codex/runtime-policy.md

**Add after "Shutdown Artifacts" section:**
```
## Daily Report Contract

Every active day must produce `overnight_codex/MORNING_REPORT.md` with:
- Status color (GREEN/YELLOW/RED)
- Completed tasks (bullet list)
- Blocked items requiring owner (if any)
- Next cycle plan
- Metrics: test count delta, budget remaining, coworker availability
- Escalations (if any)

Max length: 40 lines. Owner must be able to read in < 3 minutes.
```

**Add to Protected Areas section, the explicit allowlist:**
```
### Writable Paths (autonomous_codex mode)
- engines/taxonomy/ (per Phase B gate)
- scripts/ (factory scripts per Phase C gate)
- shared/factory/ (per Phase C gate)
- overnight_codex/ (always writable for state/reports)
- integration_tests/ (evaluation output)
```

### docs/codex/shadow-24x7-runbook.md

**Add new section: "## After Cutover":**
```
## After Cutover (autonomous_codex mode)

When `ACTIVE_AUTHORITY.md` shows `active_authority: codex` and `runtime_mode: autonomous_codex`:

### Changed behavior
- Runs are no longer queue-only. Bounded auto-apply is permitted inside approved writable paths.
- Engine-code implementation is permitted for the active phase's engine only.
- Quality gates are mandatory before every commit (no bypass).

### Unchanged behavior
- Protected areas remain read-only.
- Cross-provider review is still required on engine-code changes.
- PID lock prevents concurrent runs.
- Circuit breaker (3 consecutive failures) triggers HALT.
- Same-run discovery-to-implementation is still prohibited.

### Scheduler shape
Same as shadow: repeated bounded runs, not one infinite process.
- Entry: `powershell ... -RunCycle -Hours 1.5`
- Cadence: every 2 hours, weekdays. Once on Saturday. Off on Sunday.
- Max 3 runs per day.
```

### docs/codex/backend-proof-status.md

**Add "## Resolution Plan" section at end:**
```
## Resolution Plan

The consensus/verification blocker must be resolved before Phase A begins:

Option 1 (preferred): Re-run backend proof after Claude quota reset. If verification passes, the CLI path is proven for all phases.

Option 2 (fallback): Remap VERIFY_MODEL from anthropic/claude-opus-4.6 to a non-rate-limited model (e.g., google/gemini-2.5-pro or openai/gpt-5.4). This requires an explicit engine configuration change and a bounded proof run.

Option 3 (last resort): Use OpenRouter API backend for verification calls. This consumes EUR budget but avoids CLI rate limits.

The owner must confirm which option to pursue before April 9.
```

### reference/AUTONOMOUS_QUALITY_SYSTEM.md

**Add at the very top, before "The Axiom":**
```
## Implementation Status

**As of 2026-04-01: ZERO infrastructure implemented.**

No directories exist (work_queue/, findings_db/, synthetic_tests/, benchmarks/, escalation_queue/, artifacts/).
No factory scripts exist (synthetic_generator.py, finding_classifier.py, etc.).
None of the 6 operating modes are operational.

This document describes the TARGET STATE, not the current state. Implementation is gated behind Factory Roadmap sessions 4.5 and later.

During the autonomous period (Apr 9 - Jul 1), only Factory Roadmap sessions 1-3 will be attempted. The full AQS system is a post-July goal. Manual hunt cycles (not automated) may begin in Phase D (Jun 9+).
```

### reference/FACTORY_ROADMAP_v2.md

**Add after the Architecture section:**
```
## Implementation Progress

**As of 2026-04-01:**
- Session 1: NOT STARTED
- Session 2: NOT STARTED
- Session 2.5 (WSL setup): PARTIALLY DONE (WSL works, CLI auth partially proven)
- Session 3: NOT STARTED
- Sessions 4-10: NOT STARTED

The interleaving timeline below is ASPIRATIONAL. Actual timeline depends on the autonomous period doctrine in `docs/codex/OPERATING_DOCTRINE.md`.
```

**Update the timeline table:** The current table references "Now" as "Excerpting: model role research" which was weeks ago. Update to reflect the actual April 9 start.

### reference/TEAM_ARCHITECTURE.md

**Add warning after "Enabling Agent Teams" section:**
```
## Implementation Warning

Agent Teams (`CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS`) is an EXPERIMENTAL feature as of April 2026. It has NOT been tested in this project. The team compositions described in this document are design targets, not proven operational patterns.

During the autonomous period (Apr 9 - Jul 1), Agent Teams should NOT be used for production work. Use sequential sessions with cross-provider review instead. Agent Teams may be tested experimentally during Phase D (Harden) on low-risk tasks only.

If Agent Teams stabilize and pass a bounded proof (3 successful team runs on non-critical tasks), they can be adopted for Phase D work.
```

### reference/GOVERNANCE.md

**Add section: "## Autonomous Period Adaptation":**
```
## Autonomous Period Adaptation (Apr 9 - Jul 1)

During the autonomous period, the owner does not relay findings between providers. The cross-provider review model adapts:

### How it works without owner relay
1. The system (Codex orchestrator) dispatches Claude Code to build
2. The system dispatches Codex CLI (`codex exec review`) to review the diff
3. The system dispatches Gemini CLI (`gemini -p`) to challenge the design
4. Findings from all three are collected by the orchestrator and logged
5. BLOCKING findings from ANY provider block the commit

### When to escalate to owner
- If Codex and Gemini disagree on a finding's severity (one says CRITICAL, other says LOW)
- If the change touches Arabic scholarly content (domain judgment)
- If the finding suggests a SPEC ambiguity (architectural decision)

### What's different from the relay model
- The owner does NOT see every review — only escalations
- The system resolves non-controversial findings autonomously
- Disagreements between providers that don't touch scholarly content are resolved by majority (2/3 agree)
- Disagreements that DO touch scholarly content are ALWAYS escalated
```

---

## Verification Plan

This is a review document. No implementation was performed. Verification consists of:

1. **Owner reads this doctrine** and confirms alignment with intent
2. **Owner confirms budget** for the 83-day period (EUR total, subscription continuity)
3. **Owner confirms scope** of Phases A-E
4. **Owner confirms anti-criteria** in Section 7
5. **Gate 0 items are completed** before April 9 cutover
6. **Document corrections from Section 9** are applied before cutover

After owner approval, the corrections in Section 9 should be committed as:
```
docs(codex): apply autonomous period operating doctrine corrections
```
