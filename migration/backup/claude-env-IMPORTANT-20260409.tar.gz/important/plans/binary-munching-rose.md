# KR Factory Master Plan — Autonomous Engine-Building Environment

## Context

The KR pipeline (خزانة ريان) has 2 completed engines (source, normalization) and 1 in hardening (excerpting), with 4 remaining (passaging, atomization, taxonomy, synthesis). The pipeline works. But the *process* of building it is fragile:

- The owner manually relays messages between Claude Chat (architect) and Claude Code (builder)
- Quality enforcement depends on the architect's discipline, which has failed in Sessions 5, 6, 7
- No automated testing (CI), no dashboard, no decision log, no domain review pipeline
- Skills referenced by agents don't exist in the repo
- Context degrades across long sessions with no structural mitigation

**This plan builds the factory that builds the pipeline.** Every workstream exists to make the engine-building process autonomous, reliable, and self-correcting — so the owner can focus on Islamic studies while the factory produces his scholarly companion.

**Governing principle:** The owner's time is only spent on things a human genuinely must do: reading Arabic scholarly output, making domain judgments, providing resources. Everything else is automated.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                    OWNER LAYER                          │
│  Dashboard (GitHub Pages)  ←→  Human Gate Queue         │
│  Arabic Output Reviewer    ←→  Domain Decision Forms    │
│  (only genuine human-required tasks reach here)         │
└──────────────────────┬──────────────────────────────────┘
                       │ structured files in git
┌──────────────────────▼──────────────────────────────────┐
│              CLAUDE CODE (Opus 4.6, 1M context)         │
│                                                         │
│  ┌─────────────┐  ┌──────────────┐  ┌───────────────┐  │
│  │  Architect   │  │   Builder    │  │   Reviewer    │  │
│  │  Subagents   │  │   (main CC)  │  │   Agents      │  │
│  │  (clean ctx) │  │              │  │   (21 agents) │  │
│  └──────┬──────┘  └──────┬───────┘  └───────┬───────┘  │
│         │                │                   │          │
│  ┌──────▼────────────────▼───────────────────▼───────┐  │
│  │              Quality Gate Layer                    │  │
│  │  13 hooks + pre-commit + CI + protocol enforcement │  │
│  └───────────────────────────────────────────────────┘  │
│                                                         │
│  ┌─────────────┐  ┌──────────────┐  ┌───────────────┐  │
│  │  Gemini API  │  │  Scheduled   │  │  Decision     │  │
│  │  (diversity) │  │  Triggers    │  │  Log (ADRs)   │  │
│  └─────────────┘  └──────────────┘  └───────────────┘  │
└─────────────────────────────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────┐
│                 EXTERNAL LAYER                          │
│  GitHub Actions (CI/CD)    Usul.ai (scholar verify)     │
│  GitHub Pages (dashboard)  Sunnah.com (hadith verify)   │
│  KITAB/OpenITI (corpus)    Swan embeddings (semantic)   │
└─────────────────────────────────────────────────────────┘
```

### Key Design Decisions

**D-F001: CC is both architect and builder.**
Claude Code with Opus 4.6 performs architectural reasoning via focused subagents (Plan type, ~3K token baseline, no rules/hooks noise). This gives Claude Chat-quality reasoning without manual relay. Two subagent strategies (protocol-guided + first-principles) provide knowledge diversity within a single model.

**D-F002: Gemini provides genuine model diversity.**
For major decisions (SPEC design, engine transitions), CC calls Gemini API from a script. Different model = different blind spots caught. Paid tier for privacy (~$1-2/day when active). No manual relay — CC calls the API directly.

**D-F003: Scheduled triggers for continuous operation.**
Desktop scheduled tasks (Windows Task Scheduler) wake CC on a cron schedule. CC reads ENGINE_STATE.json, picks up where it left off. No session dependency. Machine must be on (acceptable for desktop use).

**D-F004: Human gates are asynchronous queues, not blocking calls.**
When CC needs human input, it writes a structured request to `human_gate/pending/`, continues on non-blocked work, and picks up the owner's decision on next wake-up. Owner reviews at their convenience.

**D-F005: Quality is enforced structurally, not by willpower.**
Every protocol step that previously depended on "someone remembering" gets a corresponding hook, CI check, or pre-commit gate. Standing Order 7 (adversarial pass) becomes an automated agent dispatch, not a mental discipline.

---

## Workstreams

### W1: CI/CD Foundation

**What:** GitHub Actions workflow for automated testing, type checking, and formatting on every push. Pre-commit hooks for local enforcement. Test stratification (fast deterministic tests vs expensive LLM tests).

**Why:** Tests currently only run when someone remembers. CI catches regressions automatically. Pre-commit hooks prevent bad code from entering git. This is the foundation everything else builds on.

**Deliverables:**
- Updated `.github/workflows/test.yml` with ruff, black, pyright, test stratification
- Nightly workflow for expensive LLM tests (gated by `--expensive` marker)
- `.pre-commit-config.yaml` with ruff, black, pyright, conventional-commits
- Custom pre-commit hook: `check_decision_discipline.py`
- Contract validation job (D-023 metadata flow, cross-engine contracts)
- GitHub branch protection rules (require all checks pass)

**Key files to modify:**
- `.github/workflows/test.yml` (exists, needs expansion)
- `.pre-commit-config.yaml` (new)
- `scripts/check_decision_discipline.py` (new)
- Engine `conftest.py` files (add `@pytest.mark.expensive` support)

**Dependencies:** None
**Effort:** 1 session
**Session type:** Dedicated CC session

---

### W2: Domain Knowledge System

**What:** Create `.claude/skills/` with all domain knowledge files that agents reference. Port the 9 KR-specific skills from Claude.ai (/mnt/skills/user/) to Claude Code format.

**Why:** CRITICAL gap. 21 agents reference 6+ skills that don't exist in the repo. When context resets or a new session starts, domain knowledge is lost. Agents like `arabic-reviewer` and `spec-writer` read these skills before working — without them, they operate without domain expertise.

**Deliverables:**
- `.claude/skills/arabic-text/SKILL.md` — Unicode, diacritics, encoding
- `.claude/skills/islamic-sciences-classification/SKILL.md` — Genre detection signals
- `.claude/skills/scholarly-attribution/SKILL.md` — Arabic naming, disambiguation
- `.claude/skills/domain-glossary/SKILL.md` — Terminology mapping
- `.claude/skills/arabic-text-quality/SKILL.md` — OCR corruption, quality scoring
- `.claude/skills/quranic-text-handling/SKILL.md` — Quran detection, preservation
- Ported KR skills from Claude.ai (kr-build-prep, kr-core-extract, kr-evaluate, etc.)
- `.claude/skills/SKILL_REGISTRY.md` — inventory, version, last-updated dates
- `.claude/agents/AGENT_REGISTRY.md` — active/archived status, dependencies

**Key files to create/modify:**
- `.claude/skills/*/SKILL.md` (6+ new files)
- `.claude/agents/AGENT_REGISTRY.md` (new)

**Dependencies:** None
**Effort:** 2-3 sessions (significant content creation)
**Session type:** Dedicated CC sessions (may need owner input for domain content from Claude.ai skills)

---

### W3: Autonomous Execution Core

**What:** Scheduled triggers, ENGINE_STATE.json state machine, session recovery protocol. CC operates as a persistent daemon that wakes up, reads state, works, and sleeps.

**Why:** Without this, every session requires a human to start it and provide context. The factory can't be autonomous if it depends on someone pressing "go" every time.

**Deliverables:**
- Desktop scheduled task configuration (Windows Task Scheduler via CC /schedule)
- `ENGINE_STATE.json` full specification and state transition logic
- Session recovery script that reads ENGINE_STATE.json and generates a work prompt
- Task expiry renewal mechanism (3-day expiry requires auto-renewal)
- Heartbeat logging (prove the factory is alive and working)
- Failure recovery: if a session crashes, next wake-up detects incomplete state and resumes

**Key files to create/modify:**
- `scripts/factory_state.py` (state machine implementation)
- `scripts/factory_session_prompt.py` (generates work prompt from state)
- `.claude/scheduled_tasks/` (task definitions)
- `ENGINE_STATE.json` (state file, already partially defined in AGENT_ARCHITECTURE.md)

**Dependencies:** W1 (CI ensures tests pass before state transitions)
**Effort:** 2 sessions
**Session type:** Dedicated CC sessions

---

### W4: Quality Gate Enforcement

**What:** Convert willpower-dependent protocol steps to structural enforcement. Every protocol step gets a corresponding automated check.

**Why:** Protocols failed in Sessions 5, 6, 7 because they depended on the architect remembering to invoke them. Structural enforcement means quality doesn't depend on anyone's discipline.

**Deliverables:**

Protocol enforcement hooks:
- `hooks/handoff-checklist-gate.sh` — blocks commit with "handoff:" prefix unless checklist is committed
- `hooks/review-checklist-gate.sh` — blocks merge unless review checklist has ACCEPT/REJECT verdict
- `hooks/adversarial-pass-dispatch.sh` — auto-dispatches adversarial review agent after code-reviewer completes
- `hooks/spec-example-trace.sh` — verifies SPEC examples are traced before handoff

Quality automation:
- Auto-dispatch `code-reviewer` agent when `engines/*/src/` files change (currently manual)
- Auto-dispatch `arabic-reviewer` when files touching Arabic text change
- Auto-dispatch `boundary-validator` when `contracts.py` changes
- Regression detection: compare test counts before/after every session

Standing Order 7 automation:
- After every review completes, spawn a fresh adversarial agent with ONLY the code + SPEC (no review context)
- This agent tries to break the code from first principles
- Its findings are appended to the review checklist

**Key files to create/modify:**
- `.claude/hooks/handoff-checklist-gate.sh` (new)
- `.claude/hooks/review-checklist-gate.sh` (new)
- `.claude/hooks/adversarial-pass-dispatch.sh` (new)
- `.claude/settings.json` (add hook configurations)

**Dependencies:** W1 (pre-commit infrastructure), W2 (agents need domain skills)
**Effort:** 2 sessions
**Session type:** Dedicated CC sessions

---

### W5: Multi-Model Architect System

**What:** Architect subagent definitions within CC for high-quality reasoning. Gemini API integration for genuine model diversity on major decisions.

**Why:** The factory's architectural decisions must be at least as good as Claude Chat produced. Focused subagents with clean context achieve this. Gemini provides a genuinely different perspective that catches Claude's blind spots.

**Deliverables:**

Architect subagents:
- `.claude/agents/architect-protocol.md` — Reads Decision Playbook, follows established patterns, proposes decisions
- `.claude/agents/architect-firstprinciples.md` — Reasons independently, no playbook access, catches playbook blind spots
- `.claude/agents/architect-comparator.md` — Compares both architects' outputs, flags disagreements, produces consensus
- Architect invocation protocol: when to use single architect vs dual + comparator

Gemini integration:
- `scripts/gemini_review.py` — Calls Gemini API with structured prompt, returns structured review
- `scripts/multi_model_consensus.py` — Orchestrates CC architect + Gemini for major decisions
- Gemini prompt templates for: SPEC review, evaluation strategy, engine transition GO/NO-GO
- Disagreement handling: CC + Gemini disagree → human gate queue

Quality metrics:
- Track architect agreement rate over time (should be 80-95%; too high = rubber-stamping, too low = noise)
- Log all architect decisions with model, prompt, reasoning, verdict

**Key files to create/modify:**
- `.claude/agents/architect-*.md` (3 new agents)
- `scripts/gemini_review.py` (new)
- `scripts/multi_model_consensus.py` (new)

**Dependencies:** W3 (autonomous execution for scheduled architect reviews), W2 (domain skills for architect prompts)
**Effort:** 2 sessions
**Session type:** Dedicated CC sessions

---

### W6: Owner Interface & Human Gate

**What:** GitHub Pages dashboard, structured human gate queue, Arabic output formatter. The owner sees exactly what needs attention, in a format that respects their time.

**Why:** Currently the owner gets raw JSON and has to ask "where are we?" The dashboard answers this automatically. The human gate queue ensures genuine decisions reach the owner in a reviewable format. The Arabic formatter presents scholarly text properly (RTL, diacritics, proper fonts).

**Deliverables:**

Dashboard:
- `scripts/generate_dashboard.py` — Generates HTML dashboard from test results, budget, state
- GitHub Actions workflow step to deploy dashboard to GitHub Pages
- Dashboard sections: engine phase, test pass rate, budget, items needing attention, recent decisions
- Auto-refreshes on every push to master

Human gate:
- `human_gate/pending/` directory for structured decision requests
- `human_gate/completed/` directory for owner responses (committed to git)
- Decision request template with: context, options, recommendation, what happens if deferred
- `scripts/human_gate_summary.py` — Generates owner-readable summary of pending decisions

Arabic output formatter:
- `scripts/format_arabic_output.py` — Converts raw JSON excerpts to readable HTML
- Proper RTL layout, Amiri font, diacritics preserved
- Side-by-side: Arabic original + structured metadata (genre, author, science)
- Highlight uncertain fields that need owner judgment

**Key files to create/modify:**
- `scripts/generate_dashboard.py` (new)
- `scripts/human_gate_summary.py` (new)
- `scripts/format_arabic_output.py` (new)
- `.github/workflows/dashboard.yml` (new)
- `human_gate/` directory structure (new)

**Dependencies:** W1 (CI for dashboard deployment), W2 (domain knowledge for Arabic formatting)
**Effort:** 2-3 sessions
**Session type:** Dedicated CC sessions

---

### W7: Memory & Decision Logging

**What:** Architecture Decision Records (ADRs) in git, systematic memory cleanup, searchable decision history.

**Why:** Memory entries go stale. Decisions are scattered across NEXT.md files, review checklists, and git history. The owner can't independently read the decision trail. ADRs provide a permanent, searchable, owner-readable record.

**Deliverables:**

ADR system:
- `adr/` directory with template
- Backfill ADR-001 through ADR-010 from existing decisions (execution model, consensus pair, test architecture, etc.)
- `adr/INDEX.md` with tags for searchability
- Integration: ADR references in SPEC files, DECISION_PLAYBOOK.md, code comments

Memory hygiene:
- `scripts/memory_audit.py` — Scans MEMORY.md for stale entries (references to files that moved/deleted)
- Scheduled memory cleanup (weekly, checks file references, flags outdated entries)
- Memory categorization: active (currently relevant), archived (historically interesting), stale (wrong/outdated)
- Auto-archive protocol: entries older than 30 days get verified or archived

**Key files to create/modify:**
- `adr/` directory + template + initial backfill (new)
- `scripts/memory_audit.py` (new)
- MEMORY.md (periodic updates via script)

**Dependencies:** W3 (autonomous execution for scheduled cleanup)
**Effort:** 1-2 sessions
**Session type:** Dedicated CC sessions

---

### W8: External Knowledge Integration

**What:** API clients for Usul.ai, Sunnah.com, KITAB/OpenITI. Arabic text embeddings via Swan models.

**Why:** Domain review without external sources is unreliable. Usul.ai cross-references scholar metadata. Sunnah.com verifies hadith references. KITAB provides corpus-level patterns. Swan embeddings enable semantic search across the library.

**Deliverables:**

Usul.ai integration:
- `shared/external/usul_client.py` — API client for scholar verification
- Integration into verification agents (verifier-a, verifier-b)
- Caching layer to avoid redundant queries

Sunnah.com integration:
- `shared/external/sunnah_client.py` — Hadith reference verification
- Integration into excerpting engine (hadith layer detection)

KITAB/OpenITI corpus:
- Download and index relevant subset
- `shared/external/kitab_client.py` — Corpus pattern queries
- Text reuse detection for cross-referencing

Swan embeddings:
- `shared/external/embeddings.py` — Arabic scholarly text embedding via Swan-Large
- Vector store for semantic search across processed library
- Integration into taxonomy engine (semantic similarity for classification)

**Key files to create/modify:**
- `shared/external/` directory (new)
- API client files (4 new)
- Integration tests for each client

**Dependencies:** W2 (domain knowledge for query construction), W3 (autonomous execution for batch queries)
**Effort:** 3-4 sessions (1 per integration)
**Session type:** Dedicated CC sessions, may need owner for API keys
**Trigger conditions:** Per SESSION_3_4_BACKLOG.md — most triggered by evaluation results showing gaps

---

### W9: Sustainability & Self-Healing

**What:** Health check scripts, metric tracking, degradation detection, self-repair protocols. The factory monitors itself.

**Why:** Without this, entropy wins after 3 months. Skills go stale, memory accumulates, test counts drift, quality gates erode. The factory must detect and report its own degradation.

**Deliverables:**

Health monitoring:
- `scripts/factory_health.py` — Comprehensive health check (test count trend, coverage, API cost, memory freshness, skill file dates, hook configuration integrity)
- Scheduled weekly health report (written to `health_reports/YYYY-MM-DD.md`)
- Alert thresholds: test count drops, coverage decreases, cost spikes, stale memories

Self-repair:
- Auto-fix: If ruff/black formatting drifts, auto-format and commit
- Auto-detect: If agent definitions reference non-existent files, report to owner
- Auto-escalate: If quality gate fails 3x on same issue, escalate to human gate

Metric tracking:
- Test count per engine over time (should only go up)
- Coverage per engine over time
- API cost per session, per engine, cumulative
- Architect agreement rate (CC subagents + Gemini)
- Human gate queue depth and response time

Skill versioning:
- `scripts/skill_audit.py` — Checks skill files for freshness, cross-references with agent definitions
- Skills have `last_verified` date in frontmatter; flagged if >60 days old

**Key files to create/modify:**
- `scripts/factory_health.py` (new)
- `scripts/skill_audit.py` (new)
- `health_reports/` directory (new)

**Dependencies:** All other workstreams (meta-workstream)
**Effort:** 1 session initial, then ongoing
**Session type:** Dedicated CC session for initial setup; scheduled trigger for ongoing

---

## Execution Order

Dependency-driven phasing. Each phase completes before the next starts, but independent workstreams within a phase can run in parallel.

### Phase A: Foundation (Sessions 1-3)
**Goal:** Automated testing and domain knowledge exist.

```
Session 1: W1 — CI/CD Foundation
  - GitHub Actions expanded workflow
  - Pre-commit hooks installed
  - Test stratification (deterministic vs expensive)

Session 2: W2 — Domain Knowledge (part 1)
  - Create .claude/skills/ structure
  - Port 6 core domain skill files
  - Agent and skill registries

Session 3: W2 — Domain Knowledge (part 2)
  - Port 9 KR skills from Claude.ai format
  - Verify all agent skill references resolve
  - Domain knowledge integration tests
```

**Exit criteria:** CI passes on push. All agents can resolve their skill references. Pre-commit hooks block bad commits.

### Phase B: Autonomous Core (Sessions 4-5)
**Goal:** CC can operate without human initiation.

```
Session 4: W3 — Autonomous Execution
  - ENGINE_STATE.json state machine
  - Session recovery from state
  - Desktop scheduled task setup

Session 5: W3 + W4 — Execution + Quality Gates
  - Scheduled trigger testing and hardening
  - Protocol enforcement hooks
  - Auto-dispatch review agents on code changes
```

**Exit criteria:** CC can wake up on schedule, read state, do meaningful work, write state, and sleep. Quality gates block protocol violations structurally.

### Phase C: Intelligence (Sessions 6-8)
**Goal:** Multi-model architecture and decision logging.

```
Session 6: W5 — Multi-Model Architect (part 1)
  - Architect subagent definitions (protocol + first-principles + comparator)
  - Architect invocation protocol

Session 7: W5 + W7 — Architect + Decisions
  - Gemini API integration
  - Multi-model consensus script
  - ADR system setup, backfill initial decisions

Session 8: W7 — Memory & Decision Logging
  - Memory audit script
  - Scheduled memory cleanup
  - ADR integration with SPEC and code
```

**Exit criteria:** Major decisions go through dual-architect review. All historical decisions backfilled as ADRs. Memory audit catches stale entries.

### Phase D: Owner Interface (Sessions 9-11)
**Goal:** Owner can see status and make decisions efficiently.

```
Session 9: W6 — Dashboard
  - Dashboard generation script
  - GitHub Pages deployment
  - Auto-refresh on every push

Session 10: W6 — Human Gate
  - Pending/completed directory structure
  - Decision request templates
  - Summary generation script

Session 11: W6 — Arabic Output Formatter
  - JSON-to-HTML conversion for scholarly text
  - RTL layout, Amiri font, diacritics
  - Side-by-side metadata view
```

**Exit criteria:** Owner can open a URL and see current status. Pending decisions are presented in structured, non-technical format. Arabic text is readable with proper formatting.

### Phase E: External Knowledge (Sessions 12-15)
**Goal:** Domain verification uses external sources.

```
Session 12: W8 — Usul.ai integration
Session 13: W8 — Sunnah.com integration
Session 14: W8 — KITAB/OpenITI corpus setup
Session 15: W8 — Swan embeddings + semantic search
```

**Note:** These sessions are TRIGGERED by evaluation results, per SESSION_3_4_BACKLOG.md. If evaluation doesn't reveal gaps in scholar verification, Usul.ai integration can be deferred. Build only what's needed.

**Exit criteria:** Verification agents can cross-reference claims against external sources. Hadith references can be validated. Semantic search works across processed books.

### Phase F: Sustainability (Session 16 + ongoing)
**Goal:** The factory monitors and maintains itself.

```
Session 16: W9 — Health monitoring + self-repair
  - Factory health script
  - Scheduled health reports
  - Skill audit and versioning
  - Self-repair protocols
```

**Exit criteria:** Weekly health reports generated automatically. Stale skills/memories detected. Quality degradation triggers alerts.

---

## Interleaving with Engine Work

**Critical:** The factory setup does NOT block engine development. After each phase completes, resume engine work with the new infrastructure in place:

- After Phase A: Continue excerpting engine with CI protection and domain skills
- After Phase B: Excerpting hardening and evaluation runs autonomously
- After Phase C: Passaging/atomization engines get multi-model architect review
- After Phase D: Owner reviews Arabic excerpting output through proper interface
- After Phase E: Taxonomy and synthesis engines get external knowledge verification

The factory and engines grow together. Each factory improvement makes the next engine build better.

---

## Validation & Stress Test

### Weakest Links

**1. Windows Scheduled Task Reliability**
- Risk: Desktop tasks depend on machine being on. Power loss, Windows Update restarts, or Task Scheduler bugs could stop the factory.
- Mitigation: Heartbeat logging + stale-heartbeat alert. If heartbeat stops, owner gets notification. Cloud scheduled tasks as backup (1hr minimum interval, costs money, but reliable).
- Severity: MEDIUM. The owner's machine is presumably on during study hours.

**2. Single-Model Architect Blind Spots**
- Risk: CC subagents use the same underlying model (Opus 4.6). Systematic biases in Opus affect both protocol-guided and first-principles architects.
- Mitigation: Gemini provides genuine model diversity for major decisions. For routine decisions, the dual-prompting strategy catches prompt-specific (not model-specific) blind spots.
- Severity: LOW for routine decisions (hooks catch code-level errors), MEDIUM for architectural decisions (Gemini covers this).

**3. Gemini API Stability**
- Risk: Google reduced free tier limits 50-80% in Dec 2025. Further reductions or deprecation possible.
- Mitigation: Gemini is used for major decisions only (3-5 per engine lifecycle). Even at 5 RPM free tier, this is sufficient. Paid tier ($1-2/day) is negligible cost. Fallback: use a different model API (GPT-4o, Mistral) or CC-only dual-prompting.
- Severity: LOW. Multiple fallback options exist.

**4. Human Gate Queue Starvation**
- Risk: Owner gets busy with studies. Pending decisions accumulate. Factory is blocked on human decisions with no timeout.
- Mitigation: CC continues on non-blocked work items. Dashboard shows pending count prominently. For decisions pending >7 days, CC auto-escalates urgency. For truly blocked items, CC can attempt to proceed with the conservative/safe option and flag for post-hoc review.
- Severity: LOW. Owner explicitly said "as much as possible" for genuine needs.

**5. Memory/Decision Log Entropy**
- Risk: After 6 months, MEMORY.md has 200+ entries, many stale. ADR directory has 50+ files, hard to navigate. Decision Playbook is 100K tokens.
- Mitigation: Weekly memory audit script detects stale entries. ADR index with tags. Decision Playbook organized by engine and topic.
- Severity: MEDIUM. This is the most likely long-term degradation vector. The memory audit script (W7) is the primary defense.

**6. No External Failsafe for CC Quality**
- Risk: If CC has a "bad session" (degraded reasoning due to context pressure, model issues, or prompt drift), who catches it?
- Mitigation: Multi-layered defense:
  - Pre-commit hooks catch code-level errors
  - CI catches test regressions
  - Architect subagents catch design errors (different prompting strategy)
  - Gemini catches model-specific blind spots
  - Scheduled health checks catch quality metrics drift
  - Owner reviews Arabic output (domain correctness)
- Severity: LOW. No single layer is sufficient, but the combination is robust. The key insight: CC's quality gate infrastructure (13 hooks + 21 agents + CI) is MORE rigorous than a human architect's discipline.

### What I Might Be Overengineering

**1. External Knowledge Integration (W8)**
- Usul.ai, Sunnah.com, KITAB, Swan embeddings — 4 integrations, 4 sessions.
- Reality check: The excerpting engine hasn't even run its first real evaluation. We don't know which external sources are needed.
- Recommendation: Keep W8 trigger-conditional. Build only what evaluation reveals as needed.

**2. Arabic Output Formatter (W6 part 3)**
- Full HTML formatting with Amiri font and side-by-side metadata.
- Reality check: The owner is an Islamic studies student who can read Arabic in any format. A well-structured markdown file might be sufficient.
- Recommendation: Start with structured markdown. Upgrade to HTML only if the owner finds markdown insufficient.

**3. Architect Comparator Agent (W5)**
- Three architect agents (protocol, first-principles, comparator) for every decision.
- Reality check: Most routine decisions don't need this overhead.
- Recommendation: Use single architect for routine decisions, dual + comparator only for SPEC design and engine transitions.

### What I Might Be Missing

**1. Rollback Mechanism**
- If a commit introduces a regression that passes CI but breaks domain correctness, there's no guided rollback procedure.
- Recommendation: Add to W4 — a `scripts/safe_rollback.py` that reverts to last-known-good state.

**2. Cross-Engine Regression**
- Current CI runs per-engine tests. A change in shared/ could break multiple engines.
- Recommendation: CI workflow should run ALL engine tests when shared/ files change.

**3. Factory Self-Test**
- The factory tests engines, but does the factory test itself?
- Recommendation: Add to W9 — a `scripts/factory_self_test.py` that verifies hooks fire, agents resolve skills, CI passes, scheduled tasks are alive.

**4. Backup & Recovery**
- If the repo is corrupted or the machine fails, how is the factory restored?
- Recommendation: GitHub is the backup. All state is in git. Document recovery procedure in W9.

---

## Verification Plan

After all workstreams complete, verify the factory end-to-end:

### Factory Acceptance Test

1. **Autonomous Wake-Up:** Scheduled trigger fires, CC reads ENGINE_STATE.json, generates a work prompt, and begins working. No human intervention.

2. **Quality Gate Enforcement:** Intentionally introduce a protocol violation (skip review checklist). Verify the commit is blocked.

3. **Multi-Model Architect:** CC proposes a SPEC change. Verify both CC subagents and Gemini produce independent reviews. Verify disagreements are flagged.

4. **Human Gate:** CC encounters a decision requiring human judgment. Verify it writes to human_gate/pending/ and continues on non-blocked work.

5. **Dashboard:** Push a commit. Verify dashboard updates within 5 minutes on GitHub Pages.

6. **Regression Detection:** Intentionally break a test. Verify CI catches it. Verify regression-detector agent identifies the new failure.

7. **Memory Audit:** Introduce a stale memory entry. Verify weekly audit flags it.

8. **Domain Skill Resolution:** Dispatch arabic-reviewer agent. Verify it loads .claude/skills/arabic-text/SKILL.md successfully.

9. **Health Check:** Run factory_health.py. Verify it reports test count trend, coverage, API cost, memory freshness.

10. **End-to-End Engine Build:** Build a trivial test engine (mock passaging engine with 3 deterministic rules). Verify the entire factory pipeline works: SPEC → architect review → build → test → CI → evaluate → human gate → complete.

---

## First Session: W1 — CI/CD Foundation

The very first session should build the CI/CD foundation because:
1. Every subsequent workstream benefits from automated testing
2. Pre-commit hooks immediately prevent bad commits
3. GitHub Actions catches regressions that current manual testing misses
4. Low risk, high immediate value, no dependencies

**Session 1 deliverables:**
- [ ] Expand `.github/workflows/test.yml` (ruff, black, pyright, test stratification)
- [ ] Create nightly workflow for expensive LLM tests
- [ ] Create `.pre-commit-config.yaml`
- [ ] Create `scripts/check_decision_discipline.py`
- [ ] Add `@pytest.mark.expensive` to LLM-dependent tests
- [ ] Enable GitHub branch protection on master
- [ ] Verify: push a commit, confirm CI runs and passes
