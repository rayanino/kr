# Plan: Harden Overnight Sprint System (FIX-1 through FIX-8)

## Context

The overnight sprint system ran on 2026-03-28 and completed 24/27 readonly tasks but **zero** write tasks. Three test-generation timeouts (same root cause: sonnet + complex tasks) triggered the circuit breaker, killing 48 queued tasks. Two of those "timed out" tasks actually produced 22-23KB of useful output. The goal is to make this system trustworthy for 8-20 hour unmonitored runs.

## Files to Modify

| File | Changes |
|------|---------|
| `scripts/overnight_orchestrator.py` | FIX-1, 3, 4, 5, 6, 7 |
| `scripts/weekend_parallel.py` | FIX-2, 3, 4, 5, 6 |
| `scripts/sprint_dashboard.py` | FIX-8, partial_success icon |

## Implementation Order

FIX-3 → FIX-1 → FIX-5 → FIX-7 → FIX-6 → FIX-2 → FIX-4 → FIX-8

---

### FIX-3: Task Ordering — Easy Wins First

**overnight_orchestrator.py:**
- Line 258: Add `estimated_complexity: str = "medium"` to `TaskDef`
- Line 1177: Change sort from `key=lambda t: t.priority` to `key=lambda t: (t.priority, _COMPLEXITY_ORDER.get(t.estimated_complexity, 1), t.task_id)` where `_COMPLEXITY_ORDER = {"low": 0, "medium": 1, "high": 2}`
- Line 1406 (dry-run): Show complexity in the plan output

**weekend_parallel.py:**
- Line 84: Add `estimated_complexity: str = "medium"` to `TaskDef`
- Lines 384-385: Change both sorts from `(t.priority, t.task_id)` to `(t.priority, _COMPLEXITY_ORDER.get(t.estimated_complexity, 1), t.task_id)`
- Define `_COMPLEXITY_ORDER` near top of file

Backwards-compatible: old manifests without the field get `"medium"` default. Both `load_manifest` functions filter to known fields.

---

### FIX-1: Smart Circuit Breaker

**overnight_orchestrator.py:**
- Line 43: Add constants `MAX_CONSECUTIVE_CRASHES = 3` and `MAX_CONSECUTIVE_TIMEOUTS = 5`
- Lines 279-294 (`OvernightState`): Add `consecutive_crashes: int = 0` and `consecutive_timeouts: int = 0`
- Lines 1609-1611 (success reset): Also reset `consecutive_crashes = 0` and `consecutive_timeouts = 0`
- Lines 1613-1616 (failure recording): Replace single increment with categorized:
  - `status == "timeout"` → increment `consecutive_timeouts`, reset `consecutive_crashes`
  - `status == "failed"` → increment `consecutive_crashes`, reset `consecutive_timeouts`
  - Keep `consecutive_failures` increment for backwards compat
- Lines 1474-1478 (breaker check): Replace single check with two:
  - `consecutive_crashes >= MAX_CONSECUTIVE_CRASHES` → stop (hard)
  - `consecutive_timeouts >= MAX_CONSECUTIVE_TIMEOUTS` → stop (soft)

Backwards-compatible: new fields default to 0. Old state.json files load fine via `OvernightState(**data)`.

---

### FIX-5: Partial Success Detection

**overnight_orchestrator.py:**
- After line 720: Add `_check_partial_success(task_id)` helper — checks if `overnight/results/{task_id}/` has `findings.json`, `findings.md`, or `summary.md` > 1KB
- Lines 699-704 (timeout handler): After creating timeout `TaskResult`, check `_check_partial_success` → if True, set `status = "partial_success"` and append note to error
- Lines 1607-1620 (result recording): Add new branch for `partial_success` BEFORE `failed/timeout`:
  - Count as completed (not failed)
  - Reset all failure counters (does NOT trigger breaker)
  - Print "PARTIAL SUCCESS — output preserved"
- Line 1131 (`pick_next_ready`): Add `"partial_success"` to `blocked_ids` set (downstream deps still skipped since commit may not exist)
- Line 1148: Do NOT add `partial_success` to `completed_ids` (it's not a full success for deps)

**weekend_parallel.py:**
- Lines 230-234 (timeout handler): After `proc.kill()`, check for findings files > 1KB in `task_dir`. If found, set `status = "partial_success"` instead of `"timeout"`
- Lines 121-130 (`SprintState.record_result`): Treat `partial_success` same as `success` for counting

---

### FIX-7: Adaptive Timeouts for Write Tasks

**overnight_orchestrator.py:**
- Before main loop (~line 1460): Initialize `timeout_overrides: dict[str, float] = {}` and `category_timeouts: dict[str, int] = {}`
- Add constant `MAX_TIMEOUT_MINUTES = 45`
- Before `execute_task()` call (line 1530): Calculate effective timeout:
  - Base: `task.timeout_minutes`
  - Multiply by `timeout_overrides.get(task.category, 1.0)`
  - If `task.estimated_complexity == "high"`: multiply by 1.5
  - Cap at `MAX_TIMEOUT_MINUTES`
  - Temporarily set `task.timeout_minutes = effective_timeout`, restore after execution
- After result recording: If timeout, increment `category_timeouts[cat]` and set `timeout_overrides[cat] = 1.0 + 0.5 * min(count, 3)`. If success, clear that category's tracking.

---

### FIX-6: Unified Heartbeat

**overnight_orchestrator.py:**
- Lines 571-584 (`_write_heartbeat`): Add `"source": "write_orchestrator"` to the JSON

**weekend_parallel.py:**
- Add `HEARTBEAT_FILE = OVERNIGHT_DIR / ".heartbeat"` constant
- Add `_write_unified_heartbeat(state, total_readonly, total_write)` function using atomic temp+rename pattern. Fields: `source`, `pid`, `timestamp`, `readonly_completed`, `readonly_failed`, `readonly_active` (list), `write_completed`, `write_failed`, `total_readonly`, `total_write`
- Call after `state.save()` at lines 445 and 459

---

### FIX-2: Write Orchestrator Health Monitoring

**weekend_parallel.py:**
- Add `write_orchestrator_status: str` field to `SprintState.__init__` (default `"not_started"`) and include in `save()` data dict
- Add `_monitor_write_orchestrator(proc, state, shutdown, poll_interval_s=60)` function:
  - Runs as daemon thread
  - Polls `proc.poll()` every 60s → detect early death
  - Reads `.heartbeat` for progress → detect stall (no change for 50 min / 2x max timeout)
  - Updates `state.write_orchestrator_status` with running|stalled|dead|completed
  - Catches `PermissionError`/`OSError` on Windows file access
- After line 402 (write_proc launch): Set `state.write_orchestrator_status = "running"`, start monitor thread as daemon
- After line 472 (communicate): Update final status from `write_proc.returncode`

---

### FIX-4: Crash Resume

**weekend_parallel.py:**
- Line 502: Add `parser.add_argument("--resume", action="store_true")`
- Pass `resume=args.resume` to `run_parallel()`
- Add `resume: bool = False` parameter to `run_parallel()` signature
- Before `state = SprintState()` (line 372): If `resume` and `STATE_FILE` exists, load old state, extract completed task IDs (status in `success`, `partial_success`), filter `regular_readonly` and `write_tasks` to skip them. Print resume summary.

**overnight_orchestrator.py:**
- Line 1674: Add `parser.add_argument("--resume", action="store_true")`
- Pass `resume=args.resume` to `run_overnight()`
- Add `resume: bool = False` to `run_overnight()` signature
- Lines 1416-1434: When `resume=True`, skip stale state deletion. Call `load_state()`, and if valid stopped/crashed state exists, reuse it (reset failure counters, set status to running, recalculate deadline). Otherwise fall through to fresh start.

---

### FIX-8: Dashboard Shows Write Orchestrator Status

**sprint_dashboard.py:**
- Line 28: Add `"partial_success": "~"` and `"rolled_back": "R"` to `status_icon`
- After line 36: Load `.heartbeat` file
- Extract write orchestrator process info from heartbeat: `source`, `last_task`, `last_task_status`, `timestamp` (check staleness > 1 hour)
- Also read `write_orchestrator_status` from `weekend_state.json`
- Lines 82-86: Add `Process:` line showing heartbeat-derived status, and `Last:` line showing last task and result

---

## Verification

After all fixes:
1. `python scripts/weekend_parallel.py --manifest overnight/sprint_manifest.json --dry-run` — tasks should show complexity-based ordering
2. `python scripts/weekend_parallel.py --manifest overnight/sprint_manifest.json --task audit-stale-artifacts` — single task completes successfully
3. `python scripts/sprint_dashboard.py` — shows write orchestrator status section
4. Verify all three files have no syntax errors: `python -c "import scripts.weekend_parallel"` etc.

## Commit

`fix(overnight): harden sprint system — smart breaker, resume, health monitoring`
