# Evaluation: code-review-graph for KR Project

## Context

The owner found [tirth8205/code-review-graph](https://github.com/tirth8205/code-review-graph) (5.5K stars, MIT, Python) — a Tree-sitter-based knowledge graph that builds a structural map of codebases so AI assistants read only relevant files during code reviews. Claims 6.8× fewer tokens on reviews, up to 49× on daily tasks.

**Question:** Should KR adopt this tool?

---

## What code-review-graph does

- Parses code with Tree-sitter into nodes (functions, classes, imports) and edges (calls, inheritance, test coverage)
- Stores the graph in local SQLite
- Exposes 22 MCP tools for blast-radius analysis, semantic search, architecture overview
- Auto-updates on git commits via watchdog hooks
- Key metric: token reduction for AI context windows

## KR codebase reality

| Metric | Value | Implication |
|--------|-------|-------------|
| Python source files | 257 | Small — not a monorepo |
| Python source lines | 66K | Medium — fits in 1M context |
| Test files | 109 | Manageable |
| Files per commit (median) | 1-7 | Small blast radius |
| contracts.py importers | 125 files | Largest cross-cutting concern |
| Total .py files (incl. generated) | 2,208 | Moderate with dependencies |
| Current MCP servers | 4+ (Serena, Context7×2, memory, tavily, sequential-thinking) | Already approaching the ≤5 limit |

## Verdict: **Do NOT adopt**

### Reasons against

1. **Wrong bottleneck.** KR's bottleneck is scholarly text quality (Arabic diacritics, school attribution, SPEC correctness), not code navigation token efficiency. The tool optimizes for a problem KR doesn't have. The 1M Opus context window can hold the entire KR Python codebase — there is no token pressure on code review.

2. **Codebase is too small.** The tool's headline metrics (49× reduction, 6.8× fewer tokens) come from monorepos with 27K+ files. KR has 257 Python source files. An engineer (human or AI) working on the excerpting engine already knows the ~15 relevant files. A structural graph adds overhead without meaningful improvement.

3. **MCP server budget is at limit.** The context-management rule says "Keep enabled MCP servers to ≤5." KR already has Serena (code navigation), Context7×2 (docs lookup), memory (graph), tavily (search), and sequential-thinking. Adding another MCP server consumes context budget that is better spent on the actual work.

4. **Serena already covers the core use case.** The Serena MCP plugin provides: `find_symbol`, `find_referencing_symbols`, `get_symbols_overview`, `search_for_pattern`, `insert_after_symbol`, `replace_symbol_body`. These are the same structural navigation capabilities that code-review-graph offers, already integrated and producing no additional dependency.

5. **Blast radius is already managed by rules.** The `shared-concept-changes.md` rule requires grep-first, check-all-consumers, and independent reviewer dispatch when modifying shared concepts. This is a process solution that works for KR's scale. A graph tool would be overkill.

6. **Dependency risk.** Tree-sitter + tree-sitter-language-pack + networkx + watchdog + fastmcp + mcp = 6 new dependencies (plus transitive). The tool is 4 months old. Dependency churn risk is non-trivial for a correctness-focused project.

7. **No Arabic text benefit.** The tool parses code structure (Python AST). KR's hardest problems are in Arabic scholarly text processing — an area where Tree-sitter provides zero value. Every hour spent configuring code-review-graph is an hour not spent on SPEC hardening or prompt architecture.

### What it WOULD help with (minor)

- **contracts.py blast radius:** 125 files import from excerpting contracts. A graph tool could trace which functions are affected by a contracts change. But: this happens rarely (contracts are stable post-build), and `grep` + Serena already handle it.
- **Cross-engine dependency tracking:** If 7 engines were all active simultaneously, a graph would help. But: only excerpting is active, source+normalization are complete, others are first-draft only.

### Better alternatives for what this tool does

| Need | Better alternative | Why |
|------|--------------------|-----|
| Blast radius analysis | `grep -r` + Serena `find_referencing_symbols` | Already available, zero new deps |
| Code review context | CC subagent with specific file list | Already the pattern in use |
| Architecture overview | `docs/architecture/pipeline_diagrams.md` (Mermaid) | Already exists |
| Test coverage mapping | `pytest --cov` + existing test patterns | Already in use |

## Recommendation

**Skip it.** The tool solves a real problem (token waste on large codebases) that KR doesn't have. Revisit only if:
- KR grows to 1000+ Python files across all 7 engines
- Context window pressure becomes a measurable bottleneck
- Serena is removed or becomes insufficient

**No action needed from the owner.**
