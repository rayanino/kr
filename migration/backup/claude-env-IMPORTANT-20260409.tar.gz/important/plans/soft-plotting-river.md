# CLI Speed Architecture — Maximize Excerpting Throughput

## Context

The excerpting engine makes 4+ LLM calls per chunk via CLI backends (claude -p, codex exec, gemini -p), each taking ~500s. A 5-package test takes 2-9 hours. Scaling to 7,475 books (~37K chunks) at current throughput: **86 days at 5 concurrent**. Target: **≤21 days**. That requires **4x throughput improvement** — from 5 to ~20 effective concurrent CLI calls, plus waste elimination.

Production runs MUST use CLI (flat-rate subscriptions, $0 marginal cost). API reserved for development iteration only.

---

## Multi-Model Review Findings (Claude + Codex GPT-5.4 + Gemini)

Three independent reviews identified 10 findings that shaped this plan:

| # | Finding | Severity | Source | Resolution |
|---|---------|----------|--------|------------|
| F1 | `verify_units()` in phase2_group.py mutates TeachingUnit in-place (lines 235,245,257,266) | MEDIUM | Code validator | Safe in per-chunk model (each chunk owns its units), but fix for hygiene — use `model_copy(update=...)` |
| F2 | Hook logger `call_counter`, `call_start_time`, `trace_context` are shared mutable state | HIGH | Codex+Validator | **Per-thread CLIInstructorAdapter instances** (not shared) |
| F3 | Cache key missing `source_metadata`, `structural_format`, `response_model` schema | HIGH | Codex | **Hash the full constructed prompt** (system+user messages as sent), not individual constants |
| F4 | `_tool_checked` set has TOCTOU race (check-then-add not atomic) | LOW | Validator | Per-thread adapters eliminate this |
| F5 | No circuit breaker — 40 threads retrying against a down backend = retry storm | HIGH | Gemini | **New: CircuitBreaker class** in parallel_orchestrator |
| F6 | Silent cache poisoning — LLM refusals cached as valid results | HIGH | Gemini | **Cache validation gate**: must parse as expected Pydantic model with non-empty primary fields |
| F7 | `os.replace()` fails on Windows when target locked by reader | MEDIUM | Gemini | **WAL-based progress** (.jsonl append) instead of JSON replace |
| F8 | `run_consensus()` pseudocode omits excerpt-to-item mapping, gate triggers | MEDIUM | Codex | Need dedicated `_run_consensus_for_chunk()` wrapper |
| F9 | OneDrive sync on Desktop path causes I/O overhead with 100K+ artifact files | LOW | Gemini | Document: use non-synced output directory for production |
| F10 | Concurrency ceiling unknown — 21-day target assumes concurrency 40 works | HIGH | All three | **Pre-production ramp test** protocol added to verification |

**Confirmed correct by all reviewers:** ThreadPoolExecutor choice, global semaphore pattern, per-chunk function statelessness (classify_chunk, enrich_chunk, verify_chunk, resolve_consensus), raw LLM caching, layer ordering.

---

## Architecture Overview: 7 Optimization Layers

```
Layer 1: PER-PHASE TIMEOUTS      — stop wasting 60 min on doomed calls        [1-2h effort, ~60 min/run saved]
Layer 2: CHUNK-LEVEL RESUME       — never redo completed work after crash      [4-6h effort, ~4h/crash saved]
Layer 3: INPUT-BASED CACHING      — skip identical re-processing on restart    [3-4h effort, full-rerun saved]
Layer 4: CHUNK-LEVEL PARALLELISM  — THE BIG WIN: 4-20x throughput increase    [6-8h effort, 4x+ speedup]
Layer 5: CIRCUIT BREAKER          — survive backend outages without waste      [2-3h effort, critical for 21-day run]
Layer 6: BATCH ESCALATION         — N disagreement calls → 1 batched call     [2-3h effort, ~4 min/pkg saved]
Layer 7: PROGRESS VISIBILITY      — real-time dashboard of pipeline state      [2-3h effort, operational clarity]
```

**Not recommended at this stage:**
- Model routing (Phase 2a faster model): Requires full evaluation rerun to validate accuracy. Revisit after caching enables cheap A/B comparison.
- Adaptive timeout (monitor subprocess stdout growth): CLI backends don't stream incrementally on Windows. Speculative, needs prototype.

---

## Layer 1: Per-Phase Timeouts

**Problem:** Flat `TIMEOUT_SECONDS=1800` (30 min) for all phases. Ibn_aqil_v3 burned 60 min on 2 enrichment timeouts before succeeding on attempt 3.

**Solution:** Replace single timeout with per-phase values calibrated from measured data:

| Phase | Measured Range | New Timeout | Rationale |
|-------|---------------|-------------|-----------|
| 2a classify | 258-1438s | 900s (small chunk) / 1200s (>1500 words) | Proportional to word count |
| 2b group | 106-937s | 900s | Shorter output than classify |
| 3 enrich | 260-430s | 900s | Conservative buffer |
| 3 verify | 98-252s | 600s | GPT-5.4 is 3-4x faster |
| 3 escalation | 14-150s | 300s | Simple response model |

**Also:** On retry, multiply timeout by 1.5x (not repeat same timeout), capped at 2x base. Skip backoff sleep for ValidationError retries (not rate-related).

**Files to modify:**
- `engines/excerpting/contracts.py` — Add 5 timeout fields to ExcerptingConfig (replace single TIMEOUT_SECONDS)
- `engines/excerpting/src/phase2_classify.py` — Use `config.CLASSIFY_TIMEOUT` in `classify_chunk()`
- `engines/excerpting/src/phase2_group.py` — Use `config.GROUP_TIMEOUT`
- `engines/excerpting/src/phase3_enrichment.py` — Use `config.ENRICH_TIMEOUT`
- `engines/excerpting/src/phase3_consensus.py` — Use `config.VERIFY_TIMEOUT` and `config.ESCALATION_TIMEOUT`

**Codex-independent:** YES. Purely mechanical substitution with clear spec.

---

## Layer 2: Chunk-Level Resume

**Problem:** Resume only works at package level. Crash at chunk 15/20 = redo 14 chunks = ~3.8 hours wasted.

**Solution:** WAL-based progress tracking via append-only JSONL (addresses F7 — `os.replace()` fails on Windows when file locked by reader).

**Progress file:** `{output_dir}/progress.jsonl` (append-only, crash-safe):
```jsonl
{"chunk_id":"div_001","phase":"phase2a","status":"done","timestamp":"2026-03-31T10:00:00Z"}
{"chunk_id":"div_001","phase":"phase2b","status":"done","timestamp":"2026-03-31T10:08:00Z"}
{"chunk_id":"div_001","phase":"phase3_enrich","status":"failed","error":"EX-M-002","timestamp":"2026-03-31T10:16:00Z"}
```

**Why JSONL over JSON:** (F7 mitigation)
- Append is atomic on NTFS — no partial writes even on crash
- No `os.replace()` needed — eliminates Windows PermissionError when monitoring script reads the file
- Replay on startup: scan lines, last entry per (chunk_id, phase) wins
- Works correctly under concurrent thread writes (each append is a single `write()` syscall)

**Protocol:**
1. On startup → replay `progress.jsonl` to build in-memory state dict
2. Before starting a chunk's phase → check in-memory state + verify artifact file exists and is valid
3. On success → append "done" line, update in-memory state
4. On failure → append "failed" line with error code

**Artifact loading on resume:**

| Phase | Artifact File | Validation |
|-------|--------------|------------|
| 2a | `phase2a_classifications/chunk_{id}.json` | Non-empty, valid JSON, segments list non-empty |
| 2b | `phase2b_groupings/chunk_{id}.json` | Non-empty, valid JSON, units list non-empty |
| 3 enrich | `raw_llm_responses/enrich_*.json` by chunk_id | Parse as EnrichmentResult |

**New file:** `engines/excerpting/src/progress.py` — `ProgressTracker` class with `is_done()`, `mark_done()`, `mark_failed()`, `replay()`, `_append()`.

**Modified files:**
- `engines/excerpting/src/phase2_classify.py` — `run_phase2a()` accepts optional ProgressTracker, skips done chunks
- `engines/excerpting/src/phase2_group.py` — same pattern
- `engines/excerpting/src/phase3_enrichment.py` — same pattern
- `engines/excerpting/src/phase3_consensus.py` — same pattern
- `scripts/run_integration_test.py` — Create ProgressTracker in `run_pipeline()`, load prior progress, pass to phases

**Codex-independent:** YES. Self-contained module + mechanical integration into phase loops.

---

## Layer 3: Input-Based Caching

**Problem:** Identical chunks re-processed on every run. No dedup.

**Solution:** Hash all inputs that affect output → cache key → skip if result exists.

**Cache key algorithm (revised per F3 — hash the FULL prompt, not constants):**

```python
def compute_cache_key(
    phase: str,
    system_message: str,   # The FULL system prompt as sent (includes schema, structural_format, etc.)
    user_message: str,      # The FULL user prompt as sent (includes assembled_text, source_metadata, etc.)
    model: str,
    temperature: float,
    max_tokens: int,
) -> str:
    """Hash everything that affects LLM output. No input omissions possible."""
    payload = json.dumps({
        "phase": phase,
        "system": system_message,
        "user": user_message,
        "model": model,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:16]
```

**Why hash full prompts (F3 fix):** The original plan hashed individual constants + assembled_text. Codex review found 4 missing inputs: `source_metadata`, `structural_format`, `response_model` schema, `error_feedback`. By hashing the exact system+user messages as constructed, we capture ALL inputs — nothing can be missed. Any change to prompt construction logic = different hash = automatic invalidation.

**Cache validation gate (F6 fix — prevent silent cache poisoning):**
```python
def validate_before_caching(phase: str, raw_result: str, response_model: type) -> bool:
    """Reject LLM refusals, empty results, and malformed responses before caching."""
    try:
        parsed = json.loads(raw_result)
        obj = response_model.model_validate(parsed)
        # Phase-specific non-empty checks:
        if phase == "classify" and len(obj.segments) == 0:
            return False
        if phase == "group" and len(obj.teaching_units) == 0:
            return False
        if phase == "enrich" and len(obj.enrichments) == 0:
            return False
        return True
    except (json.JSONDecodeError, ValidationError):
        return False
```

**Key design decision:** Cache the **raw LLM result** (pre-normalization, pre-repair), not the post-processed result. If normalization or repair logic changes, cached results are re-processed through updated post-processing. Safer for knowledge integrity.

**Integration point:** The cache check inserts into the per-chunk worker function, BETWEEN prompt construction and the LLM call:

```python
# 1. Build system_message and user_message (existing code)
# 2. Compute cache key from the built messages
cache_key = compute_cache_key(phase, system_message, user_message, model, temp, max_tokens)
# 3. Check cache
cached = cache.load(cache_key, response_model)
if cached is not None:
    return cached  # Skip LLM call
# 4. Make LLM call (existing code)
result = client.chat.completions.create(...)
# 5. Validate and cache
if validate_before_caching(phase, raw_result, response_model):
    cache.save(cache_key, chunk_id, model, raw_result)
```

**This requires extracting the built messages before the client call.** Currently, message construction happens inside `classify_chunk()`, `group_chunk()`, etc. The cache integration needs access to the constructed messages. Two approaches:
- **Option A (preferred):** Extract message construction into a separate function `build_classify_messages(chunk, config) -> (system, user)`, then cache check wraps the call.
- **Option B:** Add cache hooks inside each phase function (more invasive).

**Storage:** `{output_dir}/cache/{phase}/{cache_key}.json` with metadata (chunk_id, model, timestamp).

**New file:** `engines/excerpting/src/cache.py` — `CacheManager` with `compute_key()`, `load()`, `save()`, `validate_before_caching()`.

**Codex-independent:** YES. Self-contained with clear spec. The full-prompt hashing eliminates the risk of missing inputs.

---

## Layer 4: Chunk-Level Parallelism + Pipeline Overlap (THE BIG WIN)

**Problem:** Chunks processed sequentially within each phase. At 1 call at a time, throughput is 1/500th of the CLI backend's capacity.

**Solution:** ThreadPoolExecutor with global semaphore controlling max concurrent CLI calls.

### Why ThreadPoolExecutor, not asyncio

1. CLI adapter uses `subprocess.run()` (blocking). Converting to async requires rewriting the entire adapter + invalidating 49 tests.
2. Python threads are perfect for I/O-bound subprocess waits (99.9% time in `subprocess.run()`, GIL irrelevant).
3. Windows compatibility: ThreadPoolExecutor works identically on Windows/Unix.

### Architecture

New file: `engines/excerpting/src/parallel_orchestrator.py`

```
                   run_integration_test.py
                          |
                          v
              ┌─────────────────────────┐
              │  parallel_orchestrator   │  ← NEW (config.CONCURRENCY > 1)
              │                         │
              │  ConcurrencyController  │  (threading.Semaphore)
              │  CircuitBreaker         │  (Layer 5, see below)
              │  ChunkPipelineContext   │  (per-chunk state)
              │  run_parallel_pipeline  │  (ThreadPoolExecutor)
              └─────────────────────────┘
                 |    |    |    |
                 v    v    v    v
           classify  group  enrich  verify
           (existing per-chunk functions, unchanged)
```

### Per-Chunk Pipeline Worker

Each chunk gets its own thread running the full phase chain. The semaphore gates only the LLM call:

```python
def process_chunk(ctx, clients, config, semaphore, breaker, progress, cache):
    """Full pipeline for one chunk. Called in its own thread."""

    # Phase 2a — classify
    if not progress.is_done(ctx.chunk_id, "phase2a"):
        breaker.check()  # Raises if circuit open (Layer 5)
        semaphore.acquire()
        try:
            ctx.segments = classify_chunk(ctx.chunk, ctx.client, config)
        finally:
            semaphore.release()
        progress.mark_done(ctx.chunk_id, "phase2a")
    else:
        ctx.segments = load_cached_segments(ctx.chunk_id)  # Resume path

    # Phase 2b — group (depends on 2a for THIS chunk only)
    if not progress.is_done(ctx.chunk_id, "phase2b"):
        breaker.check()
        semaphore.acquire()
        try:
            ctx.units = group_chunk(ctx.chunk, ctx.segments, ctx.client, config)
        finally:
            semaphore.release()
        progress.mark_done(ctx.chunk_id, "phase2b")
    else:
        ctx.units = load_cached_units(ctx.chunk_id)

    # Phase 3 deterministic (no LLM, no semaphore)
    ctx.excerpts = build_deterministic(ctx.chunk, ctx.units, ctx.segments)

    # Phase 3 enrichment
    if not progress.is_done(ctx.chunk_id, "phase3_enrich"):
        breaker.check()
        semaphore.acquire()
        try:
            ctx.enriched = enrich_chunk(ctx.chunk, ctx.excerpts, ctx.client, config)
        finally:
            semaphore.release()
        progress.mark_done(ctx.chunk_id, "phase3_enrich")
    else:
        ctx.enriched = load_cached_enriched(ctx.chunk_id)

    # Phase 3 verification + consensus
    if not progress.is_done(ctx.chunk_id, "phase3_consensus"):
        breaker.check()
        semaphore.acquire()
        try:
            ctx.final, ctx.gates = run_consensus_for_chunk(
                ctx.chunk, ctx.enriched, clients, config, source_metadata
            )
        finally:
            semaphore.release()
        progress.mark_done(ctx.chunk_id, "phase3_consensus")
```

**Pipeline overlap happens naturally:** With 20 threads and semaphore(20), at any moment some threads are in classify, others in group, others in enrich, others in verify. The semaphore prevents >20 simultaneous CLI calls regardless of phase mix.

### Thread Safety — Resolved (F1, F2, F4)

| Finding | Resolution | Implementation |
|---------|-----------|----------------|
| F2: Hook logger shared state | **Per-thread CLIInstructorAdapter** | Each worker thread creates its own adapter instance with its own hook logger. Thread-ID prefix on artifact filenames: `enrich_T03_0042.json` |
| F1: `verify_units()` mutates input | Safe (each chunk owns its units) | No change needed, but TODO: refactor to use `model_copy()` for hygiene |
| F4: `_tool_checked` TOCTOU race | Per-thread adapters | Each adapter has its own `_tool_checked` set |
| F8: `run_consensus()` architecture | New wrapper | `_run_consensus_for_chunk()` encapsulates: verify → collect disagreements → batch escalate → resolve → gate check |
| trace_contexts dict | Per-chunk context | Each worker sets `semantic_phase` and `chunk_id` on its own adapter's hooks before each call |

### `_run_consensus_for_chunk()` — New wrapper (F8 fix)

The plan's original pseudocode skipped the excerpt-to-verification-item mapping, per-excerpt resolution, and gate trigger logic from `run_consensus()`. The new wrapper:

```python
def _run_consensus_for_chunk(chunk, enriched_excerpts, clients, config, source_metadata):
    """Consensus pipeline for one chunk (called from per-chunk worker).

    Encapsulates: verify_chunk → match items to excerpts → resolve_consensus per excerpt
    → collect gate entries → return (final_excerpts, gate_entries).
    Mirrors the per-chunk logic in run_consensus() lines 743-877.
    """
    # 1. Check if any excerpts need consensus (school, attribution, self-containment)
    # 2. Call verify_chunk() — ONE LLM call for the chunk
    # 3. Match VerificationItems to excerpts by unit_index
    # 4. Call resolve_consensus() per excerpt (no LLM, just logic)
    # 5. Collect gate entries from gate triggers
    # 6. Return (resolved_excerpts, gate_entries)
```

### Composition with Package-Level Parallelism

`run_full_integration.py` already has `--parallel N` for packages. With chunk-level `--concurrency M`:
- Total system load = `N × M`
- Recommended: `--parallel 1 --concurrency 20` (one package, 20 concurrent chunk calls)
- For multi-package: `--parallel 2 --concurrency 10` (stay under system limit)

### Speedup Calculation

| Scenario | Sequential | Concurrency 10 | Concurrency 20 | Concurrency 40 |
|----------|-----------|----------------|----------------|----------------|
| 5-chunk test | ~3.0h | ~18 min | ~9 min | ~5 min |
| 50-chunk package | ~30h | ~3h | ~1.5h | ~45 min |
| 37K chunks (full library) | ~856 days | ~86 days | ~43 days | ~21 days |

**To hit 21-day target: concurrency 40.** But CLI backend rate limits are unknown (F10). Pre-production ramp test required to find actual ceiling.

**Config:**
- `engines/excerpting/contracts.py` — Add `CONCURRENCY: int = 1` to ExcerptingConfig
- `scripts/run_integration_test.py` — Add `--concurrency` flag
- `scripts/run_full_integration.py` — Forward `--concurrency` to subprocess

**Codex-independent:** PARTIALLY. Module is self-contained, but thread safety (F2, F8) and circuit breaker (F5) need architect review before merge.

---

## Layer 5: Circuit Breaker (NEW — F5 fix)

**Problem:** Without a circuit breaker, 40 threads retrying against a down backend create a retry storm — wasting time and potentially getting IP-blocked.

**Solution:** Shared circuit breaker that pauses all threads when backend failure rate spikes.

**State machine:**
```
CLOSED (normal) ──[5 consecutive failures]──> OPEN (blocking)
OPEN ──[wait 60s]──> HALF_OPEN (probe)
HALF_OPEN ──[1 success]──> CLOSED
HALF_OPEN ──[1 failure]──> OPEN (double wait: 120s, 240s, max 1800s)
```

**Implementation:**
```python
class CircuitBreaker:
    """Prevents retry storms when CLI backends are down."""

    def __init__(self, failure_threshold: int = 5, base_cooldown: float = 60.0, max_cooldown: float = 1800.0):
        self._lock = threading.Lock()
        self._consecutive_failures = 0
        self._state = "CLOSED"
        self._cooldown = base_cooldown
        self._open_since: float = 0.0

    def record_success(self):
        with self._lock:
            self._consecutive_failures = 0
            self._state = "CLOSED"
            self._cooldown = self._base_cooldown

    def record_failure(self):
        with self._lock:
            self._consecutive_failures += 1
            if self._consecutive_failures >= self._failure_threshold:
                self._state = "OPEN"
                self._open_since = time.monotonic()
                logger.warning("Circuit OPEN — %d consecutive failures, cooling down %.0fs",
                               self._consecutive_failures, self._cooldown)

    def check(self):
        """Called before each LLM call. Blocks if circuit open, probes if half-open."""
        with self._lock:
            if self._state == "CLOSED":
                return
            elapsed = time.monotonic() - self._open_since
            if elapsed < self._cooldown:
                # Still cooling down — block the thread
                wait_remaining = self._cooldown - elapsed
        # Wait outside lock
        logger.info("Circuit open, waiting %.0fs before probe...", wait_remaining)
        time.sleep(wait_remaining)
        # After wait, set HALF_OPEN (one thread probes)
```

**Per-backend breakers:** One CircuitBreaker per backend (claude, codex, gemini), not global. A Claude outage shouldn't block Codex verification calls.

**Location:** Inside `engines/excerpting/src/parallel_orchestrator.py` (same module as ConcurrencyController).

**Codex-independent:** YES. Self-contained class with clear contract.

---

## Layer 6: Batch Escalation

**Problem:** Each author attribution disagreement = 1 escalation call (~100s). 4 disagreements = 4 calls = 400s.

**Solution:** Collect all disagreements per chunk, send 1 batched call.

**New response model:**
```python
class BatchEscalationResult(BaseModel):
    items: list[BatchEscalationItem]  # Each has item_index, author_id, reasoning
```

**Prompt structure:** All disagreements in one prompt with item indices. Max batch size 20 (fits in Mistral's 128K context at ~600 tokens/item).

**Refactored flow in `_run_consensus_for_chunk()`:**
1. Collect: Run verification, identify all disagreements
2. Batch: One escalation call for all author disagreements
3. Resolve: Apply batch results to individual excerpts

**Savings:** 4 calls × 100s = 400s → 1 call × 150s = 150s. **250s saved per package with disagreements.**

**File:** `engines/excerpting/src/phase3_consensus.py` — Add `_call_batch_escalation()`, integrate into `_run_consensus_for_chunk()`.

**Codex-independent:** YES. Self-contained refactor with clear before/after behavior.

---

## Layer 7: Progress Visibility

**Problem:** Multi-hour (or multi-day) runs with no visibility into what's happening.

**Solution:** Real-time status file updated by the parallel orchestrator.

**Status file:** `{output_dir}/status.json` updated every 30s:
```json
{
  "updated": "2026-03-31T14:30:00Z",
  "total_chunks": 50,
  "completed": 23,
  "in_progress": {"classify": 3, "group": 2, "enrich": 4, "verify": 1},
  "failed": 2,
  "pending": 15,
  "elapsed_seconds": 3600,
  "avg_seconds_per_chunk": 156,
  "estimated_remaining_seconds": 2340,
  "active_cli_calls": 10,
  "concurrency_limit": 20,
  "circuit_breakers": {"claude": "CLOSED", "codex": "CLOSED", "gemini": "CLOSED"},
  "cache_hits": 12,
  "cache_misses": 11
}
```

**Companion script:** `scripts/kr_pipeline_monitor.py` — reads status.json, prints formatted dashboard. Run in separate terminal.

**Codex-independent:** YES. Simple file-write pattern.

---

## Implementation Order

| # | Layer | Effort | Speedup | Dependencies | Codex? |
|---|-------|--------|---------|--------------|--------|
| 1 | Per-phase timeouts | 1-2h | ~60 min/run waste eliminated | None | YES |
| 2 | Chunk-level resume (WAL) | 4-6h | ~4h/crash recovered | None | YES |
| 3 | Input-based caching + validation gate | 4-5h | Full re-run cost on restart | Layer 2 (compose naturally) | YES |
| 4 | Chunk parallelism + per-thread adapters | 8-10h | **4-20x throughput** | Layers 2+3 | REVIEW |
| 5 | Circuit breaker | 2-3h | Survive backend outages | Layer 4 (integrated) | YES |
| 6 | Batch escalation | 2-3h | ~4 min/package | None | YES |
| 7 | Progress visibility | 2-3h | Operational clarity | Layer 4 (status from orchestrator) | YES |

**Total effort:** ~23-32 hours. Layers 1-3 are safe, incremental wins. Layer 4+5 are the transformative changes.

**Recommended approach:** Implement Layers 1-3 first (safe, testable, each provides standalone value), then Layers 4+5 together (the multiplier + its safety net), then 6-7 (polish).

---

## Verification Plan

### Per-Layer Testing

| Layer | Test Strategy |
|-------|--------------|
| 1 (Timeouts) | Update 5-10 existing tests that mock config timeout values. Verify per-phase timeout used. |
| 2 (Resume) | 8-10 new tests: JSONL append/replay, corrupt line handling, artifact integrity, skip-on-done, concurrent appends. |
| 3 (Caching) | 12-15 new tests: full-prompt hash, hit/miss, auto-invalidation on prompt change, cache poisoning rejection (refusal, empty segments), corrupt cache file. |
| 4 (Parallelism) | 15-20 new tests: concurrent mock clients, semaphore limiting, per-chunk state machine, per-thread adapter isolation, error in one chunk doesn't affect others, KeyboardInterrupt cleanup. |
| 5 (Circuit breaker) | 8-10 new tests: CLOSED→OPEN transition, OPEN→HALF_OPEN timing, HALF_OPEN→CLOSED on success, HALF_OPEN→OPEN on failure, cooldown doubling, per-backend isolation. |
| 6 (Batch escalation) | 5-8 new tests: empty batch, single item, multiple items, partial failure fallback. |
| 7 (Visibility) | 3-5 new tests: status.json schema, update frequency. |

### End-to-End Validation

1. **Correctness:** Run `--max-chunks 3 --concurrency 1` (sequential baseline) and `--max-chunks 3 --concurrency 3` (parallel). Diff `excerpts.jsonl` — **must be byte-identical**.
2. **Resume:** Run 3-chunk package, kill at chunk 2. Restart. Verify chunk 1 skipped (JSONL shows "done"), chunk 2 retried, chunk 3 processed.
3. **Cache:** Run same package twice. Second run should complete in <10s (all cache hits). Third run with modified prompt constant should re-process all (cache miss due to different system_message hash).
4. **Cache poisoning:** Inject a cached file with empty segments list. Verify it's rejected on load and the chunk is re-processed.
5. **Circuit breaker:** Mock 5 consecutive failures. Verify all threads pause for cooldown period. Verify one thread probes on HALF_OPEN.
6. **Existing tests:** All 808 excerpting + 49 CLI adapter + 4 runner tests must pass unchanged.

### Pre-Production Concurrency Ramp Test (F10 mitigation)

Before launching the 37K-chunk production run:
1. `--max-chunks 5 --concurrency 5` on all 5 test packages → verify identical output to sequential baseline
2. Ramp test on a single large package: concurrency 5, 10, 20, 40
3. At each level: measure throughput, error rate, retry rate
4. Find the **saturation point** where throughput plateaus or error rate spikes
5. Set production `--concurrency` to 80% of saturation point (leave headroom)
6. If saturation < 20: adjust 21-day target or accept longer timeline

---

## Risk Matrix (Updated with Multi-Model Findings)

| Risk | Probability | Impact | Mitigation | Status |
|------|------------|--------|------------|--------|
| **F5: Retry storm on backend outage** | HIGH | CRITICAL | Circuit breaker (Layer 5) | DESIGNED |
| **F2: Hook logger thread races** | CERTAIN | HIGH | Per-thread adapter instances | DESIGNED |
| **F6: Silent cache poisoning** | MEDIUM | CRITICAL | Cache validation gate | DESIGNED |
| **F10: Concurrency ceiling unknown** | HIGH | HIGH | Pre-production ramp test | DESIGNED |
| **F3: Incomplete cache key** | N/A | N/A | Full-prompt hashing eliminates this class of bug | RESOLVED |
| **F7: Windows os.replace() under readers** | N/A | N/A | WAL-based JSONL replaces JSON | RESOLVED |
| CLI backend rate limits | HIGH | MEDIUM | Configurable concurrency + circuit breaker | DESIGNED |
| Cache key collision (16 hex) | NEGLIGIBLE | LOW | 64-bit space vs 37K corpus | ACCEPTED |
| Windows subprocess handle exhaustion | LOW | LOW | Concurrency cap well within 16384 limit | ACCEPTED |
| Memory pressure | LOW | LOW | ~10KB per chunk × 1000 = 10MB | ACCEPTED |
| **F9: OneDrive sync overhead** | LOW | MEDIUM | Document: use non-synced output directory | DOCUMENTED |

---

## Key Architectural Decisions

1. **ThreadPoolExecutor over asyncio** — CLI adapter uses blocking subprocess.run(). Rewriting to async would invalidate 49 tests for no real benefit (threads are I/O-bound).

2. **Global semaphore over per-phase pools** — One semaphore controls all CLI calls regardless of phase. Simpler, prevents oversubscription, naturally allows pipeline overlap.

3. **Per-chunk full-chain workers over phase-at-a-time batching** — Each thread runs classify→group→enrich→verify for its chunk. Achieves pipeline overlap without complex inter-phase coordination.

4. **Cache raw LLM output, not post-processed** — If normalization/repair logic changes, cached results still go through updated post-processing. Safer for knowledge integrity.

5. **Hash full prompts, not constants (F3)** — Eliminates the entire class of "missed cache input" bugs. The cache key captures exactly what the LLM sees.

6. **WAL over JSON (F7)** — JSONL append is crash-safe and reader-safe on Windows NTFS. No PermissionError from concurrent readers.

7. **Per-backend circuit breakers (F5)** — A Claude outage doesn't block Codex calls. Each backend has independent failure tracking and cooldown.

8. **Per-thread adapter instances (F2)** — Eliminates all hook logger races, `_tool_checked` TOCTOU, and trace context confusion. Clean ownership model.

9. **Existing phase functions unchanged** — `classify_chunk()`, `group_chunk()`, `enrich_chunk()`, `verify_chunk()` are called directly by the parallel orchestrator. `run_phase2a()` etc. sequential wrappers remain for tests and `--concurrency 1` path.

---

## Critical Files

**New files (4):**
- `engines/excerpting/src/parallel_orchestrator.py` — ~450 lines (ConcurrencyController, CircuitBreaker, ChunkPipelineContext, run_parallel_pipeline, _run_consensus_for_chunk)
- `engines/excerpting/src/progress.py` — ~120 lines (ProgressTracker with WAL)
- `engines/excerpting/src/cache.py` — ~200 lines (CacheManager with validation gate)
- `scripts/kr_pipeline_monitor.py` — ~80 lines (status dashboard)

**Modified files (7):**
- `engines/excerpting/contracts.py` — Add per-phase timeouts + CONCURRENCY to ExcerptingConfig
- `engines/excerpting/src/phase2_classify.py` — Use CLASSIFY_TIMEOUT, accept ProgressTracker, extract message construction for cache integration
- `engines/excerpting/src/phase2_group.py` — Use GROUP_TIMEOUT, accept ProgressTracker, extract message construction
- `engines/excerpting/src/phase3_enrichment.py` — Use ENRICH_TIMEOUT, accept ProgressTracker, extract message construction
- `engines/excerpting/src/phase3_consensus.py` — Use VERIFY/ESCALATION_TIMEOUT, batch escalation, accept ProgressTracker
- `scripts/run_integration_test.py` — Add --concurrency flag, create ProgressTracker+CacheManager, route to parallel_orchestrator when concurrency>1, create per-thread adapters with per-thread hook loggers
- `scripts/run_full_integration.py` — Forward --concurrency to subprocess args

**Unchanged (confirmed by multi-model review):**
- `shared/llm/cli_adapter.py` — Thread-safe when used as per-thread instances (subprocess.run is reentrant, no shared mutable state across instances)
- `engines/excerpting/src/phase3_orchestrator.py` — Sequential wrapper for --concurrency 1 path
- All test files — 808 tests must pass without modification
