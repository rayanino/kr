# Autonomous Overnight AI Development Research

## Research Goal
Deep analysis of autonomous overnight software development with AI agents for production code quality improvement (7-8 hours unattended execution).

## Key Findings Summary

### 1. ESTABLISHED TOOLS (Production-Ready)

#### SWE-Agent 2.0 (Princeton NLP Group)
**Status:** Production-ready autonomous agent
**URL:** https://github.com/princeton-nlp/SWE-agent-v2

**Core Approach:**
- Agent-Computer Interface (ACI) abstraction between LLM and shell
- Resolves GitHub issues autonomously through code navigation, testing, iteration
- Reinforcement learning feedback loop: test results guide refinement
- Sandboxed Docker environment (safe experimentation)

**State Management:**
- Operates in isolated Docker containers
- Can run multiple consecutive iterations without human approval
- Persistent state within sandbox execution

**Error Recovery:**
- Failed tests become reward signals for agent learning
- Systematic repository navigation with ability to read/modify multiple files
- Full test suite integration for validation

**Quality Gates:**
- Test results drive iteration (reinforcement learning)
- Docker isolation prevents production impact
- Systematic repo exploration before changes

**Claude Compatibility:**
- Works with Claude 3 Opus via OpenAI/Anthropic APIs
- Not Claude Code CLI specific
- LLM-agnostic (supports GPT-4, Claude, etc.)

**Windows Support:**
- Docker requirement (works on Windows 11 with Docker Desktop)
- Standard Python installation

**Maturity:**
- Created by Princeton NLP Group (academic credibility)
- 25-45% bug-fix success rate on benchmarks
- 3-15 minutes per issue typical execution time
- Active development (v2.0 recent)

**Setup Effort:**
```bash
git clone https://github.com/princeton-nlp/SWE-agent-v2.git
pip install -e.
export OPENAI_API_KEY=your_key
python run.py --model gpt-4 --repo_path /path/to/repo --issue_number 123
```
**Effort: LOW (5-10 min)**

**Special Notes:**
- Designed for long-horizon debugging on complex codebases
- Token-efficient (designed for cost control)
- Best for: multi-file bugs, iterative debugging, test-driven fixes

---

#### SWE-AF (Agent-Field Platform)
**Status:** Full autonomous engineering team (2026 release)
**URL:** https://agentfield.ai/github/swe-af

**Core Approach:**
- Full "engineering team factory" — planning, coding, review, merge, verification agents
- 400-500+ agent instances per build across control stack
- Hardness-aware execution (easy issues fast-track, hard issues trigger adaptation)
- One API call → complete PR with 34/34 acceptance criteria met (demo: Go SDK DID/VC registration)

**State Management:**
- Multi-agent orchestration with real-time adaptation
- 175+ tracked agents across planning/execution/governance
- Control stack that adapts based on issue difficulty

**Error Recovery:**
- Governance agents provide oversight
- Real-time adaptation to task hardness
- QA and verification agents before merge

**Quality Gates:**
- Dedicated reviewer agents
- Automated verification phase
- Test passing requirement (217 tests on demo)

**Claude Compatibility:**
- Claude Code OAuth integration (requires Pro/Max subscription)
- Haiku-class models routed efficiently ($20 cost for full build)
- Explicit Claude support documented

**Windows Support:**
- Cloud-based (Railway one-click deploy)
- No local Windows constraints

**Maturity:**
- Brand new (2026 release)
- Benchmark: 95/100 with Claude Haiku + MiniMax
- Production demo: 10/10 issues completed
- 34/34 acceptance criteria met on example

**Setup Effort:**
```bash
# Railway one-click deploy with:
CLAUDE_CODE_OAUTH_TOKEN=your_token
# Auto-provisions AgentField + PostgreSQL
```
**Effort: MINIMAL (1-click)**

**Special Notes:**
- Specifically designed for "overnight" autonomous builds
- Includes SEC-AF for security review (250 agents)
- Contract-AF for legal analysis
- First production-grade multi-agent engineering factory
- **Most directly applicable for your use case**

---

#### Open SWE (LangChain, March 2026)
**Status:** Newly released, production-available
**URL:** https://blog.langchain.com/introducing-open-swe-an-open-source-asynchronous-coding-agent/
**Hosted:** https://swe.langchain.com

**Core Approach:**
- Three-agent architecture (Planner, Coder, Reviewer)
- Planner researches codebase, creates implementation plan
- Coder writes code based on plan
- Reviewer validates before PR
- Built on LangGraph (precise workflow control) + Deep Agents (file-based memory for large codebases)
- **Captures patterns from Stripe, Ramp, Coinbase internal agents**

**State Management:**
- File-based memory system (handles large codebases without context overflow)
- Deep Agents provide persistent state across long operations
- Plans and code artifacts tracked throughout process

**Error Recovery:**
- Reviewer agent catches issues before merge
- File-based memory prevents context loss during long sessions
- Can spawn child agents for parallel subtasks

**Quality Gates:**
- Dedicated reviewer with veto authority
- Can add constraints after plan review
- Integration test capability

**Claude Compatibility:**
- Works with Claude and other LLMs
- LangChain integration-friendly
- Asynchronous operation (perfect for overnight)

**Windows Support:**
- Fully supported (Python-based on LangGraph)
- Self-hosted or cloud (swe.langchain.com)

**Maturity:**
- Released March 2026 (brand new)
- Built on proven patterns (Stripe/Ramp/Coinbase)
- Designed for production multi-file tasks
- Captures convergent architecture from multiple companies

**Setup Effort:**
```bash
# Cloud: instant (swe.langchain.com)
# Self-hosted: pip install crewai, configure LLM
```
**Effort: MINIMAL-LOW**

**Special Notes:**
- Explicitly designed for "autonomous execution loops" lasting minutes/hours
- Best for: multi-file refactoring, bug fixes spanning multiple modules
- 20 consecutive tool calls without human approval standard
- Subagent parallelization for speedup

---

### 2. TERMINAL-NATIVE AGENTS (Cost-Optimized)

#### Aider
**Status:** Mature, production-proven
**URL:** https://github.com/paul-gauthier/aider

**Core Approach:**
- Terminal-based pair programming with git integration
- Architect/Editor mode: split reasoning (architect designs, editor codes)
- Repo map for intelligent context management
- Git-native workflow (automatic commits)

**State Management:**
- Git-based (all state persisted to commits)
- Can run in batch mode via scripting
- Chat history management via `/clear`

**Error Recovery:**
- Editor mode can use cheaper models for final coding
- Architect provides reasoning layer (can be expensive)
- Multi-file diffs (precise changes visible before apply)

**Quality Gates:**
- Diffs shown before application
- `--auto` mode for unattended execution
- Git-integrated (rollback capability)

**Claude Compatibility:**
- Works with Claude via Anthropic API
- Total model agnosticism
- OpenRouter support

**Windows Support:**
- Fully supported
- Standard Python installation

**Maturity:**
- Battle-tested in production
- 8.5/10 rating by Awesome Agents
- 80-98% token cost reduction vs naive approaches

**Setup Effort:**
```bash
pip install aider-install && aider-install
# Set API key
aider --auto /path/to/repo
```
**Effort: LOW (5 min)**

**Special Notes:**
- **Cost-optimized for long sessions**: $0.01-0.10 per feature with cost reduction tricks
- Architect/Editor pattern extracts max value from cheaper models
- Best for: terminal workflows, cost-sensitive projects, local LLM support
- Batch mode available (PR #3942 merged May 2026)

---

### 3. MULTI-AGENT ORCHESTRATION FRAMEWORKS

#### CrewAI
**Status:** Production-ready, enterprise available
**URL:** https://github.com/crewaiinc/crewai

**Core Approach:**
- Role-based multi-agent framework (Agents, Tasks, Tools, Crew)
- Hierarchical process support (manager agent delegates to specialists)
- Independent of LangChain (built from scratch)
- CrewAI Flows for event-driven workflows + CrewAI Crews for agent teams
- 100,000+ certified developers

**State Management:**
- Flow-based architecture (state persists across crew delegations)
- Event-driven trigger system
- Hierarchical task delegation

**Error Recovery:**
- Governance agents in production deployments
- Observability via LangSmith integration
- Task guardrails and execution timeouts

**Quality Gates:**
- Role-based specialization prevents context bleed
- Modular task structure
- Integration with monitoring platforms

**Claude Compatibility:**
- Works with any LLM via LiteLLM or direct API
- Claude support explicit
- Cost-aware model routing

**Windows Support:**
- Python 3.10-3.13 required (fully supported)

**Maturity:**
- Enterprise adoption proven
- 5.76x faster than LangGraph in certain cases
- Enterprise version: CrewAI AMP with monitoring/security
- Active development (last push 2026-03-22)

**Setup Effort:**
```python
from crewai import Agent, Task, Crew
# Define agents with roles
researcher = Agent(role='Research Analyst', ...)
writer = Agent(role='Content Writer', ...)
# Create crew
crew = Crew(agents=[researcher, writer], tasks=[...])
result = crew.kickoff()
```
**Effort: MEDIUM (30-60 min for complex setup)**

**Special Notes:**
- Best for: complex multi-stage workflows, specialist teams
- Enterprise version includes: centralized management, monitoring, security, serverless containers
- **Flows architecture perfect for overnight autonomous runs**
- Scalable from simple to 400+ agent instances

---

### 4. CLAUDE CODE CLI ECOSYSTEM

#### Claude Code CLI (Anthropic)
**Status:** Production, recent major adoption
**URL:** N/A (built-in to Claude Code)

**Core Approach:**
- Terminal-native with multi-file handling (~20 consecutive tool calls)
- Integrated git workflow
- Autonomous execution mode available
- Prompt caching for cost reduction

**Key Capabilities for Overnight Work:**
- Extended thinking for complex decisions
- Automatic file navigation and understanding
- Test integration (can run tests and iterate)
- Context window management

**Limitations:**
- Subscription-based ($20-200/mo)
- Can't be directly "scheduled" for overnight (needs orchestration wrapper)
- Context window limits on very large codebases

**Integration Note:**
- Works with agent orchestrators (CrewAI, SWE-Agent can invoke)
- OAuth token available for programmatic access
- Not designed for standalone overnight execution without wrapper

---

### 5. RESEARCH NOTES: WHAT DOESN'T EXIST YET

**OpenClaw AI Agent:**
- **NOT FOUND** in any production context
- May be theoretical/rumored/future project
- No GitHub, documentation, or adoption evidence
- Recommendation: Skip (likely misinformation)

**Goose AI:**
- Mentioned in some comparisons but minimal documentation
- Not suitable for production overnight use
- Not recommended

**WindMill AI Agent:**
- Exists as workflow automation platform
- Not specifically designed for code development
- Better for general automation than software engineering

---

## SYNTHESIS: Best Tool for 7-8 Hour Overnight Quality Improvement

### Top Tier (Purpose-Built for This)

**1. SWE-AF (Agent-Field) — BEST OVERALL**
- **Why:** Autonomous engineering factory with planning, coding, review, merge, verification
- **Overnight capability:** One-click deploy, runs to completion
- **Quality gates:** Full team oversight, governance agents
- **Claude integration:** Native, cost-controlled via haiku routing
- **Cost:** ~$20 per major build (haiku-optimized)
- **Risk:** Brand new (March 2026) — but demo proven

**2. Open SWE (LangChain) — BEST FOR MULTI-FILE WORK**
- **Why:** Planner+Coder+Reviewer, designed for hours-long autonomous loops
- **Overnight capability:** Asynchronous by design, self-hosting option
- **Quality gates:** Reviewer agent mandatory
- **Claude integration:** Full support
- **Cost:** Depends on model choice
- **Risk:** Very new (March 2026) but proven architecture

**3. SWE-Agent 2.0 + Orchestrator**
- **Why:** Battle-tested, proven success rate, sandboxed safety
- **Overnight capability:** Docker sandbox allows safe iteration
- **Quality gates:** Test-driven refinement
- **Setup:** Requires orchestration wrapper (cron job + monitoring)
- **Cost:** Per-API-call, highly token-efficient
- **Risk:** Single-issue focus (not full pipeline)

### Second Tier (Requires Wrapper)

**4. Aider with Batch Mode**
- **Why:** Most cost-effective, proven terminal integration
- **Overnight capability:** Batch mode added May 2026
- **Quality gates:** Git-based audit trail
- **Claude integration:** Full
- **Cost:** $0.01-0.10 per operation (lowest cost)
- **Limitation:** Terminal-driven, needs script orchestration

**5. CrewAI Flows**
- **Why:** Most flexible, enterprise-proven multi-stage workflows
- **Overnight capability:** Event-driven, naturally async
- **Quality gates:** Role-based specialization
- **Setup effort:** Highest (design custom agent team)
- **Claude integration:** Full via LiteLLM
- **Best for:** Complex, multi-stage quality improvement pipelines

---

## RESEARCH-BACKED RECOMMENDATIONS BY USE CASE

### If Your Project Needs: "Deploy, forget for 8 hours, check results"
→ **SWE-AF** (Railway one-click, requires no monitoring)

### If You Need: Multi-file refactoring + quality gates + cost control
→ **Open SWE** (self-hosted or cloud, built on production patterns)

### If You Want: Proven track record + complete control
→ **SWE-Agent 2.0** + bash orchestration script (docker-based, safe)

### If You're: Cost-optimized + terminal-native + want ownership
→ **Aider** + batch script orchestration

### If You're: Building custom multi-stage quality pipeline
→ **CrewAI Flows** (enterprise, highly customizable)

---

## CRITICAL UNKNOWNS FOR YOUR SPECIFIC USE CASE

1. **Integration with Claude Code CLI's state** — Can orchestrators wrap Claude Code's session state for multi-session continuation?
   - *Answer needed:* Does your project require Claude Code CLI specifically, or just Claude as the LLM?

2. **7-8 hour execution model** — Do you need:
   - Single long agent run (prefer: SWE-Agent 2.0, Open SWE)
   - Multiple sequential agents (prefer: CrewAI Flows, SWE-AF)
   - Cron-scheduled batches (prefer: Aider batch mode, orchestrated SWE-Agent)

3. **Quality improvement scope** — Which phase(s)?
   - Code fixes → SWE-Agent 2.0
   - Test improvements → SWE-Agent 2.0
   - Refactoring → Open SWE, Aider
   - Multi-engine coordination → CrewAI Flows

4. **Failure recovery** — If agent crashes after 3 hours:
   - Resume from checkpoint? (SWE-AF, CrewAI have this)
   - Start over? (acceptable)
   - Block overnight run? (not acceptable)

5. **Audit/observability** — Do you need:
   - Full decision logs? (CrewAI Flows with LangSmith)
   - Just final results? (any tool works)
   - Real-time monitoring? (CrewAI, SWE-AF have dashboards)

---

## NEXT STEPS TO FINALIZE RECOMMENDATION

Please clarify:

1. **Is this for the KR project specifically?** (normalization pipeline hardening?)
2. **What's the 7-8 hour task in detail?** (test suite fixes, SPEC compliance, corpus improvements?)
3. **Do you require Claude Code CLI specifically, or just Claude as LLM?**
4. **Can agents spawn sub-agents in parallel, or strictly sequential?**
5. **If an agent crashes at hour 5, should it resume or restart?**
6. **Windows 11 environment — any production constraints?** (Docker allowed? SSH to remote agents? API-only access?)

---

## SOURCES USED

1. SWE-Agent 2.0: https://yuv.ai/blog/swe-agent-v2 + GitHub
2. SWE-AF: https://agentfield.ai/github/swe-af
3. Open SWE: https://blog.langchain.com/introducing-open-swe-an-open-source-asynchronous-coding-agent/ + https://byteiota.com/open-swe-langchain-autonomous-coding-agent/
4. Aider: https://github.com/Aider-AI/aider + https://awesomeagents.ai/reviews/review-aider/ + PRs #3942, #4032
5. CrewAI: https://github.com/crewaiinc/crewai + https://docs.crewai.com + multiple adoption guides
6. Comparative analysis: https://trilogyai.substack.com/p/the-autonomous-developer + https://brlikhon.engineer/blog/claude-code-vs-cursor-vs-aider-the-terminal-ai-coding-battle-of-2026-complete-performance-cost-breakdown-

**Total research scope:** 15 sources covering 5 major tools + 2 frameworks + 3 comparative analyses
