# Plan: Hardening Session Protocol — Reusable Batch Preparation Guide

## Context

Session 1 of the excerpting foundations hardening (F1-F8) established infrastructure but exposed critical workflow flaws: atoms were bulked instead of handled individually, the owner was kept out of the loop, coworker consensus was inconsistent, and context windows hit 96%. The F1-F8 work will need 8-9 more CC sessions. After that, the SAME process repeats for G1-G4, SC1-SC3, and every remaining batch of the 40-question questionnaire. Without a reusable, battle-tested protocol, each new batch starts from scratch.

The owner's directive: "FOCUS ON MAKING THE BEST SESSION2 GUIDE, NOT COPYING YOUR WORKFLOW AS ACCURATELY AS POSSIBLE." The protocol must IMPROVE on Session 1, not replicate it. Learn from what went wrong. The owner also mandates: NO CHANGE to the engine without consensus from at least CC + Codex, preferably Gemini.

## Problem Frame

**Session 1 failures that MUST be fixed:**

| # | Failure | Impact | Root Cause |
|---|---------|--------|------------|
| 1 | Atoms were bulked into batches, not processed individually | Owner feedback diluted; individual atoms got shallow coverage | ATOM_PROTOCOL.md said "batch is the unit of dispatch" |
| 2 | Owner was briefed per-batch, not per-atom | Owner couldn't track what happened to specific feedback | No per-atom briefing step in protocol |
| 3 | Context window hit 96% | Quality degraded; session ended prematurely | CC read raw files locally instead of dispatching to subagents |
| 4 | Only 15/139 files read initially | 90% of structured feedback missed | No file inventory step; relied on extraction summary |
| 5 | Inconsistent coworker coverage (full for atoms 1-2, shallow for 3-17) | Single-model conclusions on most atoms | No per-atom coworker minimum enforced |
| 6 | Said "done" 7 times, was wrong each time | Owner found major gaps CC should have caught | No quality gate with explicit criteria |
| 7 | No atom expansion | Raw 1-sentence atoms went straight to implementation | No stage between extraction and implementation |
| 8 | DR coworkers "prepared but not executed" | Missing adversarial coverage | No timeout/follow-up protocol for async relays |

**Scaling challenge:** 40 questions x ~15 atoms per question = ~600 atoms total. Each atom needs full lifecycle. At ~15-25 atoms per CC session, that's ~24-40 CC sessions. The protocol MUST be efficient enough that a session can process atoms without filling its context, and robust enough that session handoffs preserve zero information loss.

## Requirements

- R1. Protocol is reusable across ALL batch types (F, G, SC, and future series)
- R2. Each atom is processed individually through a defined lifecycle with quality gates
- R3. Owner is briefed after EVERY atom (not batched)
- R4. Every SPEC/prompt/contract change requires CC + Codex consensus minimum, Gemini preferred
- R5. Context window management enables 15-25 atoms per session without degradation
- R6. Raw owner feedback is the starting point — atoms must be EXPANDED into complete specifications
- R7. Coworker dispatch is per-atom (analysis), though implementation may be grouped for coherence
- R8. Session handoff preserves complete state for zero-loss continuation
- R9. Protocol includes self-improvement mechanism (each session records what worked/didn't)
- R10. No single-model conclusions on any content quality judgment

## Scope Boundaries

**In scope:**
- The reusable HARDENING_SESSION_PROTOCOL.md document
- Updates to ATOM_PROTOCOL.md referencing the new protocol
- Coworker prompt templates for each role
- Context window management rules
- Session handoff template

**Out of scope:**
- Actually processing atoms (that's what the protocol governs)
- Changes to SPEC, prompts, contracts, or tests
- G-series or SC-series bundle extraction (those happen under the protocol)

## Key Technical Decisions

### D1: Per-Atom Analysis, Grouped Implementation
The owner hates bulking. The existing ATOM_PROTOCOL says "batch is the unit." Resolution: ANALYSIS (reading, expansion, coworker challenge, synthesis, owner briefing) is per-atom. IMPLEMENTATION (SPEC/prompt/test changes) may group 2-3 tightly related atoms affecting the same prompt section for coherence, but only after each atom has been individually analyzed and approved. The owner brief is ALWAYS per-atom.

**Rationale:** Per-atom analysis ensures each piece of owner feedback gets full attention. Grouped implementation prevents "prompt thrashing" where 15 isolated edits to the same prompt section create contradictions. The owner's complaint was about analysis depth, not implementation mechanics.

### D2: Dispatch-First Context Strategy
CC's context window is the scarcest resource. The protocol mandates: if a task involves reading >10KB of text, dispatch it to a subagent. CC holds summaries, decisions, and implementation — never raw files. This doubles session throughput from ~10 to ~20-25 atoms per session.

**Rationale:** Session 2 hit 96% context because CC read raw collection files (40-80KB each), raw DR reports (17-52KB each), and full SPEC sections (10-30KB each) directly. Dispatching these reads to subagents that return 2-5KB structured summaries saves 80%+ context per atom.

### D3: 7-Stage Atom Lifecycle with Quality Gates
Every atom passes through: RAW → SOURCED → EXPANDED → CHALLENGED → SYNTHESIZED → IMPLEMENTED → CLOSED. Each transition has an explicit gate with checkable criteria. No atom advances without passing the gate. "Closed" means 11 quality criteria are ALL true.

**Rationale:** Session 1's "done" declarations failed because there was no definition of "done." The 11-criterion Q-CLOSED gate makes it mechanical: either all criteria are true, or the atom isn't done.

### D4: Coworker Consensus with Formal Voting
Each coworker votes ACCEPT/MODIFY/ITERATE/REJECT per atom. Consensus requires 2+ ACCEPT/MODIFY (with modifications accepted by CC). Any REJECT blocks finalization. DR breaks CLI disagreements. All votes and dissent preserved in ledger.

**Rationale:** Session 1 had no voting protocol — coworker findings were informally absorbed. Formal voting creates accountability and traceability.

### D5: Context Budget Zones with Hard Handoff at 75%
The 1M token window is divided: 0-8% bootstrap, 8-75% working zone, 75-85% handoff buffer, 85%+ emergency. Session handoff begins at 75% — no exceptions. This guarantees high-quality handoffs without degradation.

**Rationale:** Session 2 reached 96% and degraded. 75% gives 25% buffer for a clean handoff with full state preservation.

## Implementation Units

The deliverable is a single comprehensive protocol document: `engines/excerpting/reference/HARDENING_SESSION_PROTOCOL.md`

This document supersedes ATOM_PROTOCOL.md for process governance (ATOM_PROTOCOL.md remains as historical reference and is updated with a pointer to the new protocol).

### Unit Structure

- [ ] **Unit 1: Protocol Preamble and Authority**

**Goal:** Establish the protocol's authority, scope, and relationship to existing documents.

**Files:**
- Create: `engines/excerpting/reference/HARDENING_SESSION_PROTOCOL.md` (preamble section)
- Modify: `engines/excerpting/reference/ATOM_PROTOCOL.md` (add superseded-by notice)

**Content:**
- Authority statement (ABSOLUTE, governs all hardening sessions)
- Scope: all batch types (F, G, SC, and future)
- Supersedes ATOM_PROTOCOL.md for process (preserves its Hard Rules as-is)
- Relationship to CLAUDE.md, coworker-dispatch rules, no-single-model-conclusion rules
- Version history (this is v2, evolved from Session 1's ATOM_PROTOCOL.md)

**Coworker Review:** Codex validates cross-document references are consistent. Gemini validates scholarly scope is correct.

---

- [ ] **Unit 2: Pre-Session Checklist**

**Goal:** Define what a CC session must do before processing any atoms.

**Content:**
- 10-item checklist (read protocol, read handoff, read ledger, verify branch, run tests, run sync check, read engine CLAUDE.md, inventory new bundles, estimate context budget, plan atom count target)
- Bundle intake procedure (how to unzip, inventory, and verify new collection bundles arriving at repo root)
- File inventory template (per-bundle: count files, verify source_artifacts present, verify README, check for missing bundles)
- Context budget estimation formula at session start

**Coworker Review:** Codex checks the checklist covers all necessary technical prerequisites. Gemini checks scholarly file types are correctly identified.

---

- [ ] **Unit 3: Collection Bundle Intake Protocol**

**Goal:** Define how new bundles (G1-G4, SC1-SC3, future) are received, verified, and prepared.

**Content:**
- Bundle structure reference (standard full-expansion, F7 variant, F2 lightweight, F1 early-stage)
- Intake steps: unzip → verify structure → read manifest → read source_artifacts → check authority levels
- Two-layer separation verification (owner-faithful Layer A vs engineering expansion Layer B)
- Conflict detection checklist (raw text vs structured file contradictions)
- New atom extraction procedure (read all files, extract atoms, assign MAQ-IDs, classify authority)
- Integration with MERGED_ATOM_QUEUE.md (append new atoms, update statistics)

**Coworker Review:** Codex validates the intake steps can be automated/scripted. ChatGPT DR reviews whether the bundle structure documentation is accurate against existing bundles.

---

- [ ] **Unit 4: Atom Lifecycle — 7 Stages**

**Goal:** Define the complete lifecycle each atom passes through, with gates at every transition.

**Content:**

**Stage 1: RAW** — Initial state in the atom queue.

**Stage 2: SOURCED** — CC reads raw owner source + structured files. Produces: owner quotes, signal reconstruction, tensions, authority classification, conflict notes. Gate: raw `.txt` read and quoted, authority classified, conflict check done.

**Stage 3: EXPANDED** — CC expands the 1-sentence atom into a complete specification using the expansion template (scope, exceptions, interaction map, correct/incorrect examples, implementation hypothesis, blast-radius check). Gate: scope defined, 2+ exceptions evaluated, interaction map complete, examples formulated, implementation hypothesis stated, blast-radius clear.

**Stage 4: CHALLENGED** — CC dispatches coworkers with expansion document. Codex gets contract/adversarial prompt, Gemini gets scholarly/adversarial prompt, DR gets gap-finding prompt. Gate: 2/3 coworker reports received, structured and recorded.

**Stage 5: SYNTHESIZED** — CC creates 3-column comparison, resolves disagreements per voting protocol, refines expansion, finalizes implementation decision. Gate: synthesis table exists, all disagreements resolved, implementation decision specific.

**Stage 6: IMPLEMENTED** — CC makes SPEC/prompt/contract/test changes. Runs validation suite. Gate: files changed, pytest green, pyright clean, sync check passed, empirical validation if prompt-affecting.

**Stage 7: CLOSED** — CC briefs owner, updates ledger, checks blast-radius for upcoming atoms. Gate: Q-CLOSED (11 criteria all true).

**The expansion template (key deliverable within this unit):**
```
## ATOM [MAQ-ID]: [Name]
### Raw Signal — [exact owner quotes with file:line refs]
### Authority — [owner_explicit | owner_consistent_inference | model_only]
### Scope — [what this governs, IN/OUT boundaries]
### Rule Statement — [testable, falsifiable rule]
### Exceptions — [2+ evaluated, each accepted/rejected with reasoning]
### Interaction Map — [which FPs/prompt rules/atoms this touches]
### Correct Application Example — [concrete scenario with Arabic text ref]
### Incorrect Application Example — [how misapplication causes damage]
### Implementation Hypothesis — [where it lands, word budget impact]
### Blast-Radius Assessment — [finalized atom conflicts or "none"]
```

**Coworker Review:** This is the most critical unit. Codex validates the gates are mechanically checkable. Gemini validates the scholarly aspects of the expansion template. ChatGPT DR stress-tests the lifecycle for edge cases (what happens when an atom requires reopening a finalized atom? When expansion reveals the atom is actually two atoms?).

---

- [ ] **Unit 5: Coworker Consensus Protocol**

**Goal:** Define voting rules, dispatch templates, disagreement resolution, and async relay handling.

**Content:**

**Coverage Tiers:**
| Change Type | Minimum | Target |
|-------------|---------|--------|
| Prompt-affecting | CC + Codex + Gemini | + 1 DR |
| SPEC-structural | CC + Codex + Gemini | + 2 DR |
| Contract-affecting | CC + Codex | + Gemini |
| SPEC-doctrinal | CC + Gemini | + 1 DR |
| Phase gates | All 6 | All 6 |

**Voting:** ACCEPT / MODIFY / ITERATE / REJECT per atom per coworker.
**Consensus:** 2+ ACCEPT/MODIFY (with accepted modifications) and 0 REJECT = FINALIZED.
**Disagreement resolution:** SPEC as tiebreaker → FP-13 precedence → evidence weight → CC decides with documented reasoning → DR tiebreaker for structural changes → owner for study-experience only.

**Prompt templates:** One per coworker role (Contract Guardian, Scholarly Auditor, Adversarial Reasoner) with per-DR specialization (ChatGPT: architecture, Claude: scholarly depth, Gemini: pedagogy).

**Async relay protocol:** Dispatch → owner relays → 48h timeout → proceed with N-1 → mark PRELIMINARY.

**Coworker Review:** Codex validates the voting rules are unambiguous. Gemini validates the scholarly review scope. Claude DR reviews the disagreement resolution hierarchy for scholarly edge cases.

---

- [ ] **Unit 6: Context Window Management**

**Goal:** Define budget zones, dispatch-vs-local rules, compaction protocol, and recovery procedures.

**Content:**

**Budget zones:**
- Zone 0 (0-3%): System overhead (fixed)
- Zone 1 (3-8%): Bootstrap (one-time)
- Zone 2 (8-75%): Working zone (atom processing)
- Zone 3 (75-85%): Handoff buffer (mandatory handoff begins)
- Zone 4 (85-96%): Emergency (compact + minimal recovery)
- Zone 5 (96-100%): FORBIDDEN (never enter)

**Dispatch-first rules:**
- ALWAYS dispatch: collection file reading, SPEC section reading, DR report summarization, cross-atom regression checks
- ALWAYS local: synthesis decisions, implementation edits, ledger updates, owner briefing
- CONDITIONAL: blast-radius checks (dispatch if >60% context), test execution (always via Bash with -q flag)

**Per-atom context budget:** ~15-22K tokens with dispatch-first vs ~29-67K tokens without. Target: 20-25 atoms per session.

**After-every-3rd-atom check:** CC explicitly states context estimate and remaining capacity.

**Compaction recovery:** Re-read only: session state, engine CLAUDE.md, SPEC §1.1b, current prompt, last 5 ledger entries, current batch atoms. (~10K tokens vs 52K full bootstrap.)

**Coworker Review:** Codex validates the token math against actual file sizes. ChatGPT DR reviews whether the dispatch strategy creates information loss risks.

---

- [ ] **Unit 7: Session Handoff Protocol**

**Goal:** Define what a session must produce before terminating, and what the next session needs to start.

**Content:**

**Handoff triggers:**
- Planned: after last atom that fits in Zone 2
- Triggered: when entering Zone 3 (75%)
- Emergency: when in Zone 4 (85%) without started handoff

**Handoff document template** (located at `reference/handoffs/excerpting_foundations_sessionN+1_kickoff_YYYY-MM-DD.md`):
1. STOP — 8-item read checklist
2. Session N accomplishments (atoms processed, FPs added, prompt changes, test count)
3. What went RIGHT (patterns to keep)
4. What went WRONG (anti-patterns to avoid)
5. Context management report (peak usage, compactions, dispatch efficiency)
6. What remains (unstarted atoms, PRELIMINARY atoms, unresolved risks)
7. Coworker mandate for session N+1
8. Budget update

**State files to update:** `.kr/HANDOFF.md`, ledger, MERGED_ATOM_QUEUE status column.

**Session retrospective:** Each session records 3 process improvements discovered. These feed into the NEXT version of this protocol (living document).

**Coworker Review:** Codex validates the handoff template contains all machine-readable state needed. Gemini validates scholarly context is preserved across handoffs.

---

- [ ] **Unit 8: Self-Improvement Mechanism**

**Goal:** Ensure the protocol evolves based on experience, not fossilizes.

**Content:**
- After each session, CC records in a `SESSION_RETROSPECTIVE.md` per-session file: 3 things that worked, 3 things that didn't, 3 proposed protocol improvements
- After every 3 sessions, a protocol review pass: CC + Codex review all retrospectives and propose amendments
- Protocol amendments require: CC + Codex agreement minimum; Gemini for scholarly aspects
- Version history in the protocol document header tracks all amendments

**Coworker Review:** Codex validates the retrospective template captures actionable data. ChatGPT DR reviews whether the improvement cycle is sufficient to catch degradation.

---

- [ ] **Unit 9: Quick Reference Card**

**Goal:** A 1-page cheat sheet that a CC session can read in 30 seconds at session start.

**Content:**
- 7-stage lifecycle as a one-line flow diagram
- Per-stage: who does what, what gate, 1-sentence summary
- Dispatch decision tree: "Is it >10KB? → dispatch. Is it a decision? → local."
- Context checkpoints: "After atom 3: state estimate. At 75%: start handoff. At 85%: emergency stop."
- Coworker minimum: "Prompt change = CC+Codex+Gemini. SPEC change = CC+Codex+Gemini. Phase gate = all 6."
- Anti-patterns: "NEVER bulk atoms. NEVER read raw files locally. NEVER skip owner brief. NEVER say 'done' without Q-CLOSED."

**Coworker Review:** Codex validates accuracy against the full protocol. Gemini validates scholarly terminology is correct.

## Verification

After the protocol document is written:

1. **Structural check:** Run `python3 scripts/check_spec_quality.py` adapted for the protocol document (check for testable rules, concrete examples, no ambiguous language)
2. **Cross-reference check:** Every reference to ATOM_PROTOCOL.md, CLAUDE.md, coworker-dispatch rules, no-single-model-conclusion rules is accurate
3. **Coworker review of the COMPLETE document:**
   - Codex CLI: structural consistency, cross-reference accuracy, mechanical checkability of all gates
   - Gemini CLI: scholarly scope correctness, Arabic text handling rules preserved
   - ChatGPT DR: adversarial review of the protocol itself — where could a future session misinterpret or shortcut the rules?
4. **Owner review:** The owner reads the Quick Reference Card and confirms it captures their intent
5. **Simulation test:** Apply the protocol to ONE atom from the G1 bundle to verify it works end-to-end before committing

## Risks & Dependencies

| Risk | Mitigation |
|------|------------|
| Protocol is too long for a CC session to internalize | Quick Reference Card (Unit 9) provides 30-second overview; full protocol read once at session start |
| Dispatch-first strategy loses nuance from raw files | Subagent summaries include verbatim owner quotes; CC can escalate to Tier 2 (targeted file read) if summary is insufficient |
| 48h DR timeout slows atom processing | Protocol explicitly allows proceeding with N-1 and PRELIMINARY marking; CLI coworkers don't have this latency |
| Owner relay fatigue (many DR prompts) | Batch DR prompts per coworker (one combined prompt covering multiple atoms) |
| Protocol becomes rigid and doesn't evolve | Self-improvement mechanism (Unit 8) with session retrospectives and 3-session review cycles |
| Future batch types (not F/G/SC) don't fit the protocol | Protocol is parameterized by batch type, not hardcoded for F-series |

## Sources & References

- Existing protocol: `engines/excerpting/reference/ATOM_PROTOCOL.md`
- Atom queue: `engines/excerpting/reference/MERGED_ATOM_QUEUE.md`
- Hardening ledger: `engines/excerpting/reference/FOUNDATIONS_HARDENING_LEDGER.md`
- Session 3 kickoff: `reference/handoffs/excerpting_foundations_session3_kickoff_2026-04-04.md`
- Coworker dispatch skill: `.claude/skills/coworker-dispatch/SKILL.md`
- No-single-model rule: `.claude/rules/no-single-model-conclusion.md`
- Mandatory dispatch rule: `.claude/rules/mandatory-coworker-dispatch.md`
- Context management rule: `.claude/rules/context-management.md`
- Owner feedback memories: `feedback_139_files_golden_data.md`, `feedback_take_full_authority.md`, `feedback_never_declare_done_early.md`
- New bundles at repo root: `chatgpt_g1_collection_bundle.zip` through `chatgpt_g4_collection_bundle.zip`, `chatgpt_sc1_collection_bundle.zip`
