# Plan: Implement DR-1 + DR-3 + Supporting Changes (Items 1-8)

## Context

6-reviewer evaluation of the excerpting engine's first 133-excerpt output produced 3 domain rules. DR-1 (definition pair splitting) and DR-3 (khilaf preservation) were adopted; DR-2 (evidence splitting) was deferred. This plan implements the adopted rules, extends the CrossReference schema, adds companion detection, improves evidence_refs quality, and amends the SPEC.

## Execution Order (6 milestones, 3 test gates)

```
M1: Item 1 (DR doc) + Item 4 (CrossReference schema)  ← parallel, independent
    TEST GATE: 907 tests pass + pyright clean
M2: Items 2+3 (DR-1/DR-3 in GROUP_SYSTEM_PROMPT)      ← same file
    TEST GATE: 907 tests pass + prompt format test
M3: Item 5 (companion detection) + Item 6 (evidence quality)  ← parallel
    TEST GATE: 907 + new tests pass
M4: Item 7 (SPEC amendments)                           ← reflects all code changes
M5: Item 8 (rewrite NEXT.md)
```

## Milestone 1: Item 1 + Item 4

### Item 1: Update `engines/excerpting/domain_rules/DR_DOMAIN_RULES.md`

| Change | Location | Action |
|--------|----------|--------|
| Status line | Line 4 | `ADOPTED (4-1 DR-1, 5-0 DR-3) — DR-2 DEFERRED` |
| DR-1 self-containment | Line 24 | Append: "UNLESS splitting breaks self-containment" |
| DR-2 deferral | Section header (line 83) | Insert DEFERRED status block with rationale |
| DR-3 threshold | Lines 178-180 | Replace ~800-word with structural criteria |
| Modified rule note | Lines 206-224 | Note DP-4 stays original (DR-2 deferred) |
| Bottom status | Lines 296-305 | Replace "Pending" with "ADOPTED" summary |

### Item 4: Extend `engines/excerpting/contracts.py` CrossReference (line 168-181)

Add after `target_div_id`, before `resolved`:
```python
target_excerpt_id: Optional[str] = Field(
    None, description="Links to companion excerpt from same source passage"
)
relationship_type: Optional[str] = Field(
    None,
    description="Semantic relationship: companion_definition, evidence_for, "
    "ruling_proven_by, refutation_of, continuation",
)
```

**Backward-compatible:** Both Optional with None defaults. All existing constructors and fixtures unchanged.

---

## Milestone 2: Items 2+3

### File: `engines/excerpting/src/phase2_group.py` — GROUP_SYSTEM_PROMPT

**Insert point:** After line 98 (end of DECONTEXTUALIZATION PREVENTION Q&A rule), before SELF-CONTAINMENT EVALUATION (line 100).

**Insert DR-1 block** (exact text from NEXT.md) then **DR-3 block** immediately after.

**Safe:** No `{curly_braces}` in new text → `test_has_single_format_variable` passes.

**Add 2 tests** in `test_phase2_group.py::TestGroupSystemPrompt`:
- `test_dr1_definition_pair_splitting` — asserts DR-1 keywords present
- `test_dr3_khilaf_preservation` — asserts DR-3 keywords and OVERRIDES clause

---

## Milestone 3: Item 5 + Item 6

### Item 5: Companion detection — new function in `phase3_enrichment.py`

```python
def detect_dr1_companions(excerpts: list[ExcerptRecord]) -> list[ExcerptRecord]:
```

**Logic:** Group by (source_id, div_id, chunk_index). For consecutive units where both have `primary_function == DEFINITION`, add bidirectional `CrossReference(relationship_type="companion_definition", target_excerpt_id=...)`.

**Integration:** `phase3_orchestrator.py` line 146, between Stage 2 (enrichment) and Stage 3 (consensus):
```python
# ── Stage 2.5: DR-1 companion detection (deterministic) ────
from engines.excerpting.src.phase3_enrichment import detect_dr1_companions
all_excerpts = detect_dr1_companions(all_excerpts)
```

**Tests (4 new):**
1. Adjacent definition pair → companion cross-refs added
2. Adjacent non-definitions → no change
3. Non-adjacent definitions → no change
4. Pre-existing cross-references preserved

### Item 6: Evidence quality — extend ENRICH_SYSTEM_PROMPT

Add `EVIDENCE RESOLUTION HINTS` subsection within field 6 (CROSS-REFERENCES) of the enrichment prompt. Instructs LLM to add canonical surah/ayah identification and hadith collection+number as cross_references entries.

**Does NOT modify `evidence_refs`** (stays F-DET-5 deterministic per SPEC line 464). Routes through `cross_references` instead.

**1 new test:** `test_prompt_contains_evidence_resolution_hints`

---

## Milestone 4: Item 7 — SPEC amendments

### `engines/excerpting/SPEC.md` — 3 locations

| Section | Line area | Change |
|---------|-----------|--------|
| §5.3.2 | ~955 | Insert DR-1 + DR-3 in prompt code block + divergence note |
| §6.1 | ~1268 | Add "Relationship to Domain Rules" (DR-1/DR-2/DR-3) after DP-6 |
| §2.2.2 | ~473 | Update CrossReference structure definition with 2 new fields |

---

## Milestone 5: Item 8 — Rewrite NEXT.md

Replace current content with re-run instructions (Step 9: `python scripts/run_full_integration.py --backend api --output-dir integration_tests/smoke_api_v2/`)

---

## Key Risk: SPEC/Code Prompt Divergence

The SPEC §5.3.2 prompt and `phase2_group.py` GROUP_SYSTEM_PROMPT already diverge (code has DERIVED BENEFITS, NUMBERED ITEM BOUNDARIES, extended DP rules, COPY FIDELITY that SPEC lacks). Plan adds DR-1/DR-3 to both but does NOT sync pre-existing differences. A note in §5.3.2 declares `phase2_group.py` as authoritative, with full sync as follow-up.

## Verification: Multi-Model Validation at Every Milestone

Every milestone uses the full 3-tool gate: pytest, pyright, AND Codex/Gemini.

### M1 Gate (after Item 1 + Item 4)
1. `python -m pytest engines/excerpting/tests/ -x -q` — 907 tests pass
2. `python -m pyright engines/excerpting/contracts.py` — 0 errors
3. **Codex:** Validate CrossReference schema backward-compatibility — confirm all existing constructors still work, check serialization roundtrip
4. **Gemini:** Review DR_DOMAIN_RULES.md amendments for Arabic scholarly accuracy — verify the structural criteria replacing the 800-word threshold in DR-3 are sound

### M2 Gate (after Items 2+3)
1. `python -m pytest engines/excerpting/tests/ -x -q` — 907 tests pass
2. `python -m pyright engines/excerpting/src/phase2_group.py` — 0 errors
3. **Codex:** Cross-prompt consistency check — verify DR-1/DR-3 text is identical between `phase2_group.py` and `DR_DOMAIN_RULES.md`, check no `{curly_braces}` leaked
4. **Gemini:** Arabic scholarly review of DR-1/DR-3 prompt text — verify detection markers are correct Arabic patterns, check لغة/شرعا and khilaf terminology is convention-compliant

### M3 Gate (after Items 5+6)
1. `python -m pytest engines/excerpting/tests/ -x -q` — 907 + new tests pass
2. `python -m pyright engines/excerpting/src/phase3_enrichment.py engines/excerpting/src/phase3_orchestrator.py` — 0 errors
3. **Codex:** Review `detect_dr1_companions` logic — verify the adjacency detection is correct, check no mutation of originals, validate bidirectional cross-ref symmetry
4. **Gemini:** Review evidence resolution hints prompt additions — verify Quranic/hadith canonical resolution instructions use correct Arabic scholarly terminology

### M4 Gate (after Item 7)
1. **Codex:** Full SPEC consistency audit — verify §5.3.2 DR-1/DR-3 text matches code, §2.2.2 CrossReference matches contracts.py, §6.1 domain rules are internally consistent
2. **Gemini:** Arabic scholarly accuracy of SPEC §6.1 domain rule descriptions

### M5 Gate (after Item 8)
1. **Codex:** Verify NEXT.md points to correct re-run command and references the right output directory
