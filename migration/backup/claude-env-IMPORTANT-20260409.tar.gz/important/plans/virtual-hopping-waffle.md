# Plan: Add `--max-chunks` to `run_integration_test.py`

## Context

The excerpting engine integration test processes ALL assembled chunks through the full pipeline (Phase 1 → 2a → 2b → 3). For the Ibn Aqil package, that's ~14 chunks — each requiring multiple LLM calls in Phase 2a (classification) and 2b (grouping). For a smoke test that just needs to verify the LLM integration works end-to-end with ONE real call, processing all 14 chunks is unnecessary cost and latency.

Adding `--max-chunks N` lets us truncate after Phase 1 (which is free/deterministic) and only send N chunks through the LLM phases. This is the minimal change to enable a focused smoke test.

## Implementation

**Single file:** `scripts/run_integration_test.py`

### Step 1: Add CLI argument (after line 872, before `args = parser.parse_args`)

```python
parser.add_argument(
    "--max-chunks",
    type=int,
    default=None,
    help="Limit Phase 2/3 processing to the first N chunks from Phase 1. "
    "Default: None (process all). Useful for smoke-testing LLM calls.",
)
```

### Step 2: Add parameter to `run_pipeline()` signature (line 424-428)

```python
def run_pipeline(
    package_path: Path,
    output_dir: Path,
    source_metadata: Optional[dict[str, str]],
    mock: bool,
    max_chunks: Optional[int] = None,  # <-- ADD
) -> int:
```

### Step 3: Truncate chunks after Phase 1 serialization (after line 560, before line 562)

Insert between `_serialize_chunks(chunks, output_dir)` and `if not chunks:`:

```python
# Truncate chunk list for LLM phases if --max-chunks is set.
# Phase 1 artifacts (phase1_chunks.json) already serialized above with ALL chunks.
if max_chunks is not None:
    original_count = len(chunks)
    chunks = chunks[:max_chunks]
    logger.info(
        "--max-chunks=%d: processing %d of %d chunks in Phases 2-3",
        max_chunks, len(chunks), original_count,
    )
```

### Step 4: Pass through from `main()` (line 917-922)

```python
return run_pipeline(
    package_path=args.package_path,
    output_dir=args.output_dir,
    source_metadata=args.source_metadata,
    mock=args.mock,
    max_chunks=args.max_chunks,  # <-- ADD
)
```

### Step 5: Print in CLI header (after line 904)

```python
print(f"Max chunks:      {args.max_chunks or 'all'}")
```

## Verification

1. **Type check:** `python -m pyright scripts/run_integration_test.py`
2. **Mock smoke test** (no API cost):
   ```bash
   PYTHONPATH=. python scripts/run_integration_test.py \
     --package-path experiments/format_diversity_test/packages/ibn_aqil_v1 \
     --output-dir /tmp/smoke_mock --mock --max-chunks 1
   ```
   Expect: only 1 chunk processed in Phase 2a/2b/3 output dirs.

3. **Real LLM smoke test:**
   ```bash
   OPENROUTER_API_KEY=<key> PYTHONPATH=. python scripts/run_integration_test.py \
     --package-path experiments/format_diversity_test/packages/ibn_aqil_v1 \
     --output-dir /tmp/smoke_test_real --max-chunks 1
   ```
   Expect: 1 chunk classified, grouped, and enriched. LLM logs in output dir.

4. **Edge case:** `--max-chunks 0` should produce 0 chunks and exit cleanly via the existing empty-check at line 562.

## Post-execution

- If LLM call succeeds: commit the `--max-chunks` change + push. Output saved in `/tmp/smoke_test_real/`.
- If LLM call fails: capture error to `integration_tests/smoke_test_failure.log`, still commit the `--max-chunks` feature, push both.
