# Fix Remaining Integration Test Failures

## Context

Codex v2 comparison test finished. 3/5 packages succeeded (39 excerpts), 1 crashed mid-phase3 (ext_39_masala), 1 never ran (ext_46_qa). Claude v2 comparison test was completely invalid — ALL 5 packages failed because Claude CLI is not authenticated.

## Root Causes Found

| Issue | Root Cause | Evidence |
|-------|-----------|----------|
| Claude v2: 0/5, all exit code 1 | **Claude CLI not logged in** | `echo "Hi" \| claude -p - --bare` → "Not logged in · Please run /login" |
| Codex ext_39_masala crash | Phase3 LLM call (enrich_0004) sent but no response received. No run_metadata.json → process killed or unhandled crash | 4 raw_llm_requests, only 3 raw_llm_responses |
| No SUMMARY.json for Codex batch | Batch runner crashed or was killed before writing summary | Missing SUMMARY.json, ext_46_qa dir never created |

## Fixes Required

### FIX 1: Claude CLI Authentication (USER ACTION)

The user must run ONE of:
```bash
claude login          # Interactive browser login (short-lived OAuth token)
# OR
claude setup-token    # Long-lived API key (better for overnight runs)
```

No code change needed. This is an environment issue.

### FIX 2: Crash-Safe Batch Runner

**Problem:** `run_full_integration.py` writes SUMMARY.json only at the very end. If any package crashes the batch runner (or user kills it), ALL results are lost — no summary, no record of which packages completed.

**File:** `scripts/run_full_integration.py`

**Fix:** Write incremental summary after EACH package completes:
```python
# After line 247: results[name] = pkg_result
# Add:
_write_incremental_summary(output_dir, results, batch_start)
```

Add helper:
```python
def _write_incremental_summary(output_dir, results, batch_start):
    """Write partial SUMMARY.json after each package — crash-safe progress."""
    total_time = time.monotonic() - batch_start
    succeeded = sum(1 for r in results.values() if r.get("status") == "success")
    failed = sum(1 for r in results.values() if r.get("status") == "error")
    summary = {
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "output_dir": str(output_dir),
        "packages": results,
        "totals": {
            "packages_run": len(results),
            "packages_succeeded": succeeded,
            "packages_failed": failed,
            "total_excerpts": sum(r.get("excerpt_count", 0) for r in results.values()),
            "total_errors": sum(r.get("error_count", 0) for r in results.values()),
            "total_time_seconds": round(total_time, 2),
            "total_cost_estimate": round(sum(r.get("cost_estimate", 0.0) for r in results.values()), 6),
        },
        "complete": False,
    }
    (output_dir / "SUMMARY.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
```

At final write, set `"complete": True`.

### FIX 3: Phase3 crash doesn't lose Phase2 work

**Problem:** If phase3 crashes fatally (line 818-824 in run_integration_test.py), it calls `_save_timing_and_metadata` but does NOT write `processing_log.jsonl`. Without a processing_log, the resume logic can't detect this package was partially processed.

**File:** `scripts/run_integration_test.py`, phase3 crash handler (line 818-824)

**Fix:** Write a partial processing_log even on phase3 crash:
```python
except Exception as exc:
    logger.error("Phase 3 failed: %s", exc)
    all_errors.append(f"phase3_fatal: {exc}")
    # Write partial processing log so resume knows phase2 completed
    write_processing_log(
        source_id=package.manifest.source_id,
        errors=all_errors,
        timings=timings,
        excerpt_count=0,
        gate_count=0,
        output_dir=output_dir,
    )
    _save_timing_and_metadata(
        output_dir, timings, all_errors, config, source_metadata
    )
    return 1
```

BUT: this means resume will SKIP this package (processing_log exists). So also update the resume logic to distinguish "completed successfully" from "crashed". Check for `phase3_fatal` in the log errors:

```python
# In run_full_integration.py, update resume check:
done_marker = pkg_output / "processing_log.jsonl"
if done_marker.exists():
    prev = read_package_results(pkg_output)
    # Check if it was a clean completion or a crash
    if any("phase3_fatal" in e for e in prev.get("errors", [])):
        print(f"  RE-RUNNING — previous run crashed in phase3")
        # Delete partial output to allow clean re-run
        import shutil
        shutil.rmtree(pkg_output)
        pkg_output.mkdir(parents=True, exist_ok=True)
    else:
        print(f"  SKIPPING — already completed ...")
        results[name] = prev
        continue
```

### FIX 4: Verify model diversity in Codex comparison

**Problem:** When `KR_PRIMARY_MODEL=openai/gpt-5.4`, the VERIFY_MODEL is also `openai/gpt-5.4` (default). This means enrichment and verification use the SAME model — no cross-model consensus. Defeats the purpose of D-041.

**File:** `scripts/run_integration_test.py`, KR_PRIMARY_MODEL override section

**Fix:** When primary model is overridden, also set verify to a DIFFERENT model:
```python
model_override = os.environ.get("KR_PRIMARY_MODEL")
if model_override:
    # Primary model does classify + group + enrich
    updates = {"CLASSIFY_MODEL": model_override, "GROUP_MODEL": model_override, "ENRICH_MODEL": model_override}
    # Ensure verify model is DIFFERENT from primary for real consensus
    if model_override == config.VERIFY_MODEL:
        updates["VERIFY_MODEL"] = "anthropic/claude-opus-4-6"
    config = config.model_copy(update=updates)
```

## Implementation Order

1. Fix 2 (crash-safe summary) — 5 min
2. Fix 3 (phase3 crash recovery) — 10 min
3. Fix 4 (verify model diversity) — 2 min
4. Fix 1 (user runs `claude login`) — user action

## Verification

1. `python -m pytest engines/excerpting/tests/ -x -q` — all pass
2. Run preflight: `python scripts/preflight_cli_test.py --backend codex`
3. Re-run ext_39_masala only: `python scripts/run_integration_test.py --package-path experiments/format_diversity_test/packages/ext_39_masala --output-dir integration_tests/compare_codex_v2/ext_39_masala --backend cli --source-metadata '{"author_name": null}'`
4. After `claude login`: `python scripts/preflight_cli_test.py --backend claude`
