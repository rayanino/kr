# Plan: Deep Environment Hardening for Maximum Quality

## Context

Round 1 fixed crashes and structural issues. This round addresses the **substantive quality gaps** found by parallel audits of the hook chain, agent system, and Arabic text safety mechanisms. The focus: ensure no environmental limitation can allow incorrect data to enter the user's Islamic scholarly library.

Three independent audits identified 10 high-impact improvements. This plan implements the top 7 that directly affect output quality.

---

## Step 1 — Harden arabic-safety-check.sh with 4 critical missing patterns

**File:** `kr/.claude/hooks/arabic-safety-check.sh`

The current hook checks 8 patterns but misses 4 **critical silent corruption vectors** that would silently destroy Arabic text with no warning:

| Pattern | Why Deadly | Where to Add |
|---------|-----------|--------------|
| `.encode('ascii'` with `'ignore'`/`'replace'` | Silently drops ALL Arabic characters | New Check 9 |
| `.encode('latin-1')`/`encode('cp1252')` | Converts unmappable Arabic to `?` | New Check 9 (same check) |
| `.casefold()` | Python's aggressive case-folding, like .lower() but worse | Extend Check 1 |
| `unicodedata.normalize('NFKD')` | Decomposes Arabic diacritics into separate combining chars — violates D-004 | New Check 10 |

**Implementation:**

1. Extend the `.lower()/.upper()` check (existing Check 1) to also catch `.casefold()`:
   ```
   grep -nE '\.(lower|upper|casefold)\(\)' "$FILE"
   ```

2. Add Check 9 — dangerous encode patterns:
   ```bash
   # Check 9: encode() with lossy error handlers — silently destroys Arabic
   ENCODE_LOSSY=$(grep -nE "\.encode\(['\"]?(ascii|latin|cp1252|iso-8859)" "$FILE" 2>/dev/null | grep -v '# safe:')
   if [ -n "$ENCODE_LOSSY" ]; then
       echo "BLOCKED: Lossy .encode() found — will destroy Arabic text." >&2
       exit 1
   fi
   ```

3. Add Check 10 — NFKD normalization:
   ```bash
   # Check 10: unicodedata.normalize('NFKD') — decomposes Arabic diacritics
   NFKD=$(grep -nE "normalize\(['\"]NFD|normalize\(['\"]NFKD" "$FILE" 2>/dev/null | grep -v '# safe:')
   if [ -n "$NFKD" ]; then
       WARNINGS+="CRITICAL WARNING: unicodedata.normalize('NFKD'/'NFD') decomposes Arabic diacritics..."
   fi
   ```

Both Check 9 (encode) and the casefold extension should be **BLOCKING** (exit 1), same as the .lower()/.upper() check — these are equally destructive to Arabic text.

---

## Step 2 — Harden stop-quality-gate.sh with 3 missing checks

**File:** `kr/.claude/hooks/stop-quality-gate.sh`

Current gate only checks pyright + tests. Missing 3 critical validations:

### Check 3: Arabic safety re-scan (BLOCKING)
After the pyright/tests loop, add:
```bash
# Check 3: Arabic safety on ALL modified engine files
for f in $ENGINE_PY; do
    if [ -f "$f" ]; then
        ARABIC_OUT=$(CLAUDE_TOOL_FILE_PATH="$f" bash "$CLAUDE_PROJECT_DIR/.claude/hooks/arabic-safety-check.sh" 2>&1 || true)
        ARABIC_EXIT=$?
        if [ "$ARABIC_EXIT" -ne 0 ]; then
            ERRORS+="arabic-safety: BLOCKED in $f\n"
        fi
    fi
done
```

### Check 4: D-023 metadata flow (ADVISORY)
If any contracts.py was modified, run the metadata flow check:
```bash
CONTRACTS_HIT=$(echo "$ALL_PY" | grep 'contracts.py' || true)
if [ -n "$CONTRACTS_HIT" ]; then
    D023_OUT=$(python3 scripts/verify_metadata_flow.py 2>&1 || true)
    if echo "$D023_OUT" | grep -qiE '(FAIL|ERROR|missing)'; then
        ERRORS+="D-023: metadata flow violations detected\n"
    fi
fi
```

### Check 5: Frozen source integrity (BLOCKING)
```bash
FROZEN_CHANGES=$(git diff --name-only HEAD 2>/dev/null | grep 'library/sources/.*/frozen/' || true)
if [ -n "$FROZEN_CHANGES" ]; then
    ERRORS+="FROZEN SOURCE MODIFIED (Principle 18 violation): $FROZEN_CHANGES\n"
fi
```

---

## Step 3 — Fix Windows compatibility issues

### 3a. Fix circuit-breaker.sh /tmp path
**File:** `kr/.claude/hooks/circuit-breaker.sh`

Change:
```bash
FAILURE_DIR="/tmp/kr_circuit_breaker"
```
To:
```bash
FAILURE_DIR="${CLAUDE_PROJECT_DIR:-.}/.claude/.circuit_breaker_state"
```

This persists across sessions and doesn't depend on `/tmp` permissions.

### 3b. Increase Windows-critical timeouts
**File:** `kr/.claude/settings.json`

| Hook | Current | New | Reason |
|------|---------|-----|--------|
| pre-commit-check.sh | 30s | 60s | Runs 10+ checks including full pytest; Windows process overhead |
| pyright-check.sh | 30s | 45s | Windows Python startup + pyright scan overhead |
| auto-test.sh | 120s | 180s | Large test suites (808+ excerpting tests) on Windows |

---

## Step 4 — Add PreCompact hook for context checkpointing

**File:** `kr/.claude/hooks/pre-compact-checkpoint.sh` (NEW)
**Settings:** Add `PreCompact` event to `kr/.claude/settings.json`

Before compaction destroys context, save a checkpoint of the current working state:
```bash
#!/usr/bin/env bash
# PreCompact: save critical working state before context is compressed.
cd "$CLAUDE_PROJECT_DIR" 2>/dev/null || exit 0

CHECKPOINT_FILE=".claude/.pre_compact_checkpoint.json"

python3 -c "
import json, subprocess, os
state = {}
# Active task from NEXT.md
try:
    state['active_task'] = open('NEXT.md').readline().strip()
except: pass
# Active engine
try:
    diff = subprocess.check_output(['git','diff','--name-only','HEAD'], text=True)
    engines = set(l.split('/')[1] for l in diff.strip().split('\n') if l.startswith('engines/'))
    state['active_engines'] = list(engines)
except: pass
# Modified files
try:
    state['modified_files'] = subprocess.check_output(['git','diff','--name-only','HEAD'], text=True).strip().split('\n')
except: pass
# Budget
try:
    d = json.load(open('tests/results/source_engine/COST_LOG.json'))
    state['budget_eur'] = sum(v.get('cost_eur',0) for v in d.values() if isinstance(v,dict))
except: pass
json.dump(state, open('$CHECKPOINT_FILE','w'), indent=2)
print(f'Pre-compaction checkpoint saved: {len(state)} fields')
" 2>/dev/null || true

exit 0
```

The PostCompact hook (already created) will reference this checkpoint if it exists.

---

## Step 5 — Add FileChanged hook for config drift detection

**File:** `kr/.claude/settings.json` — add new hook event

Detect when `.claude/settings.json` or hook scripts are modified outside of Claude (e.g., manually or by another tool), which could disable safety guardrails:

```json
"FileChanged": [
    {
        "matcher": "settings.json",
        "hooks": [
            {
                "type": "command",
                "command": "echo 'WARNING: .claude/settings.json was modified externally. Safety hooks may have changed. Run /hooks to verify.'",
                "timeout": 5
            }
        ]
    }
]
```

---

## Step 6 — Fix agent issues (3 targeted fixes)

### 6a. spec-writer.md — add Write tool
**File:** `kr/.claude/agents/spec-writer.md`

Current tools: `Read, Grep, Glob, Bash, WebSearch`
Add: `Write`

An agent named "spec-writer" that can't write is confusing and limits its utility.

### 6b. test-engineer.md — add missing Arabic edge cases
**File:** `kr/.claude/agents/test-engineer.md`

Add to the mandatory edge cases section:
```
- **Invisible Unicode:** U+200B (zero-width space), U+FEFF (BOM), U+200E/F (bidi marks) at text boundaries
- **Presentation forms:** Arabic presentation form sequences (U+FB50-U+FEFF) requiring normalization
- **Diacritic stacks:** Single base character with 3+ combining marks (stress tests)
```

### 6c. arabic-safety-check.sh Check 1 — add .casefold()
Already covered in Step 1 above (extend the grep pattern).

---

## Step 7 — Post-implementation: Codex + Gemini independent audit

After all changes are made, run Codex and Gemini as independent auditors:

```bash
# Codex audit (fresh eyes on hooks)
codex exec "Read all files in .claude/hooks/. For each hook: (1) identify what Arabic corruption patterns it catches, (2) identify what it MISSES, (3) rate its Windows compatibility 1-5. Output a structured report." --approval-mode full-auto

# Gemini audit (fresh eyes on settings)
gemini -p "Read .claude/settings.json and all files in .claude/hooks/ and .claude/agents/. Audit this Claude Code configuration for: (1) any hook that could silently fail on Windows, (2) any agent with incorrect tool permissions, (3) any missing quality gate that could allow incorrect Arabic text into the system. Be thorough and adversarial."
```

This provides **triple-model verification** of the environment itself — the same principle the KR project uses for content decisions (D-041).

---

## Verification Plan

After all changes:

1. **Syntax check all hooks:**
   ```bash
   for f in .claude/hooks/*.sh; do bash -n "$f" && echo "PASS: $f"; done
   ```

2. **Settings validation:**
   ```bash
   node -e "JSON.parse(require('fs').readFileSync('.claude/settings.json','utf8')); console.log('PASS')"
   ```

3. **Functional test — arabic safety new patterns:**
   ```bash
   # Create temp file with dangerous pattern
   echo 'text.encode("ascii", errors="ignore")' > /tmp/test_arabic.py
   CLAUDE_TOOL_FILE_PATH=/tmp/test_arabic.py bash .claude/hooks/arabic-safety-check.sh
   # Should exit 1 (blocked)
   ```

4. **Functional test — stop gate with frozen source:**
   ```bash
   # Simulate frozen source modification
   echo '{"stop_hook_active":false}' | CLAUDE_PROJECT_DIR=. bash .claude/hooks/stop-quality-gate.sh
   ```

5. **Run Codex + Gemini audits (Step 7)**

---

## Files Modified

| File | Action |
|------|--------|
| `kr/.claude/hooks/arabic-safety-check.sh` | Add 4 missing patterns (.casefold, encode lossy, NFKD, re.ASCII) |
| `kr/.claude/hooks/stop-quality-gate.sh` | Add Arabic safety, D-023, frozen source checks |
| `kr/.claude/hooks/circuit-breaker.sh` | Fix /tmp → project-local path for Windows |
| `kr/.claude/hooks/pre-compact-checkpoint.sh` | NEW — saves working state before compaction |
| `kr/.claude/settings.json` | Add PreCompact + FileChanged hooks, increase 3 timeouts |
| `kr/.claude/agents/spec-writer.md` | Add Write tool |
| `kr/.claude/agents/test-engineer.md` | Add 3 Arabic edge cases |

## Impact Summary

| Improvement | Before | After |
|-------------|--------|-------|
| Arabic corruption patterns caught | 8 | 12 (+50%) |
| Stop gate checks | 2 (pyright + tests) | 5 (+Arabic, D-023, frozen sources) |
| Lifecycle hooks configured | 6 events | 8 events (+PreCompact, FileChanged) |
| Windows timeout adequacy | 3 inadequate | 0 inadequate |
| Agent tool accuracy | 1 misconfigured | 0 misconfigured |
