# Plan: Extend Excerpt Viewer UI for Owner's 3-Day Offline Window

## Context
The owner has 3+ days offline (Thu-Sun) to review excerpts and answer the questionnaire. Instead of markdown files, we extend the existing `tools/excerpt_viewer.html` + `tools/review.py` web UI to include questionnaire interactions, v2 review, and before/after comparisons — all with structured machine-readable feedback saved as JSONL.

## Existing UI (tools/excerpt_viewer.html + tools/review.py)
- Pure HTML/CSS/JS, zero dependencies, Arabic typography (Amiri font)
- 3-column layout: excerpt list | reading zone | review panel
- Verdict buttons (Accept/Needs Work/Reject) with keyboard shortcuts
- Issue tags (9 predefined categories)
- Free-form comments
- Saves to `owner_feedback.jsonl` per package (JSONL, atomic writes)
- Runs on localhost:8384

## What to Add

### 1. Questionnaire Mode
Add a new "Questionnaire" tab/mode to the viewer that:
- Shows each of the 40 questionnaire interactions in sequence
- Renders the Arabic excerpt inline (pulled from excerpt_selections.json)
- Shows the question text and multiple-choice options (A/B/C)
- Has a text area for detailed analysis (optional)
- Has confidence selector (High/Medium/Low)
- Saves responses to `integration_tests/questionnaire/owner_responses.jsonl`
- Shows progress (e.g., "12/40 interactions complete")
- Each response is a JSON object:
  ```json
  {
    "interaction_id": "F-3",
    "timestamp": "ISO8601",
    "multiple_choice": "B",
    "immediate_reaction": "text",
    "detailed_analysis": "text",
    "verdict": "accept|modify|reject",
    "confidence": "high|medium|low",
    "what_would_change_mind": "text (edge cases only)",
    "principles_revealed": "text (edge cases only)"
  }
  ```

### 2. V2 Review Mode
Point the existing reviewer at `integration_tests/smoke_api_v2/` — it already supports this. The owner just runs:
```bash
python tools/review.py integration_tests/smoke_api_v2/
```
No code changes needed for this.

### 3. Before/After Comparison Mode
Add a comparison view that shows campaign vs v2 excerpts side by side for the same division. Uses data from both `campaign_20260331/` and `smoke_api_v2/`.

### 4. START_HERE.md
A simple guide telling the owner:
1. Run `python tools/review.py integration_tests/smoke_api_v2/` for excerpt review
2. Open `http://localhost:8384` in browser
3. Use Questionnaire tab for the Q&A interactions
4. Use Review tab for v2 excerpt rating
5. All feedback auto-saves to JSONL files

## Files to modify
- `tools/excerpt_viewer.html` — add questionnaire mode + comparison mode
- `tools/review.py` — add questionnaire API endpoints + comparison data endpoint
- `integration_tests/questionnaire/excerpt_selections.json` — already exists, used as data source

## Files to create
- `integration_tests/questionnaire/START_HERE.md` — owner guide
- `integration_tests/questionnaire/owner_responses.jsonl` — questionnaire responses (created by UI)

## Verification
- Run `python tools/review.py integration_tests/smoke_api_v2/` and verify all modes work
- Submit a test questionnaire response and verify JSONL output
- All Arabic text renders correctly in both excerpt review and questionnaire modes
