# Diagnosis: EX-V-002 False Positive — All Excerpts Dropped

## Context

The first real LLM call succeeded — all 3 phases got valid responses from OpenRouter/Opus 4.6 with correct Instructor parsing. But ALL 7 excerpts from `div_src_test0001_2_000` were dropped by EX-V-002 (text integrity check) in `phase3_validation.py`. The error log shows `snippet` and `primary_first80` look **IDENTICAL** in every case.

## Root Cause: Asymmetric Length Comparison

**File:** `engines/excerpting/src/phase3_validation.py`, lines 83–85

```python
snippet_normalized = _normalize_whitespace(excerpt.text_snippet)       # FULL length from LLM
primary_first80 = _normalize_whitespace(excerpt.primary_text[:80])     # Exactly 80 chars
if snippet_normalized != primary_first80:
```

**The bug:** `text_snippet` is compared at its FULL length (whatever the LLM produced), while `primary_text` is truncated to exactly 80 characters. If the LLM copies N ≠ 80 characters, the strings have different lengths and `!=` is always True — even when the content is identical up to the shorter string.

**Why the log is misleading:** The diagnostic only shows `[:40]`:
```python
logger.error("snippet=%r vs primary_first80=%r",
    snippet_normalized[:40],    # ← truncated to 40
    primary_first80[:40],       # ← truncated to 40
)
```
Both prefixes look identical because the CONTENT matches — the difference is in the tail or total length.

## Evidence Chain

1. **LLMs cannot count characters precisely.** The Phase 2b prompt says "the FIRST 80 CHARACTERS...copied EXACTLY" but LLMs count grapheme clusters or tokens, not Unicode codepoints. Arabic diacritics (fatḥa, kasra, etc.) are separate codepoints but may not be counted as "characters" by the LLM.

2. **ALL 7 excerpts fail** — this is systematic, not random. A length-based mismatch (LLM consistently undercounting or overcounting Arabic codepoints) affects every excerpt identically.

3. **The validation code never truncates `text_snippet` to 80.** Confirmed by grep: no `text_snippet[:80]` anywhere in the validation path.

4. **The unit test doesn't cover this case.** The test uses `text_snippet=text[:80]` (a perfect Python substring), which always matches. Real LLM output doesn't have this precision:
   ```python
   # test_phase3_validation.py:92 — always passes because both sides are identical
   exc = _make_excerpt_record(primary_text=text, text_snippet=text[:80])
   ```

5. **`text_snippet` flows through untouched.** Phase 2b LLM → `TeachingUnit.text_snippet` → verify_units (no snippet repair) → Phase 3.1 passthrough (line 607) → validation.

## Data Flow Trace

```
Phase 2b (group_chunk):
  LLM sees assembled_text in <text> tags
  LLM produces TeachingUnit.text_snippet ≈ "first 80 chars" (actually N chars)

verify_units (V-P2-14):
  Auto-repairs start_word/end_word from constituent segments
  Does NOT touch text_snippet ← the LLM's imprecise copy persists

Phase 3.1 (build_excerpt_records):
  primary_text = assembled_text[char_start:char_end]  ← exact substring
  text_snippet = unit.text_snippet                    ← LLM's imprecise copy

Phase 3.4 (validate_excerpt):
  snippet_normalized = normalize(text_snippet)     ← length N (LLM)
  primary_first80 = normalize(primary_text[:80])   ← length 80 (exact)
  N ≠ 80 → FAIL → excerpt dropped
```

## Secondary Hypothesis: Invisible Unicode Characters

**Probability: MEDIUM** — worth checking but less likely than the length mismatch.

If `assembled_text` contains invisible Unicode characters (U+200B zero-width space, U+200E/F direction marks, U+061C Arabic letter mark) that:
- Survive `_normalize_whitespace()` (`\s` does NOT match zero-width chars)
- Exist in `primary_text` (extracted by offset, preserves everything)
- Are stripped by the LLM when "copying" to `text_snippet`

Then the byte content differs while the text LOOKS identical, even in `repr()` if the terminal renders them as empty.

**How to distinguish:** Check `len(snippet_normalized) == len(primary_first80)`. If lengths match but `!=` still fires, it's invisible characters. If lengths differ, it's the LLM counting issue.

## Recommended Fix (for implementation phase)

**Option A — Normalize both sides to same length (minimal change):**
```python
snippet_normalized = _normalize_whitespace(excerpt.text_snippet[:80])  # Truncate FIRST
primary_first80 = _normalize_whitespace(excerpt.primary_text[:80])
```

**Option B — Compare at snippet length (more tolerant):**
```python
snippet_normalized = _normalize_whitespace(excerpt.text_snippet)
primary_prefix = _normalize_whitespace(excerpt.primary_text[:len(excerpt.text_snippet)])
```

**Option C — Prefix match with minimum threshold:**
```python
snippet_norm = _normalize_whitespace(excerpt.text_snippet)
primary_norm = _normalize_whitespace(excerpt.primary_text[:80])
min_len = min(len(snippet_norm), len(primary_norm), 40)  # At least 40 chars must match
if snippet_norm[:min_len] != primary_norm[:min_len]:
    drop = True  # Only drop on genuine content mismatch
```

**Recommended: Option A.** It's the smallest change, maintains the SPEC intent (check that the text at the right position matches), and absorbs the LLM's imprecise character counting. The SPEC says "first 80 characters" — truncating text_snippet to 80 before comparing aligns with SPEC semantics.

**Also fix the diagnostic logging** to show lengths and more context:
```python
logger.error(
    "%s: Text integrity check failed for %s — DROPPED. "
    "snippet_len=%d primary80_len=%d snippet=%r primary=%r",
    ExcerptingErrorCodes.EX_V_002,
    excerpt.excerpt_id,
    len(snippet_normalized),
    len(primary_first80),
    snippet_normalized[:80],
    primary_first80[:80],
)
```

## Files to Modify

| File | Change |
|------|--------|
| `engines/excerpting/src/phase3_validation.py:83` | Truncate `text_snippet` to 80 before normalizing |
| `engines/excerpting/src/phase3_validation.py:88-95` | Improve diagnostic logging (show lengths + more chars) |
| `engines/excerpting/tests/test_phase3_validation.py` | Add test: LLM-length snippet (e.g., 65 chars) against 80-char primary |

## Verification

1. `python -m pyright engines/excerpting/src/phase3_validation.py`
2. `python -m pytest engines/excerpting/tests/test_phase3_validation.py -x -v`
3. Re-run the smoke test with the real LLM call and verify excerpts pass V-P3-2
