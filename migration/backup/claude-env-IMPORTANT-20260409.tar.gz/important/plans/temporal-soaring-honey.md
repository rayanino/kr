# Plan: Harden LLM Integration Infrastructure (NEXT.md @ a525358c)

## Context

The excerpting engine has 554 tests passing but ZERO real LLM calls have been tested. An architect + CC dual audit found 9 bugs in the LLM integration infrastructure that must be fixed before any real model calls. Additionally, 2 scripts and 2 test files need to be created for the integration test protocol. This work makes the ground solid before Round 1 testing.

**Source of truth:** `NEXT.md` — all fixes have exact code, all scripts have detailed specs.
**Baseline:** 554 tests passing (2 skipped), 0 failed.
**Constraint:** Do NOT make real LLM calls, modify prompts, or change Phase 1 code.

---

## Execution Order

**Critical:** FIX-9 before FIX-1 (FIX-9 removes `enrich_client` from `run_consensus` signature; FIX-1 wraps the call in try/except).

### Step 1: FIX-9 — Remove unused `enrich_client` parameter
- **File:** `engines/excerpting/src/phase3_consensus.py` line 663
  - Remove `enrich_client: instructor.Instructor,` from `run_consensus` signature
- **File:** `engines/excerpting/src/phase3_orchestrator.py` line ~143
  - Remove `enrich_client=enrich_client,` from `run_consensus(...)` call
- **Verify:** `grep 'enrich_client' engines/excerpting/src/phase3_consensus.py | grep -c 'def run_consensus'` → 0

### Step 2: FIX-1 — Add graceful degradation to consensus stage
- **File:** `engines/excerpting/src/phase3_orchestrator.py` lines 138-149
  - Wrap `run_consensus(...)` call in try/except matching enrichment pattern (lines 111-127)
  - On failure: keep enrichment-only excerpts with `"verification_skipped"` flag
  - Re-raise programming bugs (TypeError, AttributeError, NameError, KeyError, IndexError, ZeroDivisionError, StopIteration)
- **Exact code:** As specified in NEXT.md FIX-1 block (note: `enrich_client` already removed by FIX-9)

### Step 3: FIX-2 — Enable Instructor schema retry (max_retries=2)
- **5 files, 5 locations** — change `max_retries=0` → `max_retries=2`:
  1. `phase2_classify.py` line 343
  2. `phase2_group.py` line 172
  3. `phase3_enrichment.py` line 233
  4. `phase3_consensus.py` line 168
  5. `phase3_consensus.py` line 419

### Step 4: FIX-3 — Improve Phase 3 enrichment exception handling
- **File:** `engines/excerpting/src/phase3_enrichment.py` line 437
  - Add `from pydantic import ValidationError` to imports (line ~22, after existing pydantic usage or in the import block)
  - Replace bare `except Exception` with split: `except ValidationError` (log warning) + `except Exception` (log + exponential backoff via `time.sleep(2 ** attempt)`)
  - `import time` already present (line 13) — confirmed

### Step 5: FIX-4 — Flag excerpts with incomplete verification
- **File:** `engines/excerpting/src/phase3_consensus.py` around line 787
  - After `excerpt_to_vi` dict is built (line 785), create `units_needing_verification` set
  - In the `for exc in chunk_excerpts` loop (line 787), when `vis_for_exc` is empty:
    - If `exc.unit_index in units_needing_verification` → flag with `"verification_incomplete"`
    - Else → pass through normally (no flag)
  - Exact code as specified in NEXT.md FIX-4

### Step 6: FIX-5 — Deduplicate path in run_consensus via `loop_handled`
- **File:** `engines/excerpting/src/phase3_consensus.py` around line 720
  - Add `loop_handled = False` before retry loop
  - Set `loop_handled = True` in both the `vr is None` branch and the success branch
  - After loop: use `if not loop_handled:` to add `"verification_skipped"` flags (replaces current `if verification_result is None:` check which was structurally fragile)
  - Keep `if verification_result is None: continue` as a clean exit for the `vr is None` case
  - Exact code as specified in NEXT.md FIX-5

### Step 7: FIX-6 — Validate ResolvedScholar.role with Literal type
- **File:** `engines/excerpting/contracts.py`
  - Line 20: Add `Literal` to typing import: `from typing import Literal, Optional`
  - Line 593 (`ResolvedScholar.role`): Change `role: str` → `role: Literal["quoted_opinion", "classification_frame", "refuted_position"]`
  - Line 124 (`ScholarAttribution.role`): Same change
  - **Pre-check:** `grep -rn 'role=' engines/excerpting/tests/` — verify no test uses invalid role values

### Step 8: FIX-7 — Cross-check evidence_refs vs takhrij_data
- **File:** `engines/excerpting/src/phase3_enrichment.py` around line 290
  - In `apply_enrichment`, BEFORE the `model_copy` update dict is written (line ~296)
  - Add hadith evidence / takhrij cross-check: if `any(er.type == "hadith" for er in exc.evidence_refs)` and `not ue.takhrij_data`, append `"hadith_evidence_no_takhrij"` to `review_flags` and log warning
  - Exact code as specified in NEXT.md FIX-7

### Step 9: FIX-8 — Deduplicate _LEVEL_ORDER constant
- **File:** `engines/excerpting/src/phase3_consensus.py`
  - Add module-level constant after imports (around line 32):
    ```python
    _SC_LEVEL_ORDER: dict[SelfContainmentLevel, int] = {
        SelfContainmentLevel.FULL: 2,
        SelfContainmentLevel.PARTIAL: 1,
        SelfContainmentLevel.DEPENDENT: 0,
    }
    ```
  - Replace `_LEVEL_ORDER` in `_resolve_self_containment` (line 452) with `_SC_LEVEL_ORDER`
  - Replace `_LEVEL_ORDER` in `_parse_self_containment` (line 508) with `_SC_LEVEL_ORDER`

### Step 10: Run existing tests — confirm 554+ pass, 0 fail
- `python -m pytest engines/excerpting/tests/ -q --tb=short`

---

### Step 11: SCRIPT-1 — `scripts/run_integration_test.py`

Standalone CLI script (NOT a pytest test). Per LLM Integration Test Protocol Phase B.

**Key behaviors:**
- CLI args: `--package-path`, `--output-dir`, `--source-metadata` (JSON), `--mock`
- Load `NormalizedPackage` from path (manifest.json + content.jsonl)
- Create 3 Instructor clients via OpenRouter (`instructor.from_openai(openai.OpenAI(...), mode=instructor.Mode.JSON)`)
- Register logging hooks via `client.on("completion:kwargs/response/error", hook_fn)` — NOT wrapper classes
- Run phases directly: Phase 1 → Phase 2a → Phase 2b → Phase 3
- Save intermediates: `phase1_chunks.json`, `phase2a_classifications/`, `phase2b_groupings/`, `excerpts.jsonl`, `gate_queue.jsonl`, `processing_log.jsonl`
- Save timing per phase/chunk to `timing.json`, metadata to `run_metadata.json`
- Output dir: `integration_tests/run_{timestamp}/`
- `--mock` mode: skip API key validation, use MagicMock clients, still save all files
- Pre-run checklist: validate package, test API key (skip in mock), verify output dir, record git hash

**Reuse:**
- `_build_token_char_map` from `phase2_classify.py` (import, don't duplicate)
- `_make_mock_instructor_client`, `_make_classification_result` patterns from `conftest.py`
- Client creation pattern from `experiments/architecture_test/run_tests.py` lines 157-171
- Hook pattern from NEXT.md specification (exact code provided)

### Step 12: SCRIPT-2 — `scripts/review_helper.py`

Per LLM Integration Test Protocol Appendix (decontextualization spot-check).

**Key behaviors:**
- CLI arg: `--run-dir` (integration test run directory)
- Load `excerpts.jsonl` + `phase1_chunks.json`
- For each excerpt: find chunk, map word offsets to char offsets using `_build_token_char_map` (imported from `phase2_classify.py`)
- Print formatted blocks: excerpt_id, div path, unit_index, function, self_containment, school, attribution, topics, 200-char pre/post context, primary_text, flags, counts
- Filters: `--filter FLAG_NAME`, `--filter PARTIAL/DEPENDENT/FULL`, `--excerpt-id EXC_ID`, `--summary`

### Step 13: TEST-1 — `engines/excerpting/tests/test_pydantic_robustness.py`

10 test cases using `model_validate` (simulates Instructor parsing):
1. ClassificationResult with extra fields → accepted
2. ClassifiedSegment with invalid enum → raises
3. UnitEnrichment with string school_confidence → coerced
4. UnitEnrichment with absent takhrij_data → defaults to []
5. UnitEnrichment with empty excerpt_topic → accepted
6. ResolvedScholar with role="narrator" → raises ValidationError (FIX-6)
7. ResolvedScholar with confidence=1.5 → raises
8. VerificationResult with duplicate item_index → raises (model_validator)
9. EnrichmentResult with mismatched count → document behavior
10. ExtractionResult with notes=None vs absent → both accepted

### Step 14: TEST-2 — `engines/excerpting/tests/test_error_recovery.py`

3 test cases using conftest helpers:
1. **Single-chunk LLM failure:** 3 chunks, mock raises for chunk 2, verify chunks 1+3 succeed, chunk 2 absent
2. **Exponential backoff:** Mock raises then succeeds, verify elapsed time ≥2s
3. **Coverage retry:** Mock returns gap in segments, verify_segments raises ValueError, retry succeeds

**Reuse:** `_make_mock_instructor_client`, `_make_assembled_chunk`, `_make_classification_result` from `conftest.py`

### Step 15: Run full test suite
- `python -m pytest engines/excerpting/tests/ -q --tb=short` → 554 + ~15-20 new tests passing, 0 failed

### Step 16: Pyright checks on all modified files
- `python -m pyright` on each modified source file

### Step 17: Verification Checklist (11 items from NEXT.md)
1. Full test suite passing
2. FIX-1: grep try/except around run_consensus
3. FIX-2: grep max_retries shows 2 everywhere
4. FIX-3: grep time.sleep in phase3_enrichment.py
5. FIX-4: grep verification_incomplete
6. FIX-5: grep loop_handled
7. FIX-6: grep Literal in contracts.py
8. FIX-7: grep hadith_evidence_no_takhrij
9. FIX-9: grep enrich_client in run_consensus signature → 0
10. SCRIPT-1 mock run → output dir has all expected files
11. SCRIPT-2 --summary → prints excerpt counts

### Step 18: Commit and push
- Single commit with all changes
- Message: `handoff: harden LLM integration infrastructure — 9 fixes + 2 scripts + 2 test files`

---

## Files Modified (Part A — Fixes)

| File | Fixes |
|------|-------|
| `engines/excerpting/contracts.py` | FIX-6 (Literal import + role types) |
| `engines/excerpting/src/phase3_orchestrator.py` | FIX-9 (remove enrich_client from call), FIX-1 (try/except) |
| `engines/excerpting/src/phase3_consensus.py` | FIX-9 (remove param), FIX-2 (max_retries×2), FIX-4 (verification_incomplete), FIX-5 (loop_handled), FIX-8 (_SC_LEVEL_ORDER) |
| `engines/excerpting/src/phase3_enrichment.py` | FIX-2 (max_retries), FIX-3 (exception split + backoff), FIX-7 (hadith cross-check) |
| `engines/excerpting/src/phase2_classify.py` | FIX-2 (max_retries) |
| `engines/excerpting/src/phase2_group.py` | FIX-2 (max_retries) |

## Files Created (Part B — Infrastructure)

| File | Purpose |
|------|---------|
| `scripts/run_integration_test.py` | SCRIPT-1: Integration test runner |
| `scripts/review_helper.py` | SCRIPT-2: Excerpt review/spot-check tool |
| `engines/excerpting/tests/test_pydantic_robustness.py` | TEST-1: 10 Pydantic parsing tests |
| `engines/excerpting/tests/test_error_recovery.py` | TEST-2: 3 error recovery tests |

## DO NOT list

- Do NOT make real LLM calls
- Do NOT modify prompt text
- Do NOT change Phase 1 assembly code
- Do NOT add `"llm_enrichment_failed"` flag to existing ValidationError blocks
- Do NOT implement anything beyond NEXT.md
- Do NOT proceed to next session
