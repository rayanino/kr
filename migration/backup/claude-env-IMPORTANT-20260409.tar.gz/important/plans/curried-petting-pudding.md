---
title: "fix: Evaluator Hardening — Claude DR Part 2 Findings"
type: fix
status: active
date: 2026-04-06
origin: docs/coworker_reports/2026-04-06_evaluator_h2_hardening/claude_dr_report_part2.md
---

# Evaluator Hardening — Claude DR Part 2 (Final Report)

## Context

Claude DR part 2 is the FINAL coworker report. It could NOT access the private repo (PAT requires git auth, not HTTP) — analysis was reconstructed from descriptions. Much overlaps with already-implemented work from Claude DR part 1, Gemini DR, and ChatGPT DR.

**Most of part 2's findings are already addressed.** The genuinely new value is:
1. **N1 pattern** — Arabic book structure as resolution markers (kitab/bab/fasl-level)
2. **SBERT architecture** — concrete replacement for broken TF-IDF (deferred, ~50 lines)
3. **System Capability Index** — YAML manifest of existing capabilities (deferred, ~240 lines)

## Implementation (minimal — most already done)

- [x] **Save research report** (DONE above)

- [ ] **Add N1 pattern for Arabic book structure resolution markers**

  Add to GOLDEN_CONCEPT_PHRASES:
  ```python
  r"(?:kitab|bab|fasl|mabhath)[- ]?level"
  ```
  Zero false-positive risk. Catches derivatives applying multiresolution to Arabic divisions.

  Files: `scripts/overnight_codex_evaluator.py`, `tests/test_overnight_codex_evaluator.py`

- [ ] **Commit and push**

## Deferred Architecture Recommendations (All Coworkers Combined)

These emerged from all 4 DR reports and require careful design sessions:

| Recommendation | Source | Priority | Effort |
|----------------|--------|----------|--------|
| SBERT hybrid novelty (70/15/15) | Claude DR part 2 | CRITICAL | ~50 lines + `sentence-transformers` dependency |
| Substance-density dimension | Claude DR + Gemini CLI | CRITICAL | ~80 lines, vocabulary set design |
| System Capability Index | Claude DR part 2 | CRITICAL | ~240 lines YAML + Python |
| Bipartite Islamic/Western scoring | Gemini DR | HIGH | ~30 lines, threshold calibration |
| Concept-head matching (Surface A) | ChatGPT DR | HIGH | ~40 lines, regex + NLP |
| Behavior-claim verification | ChatGPT DR | MEDIUM-HIGH | ~60 lines, AST Field(description=...) |
| Product-layer scoring (FP-3) | Claude DR part 1 | HIGH | ~20 lines |

## ALL Coworker Reports — Complete Synthesis

| Source | Report | Findings | Implemented |
|--------|--------|---------|------------|
| Gemini CLI | Adversarial bypass | H7 jargon (2 bypasses), "without" evasion | "without" patched, 1 bypass documented |
| CC subagent A | SYMBOL_REGISTRY | 85/289 classes (stale) | Documented |
| CC subagent B | H2 test coverage | 0 direct regex tests | P4-P6 tests added (ChatGPT DR) |
| Codex CLI | Structural review | H2 code verified | Completed |
| Claude DR (1/2) | Coverage + blind spots | 8 golden gaps, H9, FP-1, FP-3 | **3/4 implemented** |
| Gemini DR | Islamic pedagogy | Vocabulary bias, Matn→Sharh→Hashiya | **Implemented** (38 keywords) |
| ChatGPT DR | Adversarial surfaces | Passive/possessive/relative evasion | **Implemented** (P4-P6) |
| Claude DR (2/2) | Structural failures | N1 pattern, SBERT, SCI | N1 to implement, rest deferred |
