# Plan: Post-Cleanup Path Fix

## Context

The cleanup (commit `e1cf114`) successfully archived 35 session docs and moved 12 scripts/data files. **No files were lost** — all are R100 renames, zero deletes, 574 tests pass.

However, a critical self-review found that **5 moved scripts compute `PROJECT_ROOT` via `Path(__file__).parent.parent`**, which now resolves to `scripts/` instead of the project root (they're one directory deeper). Plus **2 scripts have hardcoded paths** to data files at old locations.

These scripts are one-off phase runners (not imported by engine code), but they'd crash if someone tried to re-run a phase.

## Files to Fix

### PROJECT_ROOT resolution (`.parent.parent` → `.parent.parent.parent`)

1. `scripts/phases/generate_review_gui.py` — line ~12
2. `scripts/phases/phase_d_postprocess.py` — line ~13
3. `scripts/phases/run_phase_c.py` — line ~35
4. `scripts/phases/stress_test_collection.py` — line ~26
5. `scripts/phases/verify_step4_books.py` — line ~12

### Hardcoded data file paths

6. `scripts/phases/phase_d_selection.py` — line ~18: `Path("scripts/phase_d_books.txt")` → `Path("scripts/phases/data/phase_d_books.txt")`
7. `scripts/phases/verify_step4_books.py` — lines ~15-17: references to `scripts/phase_c_books.txt` etc. → `scripts/phases/data/`

### Documentation reference

8. `engines/source/VALIDATION_PLAN.md` — line ~114: `scripts/phase_c_books.txt` → `scripts/phases/data/phase_c_books.txt`

## Approach

- Read each file, find the exact path computation, fix it
- Single commit: "Fix PROJECT_ROOT paths in moved phase scripts"
- Run tests after to confirm no regressions

## Verification

1. `python -m pytest engines/*/tests/ shared/*/tests/ -q` — all 574 tests still pass
2. For each fixed script: `python -c "import scripts.phases.X"` or dry-run to confirm paths resolve
3. `git diff` to review all changes are path-only
