# Session 5a Plan: Shared Components + Trust + Validation

## Context

Session 5a builds the 6 foundational modules that the registration orchestrator (Session 5b) and pipeline integration (Session 6) depend on. These modules are deterministic — no LLM calls, no API keys needed. The Source Engine has 365 passing tests from Sessions 1–4. This session targets ~63 new tests (total ~428).

The modules provide: config loading, scholar record management, human review gating, trust scoring, and multi-layer validation. Together they implement SPEC Steps 7–8 and §5.

---

## Pre-Implementation: Contract Change

**First action — before any module code:**

Update `engines/source/contracts.py` `HumanGateCheckpoint`:
- Replace `resolved: bool = False` with `status: str = "pending"` (values: pending|approved|rejected|unsure|elevated|auto_approved)
- Add `elevated_result: Optional[dict[str, Any]] = None` (Layer 3.5 output)
- Keep `resolution` and `resolved_at` as-is

**No test impact** — no existing tests instantiate HumanGateCheckpoint.

---

## Build Order (6 modules, strict dependency sequence)

### Module 1: Config Loader
**File:** `engines/source/src/config.py` (~50 lines)
**Tests:** `engines/source/tests/test_config.py` (5 tests: 66–70)
**Deps:** None — build first

**What:** Replace stub. `load_config(library_root)` reads 4 JSON files from `library/config/`:
- `recognized_muhaqiqs.json` → `list[str]`
- `known_publishers.json` → `dict[str, dict]` (each has `score` + `variants`)
- `transliteration.json` → `dict[str, dict[str, str]]`
- `genre_synonyms.json` → `dict[str, str]`

Missing file → empty default (not error). Malformed JSON → raise with filename.

**Reuse:** `SourceEngineConfig` dataclass already defined in stub with correct field types.

---

### Module 2: Scholar Authority
**File:** `shared/scholar_authority/src/scholar_authority.py` (~250 lines)
**Tests:** `shared/scholar_authority/tests/test_scholar_authority.py` (20 tests: 1–20)
**Deps:** `name_matching.py` (already built, 22 tests), `contracts.py` (ScholarAuthorityRecord)

**What:** Replace tracer stub in `__init__.py`. New implementation in `scholar_authority.py`.

Functions:
- `compute_scholar_match_score(candidate_name, death_date, school, known_work, existing_record)` — Weighted: name 0.50, death_date 0.30, school 0.10, works 0.10. **CRITICAL: cap final score at 0.65 when only name signal has data** (prevents auto-linking on name alone).
- `lookup(name, death_date_hijri?, school?, known_work_title?, registry_path?)` → `ScholarMatchResult`. Thresholds: ≥0.85 auto_link, 0.50–0.85 human_gate, <0.50 new_record. Compare against canonical_name_ar + known_as + name_variants.
- `register(record: ScholarAuthorityRecord, registry_path?)` → `ScholarAuthorityRecord`. Sequential ID (`sch_00001`). Compute `record_completeness`. Set `data_provenance_score = 0.0`.
- `update(canonical_id, updates, source_id, registry_path?)` → `ScholarUpdateResult`. Run 5 consistency checks. **Return conflicts — do NOT import human_gate** (caller creates gate checkpoints). Preserve old values in `revision_history`.
- `get_all(registry_path?)` → dict of all records
- `_next_canonical_id()` — Scan registry for highest ID, increment.
- `_compute_record_completeness()` — 24 biographical fields fraction.

**Key design decision:** `update()` returns `ScholarUpdateResult(record, applied, conflicts)` instead of calling `human_gate.create_checkpoint()` directly. This keeps scholar_authority independent of human_gate, avoids circular deps, and makes testing self-contained. The registration orchestrator (Session 5b) will handle conflict → gate creation.

5 consistency checks:
1. Death date drift > 5 years → gate conflict
2. School affiliation change → gate conflict
3. Name change → blocked (add to known_as instead)
4. Self-reference (own teacher/student) → rejected
5. Temporal inconsistency (teacher death > student death + 30y) → gate conflict

**Storage:** `library/registries/scholars.json`. Atomic writes: NamedTemporaryFile(delete=False) → fsync → os.replace. FileLock with 30s timeout.

**Existing code to reuse:**
- `normalized_name_similarity()` from `name_matching.py` (line 50)
- `normalize_arabic_name()` from `name_matching.py` (line 14)
- `ScholarAuthorityRecord` from `contracts.py` (line 571)
- `ScholarMatchResult` already defined in `scholar_authority.py` stub (line 28)

**After implementation:** Update `__init__.py` to re-export new public API. Rewrite 4 old tests in `test_name_matching.py` (lines 133–170) that use old stub API (`clear`, old `lookup`, old `register`).

---

### Module 3: Human Gate
**File:** `shared/human_gate/src/human_gate.py` (~150 lines)
**Tests:** `shared/human_gate/tests/test_human_gate.py` (8 tests: 51–58)
**Deps:** `contracts.py` (HumanGateCheckpoint, HumanGateTrigger)

**What:** Replace stub.

Functions:
- `configure(gates_dir, auto_approve)` — Set module-level `_GATES_DIR`, `_AUTO_APPROVE`
- `create_checkpoint(source_id, trigger, trigger_detail, fields_to_review, current_values, alternatives?)` → `HumanGateCheckpoint`. ID format: `hg_{uuid4_hex[:8]}`. Persist to `pending/{source_id}.json`. Update `index.json`. **If auto_approve=True: create checkpoint, persist it, THEN immediately call resolve() with "approve"** (same code path).
- `resolve(checkpoint_id, decision, notes?)` → `HumanGateCheckpoint`. Move from pending/ to resolved/ on approve/reject. On "unsure": set status to "elevated" (Layer 3.5 placeholder).
- `get_pending(source_id?)` → `list[HumanGateCheckpoint]`
- `get_checkpoint(checkpoint_id)` → `Optional[HumanGateCheckpoint]`
- `get_pending_count()` → `int`

**Storage format:** `pending/{source_id}.json` = list of checkpoint dicts. `resolved/{source_id}.json` = same. `index.json` = `{checkpoint_id: source_id}`.

**Windows concern:** Use `NamedTemporaryFile(delete=False)` pattern from freezer.py. Close file handle before `os.replace()`.

---

### Module 4: Trust Evaluator
**File:** `engines/source/src/trust_evaluator.py` (~200 lines)
**Tests:** `engines/source/tests/test_trust_evaluator.py` (13 tests: 21–33)
**Deps:** `config.py` (muhaqiqs, publishers), `name_matching.py` (for muhaqiq matching)

**What:** Replace stub. Implement `evaluate_trust()` with 5 sub-functions.

**CRITICAL — First-Intake Formula (validated, overrides SPEC §4.A.8 text):**
- `_score_author_standing()`: death_date ≤ 1000 → 0.90; > 1000 → 0.70; None → 0.30. **NO prior-sources check on initial intake.**
- `_score_tahqiq_quality()`: Recognized muhaqiq (name_similarity ≥ 0.85 against config list) → 0.90. Unknown muhaqiq → 0.50. No muhaqiq + pre-modern (≤1300) → 0.40. No muhaqiq + unknown date → 0.35. No muhaqiq + modern (>1300) → 0.30.
- `_score_publisher_reputation()`: Check publisher name AND all variants via substring. Known → configured score. Unknown → 0.40.
- `_score_source_authority()`: primary → 0.85, reference → 0.60, modern_compilation → 0.40.
- `_score_text_fidelity()`: high → 0.90, medium → 0.60, low → 0.30, unknown → 0.40.

**Weights:** author_standing 0.30, tahqiq 0.25, publisher 0.15, source_authority 0.15, text_fidelity 0.15.

**Tier:** ≥ 0.65 → verified; < 0.65 → flagged. Also flagged if author_standing < 0.30 AND tahqiq < 0.40.

**Verification:** Test 25 runs ALL 13 fixtures against GROUND_TRUTH.json. All 13 must match.

**Reuse:** `normalized_name_similarity()` from `name_matching.py` for muhaqiq matching.

---

### Module 5: Shared Validation
**File:** `shared/validation/src/validation.py` (~100 lines)
**Tests:** Tested via `engines/source/tests/test_validation.py` (tests 34–36, 49–50)
**Deps:** Pydantic

**What:** Replace stub. 3 generic functions:
- `validate_schema(data, schema)` — `schema.model_validate(data)`, catch ValidationError, convert to `list[ValidationError]`. Severity: fatal.
- `validate_referential_integrity(data, registries, ref_fields)` — Resolve nested field paths, check existence. Severity: fatal. Error: SRC_REGISTRY_CONFLICT.
- `validate_enrichment_passthrough(before, after)` — Any key in `before` that was non-null and is now null/missing in `after` → SRC_INVALID_ENRICHMENT. Severity: fatal.

**Reuse:** `ValidationError` dataclass already defined in stub (line 17).

---

### Module 6: Source Validation
**File:** `engines/source/src/validation.py` (~250 lines)
**Tests:** `engines/source/tests/test_validation.py` (17 tests: 34–50)
**Deps:** All 5 modules above

**What:** Replace stub. `validate_source_metadata()` runs 6 checks in order:
1. Schema compliance → delegates to shared `validate_schema()`
2. Referential integrity → delegates to shared `validate_referential_integrity()`
3. Confidence thresholds → author, genre, science_scope < 0.50 → gate
4. Duplicate re-check → post-inference dedup (warning only)
5. Consistency cross-check (5a–5e):
   - 5a: nazm→verse, sharh→commentary|prose, hashiyah→commentary
   - 5b: hashiyah should not be beginner
   - 5c: author↔science scope mismatch → **HUMAN GATE** (only consistency check that gates)
   - 5d: attribution_status vs prior sources → warning
   - 5e: sharh/hashiyah must be multi-layer → **auto-correct** to true
6. Multi-layer coherence (6a–6c):
   - 6a: multi_layer=true + empty layers → gate
   - 6b: multi_layer=false + has layers → auto-correct
   - 6c: layer author refs must resolve

**Critical chain:** Check 5e auto-corrects `is_multi_layer` in-place → Check 6 then verifies layers.

---

## Concerns and Mitigations

| Concern | Risk | Mitigation |
|---------|------|------------|
| Name-only score cap at 0.65 | Without it, unique names auto-link unsafely | Implement cap in `compute_scholar_match_score()` when only name signal has data |
| `filelock` not in pyproject.toml | Works locally but breaks clean installs | Add `filelock>=3.0` to pyproject.toml dependencies |
| Windows NamedTemporaryFile | File handle open during os.replace → PermissionError | Follow freezer.py pattern: `delete=False`, close handle before `os.replace()` |
| SPEC §4.A.8 text has wrong formula | Prior-sources check causes 6/13 fixture failures | Use validated death-date-only formula for initial intake. Document deviation. |
| Old scholar_authority tests (4 tests) | Will fail with new API | Rewrite them — they're simple (4–6 lines each) |
| scholar_authority ↔ human_gate coupling | Circular dependency risk | update() returns conflicts, doesn't import human_gate |

---

## Files to Modify/Create

**Modify:**
- `engines/source/contracts.py` — HumanGateCheckpoint status field
- `engines/source/src/config.py` — Replace stub
- `engines/source/src/trust_evaluator.py` — Replace stub
- `engines/source/src/validation.py` — Replace stub
- `shared/scholar_authority/src/__init__.py` — Re-export new API
- `shared/scholar_authority/src/scholar_authority.py` — Replace stub
- `shared/scholar_authority/tests/test_name_matching.py` — Rewrite 4 old API tests
- `shared/human_gate/src/human_gate.py` — Replace stub
- `shared/validation/src/validation.py` — Replace stub
- `pyproject.toml` — Add filelock dependency

**Create:**
- `shared/scholar_authority/tests/test_scholar_authority.py` — 20 tests
- `shared/human_gate/tests/test_human_gate.py` — 8 tests
- `engines/source/tests/test_trust_evaluator.py` — 13 tests
- `engines/source/tests/test_validation.py` — 17 tests (may already exist as stub)
- `engines/source/tests/test_config.py` — 5 tests (may already exist as stub)

---

## Verification Plan

1. **After each module:** `python -m pytest <module>/tests/ -v --tb=short`
2. **After all modules:** `python -m pytest engines/source/tests/ shared/*/tests/ -q` — should show ~428 passing
3. **Trust ground truth:** Test 25 runs all 13 fixtures against `tests/fixtures/GROUND_TRUTH.json`
4. **Regression:** All 365 existing tests must still pass
5. **SPEC compliance:** `python3 scripts/check_compliance.py --all`
6. **Quality gate:** `python3 scripts/session_quality_gate.py`
