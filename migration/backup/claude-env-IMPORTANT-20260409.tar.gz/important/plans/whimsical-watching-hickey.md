# Plan: DR Knowledge Base Digestion System

## Context

The owner will relay hundreds of DR (Deep Research) responses over 3 months (April–July 2026). Each DR produces findings about the pipeline, scholarly domain, and architecture. Without structured digestion, summer will be blocked by having to manually re-read and reconcile hundreds of raw DR files. This system auto-processes every DR response into structured, linked, queryable knowledge that the dashboard displays.

**What exists (80%):** `process_dr_response.py` (working parser), `autonomous_schemas.py` (Pydantic models + JSONL I/O), `research_gap_scanner.py` (76 gaps from 4 sources), dashboard (4 pages reading from JSONL). Only 1 of 8 archived DRs has been processed.

**What's missing (the 20% that matters):** Finding→Gap linkage, contradiction detection, follow-up prompt generation, batch processing orchestrator, dashboard knowledge views.

---

## Components (7 total, 5 files to create, 4 to modify)

### A. Schema Enhancements
**File:** `scripts/autonomous_schemas.py` (modify)

Add to `Finding` model (all with defaults — existing 38 records stay parseable):
- `gap_ids: list[str]` — links to ResearchGap records this finding resolves
- `prompt_id: str | None` — which DR prompt produced this finding
- `related_finding_ids: list[str]` — contradiction/agreement clusters
- `confidence: float` — parser confidence (0.0–1.0)
- `raw_text_hash: str` — SHA-256 prefix for dedup across re-runs
- `section_heading: str` — which heading in the DR response

Add new models:
- `Contradiction` — tracks conflicting claims between DRs (finding pair + topic + resolution status)
- `DigestionRecord` — tracks processing state per DR file (finding count, version, status)

New JSONL files: `contradictions.jsonl`, `digestion_log.jsonl`

**Verify:** `read_jsonl(findings_path, Finding)` on existing 38 records parses without error.

---

### B. Improved Response Parser
**File:** `scripts/process_dr_response.py` (rewrite parsing layer, keep CLI)
**New file:** `scripts/dr_format_detectors.py`

Provider auto-detection from content markers:
- ChatGPT: `fileciteturn` citations, scored tables
- Claude: numbered section headings (`## 1.`), code blocks
- Gemini: footnote superscripts, embedded Arabic with diacritics

Parser changes:
- Paragraph-level extraction (not sentence fragments like current)
- Role classification: `recommendation` | `analysis` | `evidence` | `question` | `metadata`
- Only `recommendation` and `question` become Findings; `analysis`/`evidence` become context
- Auto-populate `spec_sections` (regex for `§\d+`, engine names) and `affected_files` (path patterns)

**Verify:** Reprocess DR37. Expect 15–25 quality findings instead of 38 fragments. Each has non-empty `spec_sections`.

---

### C. Cross-Referencing Engine
**New file:** `scripts/dr_cross_reference.py`

1. **Finding→Gap linker:** Keyword overlap scoring between finding descriptions and gap descriptions. Prompt lineage boost (same prompt_id = strong link). Threshold-based linking updates `finding.gap_ids`.

2. **Contradiction detector:** Topic clustering by category + keywords. Within clusters, detect negation patterns, opposing recommendations, conflicting facts. Creates `Contradiction` records — never auto-resolves, always flags for owner.

3. **SPEC section cross-reference:** Build section index from `engines/*/SPEC.md`, match findings against it.

**Verify:** Run on 38 existing findings. At least 20 should get gap links (many discuss taxonomy decisions). Zero false-positive contradictions from single-DR data.

---

### D. Follow-Up Prompt Generator
**New file:** `scripts/dr_followup_generator.py`

Scans findings for signals that need more research:
- Questions (`?` / `؟`), uncertainty markers, conditional claims, unverified references
- Each signal → new `ResearchGap` with `source=DR_FOLLOWUP`
- Each gap → new `DRPrompt` with target classification, dedup check, quality score

Lineage tracking: follow-up prompts use `RQ-FU-{dr_id}-{N}` IDs and reference the source finding.

**Verify:** Process DR38 (444-line Gemini, richest in scholarly questions). Should produce 5+ follow-up prompts.

---

### E. Quality Gate for DR Prompts
**New file:** `scripts/dr_quality_gate.py`

Prevents "DR for DR's sake":
- **Saturation check:** Topic with TSI > 0.8 → flag as potentially saturated
- **Unblocks validation:** `unblocks` field must reference a real gap/SPEC section/engine
- **Diminishing returns:** 3 consecutive DRs on same topic with <6 total findings → saturated
- **Category balance:** Flag prompts pushing a category >10% above DR33's allocation targets

Prompt quality score (0–100): clear question (20) + context (20) + structured request (20) + file/SPEC refs (20) + real gap unblock (20). Score <60 = flagged.

**Verify:** Batch 2's 10 prompts score >80. A synthetic bad prompt scores <60.

---

### F. Dashboard Integration
**Files:** `store.py`, `app.py`, new templates (modify)

New pages:
- **`/digestion`** — Processing status: how many DRs digested, table per DR with finding/contradiction/followup counts
- **`/contradictions`** — Side-by-side contradicting findings with resolution form
- **`/knowledge-map`** — Findings grouped by gap/SPEC section. Shows which gaps have findings, which are open

Existing page enhancements:
- `/findings` — gap linkage badges, filter by DR source
- `/status` — digestion progress bar, contradiction count

**Verify:** All existing pages render with no regressions. New pages degrade gracefully when empty.

---

### G. Batch Orchestrator
**New file:** `scripts/digest_dr_batch.py`

Master script tying everything together:
```
python scripts/digest_dr_batch.py --scan          # Process all undigested DRs
python scripts/digest_dr_batch.py --dr-file PATH  # Process one DR
python scripts/digest_dr_batch.py --reprocess-all  # Re-run with latest parser
```

Flow per DR: detect provider → parse sections → extract findings → cross-reference gaps → detect contradictions → generate follow-ups → quality gate → persist all → print summary.

Idempotent: `digestion_log.jsonl` tracks what's processed. `content_hash` in finding IDs ensures stability.

**Verify:** Run `--scan` on 8 existing DRs. Should produce ~150–250 findings, 10+ gap links, 5+ follow-ups.

---

## Dependency Graph

```
A (schemas) ──┬── B (parser) ──── C (cross-ref) ──── D (follow-up) ──── G (orchestrator)
              │
              ├── E (quality gate)  [parallel with B]
              │
              └── F (dashboard)     [parallel with B/C/D]
```

**Critical path:** A → B → C → D → G (5 sequential steps)
**Parallel work:** E and F can build alongside B/C/D

---

## Execution Order

| Step | Component | Est. effort | Depends on |
|------|-----------|-------------|------------|
| 1 | A: Schema enhancements | 30 min | — |
| 2 | B: Parser rewrite + format detectors | 2–3 hours | A |
| 3 | E: Quality gate (parallel with B) | 1 hour | A |
| 4 | C: Cross-referencing engine | 1–2 hours | B |
| 5 | D: Follow-up prompt generator | 1 hour | C |
| 6 | G: Batch orchestrator | 1 hour | B + C + D |
| 7 | F: Dashboard integration | 2 hours | A (can start early) |
| 8 | Migration: process 7 unprocessed DRs | 30 min | G |
| 9 | Batch 2 readiness: process 10 incoming DRs | 30 min | G |

---

## Verification (end-to-end)

1. `python scripts/digest_dr_batch.py --scan` processes all 8 archived DRs
2. `python scripts/dashboard.py` → localhost:8000 shows digested knowledge on all pages
3. `/knowledge-map` shows findings linked to gaps with coverage visualization
4. `/contradictions` shows any detected conflicts (may be 0 for small corpus)
5. Follow-up prompts appear in `/` (relay queue) ready for owner relay
6. Pyright clean on all new/modified files
7. Existing 38 findings in findings.jsonl parse without error (backward compatible)

---

## Risks

| Risk | Impact | Mitigation |
|------|--------|-----------|
| Arabic text corruption in parser | CRITICAL | Parser never modifies Arabic — reads headings (English/mixed), preserves body verbatim |
| Finding quality at scale (500+ DRs) | HIGH | `digestion_version` field enables reprocessing. Old data never deleted (Rule 13) |
| JSONL size (10K findings = ~5MB) | LOW | Dashboard already handles graceful degradation. Pagination deferred |
| Contradiction false positives | MEDIUM | Detector flags only — never auto-resolves. Owner makes scholarly judgment |
| "DR for DR's sake" drift | HIGH | Quality gate with saturation detection, unblocks validation, category balance |
